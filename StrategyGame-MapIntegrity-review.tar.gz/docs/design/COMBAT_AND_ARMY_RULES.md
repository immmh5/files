# COMBAT_AND_ARMY_RULES.md

**Status:** PROPOSED DESIGN

---

## 1. Army Representation

- Armies are integer counts per territory
- Minimum garrison: 1 army
- Territory with 0 armies = neutral (unowned)

## 2. Attack Eligibility

- Source territory must have ≥ 2 armies
- Target must be adjacent (per map adjacency graph)
- Source and target must be different territories
- Attacker must own the source territory
- One attack per territory per turn

## 3. Battle Resolution (Deterministic)

```
attacker_strength = attacker_armies - 1
defender_strength = defender_armies + terrain_bonus + faction_bonus

if attacker_strength > defender_strength:
    attacker_wins = true
    attacker_losses = floor(defender_strength / 2)
    defender_losses = defender_armies
    captured = true
else:
    attacker_wins = false
    attacker_losses = 0
    defender_losses = floor(attacker_strength / 2)
    captured = false
```

**Defender wins ties.** This is a deliberate design choice that makes terrain matter.

## 4. Movement Rules

- Move: transfer armies to adjacent owned territory
- Cannot move through enemy territory
- One move per territory per turn

## 5. Reinforcements

- Income computed during Turn Start phase
- Placed only on owned territories
- Income = floor(territories / 3) + region bonuses

## 6. Retreat and Protection

- No retreat mechanic in first playable version
- Attacking into a defended territory always results in battle
- Protection: defender-wins-ties rule protects border territories

## 7. Combat Feedback

- Visual: battle animation on contested territory
- Audio: combat sound effect
- UI: army count updates immediately after resolution