# Performance Strategy

## Performance as First-Class Requirement

Performance is not an afterthought. It is a design constraint from Milestone 0 forward.

## Performance Budgets

These targets are aspirational baselines to be measured on target hardware. Do not invent measurements — use actual profiling results.

| Metric | Target | Notes |
|---|---|---|
| Editor startup | < 3 seconds | Core + App assembly load |
| In-game frame rate | ≥ 60 FPS | On integrated GPU at 1080p |
| Turn resolution | < 50ms | For a 100-territory map |
| UI frame time | < 16ms | No UI thread blocking |
| Memory baseline | < 200 MB | App startup + one map loaded |

## Key Performance Strategies

### 1. Rendering — 2D over 3D

- Use `Node2D` and `SubViewport` rendering, not a full 3D scene.
- Static map layers rendered once to `ViewportTexture` and cached.
- Only dirty regions re-rendered when state changes.

### 2. Game Logic — Event-Driven, Not Frame-Driven

- Game state calculations happen **on demand** (turn events, order resolution), not every `_Process()` call.
- No `Process` callback unless animation or real-time input is active.
- `Timer` nodes for deferred execution; `Yield` for async state transitions.

### 3. Memory — Avoid Allocations in Hot Paths

- Pre-allocate commonly reused objects (order result structs, event copies).
- Use struct-based `GameEvent` records to avoid heap allocations for read-only events.
- `ObjectPool<T>` for frequently instantiated transient objects (packets, orders).

### 4. Garbage Collection

- `.NET 8` with `GC.TryStartNoGCRegion()` for frame-critical code paths.
- No `foreach` on unconstrained `IEnumerable<T>` in hot paths — use spans or concrete collections.
- Profile with `dotnet-gcdump` and `dotnet-trace` in CI.

### 5. Territory Rendering

- For maps with 500+ territories: consider `MultiMeshInstance2D` for army markers.
- For 1000+ territory maps: profile first; if CPU-bound, move territory polygon rendering to GPU.

### 6. Async I/O

- All file loading (maps, saves) is async with cancellation support.
- No `File.ReadAllText` or synchronous disk I/O on the main thread.

### 7. Networking

- Packets serialized with `MessagePack` (binary, not JSON).
- `MemoryMarshal` and `Span<T>` for zero-copy packet header parsing.
- `Channel<T>` (System.Threading.Channels) for high-throughput async receive queues.

## Profiling Tools

| Tool | Use |
|---|---|
| Godot built-in profiler | Rendering, scene performance |
| `dotnet-trace` | CPU sampling, async stacks |
| `dotnet-gcdump` | GC pressure analysis |
| `perf` / `flamegraph` | Linux system-level profiling |
| Visual Studio / Rider | .NET debugger + dotTrace |

## C++ (GDExtension) Policy

Only introduce C++ if:
1. Profiling identifies a specific measured bottleneck.
2. The bottleneck is confirmed as CPU-bound and unavoidable in C#.
3. The fix provides a measurable, reproducible improvement (>20% gains minimum).
4. A pure C# alternative was tried and documented as insufficient.

**Current expectation:** No C++ needed for the foreseeable scope.

## Profiling in CI

CI builds run a **baseline performance check**: a headless test that runs a simulated game loop (1000 turns, 50 territories). If the median turn resolution exceeds 100ms, CI fails with a warning. This is a smoke test, not a precise benchmark.
