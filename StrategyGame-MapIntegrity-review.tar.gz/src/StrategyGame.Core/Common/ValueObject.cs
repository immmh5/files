namespace StrategyGame.Core.Common;

/// <summary>
/// Immutable value object base class. Ensures equality by value, not reference.
/// </summary>
public abstract class ValueObject
{
    protected abstract IEnumerable<object> GetEqualityComponents();

    public override bool Equals(object? obj)
    {
        if (obj is null || obj.GetType() != GetType()) return false;
        var other = (ValueObject)obj;
        return GetEqualityComponents().SequenceEqual(other.GetEqualityComponents());
    }

    public override int GetHashCode()
    {
        unchecked
        {
            var hash = 17;
            foreach (var component in GetEqualityComponents())
                hash = hash * 31 + (component?.GetHashCode() ?? 0);
            return hash;
        }
    }

    public static bool operator ==(ValueObject? a, ValueObject? b) =>
        ReferenceEquals(a, b) || (a is not null && b is not null && a.Equals(b));

    public static bool operator !=(ValueObject? a, ValueObject? b) => !(a == b);
}
