# TESTING_STRATEGY.md

**Status:** PROPOSED ARCHITECTURE
**Purpose:** Define the testing approach for each system in the hybrid turn engine.

---

## 1. Testing Philosophy

| Principle | Application |
|---|---|
| **Deterministic = Testable** | Every authoritative function is a pure function → exhaustive unit testing |
| **Fast Feedback** | Core tests run in < 500ms; no Godot, no I/O, no wall-clock time |
| **Property-Based** | Combat, supply, income tested with property-based generators |
| **Contract Tests** | Interfaces (`IEventBus`, `INetworkTransport`) have contract test suites |
| **Integration = Smoke** | Integration tests verify wiring, not logic |

---

## 2. Test Pyramid

```
                    ┌─────────────────┐
                    │  E2E / Manual   │  (Gameplay feel, UI, MP sync)
                    ├─────────────────┤
                    │  Integration    │  (TurnEngine + Core systems wiring)
                    ├─────────────────┤
           ┌─────────────────────────────────┐
           │         Unit Tests              │  (Core domain, pure functions)
           │  - CombatSystem                 │
           │  - SupplyEngine                 │
           │  - EventScheduler               │
           │  - VictoryChecker               │
           │  - TurnEngine stage logic       │
           │  - Territory/Player/ValueObj    │
           └─────────────────────────────────┘
```

---

## 3. Unit Test Specifications

### 3.1 CombatSystem (Existing — Extend)
| Test Case | Description | Expected |
|---|---|---|
| `AttackerWins_WhenStrengthGreater` | 5 vs 3 armies on plains | Attacker wins, captures |
| `DefenderWins_Tie` | 4 vs 4 on plains (defender) | Defender holds |
| `DefenderWins_WithTerrain` | 4 vs 3 on mountains (+3) | Defender wins |
| `AttackerFails_OneArmy` | 1 army attacks | `InvalidOperationException` |
| `AttackerFails_NotAdjacent` | Non-adjacent territories | `InvalidOperationException` |
| `AttackerFails_SelfAttack` | Attack own territory | `InvalidOperationException` |
| `AttackerLosses_Calculated` | 5 vs 2 on plains | Attacker loses floor(2/2)=1 |

### 3.2 SupplyEngine (New)
| Test Case | Description |
|---|---|
| `Supplied_PathToCapital` | Territory connected to capital → supplied |
| `Supplied_PathToCoast` | Territory connected to coast → supplied |
| `Unsupplied_Isolated` | Island territory with no supply source → unsupplied |
| `Attrition_OnePerTerritory` | Unsupplied group loses 1 army/territory |
| `Attrition_MinGarrison` | 1-army territory → remains at 1 |
| `Neutral_AtZero` | 1 army + 1 attrition → becomes neutral |

### 3.3 EventScheduler (New)
| Test Case | Description |
|---|---|
| `Fire_OnScheduledTurn` | Event scheduled for turn 5 fires at turn 5 start |
| `Fire_InCorrectPhase` | TurnStart event fires before PlayerActions |
| `Cancel_RemovesEvent` | Cancelled event never fires |
| `Ordering_TurnThenPhaseThenInsertion` | Turn 3 TurnStart before Turn 3 TurnEnd |
| `Duration_DecrementsEachTurn` | 3-turn effect expires after 3 EventProcessing stages |
| `Effect_Expires_RemovesFromQueue` | Expired effect removed and OnExpire called |

### 3.4 TurnEngine (New)
| Test Case | Description |
|---|---|
| `TurnStart_CalculatesIncome` | Income = territories/3 + region bonuses |
| `TurnStart_AppliesAttrition` | Unsupplied groups lose armies |
| `PlayerAction_ValidMove` | Move transfers armies, marks territory acted |
| `PlayerAction_ValidAttack` | Attack resolves via CombatSystem |
| `PlayerAction_Invalid_SelfAttack` | Rejected with error |
| `PlayerAction_Invalid_NoArmies` | Rejected with error |
| `PlayerAction_MarksTerritoryActed` | Territory cannot act again same turn |
| `EventProcessing_FiresDueEvents` | Scheduled events fire at correct turn |
| `EventProcessing_DecrementsDurations` | Multi-turn effects tick down |
| `TurnEnd_ChecksVictory` | Victory detected, game over |
| `TurnEnd_AdvancesTurn` | Next player becomes active, stage = TurnStart |
| `StageTransitions_ValidOnly` | Invalid transitions throw |

### 3.5 VictoryChecker (Existing — Extend)
| Test Case | Description |
|---|---|
| `Elimination_SingleOwner` | One player owns all → victory |
| `Domination_60Percent` | ≥ 60% territories → victory |
| `NoVictory_SplitOwnership` | Multiple owners → no victory |

### 3.6 Domain Models (Existing — Extend)
| Test Case | Description |
|---|---|
| `Territory_SetOwner_UpdatesArmies` | Owner + armies set atomically |
| `Territory_RemoveArmies_MinGarrison` | Cannot remove below 1 if owned |
| `Player_PlaceArmies_DeductsFromPool` | ArmiesToPlace decreases |
| `Territory_Snapshot_Immutable` | Snapshot unaffected by later mutations |

---

## 3.7 Property-Based Tests (Using FsCheck / Xunit.Property)

| Target | Property |
|---|---|
| `CombatSystem.ResolveAttack` | `attackerStrength > defenderStrength ⇔ attackerWins` |
| `CombatSystem.ResolveAttack` | `attackerStrength <= defenderStrength ⇔ !attackerWins` |
| `CombatSystem.ResolveAttack` | `attackerWins → capturedTerritoryId == defenderId` |
| `SupplyEngine.ApplyAttrition` | `totalArmiesLost == unsuppliedTerritories.Count` (capped at 1 per) |
| `EventScheduler.Schedule` | `event.ScheduledTurn == currentTurn + turnOffset` |
| `TurnEngine.SubmitOrder` | `territory.Acted → second order rejected` |
| `GameState.Snapshot` | `snapshot.State == original.State` at time of call |

---

## 4. Integration Tests

| Test | Scope | Verifies |
|---|---|---|
| `TurnEngine_FullTurn_SinglePlayer` | TurnEngine + Combat + Supply + Events | A→B→C→D executes, state consistent |
| `TurnEngine_TwoPlayers_Alternating` | TurnEngine + TurnManager | Player A turn → Player B turn → Player A turn |
| `TurnEngine_PersistentEvent_SpansTurns` | EventScheduler + TurnEngine | 3-turn effect fires 3 times across players |
| `TurnEngine_SaveLoad_RoundTrip` | TurnEngine + Serialization | Save after TurnEnd → Load → resume identical |
| `Multiplayer_HostClient_Sync` | Host + Client (loopback) | Client state mirrors host after each snapshot |
| `AIPlayer_MakesLegalMoves` | AI + TurnEngine | All AI orders pass validation |

---

## 5. Edge Cases & Invariants

| Invariant | Test Method |
|---|---|
| `GameState` territories always consistent with map | After every mutation, `state.Territories.Keys == state.Map.Territories.Keys` |
| `Armies >= 1` for owned territories | After every mutation, `t.Owner != null ⇒ t.Armies >= 1` |
| `Owner == null ⇔ Armies == 0` | After every mutation |
| `Adjacency symmetric` | Map load validates `A.Adjacent.Contains(B) ⇔ B.Adjacent.Contains(A)` |
| `TurnStage` advances in order A→B→C→D→A | Property test: sequence never skips or reverses |
| `TurnNumber increments only at TurnEnd` | Property test: only D→A increments turn number |
| `Event queue sorted` | After every schedule/cancel, queue is ordered by (turn, phase, insertion) |
| `Effect durations never negative` | After EventProcessing, all `DurationTurns >= 0` |

---

## 6. Test Infrastructure

### Test Projects
| Project | Target | Dependencies |
|---|---|---|
| `StrategyGame.Core.Tests` | Core domain, GameState, simulation | xUnit, Moq, FsCheck |
| `StrategyGame.Integration.Tests` | TurnEngine wiring, multiplayer sync | Core, xUnit |

### Test Utilities
```csharp
// Test data builders
class TerritoryBuilder { ... }
class PlayerBuilder { ... }
class GameStateBuilder { ... }

// Deterministic RNG for tests
class TestRandom : IRandom { ... }

// In-memory event bus for tests
class TestEventBus : IEventBus { ... }
```

### CI Pipeline
```yaml
# .github/workflows/test.yml
- dotnet test --filter "Category=Unit"       --no-restore --verbosity normal
- dotnet test --filter "Category=Integration" --no-restore --verbosity normal
# Property tests run with higher iteration count
- dotnet test --filter "Category=Property" --no-restore
```

---

## 7. Test Commands

| Command | Purpose |
|---|---|
| `dotnet test tests/StrategyGame.Core.Tests --filter "Category=Unit"` | Fast unit tests |
| `dotnet test tests/StrategyGame.Core.Tests --filter "Category=Property"` | Property-based (slow) |
| `dotnet test tests/Integration.Tests` | Integration tests |
| `dotnet test --collect:"XPlat Code Coverage"` | Coverage report |

---

## 8. Acceptance Criteria for Each Implementation Task

| Task | Minimum Passing Tests |
|---|---|
| `TurnEngine` stage A | `TurnStart_CalculatesIncome`, `TurnStart_AppliesAttrition` |
| `TurnEngine` stage B | `PlayerAction_ValidMove`, `PlayerAction_Invalid_NoArmies` |
| `TurnEngine` stage C | `EventProcessing_FiresDueEvents`, `EventProcessing_DecrementsDurations` |
| `TurnEngine` stage D | `TurnEnd_ChecksVictory`, `TurnEnd_AdvancesTurn` |
| `SupplyEngine` | `Supplied_PathToCapital`, `Attrition_OnePerTerritory` |
| `EventScheduler` | `Fire_OnScheduledTurn`, `Duration_DecrementsEachTurn` |
| `CombatSystem` (extend) | All existing + `AttackerLosses_Calculated` |
| `VictoryChecker` (extend) | `Domination_60Percent` |