#!/usr/bin/env bash
# =============================================================================
# test-verify-fake.sh — Negative-path verification of ACTUAL verify.sh
#
# Creates fake dotnet/Godot executables in a temporary directory, prepends it
# to PATH so verify.sh calls them, and checks that verify.sh fails correctly.
# The script NEVER invokes the real build or modifies the project source tree.
# =============================================================================
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
FAKE_PATH=""
LOG_FILE=""
cleanup() { rm -rf "$FAKE_PATH"; }
trap cleanup EXIT

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[0;33m'; NC='\033[0m'
PASS()  { echo -e "${GREEN}[PASS]${NC} $*"; }
FAIL()  { echo -e "${RED}[FAIL]${NC} $*"; cleanup; exit 1; }
INFO()  { echo -e "${YELLOW}[INFO]${NC} $*"; }

FAKE_PATH=$(mktemp -d)
LOG_FILE="$FAKE_PATH/verify-log.txt"

# ===================================================================
# Helper: create a fake dotnet executable with argument-specific behavior
# ===================================================================
make_fake_dotnet() {
    local version="${1:-8.0.427}"
    local build_rc="${2:-0}"
    local test_rc="${3:-0}"
    cat > "$FAKE_PATH/dotnet" <<EOF
#!/usr/bin/env bash
if [[ "\$1" == "--version" ]]; then
    echo "$version"
    exit 0
fi
if [[ "\$1" == "build" ]]; then
    exit $build_rc
fi
if [[ "\$1" == "test" ]]; then
    exit $test_rc
fi
echo "unexpected command: \$*"
exit 0
EOF
    chmod +x "$FAKE_PATH/dotnet"
}

# ===================================================================
# Helper: create a fake Godot executable
#   version   — output when --version is in args
#   import_rc — exit code when --import is in args (0 = success)
#   quit_rc   — exit code when --quit is in args (0 = success)
#   block_cmd — if set, this command blocks forever instead of exiting
# ===================================================================
make_fake_godot() {
    local version="$1"
    local import_rc="${2:-0}"
    local quit_rc="${3:-0}"
    local block_cmd="${4:-}"
    cat > "$FAKE_PATH/godot" <<EOF
#!/usr/bin/env bash
case "\$*" in
    *"--version"*)
        echo "$version"
        exit 0
        ;;
    *"--import"*)
        if [[ "$block_cmd" == "import" ]]; then
            sleep 99999
        fi
        exit $import_rc
        ;;
    *"--quit"*)
        if [[ "$block_cmd" == "quit" ]]; then
            sleep 99999
        fi
        exit $quit_rc
        ;;
    *)
        exit 0
        ;;
esac
EOF
    chmod +x "$FAKE_PATH/godot"
}

# ===================================================================
# Test helper: run verify.sh with fakes on PATH.
# Returns the exit code via global VFY_EXIT.
# Uses LOG_FILE inside FAKE_PATH for captured output.
# ===================================================================
run_verify_with_fakes() {
    export GODOT_BIN="$FAKE_PATH/godot"
    # Ensure fake dotnet is FIRST in PATH, before any real ~/.local/dotnet
    export PATH="$FAKE_PATH:$HOME/.local/dotnet:${PATH#*$HOME/.local/dotnet:}"
    bash "$PROJECT_ROOT/scripts/verify.sh" >"$LOG_FILE" 2>&1
    VFY_EXIT=$?
}

# ===================================================================
# Test 1: Valid Godot version (4.7.2.stable) — verify.sh should PASS
# ===================================================================
INFO "Test 1: Valid Godot 4.7.2.stable — verify.sh passes"
make_fake_dotnet "8.0.427"
make_fake_godot "4.7.2.stable.mono.official.ed1daf0bf" 0 0
run_verify_with_fakes
if [[ $VFY_EXIT -eq 0 ]]; then
    PASS "Test 1: verify.sh exits 0 with valid Godot version."
else
    FAIL "Test 1: verify.sh should pass with valid Godot version (exit $VFY_EXIT)."
fi

# ===================================================================
# Test 2: Reject 4.7.20
# ===================================================================
INFO "Test 2: Godot 4.7.20 — verify.sh rejects"
make_fake_dotnet "8.0.427"
make_fake_godot "4.7.20.stable.mono.official" 0 0
run_verify_with_fakes
if [[ $VFY_EXIT -ne 0 ]] && grep -Fq "Expected Godot 4.7.2" "$LOG_FILE" && grep -Fq "4.7.20" "$LOG_FILE"; then
    PASS "Test 2: verify.sh rejects Godot 4.7.20 with exact diagnostic."
else
    FAIL "Test 2: verify.sh should reject Godot 4.7.20 with diagnostic (exit $VFY_EXIT)."
fi

# ===================================================================
# Test 3: Reject 4.7.1
# ===================================================================
INFO "Test 3: Godot 4.7.1 — verify.sh rejects"
make_fake_dotnet "8.0.427"
make_fake_godot "4.7.1.stable.mono" 0 0
run_verify_with_fakes
if [[ $VFY_EXIT -ne 0 ]] && grep -Fq "Expected Godot 4.7.2" "$LOG_FILE" && grep -Fq "4.7.1" "$LOG_FILE"; then
    PASS "Test 3: verify.sh rejects Godot 4.7.1 with exact diagnostic."
else
    FAIL "Test 3: verify.sh should reject Godot 4.7.1 with diagnostic (exit $VFY_EXIT)."
fi

# ===================================================================
# Test 4: Reject 4.8.0
# ===================================================================
INFO "Test 4: Godot 4.8.0 — verify.sh rejects"
make_fake_dotnet "8.0.427"
make_fake_godot "4.8.0.stable.mono" 0 0
run_verify_with_fakes
if [[ $VFY_EXIT -ne 0 ]] && grep -Fq "Expected Godot 4.7.2" "$LOG_FILE" && grep -Fq "4.8.0" "$LOG_FILE"; then
    PASS "Test 4: verify.sh rejects Godot 4.8.0 with exact diagnostic."
else
    FAIL "Test 4: verify.sh should reject Godot 4.8.0 with diagnostic (exit $VFY_EXIT)."
fi

# ===================================================================
# Test 5: Reject 4.7.2.1 (extra digit after patch)
# ===================================================================
INFO "Test 5: Godot 4.7.2.1 — verify.sh rejects"
make_fake_dotnet "8.0.427"
make_fake_godot "4.7.2.1.stable.mono" 0 0
run_verify_with_fakes
if [[ $VFY_EXIT -ne 0 ]] && grep -Fq "Expected Godot 4.7.2" "$LOG_FILE" && grep -Fq "4.7.2.1" "$LOG_FILE"; then
    PASS "Test 5: verify.sh rejects Godot 4.7.2.1 with exact diagnostic."
else
    FAIL "Test 5: verify.sh should reject Godot 4.7.2.1 with diagnostic (exit $VFY_EXIT)."
fi

# ===================================================================
# Test 6: Nonzero dotnet BUILD exit — verify.sh fails at Core build stage
# ===================================================================
INFO "Test 6: Fake dotnet build exits nonzero — verify.sh rejects Core build"
make_fake_dotnet "8.0.427" 1 0
make_fake_godot "4.7.2.stable.mono" 0 0
run_verify_with_fakes
if [[ $VFY_EXIT -ne 0 ]] && grep -Fq "Core build failed" "$LOG_FILE"; then
    PASS "Test 6: verify.sh fails with exact 'Core build failed' diagnostic."
else
    FAIL "Test 6: verify.sh should fail with 'Core build failed' diagnostic (exit $VFY_EXIT)."
fi

# ===================================================================
# Test 7: Nonzero Godot import exit — verify.sh fails
# ===================================================================
INFO "Test 7: Godot import exits nonzero — verify.sh rejects"
make_fake_dotnet "8.0.427"
make_fake_godot "4.7.2.stable.mono" 1 0
run_verify_with_fakes
if [[ $VFY_EXIT -ne 0 ]] && grep -Fq "Godot project import failed" "$LOG_FILE"; then
    PASS "Test 7: verify.sh fails with exact 'Godot project import failed' diagnostic."
else
    FAIL "Test 7: verify.sh should fail with 'Godot project import failed' diagnostic (exit $VFY_EXIT)."
fi

# ===================================================================
# Test 8: Nonzero Godot startup exit — verify.sh fails
# ===================================================================
INFO "Test 8: Godot startup exits nonzero — verify.sh rejects"
make_fake_dotnet "8.0.427"
make_fake_godot "4.7.2.stable.mono" 0 1
run_verify_with_fakes
if [[ $VFY_EXIT -ne 0 ]] && grep -Fq "Godot application startup failed" "$LOG_FILE"; then
    PASS "Test 8: verify.sh fails with exact 'Godot application startup failed' diagnostic."
else
    FAIL "Test 8: verify.sh should fail with 'Godot application startup failed' diagnostic (exit $VFY_EXIT)."
fi

# ===================================================================
# Test 9: Godot import timeout — verify.sh reports import timeout
# ===================================================================
INFO "Test 9: Godot import times out — verify.sh rejects"
make_fake_dotnet "8.0.427"
make_fake_godot "4.7.2.stable.mono" 0 0 "import"
run_verify_with_fakes
if [[ $VFY_EXIT -ne 0 ]] && grep -Fq "Godot project import timed out" "$LOG_FILE"; then
    PASS "Test 9: verify.sh fails with exact 'Godot project import timed out' diagnostic."
else
    FAIL "Test 9: verify.sh should fail with 'Godot project import timed out' diagnostic (exit $VFY_EXIT)."
fi

# ===================================================================
# Test 10: Godot startup timeout — verify.sh reports startup timeout
# ===================================================================
INFO "Test 10: Godot startup times out — verify.sh rejects"
make_fake_dotnet "8.0.427"
make_fake_godot "4.7.2.stable.mono" 0 0 "quit"
run_verify_with_fakes
if [[ $VFY_EXIT -ne 0 ]] && grep -Fq "Godot application startup timed out" "$LOG_FILE"; then
    PASS "Test 10: verify.sh fails with exact 'Godot application startup timed out' diagnostic."
else
    FAIL "Test 10: verify.sh should fail with 'Godot application startup timed out' diagnostic (exit $VFY_EXIT)."
fi

# ===================================================================
# Summary
# ===================================================================
echo ""
PASS "All 10 fake-command negative-path tests passed."
exit 0
