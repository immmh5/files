namespace StrategyGame.Core.Tests.Events;

using StrategyGame.Core.Events;
using Xunit;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;

/// <summary>
/// R4.7 — Tests for the match-scoped EventIdSource.
/// </summary>
public class EventIdSourceTests
{
    [Fact]
    public void Next_ReturnsStrictlyIncreasingValues()
    {
        var source = new EventIdSource();
        var a = source.Next();
        var b = source.Next();
        var c = source.Next();

        Assert.Equal(1L, a);
        Assert.Equal(2L, b);
        Assert.Equal(3L, c);
        Assert.True(a < b);
        Assert.True(b < c);
    }

    [Fact]
    public void TwoInstances_AreIndependent()
    {
        var sourceA = new EventIdSource();
        var sourceB = new EventIdSource();

        // IDs may legitimately overlap across different matches.
        Assert.Equal(1L, sourceA.Next());
        Assert.Equal(1L, sourceB.Next());
        Assert.Equal(2L, sourceA.Next());
        Assert.Equal(2L, sourceB.Next());
    }

    [Fact]
    public void SharedInstanceAcrossConsumers_ProducesSingleSequence()
    {
        var shared = new EventIdSource();

        var id1 = shared.Next();
        var id2 = shared.Next();
        var id3 = shared.Next();

        Assert.Equal(1L, id1);
        Assert.Equal(2L, id2);
        Assert.Equal(3L, id3);
    }

    [Fact]
    public void Overflow_Throws_WithoutWrapping()
    {
        // Start at MaxValue - 1: first call returns MaxValue-1, second returns MaxValue, third throws
        var source = new EventIdSource(long.MaxValue - 1);
        var id1 = source.Next();
        var id2 = source.Next();

        Assert.Equal(long.MaxValue - 1, id1);
        Assert.Equal(long.MaxValue, id2);

        Assert.Throws<OverflowException>(() => source.Next());
    }

    [Fact]
    public void LongMaxValue_CanBeAllocatedExactlyOnce()
    {
        var source = new EventIdSource(long.MaxValue);
        var id = source.Next();

        Assert.Equal(long.MaxValue, id);

        // Second call must throw
        Assert.Throws<OverflowException>(() => source.Next());
    }

    [Fact]
    public void Constructor_RejectsStartValueBelowOne()
    {
        Assert.Throws<ArgumentOutOfRangeException>(() => new EventIdSource(0));
        Assert.Throws<ArgumentOutOfRangeException>(() => new EventIdSource(-1));
    }

    [Fact]
    public void Peek_ReturnsNextValueWithoutConsuming()
    {
        var source = new EventIdSource();
        Assert.Equal(1L, source.Peek);
        source.Next();
        Assert.Equal(2L, source.Peek);
    }

    [Fact]
    public void Concurrent_Next_Calls_ProduceUniqueIds()
    {
        var source = new EventIdSource();
        const int threadCount = 8;
        const int callsPerThread = 1000;
        var results = new ConcurrentBag<long>();

        Parallel.For(0, threadCount, _ =>
        {
            for (int i = 0; i < callsPerThread; i++)
            {
                results.Add(source.Next());
            }
        });

        var allIds = results.ToArray();
        Assert.Equal(threadCount * callsPerThread, allIds.Length);

        // All IDs must be unique
        Assert.Equal(allIds.Length, allIds.Distinct().Count());

        // All IDs must be in the expected range [1, threadCount * callsPerThread]
        Assert.All(allIds, id => Assert.InRange(id, 1L, threadCount * callsPerThread));
    }

    [Fact]
    public async Task Peek_IsThreadSafe_UnderConcurrentNext()
    {
        var source = new EventIdSource();
        var nextTask = Task.Run(() =>
        {
            for (int i = 0; i < 10000; i++)
            {
                source.Next();
            }
        });

        var peekTask = Task.Run(() =>
        {
            for (int i = 0; i < 10000; i++)
            {
                var peeked = source.Peek;
                // Peek should always be >= 1 and should not crash
                Assert.True(peeked >= 1);
            }
        });

        await Task.WhenAll(nextTask, peekTask);
    }

    [Fact]
    public void HighConcurrency_StressTest_NoDuplicatesOrLoss()
    {
        var source = new EventIdSource();
        const int threadCount = 16;
        const int callsPerThread = 5000;
        var results = new ConcurrentBag<long>();

        Parallel.For(0, threadCount, _ =>
        {
            for (int i = 0; i < callsPerThread; i++)
            {
                results.Add(source.Next());
            }
        });

        var allIds = results.ToArray();
        Assert.Equal(threadCount * callsPerThread, allIds.Length);
        Assert.Equal(allIds.Length, allIds.Distinct().Count());
    }

    // ---------------------------------------------------------------------
    // Phase 0 (R4.7-fix) — Upper-boundary correctness tests.
    // ---------------------------------------------------------------------

    [Fact]
    public void Next_NormalAllocation_NeverZeroOrNegative()
    {
        var source = new EventIdSource();
        for (int i = 0; i < 100; i++)
        {
            var id = source.Next();
            Assert.InRange(id, 1L, long.MaxValue - 1);
        }
    }

    [Fact]
    public void Next_StartAtMaxValueMinusOne_AllocatesBothBoundaryValuesThenThrows()
    {
        var source = new EventIdSource(long.MaxValue - 1);

        Assert.Equal(long.MaxValue - 1, source.Next());
        Assert.False(source.IsExhausted);
        Assert.Equal(long.MaxValue, source.Peek);

        Assert.Equal(long.MaxValue, source.Next());
        Assert.True(source.IsExhausted);
        Assert.Equal(long.MaxValue, source.Peek);
    }

    [Fact]
    public void Next_AfterExhaustion_RepeatedCallsAlwaysThrow()
    {
        var source = new EventIdSource(long.MaxValue);
        Assert.Equal(long.MaxValue, source.Next());

        for (int i = 0; i < 5; i++)
        {
            Assert.Throws<OverflowException>(() => source.Next());
        }
    }

    [Fact]
    public void Peek_AfterExhaustion_IsLongMaxValue_AndNeverNegative()
    {
        var source = new EventIdSource(long.MaxValue);
        source.Next();

        Assert.Equal(long.MaxValue, source.Peek);
        Assert.InRange(source.Peek, 1L, long.MaxValue);
    }

    [Fact]
    public void ConcurrentCalls_NearUpperBoundary_NoNegativeOrZeroIds_ExhaustAllocatesMaxValueOnce()
    {
        // Start 10 below the upper boundary: values MaxValue-9 .. MaxValue (10 total)
        // are allocatable. 8 threads make 4 calls each (32 total): exactly 10 must
        // succeed with unique positive IDs and the remaining 22 must throw.
        const long startValue = long.MaxValue - 9;
        const int threadCount = 8;
        const int callsPerThread = 4;

        var source = new EventIdSource(startValue);
        var barrier = new Barrier(threadCount);
        var allocated = new ConcurrentBag<long>();
        var overflowCount = 0;

        Parallel.For(0, threadCount, _ =>
        {
            barrier.SignalAndWait();
            for (int i = 0; i < callsPerThread; i++)
            {
                try
                {
                    allocated.Add(source.Next());
                }
                catch (OverflowException)
                {
                    Interlocked.Increment(ref overflowCount);
                }
            }
        });

        // Exactly the 10 expected allocations, no duplicates.
        Assert.Equal(10, allocated.Count);
        var ids = allocated.Distinct().ToList();
        Assert.Equal(10, ids.Count);

        // Every expected boundary value was allocated exactly once; none missing.
        // (Loop stops strictly below MaxValue; ++ at MaxValue would wrap — the very
        // defect class being tested here.)
        for (long expected = startValue; expected < long.MaxValue; expected++)
        {
            Assert.Contains(expected, ids);
        }
        Assert.Contains(long.MaxValue, ids);

        // Never a negative or zero identifier; full range covered monotonically.
        Assert.All(allocated, id => Assert.InRange(id, 1L, long.MaxValue));
        Assert.Equal(startValue, ids.Min());
        Assert.Equal(long.MaxValue, ids.Max());

        // All remaining calls failed loudly with OverflowException.
        Assert.Equal(threadCount * callsPerThread - 10, Volatile.Read(ref overflowCount));

        // Exhaustion state consistent: no further allocation possible.
        Assert.True(source.IsExhausted);
        Assert.Equal(long.MaxValue, source.Peek);
        Assert.Throws<OverflowException>(() => source.Next());
    }

    [Fact]
    public void ConcurrentCalls_AfterExhaustion_EveryCallThrowsOverflowException()
    {
        // Saturation scenario: drain a small remaining range under concurrency,
        // then hammer from many threads — every post-exhaustion call must throw
        // OverflowException; no silent successes or wrapped IDs may escape.
        const long startValue = long.MaxValue - 3;
        var source = new EventIdSource(startValue);

        Parallel.For(0, 2, _ =>
        {
            for (int i = 0; i < 10; i++)
            {
                try { source.Next(); }
                catch (OverflowException) { }
            }
        });

        Assert.True(source.IsExhausted);

        long successfulIdsObserved = 0;
        Parallel.For(0, 8, _ =>
        {
            for (int i = 0; i < 20; i++)
            {
                try
                {
                    var id = source.Next();
                    Interlocked.Increment(ref successfulIdsObserved);
                    Assert.InRange(id, 1L, long.MaxValue); // never negative/zero even on defect
                }
                catch (OverflowException) { /* expected */ }
            }
        });

        // Every call after exhaustion must have thrown.
        Assert.Equal(0, Interlocked.Read(ref successfulIdsObserved));
    }
}
