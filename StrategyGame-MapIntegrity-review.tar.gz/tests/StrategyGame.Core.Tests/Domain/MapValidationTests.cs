namespace StrategyGame.Core.Tests.Domain;

using StrategyGame.Core.Domain;
using Xunit;

/// <summary>
/// M1.1 — Map validation: unique ids, adjacency/region references,
/// value validity and diagnostic clarity. MapDefinition construction delegates
/// to MapValidator, so an invalid map cannot exist.
/// </summary>
public class MapValidationTests
{
    private static List<Territory> RingOfThree() =>
    [
        new("A", "Alpha", ["B"]),
        new("B", "Bravo", ["A", "C"]),
        new("C", "Charlie", ["B"]),
    ];

    private static List<RegionDefinition> OneRegion(int bonus = 2) =>
        [new RegionDefinition("northlands", "Northlands", bonus)];

    [Fact]
    public void ValidMap_ProducesNoDiagnostics()
    {
        var diagnostics = MapValidator.Validate("m1", "Map One", RingOfThree(), OneRegion());
        Assert.Empty(diagnostics);
    }

    [Fact]
    public void ValidMap_ConstructsSuccessfully()
    {
        var map = new MapDefinition("m1", "Map One", RingOfThree(), OneRegion());

        Assert.Equal(3, map.TerritoryCount);
        Assert.Single(map.Regions);
        Assert.Equal(1, map.Version);
    }

    [Fact]
    public void ValidMap_WithoutRegions_ConstructsSuccessfully()
    {
        var map = new MapDefinition("m1", "Map One", RingOfThree());
        Assert.Empty(map.Regions);
        Assert.Null(map.GetTerritory("A")!.RegionId);
    }

    [Fact]
    public void DuplicateTerritoryIds_ReportedWithClearDiagnostic()
    {
        var territories = new List<Territory>
        {
            new("A", "Alpha", []),
            new("A", "Alpha Two", []),
        };

        var ex = Assert.Throws<MapValidationException>(
            () => new MapDefinition("m1", "Dup Ids", territories));
        Assert.Contains(ex.Diagnostics, d => d.Contains("Duplicate territory id: 'A'."));
    }

    [Fact]
    public void UnknownAdjacencyReference_ReportedWithBothIds()
    {
        var territories = new List<Territory> { new("A", "Alpha", ["ZZZ"]) };

        var ex = Assert.Throws<MapValidationException>(
            () => new MapDefinition("m1", "Bad Adj", territories));
        Assert.Contains(ex.Diagnostics, d =>
            d.Contains("Territory 'A'") && d.Contains("unknown adjacent territory 'ZZZ'"));
    }

    [Fact]
    public void SelfAdjacency_Reported()
    {
        var territories = new List<Territory> { new("A", "Alpha", ["A"]) };

        var diagnostics = MapValidator.Validate("m1", "Self", territories, []);
        Assert.Contains(diagnostics, d => d.Contains("'A' is adjacent to itself."));
    }

    [Fact]
    public void UndefinedRegionReference_Reported()
    {
        var territories = new List<Territory>
        {
            new("A", "Alpha", [], TerrainType.Plains, "no_such_region", false),
        };

        var diagnostics = MapValidator.Validate("m1", "Bad Region", territories, []);
        Assert.Contains(diagnostics, d => d.Contains("references undefined region 'no_such_region'") && d.Contains("'A'"));
    }

    [Fact]
    public void DuplicateRegionIds_Reported()
    {
        var regions = new List<RegionDefinition>
        {
            new("r1", "Region One", 2),
            new("r1", "Region Duplicate", 1),
        };
        var territories = new List<Territory> { new("A", "Alpha", [], TerrainType.Plains, "r1", false) };

        var diagnostics = MapValidator.Validate("m1", "Dup Regions", territories, regions);
        Assert.Contains(diagnostics, d => d.Contains("Duplicate region id: 'r1'."));
    }

    [Fact]
    public void RegionWithZeroMemberTerritories_IsLegal()
    {
        var map = new MapDefinition("m1", "Unused Region", RingOfThree(), OneRegion());
        Assert.Equal(0, map.GetRegionControlBonus("p1")); // no members → no bonus
    }

    [Fact]
    public void EmptyMapNameAndId_Reported()
    {
        var diagnostics = MapValidator.Validate(null, "   ", RingOfThree(), []);
        Assert.Contains(diagnostics, d => d.Contains("Map id"));
        Assert.Contains(diagnostics, d => d.Contains("Map name"));
    }

    [Fact]
    public void AllDiagnosticsReportedAtOnce_NotJustFirst()
    {
        var territories = new List<Territory>
        {
            new("A", "Alpha", ["ZZZ", "A"]),           // unknown ref + self-adjacency
            new("A", "Alpha Two", []),                 // duplicate id
            new("B", "Bravo", [], TerrainType.Plains, "ghost_region", false), // undefined region
        };
        var regions = new List<RegionDefinition>
        {
            new("r1", "Region One", 2),
            new("r1", "Region Dup", 2),                // duplicate region id
        };

        var diagnostics = MapValidator.Validate("m1", "Many", territories, regions);

        Assert.Contains(diagnostics, d => d.Contains("Duplicate territory id: 'A'."));
        Assert.Contains(diagnostics, d => d.Contains("self."));
        Assert.Contains(diagnostics, d => d.Contains("unknown adjacent territory 'ZZZ'."));
        Assert.Contains(diagnostics, d => d.Contains("ghost_region"));
        Assert.Contains(diagnostics, d => d.Contains("Duplicate region id: 'r1'."));
    }

    [Fact]
    public void RegionDefinition_NegativeBonus_IsRejectedByCtor()
    {
        // The negative-bonus guard lives in RegionDefinition's constructor; the
        // JSON loader surfaces it as a diagnostic (see MapLoaderTests).
        Assert.Throws<ArgumentOutOfRangeException>(
            () => new RegionDefinition("r1", "Region One", -3));
    }

    [Fact]
    public void GeneratedMap_BuildTimeValidation_ProhibitsInvalidRegions()
    {
        var territories = new List<Territory>
        {
            new("A", "Alpha", [], TerrainType.Plains, "northlands", false),
        };
        var regions = new List<RegionDefinition>
        {
            new("somewhere_else", "Not Northlands", 2),
        };

        var ex = Assert.Throws<MapValidationException>(() => new MapDefinition("m1", "Mismatch", territories, regions));
        Assert.Contains(ex.Diagnostics, d => d.Contains("undefined region 'northlands'"));
    }

    [Fact]
    public void GeometryForUnknownTerritory_Reported()
    {
        var geometry = new Dictionary<string, TerritoryGeometry>
        {
            ["ghost"] = new([new TerritoryPoint(0, 0), new TerritoryPoint(1, 0), new TerritoryPoint(1, 1)],
                new TerritoryPoint(0.5, 0.5)),
        };

        var diagnostics = MapValidator.Validate("m1", "Ghost Geo", RingOfThree(), [], geometry);
        Assert.Contains(diagnostics, d => d.Contains("unknown territory 'ghost'"));
    }

    [Fact]
    public void PolygonWithTooFewPoints_Reported()
    {
        var geometry = new Dictionary<string, TerritoryGeometry>
        {
            ["A"] = new([new TerritoryPoint(0, 0), new TerritoryPoint(1, 0)], new TerritoryPoint(0.5, 0)),
        };

        var diagnostics = MapValidator.Validate("m1", "Thin Poly", RingOfThree(), [], geometry);
        Assert.Contains(diagnostics, d => d.Contains("invalid polygon data"));
    }

    [Fact]
    public void NonFiniteGeometryPoints_Reported()
    {
        var geometry = new Dictionary<string, TerritoryGeometry>
        {
            ["A"] = new(
                [new TerritoryPoint(double.NaN, 0), new TerritoryPoint(1, 0), new TerritoryPoint(1, 1)],
                new TerritoryPoint(0.5, 0.5)),
        };

        var diagnostics = MapValidator.Validate("m1", "Nan Poly", RingOfThree(), [], geometry);
        Assert.Contains(diagnostics, d => d.Contains("non-finite point"));
    }

    [Fact]
    public void RegionControlBonus_SumsAllFullyControlledRegions()
    {
        var territories = new List<Territory>
        {
            new("A", "Alpha", [], TerrainType.Plains, "northlands", false),
            new("B", "Bravo", [], TerrainType.Plains, "northlands", false),
            new("C", "Charlie", [], TerrainType.Forest, "southlands", false),
        };
        var regions = new List<RegionDefinition>
        {
            new("northlands", "Northlands", 2),
            new("southlands", "Southlands", 3),
        };
        var map = new MapDefinition("m1", "Bonus Map", territories, regions);

        // Rotate each territory's owner to control northlands.
        map.GetTerritory("A")!.SetOwner("p1", 1);
        map.GetTerritory("B")!.SetOwner("p1", 1);

        // Southlands still neutral → only northlands bonus.
        Assert.Equal(2, map.GetRegionControlBonus("p1"));

        map.GetTerritory("C")!.SetOwner("p1", 1);
        Assert.Equal(5, map.GetRegionControlBonus("p1"));
    }
}
