# PERFORMANCE_AND_RESOURCE_BUDGETS.md

**Status:** PROPOSED DESIGN

---

## 1. Design Targets (Not Measurements)

These are design targets, not measured performance figures. Actual measurements come from profiling.

### 1.1 Rendering

| Target | Value |
|---|---|
| Frame rate | 60 FPS @ 1080p integrated GPU |
| Territory count | 100 territories (design target) |
| Turn resolution time | < 50 ms @ 200 territories |
| UI frame time | < 16 ms |

### 1.2 Memory

| Target | Value |
|---|---|
| Baseline RAM | < 300 MB |
| Map with 100 territories | < 100 MB additional |

## 2. Resource Loading

- On-demand loading: maps, textures, audio
- Background loading where safe
- Resource unloading when no longer needed
- No duplicate resources

## 3. Caching

- Static map layers cached to viewport texture
- Territory polygon data precomputed
- Army marker positions precomputed

## 4. Event-Driven Updates

- No per-frame rule evaluation
- State updates only on turn boundaries and scheduled events
- Rendering is presentation only

## 5. Performance Testing Strategy

- Baseline: headless test with simulated game loop
- Profile with dotnet-trace, dotnet-gcdump, Godot profiler
- CI: smoke test on every build
- Full profiling: milestone-level

## 6. Asset Packs

- Optional asset packs loaded on demand
- No assets loaded at startup beyond essentials
- Asset packs independently configurable