# Build and Export

## Build Overview

The project uses two build systems in coordination:
1. **.NET (`dotnet build`)** — Compiles C# source files for both `StrategyGame.Core` and `StrategyGame.App`.
2. **Godot (`godot --build-solutions`)** — Integrates the .NET build output with the Godot project.

## Build Commands

### Linux (Development)

```bash
# Build Core library
dotnet build src/StrategyGame.Core/StrategyGame.Core.csproj -c Release

# Build App (requires Godot .NET integration)
godot --headless --build-solutions src/StrategyGame.App/project.godot

# Full release build
dotnet publish src/StrategyGame.App/StrategyGame.App.csproj -c Release -o build/publish
```

### Windows (Development)

```powershell
# Same dotnet commands
dotnet build src\StrategyGame.Core\StrategyGame.Core.csproj -c Release
godot --headless --build-solutions src\StrategyGame.App\project.godot
dotnet publish src\StrategyGame.App\StrategyGame.App.csproj -c Release -o build\publish
```

## Project File Structure

### StrategyGame.Core.csproj

```xml
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
    <LangVersion>12</LangVersion>
    <TreatWarningsAsErrors>true</TreatWarningsAsErrors>
    <RootNamespace>StrategyGame.Core</RootNamespace>
  </PropertyGroup>
</Project>
```

Note: `StrategyGame.Core` has **no Godot assembly references**.

### StrategyGame.App.csproj

```xml
<Project Sdk="Godot.NET.Sdk/4.7.2">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
    <LangVersion>12</LangVersion>
    <RootNamespace>StrategyGame.App</RootNamespace>
  </PropertyGroup>
  <ItemGroup>
    <ProjectReference Include="..\StrategyGame.Core\StrategyGame.Core.csproj" />
  </ItemGroup>
</Project>
```

## Export Templates

Export templates must be downloaded separately (Godot → Editor → Manage Export Templates):

```
~/.local/share/godot/export_templates/4.7.2.stable/  (Linux)
%APPDATA%\Godot/export_templates/4.7.2.stable/       (Windows)
```

### Export Targets

| Platform | Format | Notes |
|---|---|---|
| Linux x86_64 | Native executable | Main target for Linux CI |
| Windows x86_64 | `.exe` with bundled runtime | Main target for Windows release |
| macOS | `.app` bundle | Future target |

## CI Build Strategy

### Linux CI (`ci.yml`)

```yaml
- name: Build Core
  run: dotnet build StrategyGame.Core -c Release
- name: Build App
  run: godot --headless --build-solutions
- name: Run tests
  run: ./scripts/verify.sh
```

### Windows CI (`ci-windows.yml`)

```yaml
# Note: Godot mono is Windows-only for the editor binary,
# but the .NET build and unit tests run on Linux CI.
# Windows CI runs a .NET build-only check (no Godot on Linux runner).
- name: Build Core (Windows)
  run: dotnet build src\StrategyGame.Core -c Release
- name: Build App .NET (Windows)
  run: dotnet build src\StrategyGame.App -c Release
```

## Godot .NET Integration

When `godot --build-solutions` runs, it:
1. Invokes MSBuild to compile the App project.
2. Copies assemblies into `StrategyGame.App/.godot/`.

Do not commit the `.godot/` directory to git.

## Path Handling

- Use `ProjectSettings.GlobalizePath()` for Godot-specific paths.
- Use `System.IO.Path` for cross-platform C# paths.
- Never hardcode `C:\` or `/home/` paths.
- `user://` prefix is the Godot user data directory (cross-platform).
