# Modularity and Resource Management

## Modularity Philosophy

The game must support substantial future expansion without accumulating technical debt. The approach is **practical modularity**: start with a clean, separated architecture and evolve it as feature complexity demands — not prematurely optimize with elaborate plugin frameworks.

## Core Module Boundaries

Each module is responsible for exactly one concern:

| Module | Responsibility |
|---|---|
| `StrategyGame.Core.Domain` | Game entities, rules, game state |
| `StrategyGame.Core.Events` | Event bus for in-process pub/sub |
| `StrategyGame.Core.Networking` | Network transport interfaces |
| `StrategyGame.Core.AI` | AI player interfaces |
| `StrategyGame.Core.Storage` | Persistence interfaces |
| `StrategyGame.App.Scenes` | Godot scene composition |
| `StrategyGame.App.Rendering` | 2.5D map rendering |
| `StrategyGame.App.Input` | Input handling and gestures |
| `StrategyGame.App.UI` | User interface and menus |

## Resource Loading Strategy

### On-Demand Loading

Do not load all assets at startup. The core app starts lightweight:

1. **Essential assets only at startup:** Default font, basic placeholder textures, main menu scene.
2. **Map assets loaded on game start:** Territory geometry, terrain textures, faction emblems.
3. **UI assets loaded on scene enter:** Menu backgrounds, button sets, icons.

### Resource Management Principles

- **Single ownership:** Each loaded resource has one owner responsible for disposal.
- **No duplicate resources:** A central `ResourceCache` tracks all loaded assets by path+variant.
- **Reference counting:** Resources freed when no scene or system holds a reference.
- **Background loading:** Heavy assets (maps, textures) loaded on a background thread where Godot permits.

### Godot-Specific Considerations

- Use `ResourceLoader.LoadAsync()` for non-critical assets.
- Keep `GDScript` and `C#` resource references minimal — prefer string paths and deferred loading.
- Scenes are loaded via `PackedScene` and instantiated on demand.

## Async/Await Pattern

All resource-loading operations use C# async/await with cancellation support:

```csharp
public interface IAssetLoader
{
    Task<T> LoadAsync<T>(string path, CancellationToken ct = default) where T : Resource;
    Task PreloadAsync(IEnumerable<string> paths, IProgress<float>? progress = null, CancellationToken ct = default);
    void Unload(string path);
}
```

## Future Module System (Not Implemented in Milestone 0)

As the project grows, optional gameplay systems can be added as independent assemblies:

- `StrategyGame.Mods.Battlegrounds` (optional game mode)
- `StrategyGame.Mods.Campaign` (story-driven single-player)

These are loaded via a `IModuleLoader` interface that resolves dependencies and registers event handlers. This is documented now as a design direction but **not implemented yet**.

## No Premature Plugin Framework

Do not build a generic plugin system in Milestone 0. The modular assembly structure (Core + App) is sufficient for the initial project lifecycle. Introduce a plugin loader only when actual mod support is required.
