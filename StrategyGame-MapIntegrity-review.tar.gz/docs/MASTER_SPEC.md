# Master Specification — Strategy Game Project

## Project Identity

**Project Name:** StrategyGame
**Type:** Desktop-native 2.5D territorial strategy game
**Primary Platform:** Desktop (Windows x64, Linux x64)
**Language:** C# with Godot Engine 4.7.2 stable (.NET edition)

---

## Technology Decisions (Locked)

| Decision | Value | Rationale |
|---|---|---|
| Engine | Godot 4.7.2 stable (mono) | .NET/C# support, 2D/3D rendering, cross-platform export |
| Language | C# (.NET 8) | Primary scripting; game-core in pure C# without Godot deps |
| Native code | Prohibited initially | C++ via GDExtension only if profiling proves necessity |
| Platforms | Windows x64, Linux x64 | Primary targets for desktop release |
| Renderer | Godot 4.x Forward+ / Compatibility | 2.5D map rendering via Node2D/SubViewport with depth effects |

---

## Game Vision

A polished, desktop-native territorial strategy game inspired by classic Risk-style gameplay.

Core pillars:
- Turn-based strategic layer with discrete game-state transitions.
- Continuous visual presentation with smooth animations and camera work.
- Polygon-based interactive 2.5D strategy map.
- Multiple players, factions, and AI opponents.
- Local and LAN multiplayer without mandatory internet.
- Modular architecture for long-term feature growth.

Non-goals (initially):
- 3D world simulation or complex physics.
- Cloud services or mandatory online connectivity.
- Browser-based or mobile deployment.

---

## Development Priorities

1. **Correctness and stability** — Every feature must be verified before proceeding.
2. **Performance and responsiveness** — Rendering, input, and game-logic cycles kept separate.
3. **Maintainable architecture** — Core game logic decoupled from Godot nodes and rendering.
4. **Visual quality** — Polished presentation from the foundation upward.
5. **Extensibility** — Modular systems that support future gameplay additions.
6. **Cross-platform compatibility** — Windows and Linux builds from a single codebase.

---

## Architecture Guiding Principles

- **Core-first:** Pure C# domain library (`StrategyGame.Core`) contains game rules, state, events. It has zero Godot assembly references.
- **Godot as consumer:** The application project (`StrategyGame.App`) is the Godot host. It imports `StrategyGame.Core` and provides rendering, input, and UI.
- **Testable core:** `StrategyGame.Core` is fully unit-testable without launching the Godot editor.
- **Event-driven:** Game state changes flow through typed events, not direct node references.
- **Networking is architectural:** The networking layer is designed upfront as a service interface, even if only stubbed initially.

---

## Version and Environment

- **Godot Engine:** 4.7.2.stable.mono.official.ed1daf0bf
- **.NET SDK:** 8.0.427
- **Target Framework:** net8.0
- **C# Language:** 12 (latest supported by SDK 8.0)
- **Operating Systems Verified:** Linux x86_64 (current), Windows x64 (build target)
- **Last Updated:** 2026-11-04

---

## Current Status

**Milestone 0** — Engineering foundation largely complete; remaining M0 items: headless CI pipelines and final M0 report.
**Milestone 1.1 (Map & Rules Foundation)** — COMPLETE 2026-11-10 (terrain/region/supply metadata, map validation, JSON loader, deterministic test map; see `docs/MILESTONES.md`, `docs/architecture/M1_ROADMAP.md`).

See `docs/MILESTONES.md` for the full roadmap.
See `docs/ARCHITECTURE.md` for detailed system design.
