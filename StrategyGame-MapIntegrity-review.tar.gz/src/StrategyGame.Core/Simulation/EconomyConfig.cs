namespace StrategyGame.Core.Simulation;

/// <summary>
/// M1.2 — Immutable, validated economy configuration.
///
/// PROVISIONAL RULES (do NOT treat as owner-approved):
/// - Income formula <c>floor(ownedTerritories / divisor) + controlled region bonuses</c>
///   where the divisor is the PROVISIONAL D-08 default of 3 ("Income =
///   floor(territories / 3) + region bonuses" [PROPOSED]). Mechanic values live
///   here, never scattered through engine code, so a future owner decision only
///   changes configuration — not engine logic.
/// - Region bonus amounts themselves come exclusively from each map's
///   <c>RegionDefinition.ArmyBonus</c> data (D-05 [PROPOSED]).
///
/// This config does not impose a minimum reinforcement amount: adding one (as the
/// legacy <c>GameRules.ComputeReinforcements</c> does) is a deliberate extra rule
/// that D-08 does not document, so it is NOT applied here. If the owner later
/// wants a minimum, it must be added explicitly with approval.
///
/// Overflow: engine arithmetic is performed in a <c>checked</c> context; see
/// <see cref="EconomyEngine"/>.
/// </summary>
public sealed class EconomyConfig
{
    /// <summary>
    /// Number of owned territories per base-income group (the divisor of the
    /// floor() term). Must be >= 1. PROVISIONAL default 3 per D-08 [PROPOSED].
    /// </summary>
    public int TerritoriesPerIncomeGroup { get; }

    public EconomyConfig(int territoriesPerIncomeGroup)
    {
        if (territoriesPerIncomeGroup < 1)
        {
            throw new ArgumentOutOfRangeException(nameof(territoriesPerIncomeGroup),
                territoriesPerIncomeGroup, "Territories per income group must be >= 1.");
        }
        TerritoriesPerIncomeGroup = territoriesPerIncomeGroup;
    }

    /// <summary>Provisional default configuration (divisor 3, per D-08 [PROPOSED]).</summary>
    public static EconomyConfig Default { get; } = new(3);
}
