namespace StrategyGame.Core.Domain;

/// <summary>
/// Represents a playable faction with unique identity and bonuses.
/// </summary>
public sealed class Faction
{
    public string Id { get; }
    public string Name { get; }
    public string ColorHex { get; }
    public int ArmyBonusPerTerritory { get; }
    public int InitialTerritories { get; }

    public Faction(string id, string name, string colorHex, int armyBonusPerTerritory = 0, int initialTerritories = 0)
    {
        Id = id ?? throw new ArgumentNullException(nameof(id));
        Name = name ?? throw new ArgumentNullException(nameof(name));
        ColorHex = colorHex ?? throw new ArgumentNullException(nameof(colorHex));
        ArmyBonusPerTerritory = armyBonusPerTerritory;
        InitialTerritories = initialTerritories;
    }
}
