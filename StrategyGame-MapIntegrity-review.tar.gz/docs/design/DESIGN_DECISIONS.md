# DESIGN_DECISIONS.md

**Status:** LIVING DOCUMENT — master registry of design decisions
**This is the single source of truth for every design decision in the project.**
All other `docs/design/*.md` documents must be consistent with this file. When a conflict is found, this file wins.

**Decision statuses:**
- `[CONFIRMED]` — explicit user requirement (from the project brief). Implementation must comply.
- `[PROPOSED]` — designer recommendation with rationale. **Not yet user-approved.** Implementation should treat as default but expect possible change.
- `[OPEN]` — genuinely undecided; recorded in `OPEN_QUESTIONS.md`. Do not implement without approval.

---

## D-01. Engine & Language

| Decision | Status | Notes |
|---|---|---|
| Godot 4.7.2 stable .NET (mono) edition | `[CONFIRMED]` | Locked in MASTER_SPEC.md / ADR-0001 |
| C# as primary language, .NET 8 | `[CONFIRMED]` | ADR-0003 |
| No C++ unless profiling proves need | `[CONFIRMED]` | MASTER_SPEC.md §2 |
| Windows x64 + Linux x64 targets | `[CONFIRMED]` | MASTER_SPEC.md §2 |
| Pure C# core library, Godot only as host | `[CONFIRMED]` | ADR-0002 |

## D-02. Game Identity & Differentiation

| Decision | Status | Alternatives considered | Rationale |
|---|---|---|---|
| **Deterministic combat — no dice, no RNG in battle resolution** | `[PROPOSED]` | (a) Classic dice (Risk), (b) card-driven variance, (c) fully deterministic | (a) is luck-dominated; (b) adds inventory management overhead; (c) makes outcomes skill-legible, enables replays and unit tests. Matches pillar P1. |
| **Hybrid turn system — sequential player turns + persistent events** | `[USER-APPROVED PROVISIONAL]` | (a) Simultaneous planning, (b) real-time, (c) hybrid sequential + persistent events | (c) preserves classic turn familiarity while supporting continuous gameplay. **Supersedes the earlier simultaneous-planning proposal** in pillar P2. |
| Working title **"Iron Dominion"** | `[PROPOSED]` | other names | Original identity; user may rename. Cosmetic. |
| Full-information board (no fog of war) | `[PROPOSED]` | (a) fog of war, (b) full info | Full info keeps focus on intent-prediction; fog of war adds hidden-information infrastructure better deferred. |
| Session length target 20–45 min | `[PROPOSED]` | shorter/longer | Positions the game as an evening board-game experience. |

## D-03. Turn & Phase Structure

| Decision | Status | Notes |
|---|---|---|
| **HYBRID TURN SYSTEM** — classic sequential player turns + continuous persistent events | `[USER-APPROVED PROVISIONAL]` | Sequential turns preserved; events persist across turns. See TURN_AND_EVENT_SYSTEM.md for the A–D structure. |
| One action per territory per turn | `[PROPOSED]` | Primary action economy; simpler than command points. |
| Territory acts if it has ≥ 2 armies | `[PROPOSED]` | 1 army always stays as garrison; matches existing `Territory.CanAttackFrom`. |
| Reinforcements calculated at Turn Start | `[PROPOSED]` | Income + scheduled start-of-turn effects; see hybrid structure. |
| Persistent events processed between player actions and Turn End | `[PROPOSED]` | Event conditions/schedules checked in Persistent Event Processing phase. |
| Turn timers optional; default OFF in SP, 60s/action-phase default in MP | `[PROPOSED]` | Timers are presentation/flow controls, NOT simulation clocks. |

## D-04. Combat Rules

| Decision | Status | Notes |
|---|---|---|
| Attacker commits all-but-one army | `[PROPOSED]` | Classic convention; keeps garrisons meaningful. |
| Defender strength = armies + terrain defense value | `[PROPOSED]` | Integer math; no multipliers. |
| **Defender wins ties** | `[PROPOSED]` | Reinforces terrain investment; makes mountains real obstacles. |
| Winner's losses = floor(loser strength / 2) | `[PROPOSED]` | Deterministic, symmetric, easy to test. Details in COMBAT_AND_ARMY_RULES.md. |
| Attacker captures territory only if attacker strength strictly > defender effective strength | `[PROPOSED]` | Consistent with defender-wins-ties. |
| Battle result is a pure function: `f(attackerArmies, defenderArmies, terrainBonus, factionMods) → outcome` | `[PROPOSED]` | Enables exhaustive unit testing. |

## D-05. Map & Territory

| Decision | Status | Notes |
|---|---|---|
| First map: ~48 territories, 6 regions (continents) | `[PROPOSED]` | Small enough to learn, large enough for depth. |
| Terrain types: Plains, Forest, Hills, Mountains, Marsh, Coast | `[PROPOSED]` | 6 types; each with defense and (future) income modifier. |
| Map data = JSON: polygons, adjacency graph, terrain, region, centroid | `[PROPOSED]` | Human-editable, tool-friendly. Details in MAP_AND_TERRITORY_DESIGN.md. |
| Logical territory model independent of visual representation | `[CONFIRMED]` | Explicit user requirement (project brief). |
| Continent/region control bonuses 2–5 armies | `[PROPOSED]` | Standard Risk-like range, tuned per region size. |

## D-06. Supply & Attrition

| Decision | Status | Notes |
|---|---|---|
| Supply = path through owned territories to any owned territory adjacent to a **capital or port** | `[PROPOSED]` | Capitals/ports are supply sources. Simple flood-fill from sources. |
| Unsupplied group loses 1 army per territory per round (attrition), min 1 garrison remains | `[PROPOSED]` | Punishing but not instantly fatal; retreat remains possible. |
| Territory at 0 armies becomes neutral (unowned) | `[PROPOSED]` | Creates recapture dynamics. **⚠ Unresolved conflict with min-garrison rule above** (ISSUE-M2-1). M1.2 implements provisional primitives: min-garrison (1) is the default; zero-army neutralization only behind an explicit config flag (`AttritionConfig.AllowZeroGarrisonNeutralization`, default false), reported as `WouldBeNeutralized`, never applied by the calculation itself. Statuses remain PROPOSED; M1.2 implementation does NOT approve these rules. |

## D-07. Victory Conditions

| Decision | Status | Notes |
|---|---|---|
| **Elimination** — last player with owned territories wins | `[PROPOSED]` | Core condition. |
| **Domination** — control ≥ 60% of territories at round start | `[PROPOSED]` | Prevents endless games; threshold configurable per match. |
| Score-based/timed victory | `[OPEN]` → future | Deferred; see OPEN_QUESTIONS.md Q-3. |

## D-08. Economy (First Playable)

| Decision | Status | Notes |
|---|---|---|
| Income = floor(territories / 3) + region bonuses | `[PROPOSED]` | Classic, understandable, testable. |
| Armies placed only on owned territories during Reinforcement | `[PROPOSED]` | No deep deployment. |
| **No** resources, buildings, tech, trade in first playable | `[PROPOSED]` | Scope control; see ECONOMY_AND_RESOURCES.md for the future systems. |

## D-09. Factions

| Decision | Status | Notes |
|---|---|---|
| 6 factions at release, each with **one mild passive** bonus | `[PROPOSED]` | Asymmetry without imbalance; details in PLAYER_AND_FACTION_DESIGN.md. |
| Faction bonus is a modifier input to combat/income functions | `[PROPOSED]` | Keeps combat function deterministic and testable. |
| Alliances & diplomacy | `[OPEN]` → Cat 2/3 | Deferred. |

## D-10. AI

| Decision | Status | Notes |
|---|---|---|
| Utility-based scoring AI; deterministic | `[PROPOSED]` | No ML, no external APIs (confirmed constraint). |
| 3 difficulties: Easy (weighted random), Normal (greedy utility), Hard (greedy + 1-ply opponent-response check) | `[PROPOSED]` | Details in AI_OPPONENT_DESIGN.md. |
| AI decision budget: < 10 ms per phase, no allocations in hot loop | `[PROPOSED]` | Performance target, not a measurement. |

## D-11. Multiplayer

| Decision | Status | Notes |
|---|---|---|
| Host-authoritative game state; host validates all orders | `[CONFIRMED]` | Project brief; ADR-0004. |
| Transport abstracted behind `INetworkTransport` | `[CONFIRMED]` | ADR-0004. |
| LAN-first, no cloud dependency for local play | `[CONFIRMED]` | Project brief. |
| Phased transports: loopback → ENet LAN → discovery/reconnect → WebRTC (future) | `[PROPOSED]` | Details in MULTIPLAYER_DESIGN.md. |
| Full-mesh topology is a *transport* choice, never an *authority* model | `[PROPOSED]` | Explicit distinction demanded by the brief. |

## D-12. Rendering & Presentation

| Decision | Status | Notes |
|---|---|---|
| 2.5D layered-2D rendering (Node2D + sub-viewport layers) | `[CONFIRMED]` | Project brief; ADR-0005. |
| No full 3D world | `[CONFIRMED]` | Project brief. |
| UI modals must block map input (no click-through) | `[CONFIRMED]` | Project brief. |
| Rendering loop is never the simulation clock | `[CONFIRMED]` | Project brief; simulation ticks on turn boundaries and explicit scheduled events. |

## D-13. Save & Replay

| Decision | Status | Notes |
|---|---|---|
| Event-sourced saves: map hash + ordered command log + schema version | `[PROPOSED]` | Deterministic engine ⇒ replay = re-execution. Details in SAVE_AND_REPLAY_DESIGN.md. |
| Forward migration via command-log transforms | `[PROPOSED]` | Versioned schema; old saves replayed into new version. |

## D-14. Performance

| Decision | Status | Notes |
|---|---|---|
| Design targets (not measurements): 60 FPS @1080p integrated GPU with 100 territories; < 50 ms turn resolution @ 200 territories; < 300 MB RAM baseline | `[PROPOSED]` | Targets only; profiling is the only source of truth for actuals (per project brief). |
| Event-driven updates; no per-frame rule evaluation | `[CONFIRMED]` | Project brief §5. |

## D-15. Feature Categorization

The authoritative three-tier split (First Playable / Planned / Experimental) lives in **`FIRST_PLAYABLE_VERSION.md`** and is referenced, not duplicated, elsewhere.

---

## D-16. Event System Architecture (USER-APPROVED)

The following seven event-system decisions were explicitly approved by the project owner on 2026-11-04. They remain separate from D-07 (victory rules) and do not approve any unapproved victory thresholds, denominators, or priorities.

| Decision | Status | Notes |
|---|---|---|
| **D-16-1 — Strategic Clock**: `TurnSequence` (monotonic int, +1 per Stage D), `RoundIndex` (explicit int, never derived from player count), `PresentationTime` (local-only float, never authoritative). Rounds advance when the final active player completes their turn. | `[USER-APPROVED]` | Supersedes provisional per-turn clock; rounds are now explicit state, not arithmetic. |
| **D-16-2 — Effect Durations**: Global effects (attrition, continent bonuses) use `RoundIndex`; personal effects (cooldowns, buffs) use per-player `PlayerTurnCounter[playerId]`. Deterministic ordering at round boundaries via total order (due tick → priority → sequence → id). | `[USER-APPROVED]` | Two distinct cadences; no conflation of global vs. personal timing. |
| **D-16-3 — Scheduled Event Execution**: Scheduled gameplay events fire only at phase boundaries A, C, D — never mid-Stage B. Immediate command consequences remain immediate after validation. | `[USER-APPROVED]` | Preserves action-validation stability; saves remain atomic. |
| **D-16-4 — Disconnect & Recovery**: Non-current client disconnect ⇒ gameplay continues, seat idle; Current player disconnect ⇒ bounded grace period then authoritative auto-EndTurn with empty orders (host monotonic session clock); Graceful host shutdown ⇒ checkpoint + pause; Unexpected host crash ⇒ restore latest persisted checkpoint + event watermark; **No in-memory autosave from a crashed host**; No auto host migration approved. | `[USER-APPROVED]` | Explicitly distinguishes graceful vs. crash; never claims crashed host can autosave. |
| **D-16-5 — Victory Evaluation Timing**: Victory evaluated at Stage D only. **Does NOT approve 60% domination threshold, domination denominator, or domination vs. elimination priority.** | `[USER-APPROVED]` | Timing approval decoupled from unapproved victory rules. |
| **D-16-6 — Unknown Events During Restore**: Known older schemas use registered migrations; Unknown authoritative gameplay event types reject restoration with diagnostic; Unknown presentation-only events discarded safely. | `[USER-APPROVED]` | Authoritative state never silently omits unknown gameplay effects. |
| **D-16-7 — Serialization Format**: Strongly typed DTO records with explicit schema versions; System.Text.Json for saves and LAN initially; No new serialization dependencies; Binary formats deferred until measured evidence + separate approval. | `[USER-APPROVED]` | Zero new packages; binary deferred to measured need. |

---

## Registry of Confirmed User Requirements (traceability)

1. Godot 4.7.2 .NET, C#, Win+Linux — MASTER_SPEC.
2. 2.5D map, no 3D world, no Electron/React/Python in gameplay.
3. Turn-based gameplay + continuous visual events.
4. Local multiplayer without internet; LAN; hotspot; host-authoritative; direct P2P; future full-mesh; optional internet later.
5. Modular, testable, performance-focused architecture; core logic independent of Godot nodes.
6. Playable without external AI APIs.
7. Original assets only; fictional/abstract mechanics; no realistic weapon simulation.
8. UI must prevent click-through on open menus.
9. Do not run rule calculations per rendered frame.
