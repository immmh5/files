using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("StrategyGame.Core.Tests")]
[assembly: InternalsVisibleTo("StrategyGame.Integration.Tests")]