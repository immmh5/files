namespace StrategyGame.Core.Tests.Domain;

using StrategyGame.Core.Domain;
using StrategyGame.Core.Storage;
using Xunit;

/// <summary>
/// M1.1 — JSON map loading: formats, defaults, metadata, geometry,
/// diagnostics and deterministic reproducibility.
/// </summary>
public class MapLoaderTests
{
    private static string TestDataPath(string file) =>
        Path.Combine(AppContext.BaseDirectory, "TestData", file);

    [Fact]
    public void LoadFromFile_SmallMap_LoadsAllTerritoriesRegionsAndMetadata()
    {
        var map = MapLoader.LoadFromFile(TestDataPath("small_map.json"));

        Assert.Equal("map_small_01", map.Id);
        Assert.Equal("The Small Ring", map.Name);
        Assert.Equal(1, map.Version);
        Assert.Equal(6, map.TerritoryCount);
        Assert.Equal(2, map.Regions.Count);
        Assert.Equal("Northlands", map.GetRegion("northlands")!.Name);
        Assert.Equal(2, map.GetRegion("northlands")!.ArmyBonus);
        Assert.Equal(3, map.GetRegion("southlands")!.ArmyBonus);
    }

    [Fact]
    public void LoadFromFile_SmallMap_TerritoryMetadataIsCorrect()
    {
        var map = MapLoader.LoadFromFile(TestDataPath("small_map.json"));

        var greymill = map.GetTerritory("t2")!;
        Assert.Equal("Greymill Keep", greymill.Name);
        Assert.Equal(TerrainType.Hills, greymill.Terrain);
        Assert.Equal("northlands", greymill.RegionId);
        Assert.True(greymill.IsSupplySource);
        Assert.Contains("t6", map.GetAdjacentTerritories("t2"));

        var frostpine = map.GetTerritory("t3")!;
        Assert.Equal(TerrainType.Mountains, frostpine.Terrain);
        Assert.False(frostpine.IsSupplySource);

        var saltport = map.GetTerritory("t4")!;
        Assert.Equal(TerrainType.Coast, saltport.Terrain);
        Assert.True(saltport.IsSupplySource);
        Assert.Equal("southlands", saltport.RegionId);
    }

    [Fact]
    public void LoadFromFile_SmallMap_SupplySourcesExactlyAsDesigned()
    {
        var map = MapLoader.LoadFromFile(TestDataPath("small_map.json"));

        var supplySources = map.Territories.Values
            .Where(t => t.IsSupplySource).Select(t => t.Id).OrderBy(x => x).ToList();

        Assert.Equal(["t2", "t4"], supplySources);
    }

    [Fact]
    public void LoadFromFile_SmallMap_GeometryIsLoaded()
    {
        var map = MapLoader.LoadFromFile(TestDataPath("small_map.json"));

        var geo = map.Geometry["t1"];
        Assert.Equal(4, geo.Polygon.Count);
        Assert.Equal(new TerritoryPoint(0.5, 0.5), geo.Centroid);
        Assert.Equal(6, map.Geometry.Count);
        Assert.Equal(new TerritoryPoint(2.5, 1.5), map.Geometry["t4"].Centroid);
    }

    [Fact]
    public void FromJson_LoadedTwice_IsDeterministicAndEqual()
    {
        var json = File.ReadAllText(TestDataPath("small_map.json"));

        var first = MapLoader.FromJson(json);
        var second = MapLoader.FromJson(json);

        Assert.Equal(first.Territories.Count, second.Territories.Count);
        foreach (var (id, t1) in first.Territories)
        {
            var t2 = second.Territories[id];
            Assert.Equal(t1.Name, t2.Name);
            Assert.Equal(t1.Terrain, t2.Terrain);
            Assert.Equal(t1.RegionId, t2.RegionId);
            Assert.Equal(t1.IsSupplySource, t2.IsSupplySource);
            Assert.Equal(t1.AdjacentTerritoryIds, t2.AdjacentTerritoryIds);
        }
    }

    [Fact]
    public void GameState_FromLoadedMap_CarriesMetadata()
    {
        var map = MapLoader.LoadFromFile(TestDataPath("small_map.json"));
        var state = new StrategyGame.Core.GameState.GameState(
            "g1", map, [], "p1", 1, "Reinforce");

        var greymill = state.GetTerritory("t2");
        Assert.Equal(TerrainType.Hills, greymill.Terrain);
        Assert.True(greymill.IsSupplySource);
        Assert.Equal("southlands", state.GetTerritory("t4").RegionId);
    }

    // ---------------- Malformed inputs ----------------

    [Fact]
    public void FromJson_MalformedJson_ThrowsMapValidationExceptionWithJsonDiagnostic()
    {
        var ex = Assert.Throws<MapValidationException>(
            () => MapLoader.FromJson("{ not valid json"));

        Assert.Contains(ex.Diagnostics, d => d.Contains("JSON error"));
    }

    [Fact]
    public void FromJson_MissingIdAndName_ReportsBothRequiredFields()
    {
        const string json = """
            {
              "territories": [
                { "id": "t1", "name": "One", "adjacent": [] }
              ]
            }
            """;

        var ex = Assert.Throws<MapValidationException>(() => MapLoader.FromJson(json));
        Assert.Contains(ex.Diagnostics, d => d.Contains("missing the required 'id'"));
        Assert.Contains(ex.Diagnostics, d => d.Contains("missing the required 'name'"));
    }

    [Fact]
    public void FromJson_UnknownTerrain_ReportsDiagnosticNamingTerritory()
    {
        const string json = """
            {
              "id": "m_bad",
              "name": "Bad Terrain",
              "territories": [
                { "id": "t1", "name": "One", "terrain": "lava", "adjacent": [] }
              ]
            }
            """;

        var ex = Assert.Throws<MapValidationException>(() => MapLoader.FromJson(json));
        Assert.Contains(ex.Diagnostics, d =>
            d.Contains("'t1'") && d.Contains("unknown terrain 'lava'"));
    }

    [Fact]
    public void FromJson_UnknownRegionReference_ReportsDiagnostic()
    {
        const string json = """
            {
              "id": "m_bad",
              "name": "Bad Region",
              "regions": [
                { "id": "r1", "name": "Region One", "bonus": 2 }
              ],
              "territories": [
                { "id": "t1", "name": "One", "region": "r2", "adjacent": [] }
              ]
            }
            """;

        var ex = Assert.Throws<MapValidationException>(() => MapLoader.FromJson(json));
        Assert.Contains(ex.Diagnostics, d =>
            d.Contains("'t1'") && d.Contains("undefined region 'r2'"));
    }

    [Fact]
    public void FromJson_BrokenAdjacencyReference_ReportsDiagnostic()
    {
        const string json = """
            {
              "id": "m_bad",
              "name": "Bad Adjacency",
              "territories": [
                { "id": "t1", "name": "One", "adjacent": ["t9"] },
                { "id": "t2", "name": "Two", "supply_source": true }
              ]
            }
            """;

        var ex = Assert.Throws<MapValidationException>(() => MapLoader.FromJson(json));
        Assert.Contains(ex.Diagnostics, d =>
            d.Contains("'t1'") && d.Contains("unknown adjacent territory 't9'"));
    }

    [Fact]
    public void FromJson_MissingOptionalFields_UsesDocumentedDefaults()
    {
        const string json = """
            {
              "id": "m_min",
              "name": "Minimal",
              "territories": [
                { "id": "t1", "name": "One" }
              ]
            }
            """;

        var map = MapLoader.FromJson(json);

        Assert.Equal(1, map.Version); // absent version defaults to 1
        var t1 = map.GetTerritory("t1")!;
        Assert.Equal(TerrainType.Plains, t1.Terrain);
        Assert.Null(t1.RegionId);
        Assert.False(t1.IsSupplySource);
        Assert.Empty(t1.AdjacentTerritoryIds);
        Assert.Empty(map.Regions);
        Assert.Empty(map.Geometry);
    }

    [Fact]
    public void FromJson_WrongPolygonShape_ReportsDiagnostic()
    {
        const string json = """
            {
              "id": "m_bad",
              "name": "Bad Polygon",
              "territories": [
                { "id": "t1", "name": "One", "polygon": [[0,0],[1,0]], "adjacent": [] }
              ]
            }
            """;

        var ex = Assert.Throws<MapValidationException>(() => MapLoader.FromJson(json));
        Assert.Contains(ex.Diagnostics, d => d.Contains("invalid polygon data"));
    }

    [Fact]
    public void FromJson_NegativeRegionBonus_ReportsDiagnostic()
    {
        const string json = """
            {
              "id": "m_bad",
              "name": "Bad Bonus",
              "regions": [
                { "id": "r1", "name": "Region One", "bonus": -2 }
              ],
              "territories": [
                { "id": "t1", "name": "One", "adjacent": [] }
              ]
            }
            """;

        var ex = Assert.Throws<MapValidationException>(() => MapLoader.FromJson(json));
        Assert.Contains(ex.Diagnostics, d => d.Contains("Invalid region entry"));
    }

    [Fact]
    public void FromJson_WhitespaceOnlyJson_ThrowsArgument()
    {
        Assert.Throws<ArgumentException>(() => MapLoader.FromJson("   "));
    }

    [Fact]
    public void LoadFromFile_MissingFile_Throws()
    {
        Assert.ThrowsAny<FileNotFoundException>(() =>
            MapLoader.LoadFromFile(TestDataPath("no_such_map.json")));
    }
}
