namespace StrategyGame.Core.Tests.Simulation;

using StrategyGame.Core.Actions;
using StrategyGame.Core.Domain;
using StrategyGame.Core.Events;
using StrategyGame.Core.GameState;
using StrategyGame.Core.Simulation;
using Xunit;

public class TurnEngineTests
{
    private MapDefinition CreateSmallMap()
    {
        var territories = new List<Territory>
        {
            new("t1", "Alpha", ["t2"]),
            new("t2", "Bravo", ["t1", "t3"]),
            new("t3", "Charlie", ["t2"]),
        };
        return new MapDefinition("test-map", "Test Map", territories);
    }

    private GameState CreateGameState(Player[] players, string startingPlayerId = "p1")
    {
        var map = CreateSmallMap();
        var state = new GameState("g1", map, players, startingPlayerId, 1, TurnManager.PhaseReinforce);
        return state;
    }

    private TurnEngine CreateTurnEngine(GameState state, EventScheduler? scheduler = null, IEventBus? eventBus = null)
    {
        var idSource = new EventIdSource(1);
        var sched = scheduler ?? new EventScheduler();
        return new TurnEngine(state, sched, idSource, eventBus);
    }

    [Fact]
    public void InitialStage_IsTurnStart()
    {
        var p1 = new Player("p1", "Player 1", new Faction("f1", "Red", "#FF0000"), isHuman: true);
        var state = CreateGameState([p1]);
        var engine = CreateTurnEngine(state);

        Assert.Equal(TurnStage.TurnStart, engine.CurrentStage);
        Assert.False(engine.IsGameOver);
    }

    [Fact]
    public void ExecuteTurnStart_SetsNextStageToPlayerActions()
    {
        var p1 = new Player("p1", "Player 1", new Faction("f1", "Red", "#FF0000"), isHuman: true);
        var state = CreateGameState([p1]);
        var engine = CreateTurnEngine(state);

        var result = engine.ExecuteTurnStart();

        Assert.True(result.Success);
        Assert.Equal(TurnStage.PlayerActions, engine.CurrentStage);
    }

    [Fact]
    public void TurnStart_CannotExecuteTwice()
    {
        var p1 = new Player("p1", "Player 1", new Faction("f1", "Red", "#FF0000"), isHuman: true);
        var state = CreateGameState([p1]);
        var engine = CreateTurnEngine(state);

        _ = engine.ExecuteTurnStart();
        var secondResult = engine.ExecuteTurnStart();

        Assert.False(secondResult.Success);
        Assert.Contains("already executed this turn", secondResult.ErrorMessage!);
    }

    [Fact]
    public void ExecutePlayerAction_RequiresPlayerActionsStage()
    {
        var p1 = new Player("p1", "Player 1", new Faction("f1", "Red", "#FF0000"), isHuman: true);
        var state = CreateGameState([p1]);
        var engine = CreateTurnEngine(state);

        // Not in PlayerActions stage yet
        var action = new ReinforceAction("a1", "p1", "t1", 1);
        var result = engine.ExecutePlayerAction(action);

        Assert.False(result.Success);
        Assert.Contains("Cannot execute actions", result.ErrorMessage!);
    }

    [Fact]
    public void PlayerActionsCantRunAfterTurnEnd()
    {
        var p1 = new Player("p1", "Player 1", new Faction("f1", "Red", "#FF0000"), isHuman: true);
        var p2 = new Player("p2", "Player 2", new Faction("f2", "Blue", "#0000FF"), isHuman: false);
        var state = CreateGameState([p1, p2]);

        // Set up so no one wins by domination or elimination
        state.GetTerritory("t1").SetOwner("p1", 3);
        state.GetTerritory("t2").SetOwner("p2", 3);
        state.GetTerritory("t3").SetOwner(null, 0); // neutral

        var engine = CreateTurnEngine(state);

        _ = engine.ExecuteTurnStart();
        _ = engine.AdvanceStage();
        _ = engine.ExecuteEventProcessing();
        _ = engine.ExecuteTurnEnd();

        Assert.Equal(TurnStage.TurnStart, engine.CurrentStageInternal);
    }

    [Fact]
    public void ExecuteEventProcessing_RejectsBeforeTurnStartCompleted()
    {
        var p1 = new Player("p1", "Player 1", new Faction("f1", "Red", "#FF0000"), isHuman: true);
        var state = CreateGameState([p1]);
        var engine = CreateTurnEngine(state);

        var result = engine.ExecuteEventProcessing();

        Assert.False(result.Success);
        Assert.Contains("Cannot execute EventProcessing from stage TurnStart", result.ErrorMessage!);
    }

    [Fact]
    public void AdvanceStage_Progresses_AtoBtoCtoDtoA()
    {
        var p1 = new Player("p1", "Player 1", new Faction("f1", "Red", "#FF0000"), isHuman: true);
        var state = CreateGameState([p1]);
        var engine = CreateTurnEngine(state);

        // A
        _ = engine.ExecuteTurnStart();
        Assert.Equal(TurnStage.PlayerActions, engine.CurrentStageInternal);

        // Transition A -> B happens automatically via ExecuteTurnStart; advancing further goes to C
        var next = engine.AdvanceStage();
        Assert.Equal(TurnStage.EventProcessing, next);
        Assert.Equal(TurnStage.EventProcessing, engine.CurrentStageInternal);

        // Simulate C execution by setting flag
        engine.StageCExecuted = true;
        
        // C -> D
        next = engine.AdvanceStage();
        Assert.Equal(TurnStage.TurnEnd, next);
        Assert.Equal(TurnStage.TurnEnd, engine.CurrentStageInternal);

        // D -> A (new turn)
        engine.StageDExecuted = true;
        next = engine.AdvanceStage();
        Assert.Equal(TurnStage.TurnStart, next);
        Assert.Equal(TurnStage.TurnStart, engine.CurrentStageInternal);
    }

    [Fact]
    public void ExecuteTurnEnd_AdvancesToNextPlayer()
    {
        var p1 = new Player("p1", "Player 1", new Faction("f1", "Red", "#FF0000"), isHuman: true);
        var p2 = new Player("p2", "Player 2", new Faction("f2", "Blue", "#0000FF"), isHuman: false);
        var state = CreateGameState([p1, p2], "p1");
        var engine = CreateTurnEngine(state);

        // Complete stages A and C
        _ = engine.ExecuteTurnStart();
        _ = engine.AdvanceStage(); // Move from PlayerActions to EventProcessing
        _ = engine.ExecuteEventProcessing();

        var result = engine.ExecuteTurnEnd();

        Assert.True(result.Success);
        Assert.Equal("p2", state.CurrentTurnPlayerIdInternal);
        Assert.Equal(1, state.CurrentTurnNumberInternal); // Turn number stays same for first player change
        Assert.Equal(TurnStage.TurnStart, engine.CurrentStageInternal);
    }

    [Fact]
    public void ExecuteTurnEnd_AdvancesRoundAfterLastPlayer()
    {
        var p1 = new Player("p1", "Player 1", new Faction("f1", "Red", "#FF0000"), isHuman: true);
        var p2 = new Player("p2", "Player 2", new Faction("f2", "Blue", "#0000FF"), isHuman: false);
        var state = CreateGameState([p1, p2], "p2"); // Start at p2 (last player)
        var engine = CreateTurnEngine(state);

        _ = engine.ExecuteTurnStart();
        _ = engine.AdvanceStage(); // Move to EventProcessing
        _ = engine.ExecuteEventProcessing();

        var result = engine.ExecuteTurnEnd();

        Assert.True(result.Success);
        Assert.Equal("p1", state.CurrentTurnPlayerIdInternal);
        Assert.Equal(2, state.CurrentTurnNumberInternal); // Round advanced
    }

    [Fact]
    public void IsGameOver_True_WhenPhaseGameOver()
    {
        var p1 = new Player("p1", "Player 1", new Faction("f1", "Red", "#FF0000"), isHuman: true);
        var state = CreateGameState([p1]);
        state.SetPhase(TurnManager.PhaseGameOver);
        var engine = CreateTurnEngine(state);

        Assert.True(engine.IsGameOver);
    }

    [Fact]
    public void InvalidTransition_ThrowsInvalidOperationException()
    {
        var p1 = new Player("p1", "Player 1", new Faction("f1", "Red", "#FF0000"), isHuman: true);
        var state = CreateGameState([p1]);
        var engine = CreateTurnEngine(state);

        // Try to advance without executing required stage
        Assert.Throws<InvalidOperationException>(() => engine.AdvanceStage());
    }
}