# GAME_DESIGN_BIBLE

**Status:** PROPOSED DESIGN (hybrid turn system — see TURN_AND_EVENT_SYSTEM.md)
**Working Title:** Iron Dominion
**Version:** 1.1 (Milestone 1.1 — hybrid turn system incorporated)

---

## 1. Game Identity

**Iron Dominion** is a turn-based territorial strategy game for 2–6 players using a **hybrid turn system**: classic sequential player turns combined with persistent gameplay events that span and act across turns. Every battle is resolved by deterministic rules — no dice, no randomness in combat. The tension comes from outthinking opponents, not from lucky rolls. Depth comes from supply lines, terrain, and opponent modeling on a fully readable map.

## 2. Core Gameplay Loop

```
Player N's turn:
  A. Turn Start (reinforcements, start-of-turn effects, attrition)
  B. Player Action Phase (move / attack / fortify — resolve as issued)
  C. Persistent Event Processing (fire due events, tick multi-turn effects)
  D. Turn End (end-of-turn effects, victory check, advance to next player)
```

## 3. Key Mechanics

1. **Deterministic combat** — no dice, no RNG
2. **Hybrid turn system** *(user-approved provisional)* — sequential player turns + persistent cross-turn events
3. **Supply lines** — armies cut off from friendly territory attrit
4. **Terrain** — defense bonuses make some routes expensive
5. **Continent bonuses** — overextending invites counterattack

## 4. What Differentiates This From Classic Risk

| Classic Risk | Iron Dominion |
|---|---|
| Dice-based combat | Deterministic combat |
| Reinforcements only at turn start | Turn-start reinforcements + start-of-turn effects |
| No supply concept | Supply lines and attrition |
| Armies are interchangeable blobs | Terrain, fronts, and encirclement matter |
| Snowballing winner | Attrition and overextension create natural comebacks |
| Static world between turns | Persistent events span and act across turns |

## 5. First Playable Version Scope

See `FIRST_PLAYABLE_VERSION.md` for the authoritative three-tier feature split.

## 6. Design Philosophy

- Understandable, strategically interesting systems
- No unnecessary complexity
- Deterministic and testable rules
- Modular and expandable architecture
- Original identity, rules, maps, artwork, interface, and presentation
- No proprietary game assets
- Fictional/abstract mechanics; no realistic weapon simulation
- Playable without external AI APIs

## 7. Document Index

All design documents live in `docs/design/`. The master registry is `DESIGN_DECISIONS.md`.
