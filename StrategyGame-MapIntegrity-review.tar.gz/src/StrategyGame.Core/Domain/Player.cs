namespace StrategyGame.Core.Domain;

/// <summary>
/// Represents a player in the game.
/// </summary>
public sealed class Player
{
    public string Id { get; }
    public string Name { get; private set; }
    public Faction Faction { get; }
    public bool IsHuman { get; }
    public int ArmiesToPlace { get; private set; }

    public Player(string id, string name, Faction faction, bool isHuman)
    {
        Id = id ?? throw new ArgumentNullException(nameof(id));
        Name = name ?? throw new ArgumentNullException(nameof(name));
        Faction = faction ?? throw new ArgumentNullException(nameof(faction));
        IsHuman = isHuman;
        ArmiesToPlace = 0;
    }

    public Player(string id, string name, Faction faction, bool isHuman, int armiesToPlace)
        : this(id, name, faction, isHuman)
    {
        ArmiesToPlace = armiesToPlace;
    }

    public void AddArmies(int count)
    {
        if (count < 0) throw new ArgumentOutOfRangeException(nameof(count));
        ArmiesToPlace += count;
    }

    public void PlaceArmies(int count)
    {
        if (count < 0 || count > ArmiesToPlace)
            throw new ArgumentOutOfRangeException(nameof(count));
        ArmiesToPlace -= count;
    }

    public PlayerSnapshot Snapshot() => new(Id, Name, Faction.Id, IsHuman, ArmiesToPlace);
}

/// <summary>
/// Immutable snapshot of a player's state.
/// </summary>
public readonly record struct PlayerSnapshot(
    string Id,
    string Name,
    string FactionId,
    bool IsHuman,
    int ArmiesToPlace);
