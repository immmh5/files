namespace StrategyGame.Core.Simulation;

/// <summary>
/// M1.2 — Immutable, validated attrition configuration.
///
/// PROVISIONAL RULES (D-06 [PROPOSED], not owner-approved):
/// - Unsupplied owned territories lose <see cref="ArmiesLostPerUnsuppliedTerritory"/>
///   army(ies) per territory per round (provisional default 1).
/// - Supplied territories suffer no attrition.
/// - Minimum garrison: one army always remains — attrition never reduces a
///   positive garrison below <see cref="MinimumGarrison"/> as long as
///   <see cref="AllowZeroGarrisonNeutralization"/> is false (the default).
///
/// DOCUMENTED AMBIGUITY, deliberately NOT silently resolved: D-06 also says
/// "Territory at 0 armies becomes neutral". Under the default min-garrison rule
/// attrition itself cannot produce zero armies, so neutralization remains a
/// SEPARATE state-transition rule belonging to other mechanics and later
/// milestones (M1.3). Setting <see cref="AllowZeroGarrisonNeutralization"/> to
/// true makes the calculation able to reach zero and reports
/// <see cref="AttritionEngine.TerritoryAttritionResult.WouldBeNeutralized"/>;
/// the actual ownership change STILL must be performed by a later owning
/// system. Only an explicit owner decision should flip that flag.
///
/// Neutral territories (owned by nobody) are never subject to player attrition.
/// </summary>
public sealed class AttritionConfig
{
    /// <summary>
    /// Armies lost per unsupplied territory per attrition event. Must be >= 0
    /// (0 = attrition configured inactive). PROVISIONAL default 1 per D-06.
    /// </summary>
    public int ArmiesLostPerUnsuppliedTerritory { get; }

    /// <summary>
    /// Garrison floor an owned territory keeps while
    /// <see cref="AllowZeroGarrisonNeutralization"/> is false. Must be >= 0.
    /// PROVISIONAL default 1 per D-06 ("min 1 garrison remains").
    /// </summary>
    public int MinimumGarrison { get; }

    /// <summary>
    /// Whether attrition may reduce an unsupplied territory's garrison to zero
    /// (and thus have <c>WouldBeNeutralized</c> report true). PROVISIONAL default
    /// false; flipping it requires explicit owner approval because the zero-army
    /// neutralization conflict in D-06 is unresolved.
    /// </summary>
    public bool AllowZeroGarrisonNeutralization { get; }

    public AttritionConfig(
        int armiesLostPerUnsuppliedTerritory = 1,
        int minimumGarrison = 1,
        bool allowZeroGarrisonNeutralization = false)
    {
        if (armiesLostPerUnsuppliedTerritory < 0)
        {
            throw new ArgumentOutOfRangeException(nameof(armiesLostPerUnsuppliedTerritory),
                armiesLostPerUnsuppliedTerritory, "Attrition loss per unsupplied territory must be >= 0.");
        }
        if (minimumGarrison < 0)
        {
            throw new ArgumentOutOfRangeException(nameof(minimumGarrison),
                minimumGarrison, "Minimum garrison must be >= 0.");
        }
        ArmiesLostPerUnsuppliedTerritory = armiesLostPerUnsuppliedTerritory;
        MinimumGarrison = minimumGarrison;
        AllowZeroGarrisonNeutralization = allowZeroGarrisonNeutralization;
    }

    /// <summary>Provisional default configuration (loss 1, garrison floor 1, no zero-attrition) per D-06 [PROPOSED].</summary>
    public static AttritionConfig Default { get; } = new();
}
