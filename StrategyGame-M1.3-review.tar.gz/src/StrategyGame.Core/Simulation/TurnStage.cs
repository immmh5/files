namespace StrategyGame.Core.Simulation;

/// <summary>
/// M1.3 — Turn stage enumeration (A/B/C/D cycle per TURN_AND_EVENT_SYSTEM.md).
/// Stage B (PlayerActions) is intentionally NOT an ExecutionStage for scheduled events.
/// </summary>
public enum TurnStage
{
    /// <summary>Stage A — Turn Start: reinforcements, start-of-turn effects, attrition.</summary>
    TurnStart = 0,

    /// <summary>Stage B — Player Action Phase: active player submits orders.</summary>
    PlayerActions = 1,

    /// <summary>Stage C — Persistent Event Processing: scheduled events, duration decrements.</summary>
    EventProcessing = 2,

    /// <summary>Stage D — Turn End: end-of-turn effects, victory check, advance to next player.</summary>
    TurnEnd = 3,

    /// <summary>Game has ended; no further stages advance.</summary>
    GameOver = 4,
}