namespace StrategyGame.App;

using Godot;

/// <summary>
/// Placeholder controller for future game logic wiring.
/// Currently not functional — scaffolding for Milestone 1.
/// </summary>
public partial class GameController : Node
{
    public override void _Ready()
    {
        GD.Print("[GameController] Initialized (stub)");
    }
}
