# GAME_BALANCE_GUIDELINES.md

**Status:** PROPOSED DESIGN

---

## 1. Combat Balance

### 1.1 Attacker-Defender Ratio

- Attacker commits all-but-one army
- Defender gets terrain bonus
- Defender wins ties
- Winner's losses = floor(loser strength / 2)

**Guideline:** Attacker should need ~2x defender strength to win a battle. Terrain bonuses shift this ratio.

### 1.2 Terrain Balance

| Terrain | Defense Bonus | Relative Strength |
|---|---|---|
| Plains | 0 | 1.0x |
| Forest | +1 | 1.33x |
| Hills | +2 | 1.5x |
| Mountains | +3 | 2.0x |
| Marsh | +1 | 1.33x |
| Coast | 0 | 1.0x |

**Guideline:** Mountains should require significant investment. Coast should be accessible but not overpowered.

## 2. Economic Balance

### 2.1 Income Formula

```
income = floor(territories / 3) + region_bonuses
```

**Guideline:** Income should scale with territory count. Region bonuses should be meaningful but not dominant.

### 2.2 Region Bonuses

| Region Size | Bonus |
|---|---|
| 6–8 territories | 2 armies |
| 9–12 territories | 3 armies |
| 13+ territories | 5 armies |

**Guideline:** Bonuses should encourage region control without making it mandatory.

## 3. Supply Balance

### 3.1 Attrition Rate

- 1 army lost per territory per turn
- Minimum 1 garrison remains
- Supply source: capital or port

**Guideline:** Attrition should be punishing but not instantly fatal. A bold strike that gets cut off should bleed, not instantly die.

## 4. Faction Balance

### 4.1 Faction Bonuses

Each faction has one mild passive bonus. Bonuses should be:
- Symmetric in power level
- Asymmetric in playstyle
- Not dominant in any matchup

**Guideline:** Test all 15 faction matchups for balance. No faction should win > 60% of games against any other faction.

## 5. Victory Balance

### 5.1 Elimination

Last player standing wins. No balance issues.

### 5.2 Domination

≥ 60% of territories at round start. Threshold configurable per match.

**Guideline:** 60% should be achievable but not trivial. Prevents endless games.

## 6. AI Balance

### 6.1 Difficulty Curve

| Level | Win Rate vs Human | Notes |
|---|---|---|
| Easy | 20–30% | Weighted random |
| Normal | 40–50% | Greedy utility |
| Hard | 55–65% | Greedy + 1-ply |

**Guideline:** Hard AI should beat most humans but not professionals.

## 7. Map Balance

### 7.1 Territory Distribution

- Each region: 6–12 territories
- Each region: 1–2 chokepoints
- No region completely isolated

**Guideline:** Chokepoints create strategic tension. Isolated regions create snowballing.

## 8. Testing Strategy

- Unit tests for combat resolution (exhaustive for small inputs)
- Integration tests for full round simulation
- Balance tests: 1000-game simulations per matchup
- Manual playtesting: 10+ hours per faction