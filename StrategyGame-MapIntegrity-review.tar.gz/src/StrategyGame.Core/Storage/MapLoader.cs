namespace StrategyGame.Core.Storage;

using System.Text.Json;
using System.Text.Json.Serialization;
using StrategyGame.Core.Domain;

/// <summary>
/// M1.1 — JSON map file data-transcript records, mirroring the map data format in
/// docs/design/MAP_AND_TERRITORY_DESIGN.md 1.1 (format status [PROPOSED]).
///
/// Snake_case keys follow the design example exactly
/// (e.g. "supply_source"); missing optional fields fall back to documented
/// defaults (terrain plains, no region, not a supply source, no adjacency,
/// no geometry). Loader-side semantic validation is delegated to MapValidator
/// via MapDefinition construction, so an invalid file throws MapValidationException.
///
/// Serialized with System.Text.Json only (no new packages; D-16-7).
/// </summary>
internal sealed record MapFileDto
{
    public string? Id { get; set; }
    public string? Name { get; set; }
    public int Version { get; set; } = 1;
    public List<TerritoryFileDto> Territories { get; set; } = [];
    public List<RegionFileDto> Regions { get; set; } = [];
}

/// <summary>One territory entry of a map JSON file.</summary>
internal sealed record TerritoryFileDto
{
    public string? Id { get; set; }
    public string? Name { get; set; }

    /// <summary>Region id reference; absent/null = territory belongs to no region.</summary>
    public string? Region { get; set; }

    /// <summary>Terrain category name; absent = plains.</summary>
    public string? Terrain { get; set; }

    /// <summary>Display polygon as [x,y] point pairs; optional.</summary>
    public List<List<double>>? Polygon { get; set; }

    /// <summary>Display centroid [x,y]; optional.</summary>
    public List<double>? Centroid { get; set; }

    /// <summary>Adjacent territory ids; absent = no adjacency.</summary>
    public List<string>? Adjacent { get; set; }

    /// <summary>Capital/port supply-source flag; absent = false.</summary>
    [JsonPropertyName("supply_source")]
    public bool SupplySource { get; set; }
}

/// <summary>One region entry of a map JSON file.</summary>
internal sealed record RegionFileDto
{
    public string? Id { get; set; }
    public string? Name { get; set; }

    /// <summary>Armies granted for full region control; absent = 0.</summary>
    public int Bonus { get; set; }
}

/// <summary>
/// M1.1 — Loads map JSON files into validated <see cref="MapDefinition"/> objects.
/// Pure and deterministic: the same JSON text always produces the same map.
/// Implements the JSON-loading part of <c>ISaveSerializer.LoadMap</c>'s future
/// save path (save/replay itself remains M1.4).
/// </summary>
public static class MapLoader
{
    private static readonly JsonSerializerOptions Options = new()
    {
        PropertyNameCaseInsensitive = true,
        ReadCommentHandling = JsonCommentHandling.Skip,
        AllowTrailingCommas = true,
        Converters = { new JsonStringEnumConverter() },
    };

    /// <summary>
    /// Parses and validates a map JSON string into a MapDefinition.
    /// Throws JsonException-derived errors for malformed JSON and
    /// MapValidationException for semantically invalid maps.
    /// </summary>
    public static MapDefinition FromJson(string json)
    {
        if (string.IsNullOrWhiteSpace(json))
            throw new ArgumentException("Map JSON must not be null or empty.", nameof(json));

        MapFileDto dto;
        try
        {
            dto = JsonSerializer.Deserialize<MapFileDto>(json, Options)
                  ?? throw new JsonException("Map JSON deserialized to null.");
        }
        catch (JsonException ex)
        {
            throw new MapValidationException("Map JSON is not well-formed or does not match the map schema:",
                [$"JSON error: {ex.Message}"]);
        }

        var diagnostics = new List<string>();

        // File-level required fields
        if (string.IsNullOrWhiteSpace(dto.Id))
            diagnostics.Add("Map file is missing the required 'id' field.");
        if (string.IsNullOrWhiteSpace(dto.Name))
            diagnostics.Add($"Map file is missing the required 'name' field (id: '{dto.Id ?? "<null>"}').");

        var regions = new List<RegionDefinition>();
        foreach (var r in dto.Regions)
        {
            if (r is null)
            {
                diagnostics.Add("Region list contains a null entry.");
                continue;
            }
            try
            {
                regions.Add(new RegionDefinition(r.Id ?? string.Empty, r.Name ?? string.Empty, r.Bonus));
            }
            catch (ArgumentException ex)
            {
                diagnostics.Add($"Invalid region entry: {ex.Message}");
            }
        }

        var territories = new List<Territory>();
        foreach (var t in dto.Territories)
        {
            if (t is null)
            {
                diagnostics.Add("Territory list contains a null entry.");
                continue;
            }

            var terrain = ParseTerrain(t, diagnostics);
            var adjacency = t.Adjacent ?? [];

            try
            {
                territories.Add(new Territory(t.Id ?? string.Empty, t.Name ?? string.Empty, adjacency,
                    ownerPlayerId: null, armies: 0, terrain, t.Region, t.SupplySource));
            }
            catch (ArgumentException ex)
            {
                diagnostics.Add($"Invalid territory entry: {ex.Message}");
                continue;
            }
        }

        // Geometry metadata
        var geometry = new Dictionary<string, TerritoryGeometry>();
        foreach (var t in dto.Territories)
        {
            if (t?.Polygon is null && t?.Centroid is null)
                continue;
            if (t.Id is null)
                continue; // id problems are already diagnosed above

            var polygon = new List<TerritoryPoint>();
            bool polygonOk = true;
            if (t.Polygon is not null)
            {
                foreach (var p in t.Polygon)
                {
                    if (p is null || p.Count != 2)
                    {
                        diagnostics.Add($"Territory '{t.Id}' has malformed polygon points (each point must be [x, y]).");
                        polygonOk = false;
                        break;
                    }
                    polygon.Add(new TerritoryPoint(p[0], p[1]));
                }
            }

            bool centroidOk = true;
            TerritoryPoint? centroid = null;
            if (t.Centroid is not null)
            {
                if (t.Centroid.Count != 2)
                {
                    diagnostics.Add($"Territory '{t.Id}' has a malformed centroid (must be [x, y]).");
                    centroidOk = false;
                }
                else
                {
                    centroid = new TerritoryPoint(t.Centroid[0], t.Centroid[1]);
                }
            }

            if (polygonOk && centroidOk && (t.Polygon is not null || centroid is not null))
            {
                geometry[t.Id] = new TerritoryGeometry(
                    polygon,
                    centroid ?? (polygon.Count > 0 ? AverageOf(polygon) : default));
            }
        }

        // Cross-file semantic validation via MapValidator (unknown adjacency refs,
        // undefined region refs, duplicates, self-adjacency, geometry validity).
        diagnostics.AddRange(MapValidator.Validate(dto.Id, dto.Name, territories, regions, geometry));

        if (diagnostics.Count > 0)
        {
            throw new MapValidationException(
                $"Map '{dto.Id ?? "<null>"}' failed validation with {diagnostics.Count} diagnostic(s):",
                diagnostics);
        }

        return new MapDefinition(dto.Id!, dto.Name!, territories, regions, geometry, dto.Version);
    }

    /// <summary>Loads and validates a map JSON file from disk.</summary>
    public static MapDefinition LoadFromFile(string path)
    {
        if (string.IsNullOrWhiteSpace(path))
            throw new ArgumentException("Map file path must not be null or empty.", nameof(path));
        return FromJson(File.ReadAllText(path));
    }

    private static TerrainType ParseTerrain(TerritoryFileDto t, List<string> diagnostics)
    {
        if (string.IsNullOrWhiteSpace(t.Terrain))
            return TerrainType.Plains; // documented default

        if (Enum.TryParse(t.Terrain, ignoreCase: true, out TerrainType terrain)
            && Enum.IsDefined(terrain))
        {
            return terrain;
        }

        diagnostics.Add($"Territory '{t.Id ?? "<null>"}' has unknown terrain '{t.Terrain}'.");
        return TerrainType.Plains; // diagnostic still forces load failure
    }

    private static TerritoryPoint AverageOf(List<TerritoryPoint> polygon)
    {
        double x = 0, y = 0;
        foreach (var p in polygon)
        {
            x += p.X;
            y += p.Y;
        }
        int n = Math.Max(polygon.Count, 1);
        return new TerritoryPoint(x / n, y / n);
    }
}
