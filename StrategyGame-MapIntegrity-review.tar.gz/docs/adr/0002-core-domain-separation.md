# ADR-0002: Core Domain Separation — Pure C# Without Godot References

**Status:** Accepted
**Date:** 2026-11-04

## Decision

`StrategyGame.Core` is a pure `net8.0` class library with **zero references to Godot assemblies**. It is fully unit-testable without launching the Godot editor.

`StrategyGame.App` is the Godot application project that references `StrategyGame.Core`.

## Context

A long-term strategy game project will have many changes to game rules, state management, and domain logic. If this logic is tightly coupled to Godot node types, rendering calls, or Godot's object system:

1. Testing requires launching the full Godot editor.
2. Game logic becomes harder to reason about in isolation.
3. Switching the rendering layer (e.g., moving to a custom renderer) requires rewriting game rules.
4. AI testing requires Godot instantiation.

### Alternatives Considered

| Alternative | Rejected Because |
|---|---|
| **All game logic in GDScript** | Harder to unit test; C# tooling superior; GDScript lacks generics and async patterns |
| **All game logic in Godot C# scripts** | No separation; test requires Godot; same coupling problem |
| **ECS framework (Flecs, etc.)** | Premature optimization; added complexity without demonstrated need |

## Consequences

- **Positive:** Core domain logic is testable via standard xUnit with `dotnet test`. No Godot process needed.
- **Positive:** The domain model is portable — it could be used by a console tool, server process, or different frontend.
- **Positive:** Clear architectural boundary enforced by compile-time separation.
- **Negative:** Some Godot types (Vector2, Color, Transform2D) must be mapped to/from core types (Point, Color, Matrix3x2). The App layer handles this mapping.
- **Mitigation:** Define clear mapping rules; document them in `docs/ARCHITECTURE.md`.

## Technical Detail

The `StrategyGame.Core` project targets `net8.0` and has no `<PackageReference>` or `<ProjectReference>` to any Godot assembly. All dependencies are standard .NET (`System.*`, `netstandard`). The only exception is `MessagePack` for serialization (a pure .NET package).
