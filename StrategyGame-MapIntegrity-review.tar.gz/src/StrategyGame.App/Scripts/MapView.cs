namespace StrategyGame.App;

using Godot;

/// <summary>
/// Placeholder for the 2.5D strategy map view.
/// Scaffolding only — actual map rendering in Milestone 2.
/// </summary>
public partial class MapView : Node2D
{
    public override void _Ready()
    {
        GD.Print("[MapView] Initialized (stub)");
    }
}
