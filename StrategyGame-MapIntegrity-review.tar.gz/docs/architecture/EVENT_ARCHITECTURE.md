# EVENT_ARCHITECTURE.md

**Status:** USER-APPROVED ARCHITECTURE — R4.2.2. Seven event-system decisions (DR-R4-1…7) were explicitly approved by the project owner on 2026-11-04. The architectural framework here is USER-APPROVED; implementation (R4.3) awaits separate authorization.
**Scope:** Technical event architecture for the hybrid turn system. Implementation (R4.3) awaits separate authorization.
**Companion documents:** `docs/design/EVENT_SYSTEM_SPECIFICATION.md` (categories, rules, open questions), `docs/design/EVENT_LIFECYCLE.md` (state machine), `docs/design/EVENT_SYSTEM_DECISIONS.md` (approved decisions DR-R4-1…7).

---

## 1. Findings From Existing Code (verified, not assumed)

| Claim | Verdict | Evidence |
|---|---|---|
| Delegate-based scheduled events exist in code | **FALSE — documentation only** | Zero occurrences of `Action<GameState>` / `ScheduledEvent` in `src/`. The delegate design exists only in `TURN_ENGINE_ARCHITECTURE.md` §4 (`record ScheduledEvent(... Action<GameState> Execute ...)`) — which is itself a proposal. |
| Collection mutation during enumeration exists in code | **TRUE — latent defect** | `GameEvent.cs`: `Publish<T>` iterates `handlers` (line 52) while handler code can re-enter `Subscribe`/`Unsubscribe` → `List<Delegate>` mutation mid-iteration throws `InvalidOperationException`. No snapshotting or guard exists. |
| Wall-clock time enters event identity | **TRUE** | `GameEvent.Timestamp` is `DateTime.UtcNow` set in every concrete event constructor. Acceptable for presentation/diagnostics; must NOT enter authoritative ordering (see §5). |
| Event IDs are process-global counters | **TRUE** | Each event struct keeps its own `private static long _eventIdCounter` — four independent counters producing colliding ID spaces across event types; IDs reset each process. Unsuitable for replay/network dedup. |

## 2. Layering (PROPOSED)

```
StrategyGame.Core (pure C#, no Godot)
├── Commands/        PlayerCommand records + validator/authorizer interfaces
├── Events/          DomainEvent records (facts) — existing EventBus lives here
├── Simulation/      ScheduledEventRecord (serializable data), EventScheduler,
│                    LogicalClock, ActiveEffect store
└── GameState/       authoritative state (unchanged by this design)

StrategyGame.App (Godot)
├── Presentation/    PresentationEvent queue — consumes domain events, drives
│                    animations/sounds/notifications; NEVER writes game state
└── Input/           builds PlayerCommands from UI, submits to host authority
```

Dependency direction: App → Core. Core never references Godot. Presentation events live entirely on the App side; they are derived, disposable, and unserialized into saves.

## 3. Four Event Categories — Technical Responsibilities (statuses per §EVENT_SYSTEM_SPECIFICATION)

| Category | Nature | Authority | Storage | Serialization |
|---|---|---|---|---|
| **A. Player Commands** | Intent | Requires validation + host authorization before execution | Command log (append-only) | Yes — canonical replay input |
| **B. Domain Events** | Fact (already happened) | Emitted by simulation only; immutable | Event log (bounded, see §8) | Optional (derived from state+commands) |
| **C. Scheduled Gameplay Events** | Future state change | Authoritative; executed by scheduler at due logical time | Pending-event queue inside GameState | **Yes — mandatory, pure serializable data (no delegates)** |
| **D. Presentation Events** | Visual/audio reaction | NON-authoritative, cosmetic | Transient app-side queue | No — never saved, never networked as state |

**Hard rule [CONFIRMED inheritance from project brief]:** rendering loop is never the simulation clock; presentation completion must never gate or alter a gameplay outcome.

## 4. Canonical Scheduled Event Record (PROPOSED)

```csharp
// Simulation/ScheduledEventRecord.cs — pure data, fully serializable
record ScheduledEventRecord(
    string    EventId,            // deterministic, namespace-isolated (IdGenerator pattern)
    int       SchemaVersion,      // payload schema version for migration (§7)
    string    EventTypeKey,       // registry key, NOT a CLR type name
    long      DueLogicalTick,     // logical clock value when the event fires
    EffectPhase Phase,            // TurnStart | EventProcessing | TurnEnd (candidate field)
    int       Priority,           // tie-break level (lower runs first)
    long      SequenceNumber,     // monotonic within match; final tie-breaker
    string?   TargetEntityId,     // territory/player/event target
    int       IssuerTurnNumber,   // provenance & duplicate detection
    byte[]    Payload,            // serialized parameters (typed via registry)
    EventCancellation Status);    // Active | Cancelled | Fired
```

Delegates appear nowhere in persistent state. Behavior is resolved at execution time by looking up `EventTypeKey` in a **static handler registry** (`IReadOnlyDictionary<string, IScheduledEventHandler>`), so saves contain data only and code stays in the assembly. This removes the TURN_ENGINE_ARCHITECTURE.md delegate flaw while keeping its scheduling semantics.

## 5. Deterministic Ordering (PROPOSED)

Total order over pending events at processing time:

1. `DueLogicalTick` ascending
2. `Priority` ascending
3. `SequenceNumber` ascending (assigned deterministically at schedule time from the match-scoped counter)
4. `EventId` lexicographic (last-resort stability)

Rules:
- **Logical tick** is an integer advanced only by authoritative phase transitions (clock design OPEN — see SPEC §Open Questions Q-R4-1: per-player turn vs round vs dedicated tick counter).
- Wall-clock `DateTime` is forbidden as an ordering input; it remains display-only.
- Simultaneous events (same tick) fire in the total order above — never "in insertion order" (insertion order is not reproducible across platforms if any dictionary iteration leaks in).
- **Cancellation** marks `Status = Cancelled`; cancelled events are skipped at fire time and pruned during housekeeping. Explicit cancellation only (inherits TURN_AND_EVENT_SYSTEM.md §3 rule).
- **Rescheduling** = cancel + re-issue with new `DueLogicalTick` and fresh `SequenceNumber`, preserving `EventId` lineage field for auditability (candidate design).
- **Duplicate prevention**: `(IssuerTurnNumber, EventId)` unique per match; scheduler rejects second insert of same `EventId`. Network layer adds per-sender sequence windows (§9).

Reproducibility claim: identical (match seed, command log, pending-event queue, logical clock) ⇒ identical firing sequence and outcomes. Provided all handlers are pure functions of state (design invariant, testable).

## 6. EventBus Hardening (IMPLEMENTED IN R4.1, R4.7)

- Publish over a **snapshot copy** of the handler list (copy-on-subscribe into an immutable array), eliminating mutation-during-enumeration. **IMPLEMENTED in R4.1**.
- Single global monotonically-increasing event-id source replacing the four per-type counters (or reuse namespaced IdGenerator — decision recorded in SPEC). **IMPLEMENTED in R4.7 as `EventIdSource`**.
- Handler exception policy: catch → log → continue dispatch (presentation resilience) vs fail-fast in simulation tests. Proposed: configurable, default fail-fast under test, log-and-continue in release App layer. **OPEN for review.**

## 7. Save/Load Integration (PROPOSED)

Pending-event queue is authoritative state (inherits TURN_AND_EVENT_SYSTEM.md §6): saved at stage boundaries only, never mid-action.

| Concern | Design candidate |
|---|---|
| Payload serialization | Registry maps `EventTypeKey → (schemaVersion, serializer)`. Format (MessagePack vs System.Text.Json) deferred to persistence milestone. |
| Unknown event type on load | Reject save with diagnostic listing missing keys; do NOT silently drop (silent drop loses authoritative effects). Fallback option: quarantine-as-cancelled behind explicit user confirmation. **OPEN.** |
| Version migration | Per-event-type migrators `v(n)→v(n+1)`; save carries global schema version; forward migration mirrors SAVE_AND_REPLAY_DESIGN.md §8 command-log approach. |
| Restored event validation | On load: verify entity targets exist, ticks ≥ current clock, statuses consistent; invalid events fail the load loudly. |
| Expired-after-load events | Events whose `DueLogicalTick < currentClock` at restore time are due NOW and fire in the next matching phase in total order — never skipped, never backdated. |
| Duplicate execution after restore | Save happens at a completed stage boundary; the fired-events journal records last processed `(tick, sequenceNumber)` watermark; scheduler drops any event at or below the watermark on resume. |

## 8. Performance & Lifecycle (PROPOSED)

Expected scale (from D-05/D-14): ≤ ~10²–10³ pending events per match; processing once per phase boundary, not per frame.

| Structure | Cost (fire-min lookup / insert) | Verdict |
|---|---|---|
| Sorted array + binary search insertion | O(log n) find, O(n) memmove | **Recommended baseline** — n is tiny; cache-friendly; zero extra allocations with pooled List |
| Binary min-heap | O(log n) both | Unnecessary complexity at this n |
| Bucketed-by-tick dictionary | O(1) advance | Only justified if clock becomes fine-grained ticks; premature now |
| Object pooling | — | Defer until profiling shows allocation pressure (Rule 8 / no premature optimization) |

Housekeeping: prune `Fired`/`Cancelled` records during Stage C; cap fired-events journal length (bounded ring, size tunable) since full history is reconstructible from the command log. Idle cost: none — scheduler does zero work between phases (event-driven, satisfies CONFIRMED brief constraint).

## 9. Multiplayer Compatibility (PROPOSED — no networking implemented)

Host-authoritative (D-11 `[CONFIRMED]`):

| Flow | Direction | Authority |
|---|---|---|
| Player Commands | Client → Host | Host validates & authorizes; clients may render optimistic selection but not state |
| Domain Events | Host → All | Informational sync + presentation trigger |
| Scheduled event creation/firing/cancellation | Host only | Clients receive resulting deltas; **clients never run the scheduler** |
| Presentation events | Local only | Never trusted as state |

- **Ordering protection:** per-sender monotonic `SequenceNumber` on packets; receivers drop gaps/out-of-order per reliability class already defined in `INetworkTransport`/`GamePacket`.
- **Duplicate rejection:** `(senderId, sequenceNumber)` window filter at transport layer + `(turn, EventId)` uniqueness at scheduler layer.
- **Late join / reconnect:** host sends authoritative snapshot including pending-event queue + watermark (pattern in TURN_AND_EVENT_SYSTEM.md §6).
- **Divergence detection:** periodic state hash (canonical serialization digest) broadcast by host; mismatch ⇒ resynchronize-from-host, flag diagnostic. Hash algorithm choice OPEN.

## 10. Integration With A–D Stages

Mapping against provisional hybrid structure (stage semantics remain USER-APPROVED PROVISIONAL; timing sub-decisions are OPEN — enumerated in SPEC §Open Questions):

- **A Turn Start:** execute `Phase=TurnStart` due events; apply start-of-turn effects.
- **B Player Actions:** commands validated/executed as issued; newly scheduled events take effect no earlier than their `DueLogicalTick`.
- **C Event Processing:** main scheduler pass — due events fire in total order; durations tick; expired effects removed.
- **D Turn End:** execute `Phase=TurnEnd` due events; victory check; clock advances (advance-point is OPEN Q-R4-1).

## 11. Decision Register For This Document

All entries: **PROPOSED** unless noted. Inherited approvals marked accordingly.

| ID | Decision | Status |
|---|---|---|
| EA-1 | Four-category separation (command/fact/scheduled/presentation) | PROPOSED (category existence mandated by R4.0 brief) |
| EA-2 | Serializable data records + static handler registry instead of delegate payloads | PROPOSED |
| EA-3 | Total ordering: tick → priority → sequence → id | PROPOSED |
| EA-4 | Logical integer clock; wall-clock banned from authority | PROPOSED mechanism atop CONFIRMED principle ("rendering loop is never the simulation clock") |
| EA-5 | Snapshot-copy EventBus dispatch | PROPOSED (defect fix, non-gameplay) |
| EA-6 | Sorted-array scheduler baseline | PROPOSED |
| EA-7 | Watermark-based duplicate suppression after load | PROPOSED |
| EA-8 | Host-only scheduling; clients mirror | PROPOSED atop D-11 CONFIRMED host authority |
| EA-9 | Clock granularity / pause semantics / cross-player execution | **OPEN** → SPEC Q-R4-* |
| EA-10 | Unknown-event-on-load policy; payload format; divergence hash | **OPEN** |
