namespace StrategyGame.Core.Domain;

/// <summary>
/// Order types supported by the game.
/// </summary>
public enum OrderType
{
    Reinforce,
    Attack,
    Fortify
}

/// <summary>
/// A player order submitted during a turn.
/// </summary>
public sealed class Order
{
    public string Id { get; }
    public string PlayerId { get; }
    public OrderType Type { get; }
    public string? FromTerritoryId { get; }
    public string? ToTerritoryId { get; }
    public int Armies { get; }

    public Order(string id, string playerId, OrderType type,
        string? fromTerritoryId = null, string? toTerritoryId = null, int armies = 0)
    {
        Id = id ?? throw new ArgumentNullException(nameof(id));
        PlayerId = playerId ?? throw new ArgumentNullException(nameof(playerId));
        Type = type;
        FromTerritoryId = fromTerritoryId;
        ToTerritoryId = toTerritoryId;
        Armies = armies;
    }

    public static Order Reinforce(string id, string playerId, string territoryId, int armies) =>
        new(id, playerId, OrderType.Reinforce, toTerritoryId: territoryId, armies: armies);

    public static Order Attack(string id, string playerId, string fromId, string toId, int armies) =>
        new(id, playerId, OrderType.Attack, fromId, toId, armies);

    public static Order Fortify(string id, string playerId, string fromId, string toId, int armies) =>
        new(id, playerId, OrderType.Fortify, fromId, toId, armies);

    public override string ToString() => $"Order[{Type}] {PlayerId}: {FromTerritoryId}->{ToTerritoryId} ({Armies})";
}
