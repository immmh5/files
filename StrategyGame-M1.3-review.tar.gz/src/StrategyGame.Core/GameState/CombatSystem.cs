namespace StrategyGame.Core.GameState;

using System;
using System.Collections.Generic;
using StrategyGame.Core.Domain;

/// <summary>
/// Handles attack resolution between two territories using a deterministic combat system.
/// M1.3: Updated to follow COMBAT_AND_ARMY_RULES.md with terrain/faction bonuses.
/// </summary>
public static class CombatSystem
{
    public record CombatResult(
        bool AttackerWon,
        int AttackerRemaining,
        int DefenderRemaining,
        string? CapturedTerritoryId);

    /// <summary>
    /// M1.3 — Terrain defense bonus per COMBAT_AND_ARMY_RULES.md (PROVISIONAL).
    /// Defender gets terrain bonus based on target territory's terrain type.
    /// </summary>
    private static readonly Dictionary<TerrainType, int> TerrainBonuses = new()
    {
        { TerrainType.Plains, 0 },
        { TerrainType.Forest, 1 }, // PROVISIONAL
        { TerrainType.Hills, 2 }, // PROVISIONAL
        { TerrainType.Mountains, 3 }, // PROVISIONAL
        { TerrainType.Marsh, 0 }, // No bonus, slows attacker
        { TerrainType.Coast, 1 }, // PROVISIONAL
    };

    /// <summary>
    /// Resolves an attack from one territory to another using the documented combat formula.
    /// Deterministic: no RNG. Defender wins ties (per COMBAT_AND_ARMY_RULES.md).
    /// Formula: attacker_strength = attacker_armies - 1
    ///          defender_strength = defender_armies + terrain_bonus
    /// If attacker_strength > defender_strength: attacker wins
    /// </summary>
    public static CombatResult ResolveAttack(GameState state, string attackerTerritoryId, string defenderTerritoryId)
    {
        if (!state.Map.Territories.ContainsKey(attackerTerritoryId))
            throw new ArgumentException($"Attacker territory '{attackerTerritoryId}' not found.", nameof(attackerTerritoryId));

        if (!state.Map.Territories.ContainsKey(defenderTerritoryId))
            throw new ArgumentException($"Defender territory '{defenderTerritoryId}' not found.", nameof(defenderTerritoryId));

        // Verify adjacency using the live state copies (not MapDefinition)
        var attackerTerritory = state.GetTerritory(attackerTerritoryId);
        if (!attackerTerritory.IsAdjacentTo(defenderTerritoryId))
            throw new InvalidOperationException($"Territories '{attackerTerritoryId}' and '{defenderTerritoryId}' are not adjacent.");

        // Verify attacker owns the territory
        if (attackerTerritory.OwnerPlayerId != state.CurrentTurnPlayerId)
            throw new InvalidOperationException($"Player '{state.CurrentTurnPlayerId}' does not own '{attackerTerritoryId}'.");

        // Retrieve defender before using its properties
        var defender = state.GetTerritory(defenderTerritoryId);
        var defenderArmies = defender.Armies;
        var defenderOwnerId = defender.OwnerPlayerId;

        // Verify attacker's territory is not the defender's own territory
        if (attackerTerritory.OwnerPlayerId == defenderOwnerId)
            throw new InvalidOperationException($"Cannot attack a territory owned by yourself.");

        // Verify attacker has armies to attack (at least 2 in the territory)
        if (attackerTerritory.Armies < 2)
            throw new InvalidOperationException($"Territory '{attackerTerritoryId}' has fewer than 2 armies.");

        var attackerArmies = attackerTerritory.Armies;

        // Calculate strengths per COMBAT_AND_ARMY_RULES.md
        int terrainBonus = TerrainBonuses.GetValueOrDefault(defender.Terrain, 0);
        int attackerStrength = attackerArmies - 1;
        int defenderStrength = defenderArmies + terrainBonus;

        // Deterministic resolution: attacker wins ONLY if strictly greater
        // Defender wins ties (deliberate design choice per D-05 [PROPOSED])
        bool attackerWins = attackerStrength > defenderStrength;

        int attackerRemaining;
        int defenderRemaining;
        string? capturedTerritoryId = null;

        if (attackerWins)
        {
            // Attacker wins
            // Loses floor(defender_strength / 2), defender loses all
            int attackerLosses = (int)Math.Floor((double)defenderStrength / 2);
            attackerRemaining = Math.Max(1, attackerArmies - attackerLosses); // Minimum garrison of 1
            defenderRemaining = 0;
            capturedTerritoryId = defenderTerritoryId;
        }
        else
        {
            // Defender wins (or ties)
            // Defender loses floor(attacker_strength / 2)
            int defenderLosses = (int)Math.Floor((double)attackerStrength / 2);
            defenderRemaining = Math.Max(1, defenderArmies - defenderLosses); // Minimum garrison of 1
            attackerRemaining = attackerArmies; // Attacker retreats without losses
        }

        return new CombatResult(attackerWins, attackerRemaining, defenderRemaining, capturedTerritoryId);
    }
}
