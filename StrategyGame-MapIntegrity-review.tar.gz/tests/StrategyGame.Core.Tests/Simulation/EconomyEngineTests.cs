namespace StrategyGame.Core.Tests.Simulation;

using StrategyGame.Core.Domain;
using StrategyGame.Core.GameState;
using StrategyGame.Core.Simulation;
using Xunit;

/// <summary>
/// M1.2 — EconomyEngine tests: income formula, live-GameState region control,
/// provisional-config behavior, validation and overflow.
/// </summary>
public class EconomyEngineTests
{
    // Test map:
    //   r1 (bonus 2): a1 <-source> -- a2 -- a3
    //   r2 (bonus 3): b1 <-source> -- b2
    //   i1: isolated, no region
    private static MapDefinition CreateTestMap() => new(
        "economy-map", "Economy Test Map", new[]
        {
            new Territory("a1", "One", ["a2"], TerrainType.Plains, "r1", isSupplySource: true),
            new Territory("a2", "Two", ["a1", "a3"], TerrainType.Plains, "r1", isSupplySource: false),
            new Territory("a3", "Three", ["a2"], TerrainType.Hills, "r1", isSupplySource: false),
            new Territory("b1", "BOne", ["b2"], TerrainType.Plains, "r2", isSupplySource: true),
            new Territory("b2", "BTwo", ["b1"], TerrainType.Plains, "r2", isSupplySource: false),
            new Territory("i1", "Isolated", [], TerrainType.Forest, null, isSupplySource: false),
        },
        [new RegionDefinition("r1", "Region One", 2), new RegionDefinition("r2", "Region Two", 3)]);

    private static GameState CreateGameState()
    {
        var map = CreateTestMap();
        var players = new List<Player>
        {
            new("p1", "One", new Faction("f1", "Red", "#FF0000"), true),
            new("p2", "Two", new Faction("f2", "Blue", "#0000FF"), false),
        };
        return new GameState("g", map, players, "p1", 1, "Reinforce");
    }

    /// <summary>Map without any regions and 9 independent territories — for pure base-income testing.</summary>
    private static GameState CreateUnregionedState(int territoryCount = 9)
    {
        var territories = new List<Territory>();
        for (int i = 1; i <= territoryCount; i++)
            territories.Add(new Territory($"u{i}", $"U{i}", [], TerrainType.Plains, null, false));
        var map = new MapDefinition("unregioned", "Unregioned", territories, []);
        var players = new List<Player>
        {
            new("p1", "One", new Faction("f1", "Red", "#FF0000"), true),
        };
        return new GameState("g", map, players, "p1", 1, "Reinforce");
    }

    private static void Own(GameState state, string playerId, params string[] territoryIds)
    {
        foreach (var id in territoryIds)
            state.GetTerritory(id).SetOwner(playerId, 2);
    }

    [Fact]
    public void CalculateReinforcement_NoOwnedTerritories_ZeroBudget()
    {
        var state = CreateGameState();

        var report = EconomyEngine.CalculateReinforcement(state, "p1");

        Assert.Equal(0, report.OwnedTerritoryCount);
        Assert.Equal(0, report.BaseIncome);
        Assert.Equal(0, report.RegionBonusTotal);
        Assert.Equal(0, report.TotalReinforcementBudget);
        Assert.Empty(report.ControlledRegionBonuses);
    }

    [Fact]
    public void CalculateReinforcement_BaseIncome_FloorsTerritoriesPerGroup()
    {
        // Unregioned map: no region term, isolating floor(owned / 3).
        var upTo = new Dictionary<int, int> { [1] = 0, [2] = 0, [3] = 1, [4] = 1, [5] = 1, [6] = 2, [7] = 2, [9] = 3 };
        foreach (var (owned, expectedBase) in upTo)
        {
            var state = CreateUnregionedState(9);
            for (int i = 1; i <= owned; i++)
                state.GetTerritory($"u{i}").SetOwner("p1", 1);

            var report = EconomyEngine.CalculateReinforcement(state, "p1");

            Assert.Equal(owned, report.OwnedTerritoryCount);
            Assert.Equal(expectedBase, report.BaseIncome);
            Assert.Empty(report.ControlledRegionBonuses); // no regions on this map at all
            Assert.Equal(expectedBase, report.TotalReinforcementBudget);
        }
    }

    [Fact]
    public void CalculateReinforcement_ConfigurableDivisor_ChangesBaseIncome()
    {
        var state = CreateGameState();
        Own(state, "p1", "a1", "a2", "a3", "i1"); // 4 owned, region r1 partially? → a1..a3 all owned → FULL r1!

        // Care: owning a1..a3 controls r1 fully; use config on a neutral-bonus setup instead.
        var config = new EconomyConfig(territoriesPerIncomeGroup: 2);

        // Recompute with a map where player owns 4 territories incl. full region.
        var report = EconomyEngine.CalculateReinforcement(state, "p1", config);
        Assert.Equal(2, report.BaseIncome);              // floor(4 / 2)
        Assert.Equal(2, report.RegionBonusTotal);        // r1 fully controlled
        Assert.Equal(4, report.TotalReinforcementBudget);
    }

    [Fact]
    public void CalculateReinforcement_NoControlledRegions_NoContributions()
    {
        var state = CreateGameState();
        Own(state, "p1", "a1", "i1"); // partial r1, nothing else

        var report = EconomyEngine.CalculateReinforcement(state, "p1");

        Assert.Equal(2, report.OwnedTerritoryCount);
        Assert.Empty(report.ControlledRegionBonuses);
        Assert.Equal(0, report.RegionBonusTotal);
        Assert.Equal(0, report.TotalReinforcementBudget); // floor(2/3) = 0
    }

    [Fact]
    public void CalculateReinforcement_OneFullyControlledRegion_GrantsBonus()
    {
        var state = CreateGameState();
        Own(state, "p1", "a1", "a2", "a3"); // full r1 (bonus 2)

        var report = EconomyEngine.CalculateReinforcement(state, "p1");

        var contribution = Assert.Single(report.ControlledRegionBonuses);
        Assert.Equal("r1", contribution.RegionId);
        Assert.Equal("Region One", contribution.RegionName);
        Assert.Equal(2, contribution.ArmyBonus);
        Assert.Equal(3, contribution.MemberTerritoryCount);
        Assert.Equal(2, report.RegionBonusTotal);
        Assert.Equal(1 + 2, report.TotalReinforcementBudget); // floor(3/3)=1 + 2
    }

    [Fact]
    public void CalculateReinforcement_PartiallyControlledRegion_GrantsNothing()
    {
        var state = CreateGameState();
        Own(state, "p1", "a1", "a2"); // 2 of 3 in r1; a3 neutral

        var report = EconomyEngine.CalculateReinforcement(state, "p1");

        Assert.Empty(report.ControlledRegionBonuses);
        Assert.Equal(0, report.RegionBonusTotal);
    }

    [Fact]
    public void CalculateReinforcement_EnemyTerritoryCountsForNeither()
    {
        var state = CreateGameState();
        Own(state, "p1", "a1", "a2");
        Own(state, "p2", "a3", "b1", "b2"); // p2 controls r1 fully + partial r2

        var p1 = EconomyEngine.CalculateReinforcement(state, "p1");
        var p2 = EconomyEngine.CalculateReinforcement(state, "p2");

        // p1: 2 owned (floor 2/3 = 0) — a3 is enemy → excluded; r1 partial (a3 is p2's).
        Assert.Equal(2, p1.OwnedTerritoryCount);
        Assert.Equal(0, p1.TotalReinforcementBudget);

        // p2: 3 owned (a3 r1-member, b1, b2) → floor(3/3)=1 + FULL r2 (b1+b2) bonus 3 = 4.
        Assert.Equal(3, p2.OwnedTerritoryCount);
        Assert.Equal(1, p2.BaseIncome);
        var r2 = Assert.Single(p2.ControlledRegionBonuses);
        Assert.Equal("r2", r2.RegionId); // r1 NOT fully controlled (a1,a2 still p1's)
        Assert.Equal(4, p2.TotalReinforcementBudget);
    }

    [Fact]
    public void CalculateReinforcement_NeutralTerritoriesDoNotCountTowardIncome()
    {
        var state = CreateGameState();
        Own(state, "p1", "a1", "a2", "a3", "b1"); // 4 owned; remaining a? b2 + i1 neutral

        var report = EconomyEngine.CalculateReinforcement(state, "p1");

        Assert.Equal(4, report.OwnedTerritoryCount); // b2 & i1 (neutral) excluded
        Assert.Equal(1, report.BaseIncome);          // floor(4/3)
    }

    [Fact]
    public void CalculateReinforcement_MultipleFullyControlledRegions_SumBonuses()
    {
        var state = CreateGameState();
        Own(state, "p1", "a1", "a2", "a3", "b1", "b2"); // full r1 + full r2, 5 owned

        var report = EconomyEngine.CalculateReinforcement(state, "p1");

        Assert.Equal(2, report.ControlledRegionBonuses.Count);
        Assert.Equal(["r1", "r2"], report.ControlledRegionBonuses.Select(c => c.RegionId).ToArray());
        Assert.Equal(5, report.RegionBonusTotal);       // 2 + 3
        Assert.Equal(1 + 5, report.TotalReinforcementBudget); // floor(5/3)=1
    }

    // ---------------------------------------------------------------
    // THE CRITICAL M1.2 REGRESSION: live GameState ownership, never stale map data.
    // ---------------------------------------------------------------

    [Fact]
    public void CalculateReinforcement_LosingTerritoryInGameState_ReducesRegionBonusImmediately()
    {
        // The map is constructed WITH p1 as owner of all r1 territories (e.g. from a
        // setup/saved scenario). GameState copies that ownership at construction; the
        // map is then never updated again by the engine — so live ownership MUST be
        // read from the state copies.
        var map = CreateTestMap();
        map.GetTerritory("a1")!.SetOwner("p1", 3);
        map.GetTerritory("a2")!.SetOwner("p1", 3);
        map.GetTerritory("a3")!.SetOwner("p1", 3);
        map.GetTerritory("b1")!.SetOwner("p2", 3); // map-level p2 ownership (irrelevant to state after copies)

        var players = new List<Player>
        {
            new("p1", "One", new Faction("f1", "Red", "#FF0000"), true),
            new("p2", "Two", new Faction("f2", "Blue", "#0000FF"), false),
        };
        var state = new GameState("g", map, players, "p1", 1, "Reinforce");

        // Sanity: before any capture p1 fully controls r1 through the state copies.
        var before = EconomyEngine.CalculateReinforcement(state, "p1");
        Assert.Contains(before.ControlledRegionBonuses, c => c.RegionId == "r1");

        // p2 captures a3 IN THE GAME STATE (map territory objects must stay stale).
        state.GetTerritory("a3").SetOwner("p2", 2);

        var after = EconomyEngine.CalculateReinforcement(state, "p1");
        Assert.DoesNotContain(after.ControlledRegionBonuses, c => c.RegionId == "r1"); // partial now
        Assert.Equal(2, after.OwnedTerritoryCount);
        Assert.Equal(0, after.TotalReinforcementBudget); // floor(2/3) = 0, no region bonus

        // Prove the map data stayed stale (ownership there was never updated) and that
        // the engine did NOT read it: the map still shows p1 controlling r1.
        Assert.Equal("p1", map.GetTerritory("a3")!.OwnerPlayerId);
        Assert.Equal(2, map.GetRegionControlBonus("p1"));
    }

    [Fact]
    public void CalculateReinforcement_CapturingTerritoryInGameState_GainsRegionBonusImmediately()
    {
        var state = CreateGameState();

        Own(state, "p1", "a1", "a2");
        var partial = EconomyEngine.CalculateReinforcement(state, "p1");
        Assert.Empty(partial.ControlledRegionBonuses);

        state.GetTerritory("a3").SetOwner("p1", 1); // completes r1

        var full = EconomyEngine.CalculateReinforcement(state, "p1");
        Assert.Contains(full.ControlledRegionBonuses, c => c.RegionId == "r1");
        Assert.Equal(3, full.TotalReinforcementBudget); // floor(3/3)=1 + 2
    }

    [Fact]
    public void CalculateReinforcement_DoesNotMutateGameState()
    {
        var state = CreateGameState();
        Own(state, "p1", "a1", "a2");
        var expectedArmies = state.GetTerritory("a1").Armies;
        var expectedArmiesToPlace = state.GetPlayer("p1").ArmiesToPlace;

        EconomyEngine.CalculateReinforcement(state, "p1");
        EconomyEngine.CalculateReinforcement(state, "p2");

        Assert.Equal(expectedArmies, state.GetTerritory("a1").Armies);
        Assert.Equal(expectedArmiesToPlace, state.GetPlayer("p1").ArmiesToPlace);
        Assert.Equal(1, state.CurrentTurnNumber); // no state change of any kind
    }

    // ---------------------------------------------------------------
    // Validation & overflow
    // ---------------------------------------------------------------

    [Theory]
    [InlineData(0)]
    [InlineData(-1)]
    [InlineData(-99)]
    public void EconomyConfig_NonPositiveDivisor_ThrowsArgumentOutOfRange(int divisor)
    {
        Assert.Throws<ArgumentOutOfRangeException>(() => new EconomyConfig(divisor));
        Assert.Throws<ArgumentOutOfRangeException>(() => EconomyEngine.CalculateReinforcement(
            CreateGameState(), "p1", new EconomyConfig(divisor)));
    }

    [Fact]
    public void CalculateReinforcement_UnknownPlayer_ThrowsKeyNotFound()
    {
        var state = CreateGameState();
        Assert.Throws<KeyNotFoundException>(() => EconomyEngine.CalculateReinforcement(state, "ghost"));
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    public void CalculateReinforcement_BlankPlayerId_ThrowsArgument(string playerId)
    {
        var state = CreateGameState();
        Assert.Throws<ArgumentException>(() => EconomyEngine.CalculateReinforcement(state, playerId));
    }

    [Fact]
    public void CalculateReinforcement_NullPlayerId_ThrowsArgumentNull()
    {
        var state = CreateGameState();
        Assert.Throws<ArgumentNullException>(() => EconomyEngine.CalculateReinforcement(state, null!));
    }

    [Fact]
    public void CalculateReinforcement_NullState_ThrowsArgumentNull()
    {
        Assert.Throws<ArgumentNullException>(() => EconomyEngine.CalculateReinforcement(null!, "p1"));
    }

    [Fact]
    public void CalculateReinforcement_RegionBonusSumOverflow_ThrowsOverflowDeliberately()
    {
        // Two fully controlled regions whose bonuses sum beyond int.MaxValue.
        var map = new MapDefinition(
            "overflow", "Overflow", new[]
            {
                new Territory("x1", "X1", [], TerrainType.Plains, "rBig", false),
                new Territory("x2", "X2", [], TerrainType.Plains, "rSmall", false),
            },
            [
                new RegionDefinition("rBig", "Big", int.MaxValue),
                new RegionDefinition("rSmall", "Small", 1),
            ]);
        var players = new List<Player> { new("p1", "One", new Faction("f1", "Red", "#FF0000"), true) };
        var state = new GameState("g", map, players, "p1", 1, "Reinforce");
        Own(state, "p1", "x1", "x2");

        var ex = Assert.Throws<OverflowException>(() =>
            EconomyEngine.CalculateReinforcement(state, "p1"));

        Assert.Contains("overflow", ex.Message, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void CalculateReinforcement_OverflowIsDeliberateCheckedArithmetic_NotWrap()
    {
        // Region bonus alone at int.MaxValue with any positive base income overflows too.
        var map = new MapDefinition(
            "overflow2", "Overflow Two", new[]
            {
                new Territory("x1", "X1", [], TerrainType.Plains, "rBig", false),
                new Territory("x2", "X2", [], TerrainType.Plains, "rBig", false),
                new Territory("x3", "X3", [], TerrainType.Plains, "rBig", false),
            },
            [new RegionDefinition("rBig", "Big", int.MaxValue)]);
        var players = new List<Player> { new("p1", "One", new Faction("f1", "Red", "#FF0000"), true) };
        var state = new GameState("g", map, players, "p1", 1, "Reinforce");
        Own(state, "p1", "x1", "x2", "x3"); // base income 1 + int.MaxValue → overflow

        var ex = Assert.Throws<OverflowException>(() =>
            EconomyEngine.CalculateReinforcement(state, "p1"));

        Assert.Contains("overflow", ex.Message, StringComparison.OrdinalIgnoreCase);
    }

    // ---------------------------------------------------------------
    // REVIEW v2: returned collections are genuinely read-only.
    // ---------------------------------------------------------------

    [Fact]
    public void EconomyReport_ControlledRegionBonuses_AreDefensivelyReadOnly()
    {
        var state = CreateGameState();
        Own(state, "p1", "a1", "a2", "a3"); // full r1
        var report = EconomyEngine.CalculateReinforcement(state, "p1");

        // Cannot cast back to a mutable List<T>.
        Assert.Throws<InvalidCastException>(
            () => (List<EconomyEngine.RegionBonusContribution>)report.ControlledRegionBonuses);

        // The read-only wrapper also blocks IList-level mutation attempts.
        var asIList = (System.Collections.IList)report.ControlledRegionBonuses;
        Assert.Throws<NotSupportedException>(() =>
            asIList.Add(new EconomyEngine.RegionBonusContribution("rX", "Fake", 9, 1)));
        Assert.Throws<NotSupportedException>(() => asIList.Clear());
        Assert.Single(report.ControlledRegionBonuses); // unchanged after attempts
    }
}
