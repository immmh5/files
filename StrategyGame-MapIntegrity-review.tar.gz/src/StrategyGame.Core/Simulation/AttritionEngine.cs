namespace StrategyGame.Core.Simulation;

using StrategyGame.Core.GameState;

/// <summary>
/// M1.2 — Pure, deterministic attrition calculation for unsupplied territories.
///
/// PROVISIONAL RULE (D-06 [PROPOSED], not owner-approved):
/// - Unsupplied owned territories lose the configured number of armies per
///   territory per attrition event (default 1, per <see cref="AttritionConfig"/>).
/// - The minimum garrison is respected (default 1 stays forever, unless the
///   config explicitly allows reaching zero — see the documented D-06
///   honest-ambiguity note in <see cref="AttritionConfig"/>).
/// - Neutral territory neutralization (ownership change at 0 armies) is NOT
///   performed here; this calculation only REPORTS whether a territory
///   <c>WouldBeNeutralized</c> under the configured rules. The ownership
///   transition itself belongs to the later turn/action system (M1.3).
///
/// PURE: input is (GameState, playerId, SupplyResult, config) and the output is
/// an immutable report. Neither <see cref="GameState"/> nor
/// <see cref="Domain.MapDefinition"/> is mutated. No EventScheduler wiring and
/// no automatic turn processing happen in M1.2.
///
/// STALENESS GUARD (review v2): the supplied <see cref="SupplyEngine.SupplyResult"/>
/// is validated structurally (duplicates, unknown ids, overlapping sets, null
/// lists) and then against the supply state freshly recalculated from the CURRENT
/// GameState. Ownership changes, connectivity changes, forged results, and
/// results with incomplete territory coverage are rejected with
/// <see cref="ArgumentException"/> — an unsupplied territory is never silently
/// omitted. State-corruption guards (negative armies among ALL player-owned
/// territories, supplied or not) throw <see cref="InvalidOperationException"/>.
///
/// Overflow/underflow: army reductions are capped explicitly (no unchecked
/// subtraction), and totals are computed in a <c>checked</c> context.
/// </summary>
public static class AttritionEngine
{
    /// <summary>Per-territory attrition outcome.</summary>
    /// <param name="TerritoryId">Territory this result belongs to.</param>
    /// <param name="ArmiesBefore">Garrison size before attrition.</param>
    /// <param name="ArmiesLost">Armies actually removed (at most 0 means none).</param>
    /// <param name="ArmiesAfter">Garrison size after attrition.</param>
    /// <param name="WouldBeNeutralized">True only if the garrison reached 0 (and was > 0) under the configured rules.</param>
    public readonly record struct TerritoryAttritionResult(
        string TerritoryId, int ArmiesBefore, int ArmiesLost, int ArmiesAfter, bool WouldBeNeutralized);

    /// <summary>
    /// Immutable attrition report for one player.
    /// </summary>
    /// <param name="PlayerId">Player the report was calculated for.</param>
    /// <param name="ConfiguredLossPerTerritory">Loss per unsupplied territory from the config.</param>
    /// <param name="TerritoryResults">One entry per unsupplied owned territory, in the freshly recomputed (deterministic) order.</param>
    /// <param name="TotalArmiesLost">Sum of <see cref="TerritoryAttritionResult.ArmiesLost"/> (checked).</param>
    /// <param name="TerritoriesWouldBeNeutralized">Count of results with <c>WouldBeNeutralized</c> true.</param>
    public sealed record AttritionReport(
        string PlayerId,
        int ConfiguredLossPerTerritory,
        IReadOnlyList<TerritoryAttritionResult> TerritoryResults,
        int TotalArmiesLost,
        int TerritoriesWouldBeNeutralized);

    /// <summary>
    /// Calculates attrition for every unsupplied owned territory of the player.
    /// Side-effect free.
    /// </summary>
    /// <exception cref="ArgumentNullException">Any argument is null.</exception>
    /// <exception cref="ArgumentException">
    /// PlayerId is empty/whitespace; or the supply result belongs to a different
    /// player; or it is structurally invalid (null/duplicate/unknown ids,
    /// overlapping sets); or it is STALE — i.e. it does not exactly match the
    /// supply state freshly recalculated from the CURRENT
    /// <see cref="GameState"/> (ownership changes, network changes, forged or
    /// incomplete results).
    /// </exception>
    /// <exception cref="KeyNotFoundException">No player with that id exists in state.</exception>
    /// <exception cref="InvalidOperationException">
    /// Corrupt state: any territory owned by the requested player has a negative
    /// army count, or an unsupplied territory is no longer owned by the player.
    /// </exception>
    /// <exception cref="OverflowException">Total-loss arithmetic exceeds int range (checked).</exception>
    public static AttritionReport CalculateAttrition(
        GameState state,
        string playerId,
        SupplyEngine.SupplyResult supply,
        AttritionConfig? config = null)
    {
        ArgumentNullException.ThrowIfNull(state);
        ArgumentNullException.ThrowIfNull(supply);
        if (playerId is null)
            throw new ArgumentNullException(nameof(playerId));
        if (string.IsNullOrWhiteSpace(playerId))
            throw new ArgumentException("Player id must not be null, empty or whitespace.", nameof(playerId));

        // Validate player existence BEFORE judging the supply result, so a request
        // for an unknown player surfaces as KeyNotFound, not a confusing mismatch.
        _ = state.GetPlayer(playerId);

        if (!string.Equals(supply.PlayerId, playerId, StringComparison.Ordinal))
        {
            throw new ArgumentException(
                $"Supply result belongs to player '{supply.PlayerId}' but attrition was requested for '{playerId}'.",
                nameof(supply));
        }

        // ---------------------------------------------------------------
        // 1. Structural validation of the supplied result.
        // ---------------------------------------------------------------
        var claimedSupplied = supply.SuppliedTerritoryIds
            ?? throw new ArgumentException("Supply result's supplied list is null (inconsistent input).", nameof(supply));
        var claimedUnsupplied = supply.UnsuppliedTerritoryIds
            ?? throw new ArgumentException("Supply result's unsupplied list is null (inconsistent input).", nameof(supply));
        var claimedSources = supply.SourceTerritoryIds
            ?? throw new ArgumentException("Supply result's source list is null (inconsistent input).", nameof(supply));

        if (HasDuplicateIds(claimedSupplied, out var duplicateId))
            throw new ArgumentException($"Supply result lists duplicate territory id '{duplicateId}' in the supplied list.",
                nameof(supply));
        if (HasDuplicateIds(claimedUnsupplied, out duplicateId))
            throw new ArgumentException($"Supply result lists duplicate territory id '{duplicateId}' in the unsupplied list.",
                nameof(supply));
        if (HasDuplicateIds(claimedSources, out duplicateId))
            throw new ArgumentException($"Supply result lists duplicate territory id '{duplicateId}' in the source list.",
                nameof(supply));

        foreach (var id in claimedSupplied.Concat(claimedUnsupplied).Concat(claimedSources))
        {
            if (state.Map.GetTerritory(id) is null)
                throw new ArgumentException(
                    $"Supply result references unknown territory id '{id}' (inconsistent input).", nameof(supply));
        }

        foreach (var id in claimedSupplied)
        {
            if (claimedUnsupplied.Contains(id))
                throw new ArgumentException(
                    $"Supply result lists territory '{id}' as BOTH supplied and unsupplied (inconsistent input).",
                    nameof(supply));
        }

        // ---------------------------------------------------------------
        // 2. STALENESS VALIDATION against the CURRENT GameState.
        // The supply state is recalculated fresh and compared set-wise with
        // the claim. A result computed earlier in the match (ownership since
        // changed, network since cut/restored), a forged result, or a result
        // with missing territory coverage is REJECTED — attrition is never
        // silently calculated from an out-of-date supply partition.
        // ---------------------------------------------------------------
        var fresh = SupplyEngine.CalculateSupply(state, playerId);

        if (fresh.OwnedTerritoryCount != supply.OwnedTerritoryCount ||
            !fresh.SuppliedTerritoryIds.SequenceEqualAsSet(claimedSupplied) ||
            !fresh.UnsuppliedTerritoryIds.SequenceEqualAsSet(claimedUnsupplied) ||
            fresh.HasOwnedSource != supply.HasOwnedSource ||
            !fresh.SourceTerritoryIds.SequenceEqualAsSet(claimedSources))
        {
            throw new ArgumentException(
                "Supply result is stale or does not match the CURRENT GameState " +
                "(recalculated supply differs in ownership, connectivity, sources, or territory coverage). " +
                $"Expected supplied={FormatAsOrderedList(fresh.SuppliedTerritoryIds)}, " +
                $"unsupplied={FormatAsOrderedList(fresh.UnsuppliedTerritoryIds)}, " +
                $"owned={fresh.OwnedTerritoryCount}; claimed supplied={FormatAsOrderedList(claimedSupplied)}, " +
                $"unsupplied={FormatAsOrderedList(claimedUnsupplied)}, owned={supply.OwnedTerritoryCount}.",
                nameof(supply));
        }

        // ---------------------------------------------------------------
        // 3. Corrupt-state guard: validate army counts across ALL player-owned
        // territories (supplied and unsupplied alike) before producing the
        // report, so negative garrisons anywhere are rejected consistently.
        // ---------------------------------------------------------------
        foreach (var territory in state.GetAllTerritories())
        {
            if (!string.Equals(territory.OwnerPlayerId, playerId, StringComparison.Ordinal))
                continue; // neutral/enemy territories are not this player's concern

            if (territory.Armies < 0)
            {
                throw new InvalidOperationException(
                    $"Territory '{territory.Id}' owned by player '{playerId}' has a negative army count " +
                    $"({territory.Armies}); state is corrupt.");
            }
        }

        // ---------------------------------------------------------------
        // 4. Calculation — iterate the FRESH unsupplied list (sorted,
        // deterministic). By construction it now equals the claimed set.
        // ---------------------------------------------------------------
        var attritionConfig = config ?? AttritionConfig.Default;
        List<TerritoryAttritionResult> results = [];

        foreach (var territoryId in fresh.UnsuppliedTerritoryIds)
        {
            var territory = state.GetTerritory(territoryId);
            int before = territory.Armies;

            int lost;
            if (attritionConfig.AllowZeroGarrisonNeutralization)
            {
                // Cap at the full garrison: attrition can reach 0 but never wrap under it.
                lost = Math.Min(attritionConfig.ArmiesLostPerUnsuppliedTerritory, before);
            }
            else
            {
                // Min-garrison rule: never reduce below the garrison floor.
                lost = Math.Min(attritionConfig.ArmiesLostPerUnsuppliedTerritory,
                                Math.Max(0, before - attritionConfig.MinimumGarrison));
            }

            int after = before - lost;
            bool neutralized = before > 0 && after == 0;

            results.Add(new TerritoryAttritionResult(territoryId, before, lost, after, neutralized));
        }

        int totalLost = 0;
        int neutralizedCount = 0;
        checked
        {
            foreach (var r in results)
            {
                totalLost += r.ArmiesLost;
                if (r.WouldBeNeutralized)
                    neutralizedCount++;
            }
        }

        return new AttritionReport(
            playerId,
            attritionConfig.ArmiesLostPerUnsuppliedTerritory,
            results.AsReadOnly(), // defensive: callers cannot mutate engine output
            totalLost,
            neutralizedCount);
    }

    private static bool HasDuplicateIds(IEnumerable<string> ids, out string duplicateId)
    {
        var seen = new HashSet<string>(StringComparer.Ordinal);
        foreach (var id in ids)
        {
            if (!seen.Add(id))
            {
                duplicateId = id;
                return true;
            }
        }
        duplicateId = string.Empty;
        return false;
    }

    private static string FormatAsOrderedList(IEnumerable<string> ids) => $"[{string.Join(", ", ids)}]";
}

/// <summary>Internal set-comparison helpers for the staleness validation.</summary>
file static class SupplySetComparisonExtensions
{
    /// <summary>Order-independent, duplicate-sensitive-enough set equality (duplicates are rejected earlier).</summary>
    public static bool SequenceEqualAsSet(this IReadOnlyList<string> left, IReadOnlyList<string> right)
    {
        if (left.Count != right.Count)
            return false;
        var set = new HashSet<string>(left, StringComparer.Ordinal);
        foreach (var id in right)
        {
            if (!set.Remove(id))
                return false;
        }
        return set.Count == 0;
    }
}
