namespace StrategyGame.Core.Tests.Simulation;

using StrategyGame.Core.Domain;
using StrategyGame.Core.GameState;
using StrategyGame.Core.Simulation;
using StrategyGame.Core.Storage;
using Xunit;

/// <summary>
/// M1.2 — Integration-style Core tests: the deterministic chain
/// GameState → EconomyEngine → SupplyEngine → AttritionEngine, exercised on the
/// M1.1 deterministic test map ("The Small Ring": northlands t1-t3 bonus 2 with
/// capital-source t2; southlands t4-t6 bonus 3 with port-source t4).
/// The chain is NOT wired into the TurnEngine (that is M1.3).
/// </summary>
public class SupplyAttritionChainTests
{
    private const string MapPathFile = "small_map.json";

    private static MapDefinition LoadSmallMap() =>
        MapLoader.LoadFromFile(Path.Combine(AppContext.BaseDirectory, "TestData", MapPathFile));

    private static GameState CreateGame(MapDefinition map) => new(
        "chain-game", map,
        [
            new Player("p1", "Northling", new Faction("f1", "Red", "#FF0000"), true),
            new Player("p2", "Southling", new Faction("f2", "Blue", "#0000FF"), false),
        ],
        "p1", 1, "Reinforce");

    private sealed record ChainOutputs(
        EconomyEngine.EconomyReport Economy,
        SupplyEngine.SupplyResult Supply,
        AttritionEngine.AttritionReport Attrition);

    private static ChainOutputs RunChain(GameState state, string playerId)
    {
        var economy = EconomyEngine.CalculateReinforcement(state, playerId);
        var supply = SupplyEngine.CalculateSupply(state, playerId);
        var attrition = AttritionEngine.CalculateAttrition(state, playerId, supply);
        return new ChainOutputs(economy, supply, attrition);
    }

    /// <summary>
    /// Baseline scenario: p1 fully controls northlands (t1,t2,t3) holding capital
    /// source t2, and owns one southlands territory t6 connected through t1.
    /// Expectation: income floor(4/3)=1 + region bonus 2 = 3; all four owned
    /// territories supplied; no attrition.
    /// </summary>
    [Fact]
    public void Chain_FullNorthlandsWithConnectedExtension_SuppliedAndNoAttrition()
    {
        var state = CreateGame(LoadSmallMap());
        foreach (var id in new[] { "t1", "t2", "t3", "t6" })
            state.GetTerritory(id).SetOwner("p1", 3);

        var chain = RunChain(state, "p1");

        Assert.Equal(4, chain.Economy.OwnedTerritoryCount);
        var r1 = Assert.Single(chain.Economy.ControlledRegionBonuses);
        Assert.Equal("northlands", r1.RegionId);
        Assert.Equal(3, chain.Economy.TotalReinforcementBudget);

        Assert.Equal(["t1", "t2", "t3", "t6"], chain.Supply.SuppliedTerritoryIds);
        Assert.Empty(chain.Supply.UnsuppliedTerritoryIds);

        Assert.Empty(chain.Attrition.TerritoryResults);
        Assert.Equal(0, chain.Attrition.TotalArmiesLost);
    }

    /// <summary>
    /// Losing the only supply source (t2 captured by p2) collapses supply, exposes
    /// every owned territory to attrition, and breaks the northlands region bonus —
    /// all recomputed from LIVE state, not stale map data.
    /// </summary>
    [Fact]
    public void Chain_SourceCapture_CollapsesSupply_BreaksRegionBonus_TriggersAttrition()
    {
        var state = CreateGame(LoadSmallMap());
        foreach (var id in new[] { "t1", "t2", "t3", "t6" })
            state.GetTerritory(id).SetOwner("p1", 3);

        var before = RunChain(state, "p1");
        Assert.Equal(3, before.Economy.TotalReinforcementBudget);
        Assert.Empty(before.Supply.UnsuppliedTerritoryIds);

        // p2 captures the capital source t2 in the active game state.
        state.GetTerritory("t2").SetOwner("p2", 4);

        var after = RunChain(state, "p1");

        // Economy: northlands now partial → no bonus; 3 owned → floor(3/3)=1.
        Assert.Equal(3, after.Economy.OwnedTerritoryCount);
        Assert.Empty(after.Economy.ControlledRegionBonuses);
        Assert.Equal(1, after.Economy.TotalReinforcementBudget);

        // Supply: no owned source → everything unsupplied.
        Assert.False(after.Supply.HasOwnedSource);
        Assert.Empty(after.Supply.SuppliedTerritoryIds);
        Assert.Equal(["t1", "t3", "t6"], after.Supply.UnsuppliedTerritoryIds);

        // Attrition: every unsupplied territory flagged with loss, min garrison kept.
        Assert.Equal(3, after.Attrition.TerritoryResults.Count);
        Assert.Equal(3, after.Attrition.TotalArmiesLost);
        Assert.All(after.Attrition.TerritoryResults, r => Assert.Equal(2, r.ArmiesAfter)); // 3 → 2
    }

    /// <summary>
    /// Completing southlands (capturing t4 + t5 from p2) grants the 3-army bonus
    /// AND gives p1 the port source t4, so the south pocket becomes supplied.
    /// </summary>
    [Fact]
    public void Chain_CompletingSouthlands_GainsRegionBonusAndPortSupply()
    {
        var state = CreateGame(LoadSmallMap());
        // p1 owns the whole southlands except t4... plus t4+t5 must be captured from p2.
        foreach (var id in new[] { "t4", "t5", "t6" })
            state.GetTerritory(id).SetOwner("p2", 2);
        state.GetTerritory("t5").SetOwner("p1", 2); // take t5 first (partial region)
        state.GetTerritory("t6").SetOwner("p1", 2);

        var partial = RunChain(state, "p1");
        Assert.Empty(partial.Economy.ControlledRegionBonuses); // t4 still p2's
        Assert.False(partial.Supply.HasOwnedSource);           // no owned source yet
        Assert.Equal(["t5", "t6"], partial.Supply.UnsuppliedTerritoryIds);
        Assert.Equal(2, partial.Attrition.TerritoryResults.Count);

        // p1 captures the port t4 in the active game state.
        state.GetTerritory("t4").SetOwner("p1", 2);

        var full = RunChain(state, "p1");

        var bonus = Assert.Single(full.Economy.ControlledRegionBonuses);
        Assert.Equal("southlands", bonus.RegionId);
        Assert.Equal(3, bonus.ArmyBonus);
        Assert.Equal(1 + 3, full.Economy.TotalReinforcementBudget); // floor(3/3)=1 + 3

        Assert.True(full.Supply.HasOwnedSource);
        Assert.Equal(["t4"], full.Supply.SourceTerritoryIds);
        Assert.Equal(["t4", "t5", "t6"], full.Supply.SuppliedTerritoryIds);
        Assert.Empty(full.Attrition.TerritoryResults);
    }

    /// <summary>
    /// A fortress pocket that keeps its source holds zero attrition even while
    /// disconnected from the rest of the player's network.
    /// </summary>
    [Fact]
    public void Chain_SuppliedPocketInsideEnemyLines_StillSupplied()
    {
        var state = CreateGame(LoadSmallMap());
        // p1 owns ring with capital AND an isolated pocket: give p1 ownership of
        // every supply source reachable? Instead: p1 owns t2 (source) and only t3.
        foreach (var id in new[] { "t2", "t3" })
            state.GetTerritory(id).SetOwner("p1", 5);

        var chain = RunChain(state, "p1");

        Assert.Equal(["t2", "t3"], chain.Supply.SuppliedTerritoryIds);
        Assert.Empty(chain.Attrition.TerritoryResults);

        // partial northlands (t1 neutral) → no region bonus despite owning the capital.
        Assert.Empty(chain.Economy.ControlledRegionBonuses);
        Assert.Equal(0, chain.Economy.TotalReinforcementBudget); // floor(2/3)=0
    }

    /// <summary>
    /// The chain runs consistently over snapshots too: results on a snapshot of the
    /// live state equal results on the live state (deep-copy independence).
    /// </summary>
    [Fact]
    public void Chain_SnapshotProducesIdenticalResults()
    {
        var state = CreateGame(LoadSmallMap());
        foreach (var id in new[] { "t1", "t2", "t3", "t6" })
            state.GetTerritory(id).SetOwner("p1", 3);

        var live = RunChain(state, "p1");
        var snapshotState = state.Snapshot();
        var fromSnapshot = RunChain(snapshotState, "p1");

        // Records hold IReadOnlyList collections (reference-typed members), so compare
        // field-by-field and element-wise rather than by record equality.
        Assert.Equal(live.Economy.PlayerId, fromSnapshot.Economy.PlayerId);
        Assert.Equal(live.Economy.TotalReinforcementBudget, fromSnapshot.Economy.TotalReinforcementBudget);
        Assert.Equal(live.Economy.ControlledRegionBonuses.Select(c => c.RegionId),
                     fromSnapshot.Economy.ControlledRegionBonuses.Select(c => c.RegionId));
        Assert.Equal(live.Supply.SuppliedTerritoryIds, fromSnapshot.Supply.SuppliedTerritoryIds);
        Assert.Equal(live.Supply.UnsuppliedTerritoryIds, fromSnapshot.Supply.UnsuppliedTerritoryIds);
        Assert.Equal(
            live.Attrition.TerritoryResults.Select(r => (r.TerritoryId, r.ArmiesLost, r.ArmiesAfter)),
            fromSnapshot.Attrition.TerritoryResults.Select(r => (r.TerritoryId, r.ArmiesLost, r.ArmiesAfter)));
    }

    /// <summary>
    /// The full chain is side-effect free: state and map remain untouched.
    /// </summary>
    [Fact]
    public void Chain_DoesNotMutateStateOrMap()
    {
        var map = LoadSmallMap();
        var state = CreateGame(map);
        foreach (var id in new[] { "t1", "t2", "t3", "t6" })
            state.GetTerritory(id).SetOwner("p1", 3);

        var expectedArmies = new[] { "t1", "t2", "t3", "t6" }.ToDictionary(id => id, id => state.GetTerritory(id).Armies);
        var expectedOwners = new[] { "t1", "t2", "t3", "t6" }.ToDictionary(id => id, id => state.GetTerritory(id).OwnerPlayerId);

        var chain = RunChain(state, "p1");

        foreach (var (id, armies) in expectedArmies)
        {
            Assert.Equal(armies, state.GetTerritory(id).Armies);
            Assert.Equal(expectedOwners[id], state.GetTerritory(id).OwnerPlayerId);
        }
        // And the chain outputs were computed, proving the run really happened.
        Assert.InRange(chain.Economy.TotalReinforcementBudget, 1, int.MaxValue);
    }
}
