namespace StrategyGame.Core.Tests.Simulation;

using System.Text.Json;
using System.Text.Json.Serialization;
using StrategyGame.Core.Simulation;
using StrategyGame.Core.Common;
using Xunit;

public class ScheduledEventRecordTests
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = false,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        Converters = { new JsonStringEnumConverter() }
    };

    [Fact]
    public void CreateNew_GlobalEffect_AllFieldsPopulated()
    {
        var eventId = IdGenerator.NewDeterministicId("sched", 42, 0);
        var record = ScheduledEventRecord.CreateNew(
            eventTypeKey: "autumn_attrition",
            dueTurnSequence: 10,
            dueRoundIndex: 3,
            duePlayerTurnCounts: new(),
            phase: EffectPhase.TurnStart,
            priority: 0,
            sequenceNumber: 1,
            targetEntityId: null,
            issuerTurnNumber: 5,
            payloadJson: "{\"intensity\":2}",
            currentTurnSequence: 10,
            eventId: eventId);

        Assert.Equal(eventId, record.EventId);
        Assert.Equal(1, record.SchemaVersion);
        Assert.Equal("autumn_attrition", record.EventTypeKey);
        Assert.Equal(10, record.DueTurnSequence);
        Assert.Equal(3, record.DueRoundIndex);
        Assert.Empty(record.DuePlayerTurnCounts);
        Assert.Equal(EffectPhase.TurnStart, record.Phase);
        Assert.Equal(0, record.Priority);
        Assert.Equal(1L, record.SequenceNumber);
        Assert.Null(record.TargetEntityId);
        Assert.Equal(5, record.IssuerTurnNumber);
        Assert.Equal("{\"intensity\":2}", record.PayloadJson);
        Assert.Equal(EventCancellation.Active, record.Status);
        Assert.Equal(10, record.CreatedAtTurnSequence);
        Assert.Null(record.LineageEventId);
        Assert.True(record.IsGlobalEffect);
        Assert.False(record.HasPersonalEffects);
        Assert.False(record.IsTerminal);
    }

    [Fact]
    public void CreateNew_PersonalEffect_AllFieldsPopulated()
    {
        var eventId = IdGenerator.NewDeterministicId("sched", 43, 0);
        var record = ScheduledEventRecord.CreateNew(
            eventTypeKey: "berserk_rage",
            dueTurnSequence: 15,
            dueRoundIndex: 0,
            duePlayerTurnCounts: new Dictionary<string, int> { { "p2", 7 } },
            phase: EffectPhase.EventProcessing,
            priority: 10,
            sequenceNumber: 2,
            targetEntityId: "p2",
            issuerTurnNumber: 8,
            payloadJson: "{\"bonus\":3}",
            currentTurnSequence: 15,
            eventId: eventId);

        Assert.Equal(eventId, record.EventId);
        Assert.Equal(0, record.DueRoundIndex);
        Assert.Equal(7, record.DuePlayerTurnCounts["p2"]);
        Assert.Equal(EffectPhase.EventProcessing, record.Phase);
        Assert.Equal(10, record.Priority);
        Assert.True(record.HasPersonalEffects);
        Assert.False(record.IsGlobalEffect);
    }

    [Fact]
    public void Reschedule_PreservesLineageAndIncrementsSequence()
    {
        var originalId = IdGenerator.NewDeterministicId("sched", 44, 0);
        var original = ScheduledEventRecord.CreateNew(
            "test_effect", 20, 5, new() { { "p1", 3 } },
            EffectPhase.TurnEnd, 5, 10, "t1", 10, "{}", 20, "orig-id");

        var rescheduled = original.Reschedule(
            newDueTurnSequence: 25,
            newDueRoundIndex: 6,
            newDuePlayerTurnCounts: new() { { "p1", 4 } },
            newPriority: 3,
            newSequenceNumber: 11,
            currentTurnSequence: 22);

        Assert.NotEqual(original.EventId, rescheduled.EventId);
        Assert.Equal("orig-id", rescheduled.LineageEventId);
        Assert.Equal(25, rescheduled.DueTurnSequence);
        Assert.Equal(6, rescheduled.DueRoundIndex);
        Assert.Equal(4, rescheduled.DuePlayerTurnCounts["p1"]);
        Assert.Equal(3, rescheduled.Priority);
        Assert.Equal(11L, rescheduled.SequenceNumber);
        Assert.Equal(22, rescheduled.CreatedAtTurnSequence);
        Assert.Equal(EventCancellation.Active, rescheduled.Status);
    }

    [Fact]
    public void Cancelled_SetsTerminalStateAndPreservesLineage()
    {
        var original = ScheduledEventRecord.CreateNew("test", 10, 2, new(), EffectPhase.TurnStart, 0, 1, null, 5, "{}", 10, "eid");
        var cancelled = original.Cancelled(25);

        Assert.Equal(EventCancellation.Cancelled, cancelled.Status);
        Assert.Equal(25, cancelled.CreatedAtTurnSequence);
        Assert.Equal("eid", cancelled.LineageEventId);
        Assert.True(cancelled.IsTerminal);
    }

    [Fact]
    public void Fired_SetsTerminalState()
    {
        var original = ScheduledEventRecord.CreateNew("test", 10, 2, new(), EffectPhase.TurnStart, 0, 1, null, 5, "{}", 10, "eid");
        var fired = original.Fired(30);

        Assert.Equal(EventCancellation.Fired, fired.Status);
        Assert.Equal(30, fired.CreatedAtTurnSequence);
        Assert.True(fired.IsTerminal);
    }

    [Fact]
    public void JsonRoundTrip_PreservesAllFields()
    {
        var eventId = IdGenerator.NewDeterministicId("sched", 99, 0);
        var original = ScheduledEventRecord.CreateNew(
            "test_effect", 100, 7,
            new Dictionary<string, int> { { "p1", 10 }, { "p2", 5 } },
            EffectPhase.EventProcessing, 42, 12345, "territory_42", 50,
            "{\"custom\":\"data\"}", 100, eventId);

        var json = JsonSerializer.Serialize(original, JsonOptions);
        var deserialized = JsonSerializer.Deserialize<ScheduledEventRecord>(json, JsonOptions);

        Assert.NotNull(deserialized);
        Assert.Equal(original.EventId, deserialized.EventId);
        Assert.Equal(original.SchemaVersion, deserialized.SchemaVersion);
        Assert.Equal(original.EventTypeKey, deserialized.EventTypeKey);
        Assert.Equal(original.DueTurnSequence, deserialized.DueTurnSequence);
        Assert.Equal(original.DueRoundIndex, deserialized.DueRoundIndex);
        Assert.Equal(original.DuePlayerTurnCounts, deserialized.DuePlayerTurnCounts);
        Assert.Equal(original.Phase, deserialized.Phase);
        Assert.Equal(original.Priority, deserialized.Priority);
        Assert.Equal(original.SequenceNumber, deserialized.SequenceNumber);
        Assert.Equal(original.TargetEntityId, deserialized.TargetEntityId);
        Assert.Equal(original.IssuerTurnNumber, deserialized.IssuerTurnNumber);
        Assert.Equal(original.PayloadJson, deserialized.PayloadJson);
        Assert.Equal(original.Status, deserialized.Status);
        Assert.Equal(original.CreatedAtTurnSequence, deserialized.CreatedAtTurnSequence);
        Assert.Equal(original.LineageEventId, deserialized.LineageEventId);
    }

    [Fact]
    public void JsonRoundTrip_WithCancellation_PreservesStatus()
    {
        var eventId = IdGenerator.NewDeterministicId("sched", 50, 0);
        var original = ScheduledEventRecord.CreateNew("test", 10, 1, new(), EffectPhase.TurnStart, 0, 1, null, 5, "{}", 10, eventId);
        var cancelled = original.Cancelled(20);

        var json = JsonSerializer.Serialize(cancelled, JsonOptions);
        var deserialized = JsonSerializer.Deserialize<ScheduledEventRecord>(json, JsonOptions);

        Assert.NotNull(deserialized);
        Assert.Equal(EventCancellation.Cancelled, deserialized.Status);
        Assert.Equal(eventId, deserialized.LineageEventId);
    }

    [Fact]
    public void JsonDeserialize_MissingRequiredFields_DoesNotThrowButUsesDefaults()
    {
        // System.Text.Json is lenient by default and uses default values for missing fields
        var json = "{\"eventId\":\"test\",\"schemaVersion\":1}";
        var deserialized = JsonSerializer.Deserialize<ScheduledEventRecord>(json, JsonOptions);

        Assert.NotNull(deserialized);
        Assert.Equal("test", deserialized.EventId);
        Assert.Equal(1, deserialized.SchemaVersion);
        Assert.Equal(0, deserialized.DueTurnSequence);
        Assert.Equal(EventCancellation.Active, deserialized.Status);
    }

    [Fact]
    public void JsonDeserialize_InvalidEventTypeKey_DoesNotThrowButRecordHasEmptyKey()
    {
        var json = "{\"eventId\":\"test\",\"schemaVersion\":1,\"eventTypeKey\":\"\",\"dueTurnSequence\":0,\"dueRoundIndex\":0,\"duePlayerTurnCounts\":{},\"phase\":0,\"priority\":0,\"sequenceNumber\":0,\"targetEntityId\":null,\"issuerTurnNumber\":0,\"payloadJson\":\"{}\",\"status\":0,\"createdAtTurnSequence\":0,\"lineageEventId\":null}";
        var deserialized = JsonSerializer.Deserialize<ScheduledEventRecord>(json, JsonOptions);
        Assert.NotNull(deserialized);
        Assert.Equal("", deserialized.EventTypeKey);
    }

    [Fact]
    public void JsonDeserialize_InvalidPayloadJson_DoesNotThrowButPayloadIsRawString()
    {
        var json = "{\"eventId\":\"test\",\"schemaVersion\":1,\"eventTypeKey\":\"test\",\"dueTurnSequence\":0,\"dueRoundIndex\":0,\"duePlayerTurnCounts\":{},\"phase\":0,\"priority\":0,\"sequenceNumber\":0,\"targetEntityId\":null,\"issuerTurnNumber\":0,\"payloadJson\":\"not valid json\",\"status\":0,\"createdAtTurnSequence\":0,\"lineageEventId\":null}";
        var deserialized = JsonSerializer.Deserialize<ScheduledEventRecord>(json, JsonOptions);
        Assert.NotNull(deserialized);
        Assert.Equal("not valid json", deserialized.PayloadJson);
    }

    [Fact]
    public void DeterministicId_ReproducibleAcrossCalls()
    {
        var id1 = IdGenerator.NewDeterministicId("sched", 123, 0);
        var id2 = IdGenerator.NewDeterministicId("sched", 123, 0);
        Assert.Equal(id1, id2);
    }

    [Fact]
    public void OrderingMetadata_PreservedInJson()
    {
        var eventId = IdGenerator.NewDeterministicId("sched", 77, 0);
        var record = ScheduledEventRecord.CreateNew(
            "order_test", 5, 2, new() { { "p1", 3 } },
            EffectPhase.TurnEnd, 10, 999, "target", 1, "{}", 5, eventId);

        var json = JsonSerializer.Serialize(record, JsonOptions);
        var deserialized = JsonSerializer.Deserialize<ScheduledEventRecord>(json, JsonOptions);

        Assert.NotNull(deserialized);
        Assert.Equal(record.DueTurnSequence, deserialized.DueTurnSequence);
        Assert.Equal(record.DueRoundIndex, deserialized.DueRoundIndex);
        Assert.Equal(record.Priority, deserialized.Priority);
        Assert.Equal(record.SequenceNumber, deserialized.SequenceNumber);
        Assert.Equal(record.Phase, deserialized.Phase);
    }

    [Fact]
    public void Phase_EnumSerializesAsString()
    {
        var record = ScheduledEventRecord.CreateNew("test", 0, 0, new(), EffectPhase.TurnStart, 0, 0, null, 0, "{}", 0, "id");
        var json = JsonSerializer.Serialize(record, JsonOptions);
        Assert.Contains("\"phase\":\"TurnStart\"", json);

        record = record with { Phase = EffectPhase.EventProcessing };
        json = JsonSerializer.Serialize(record, JsonOptions);
        Assert.Contains("\"phase\":\"EventProcessing\"", json);

        record = record with { Phase = EffectPhase.TurnEnd };
        json = JsonSerializer.Serialize(record, JsonOptions);
        Assert.Contains("\"phase\":\"TurnEnd\"", json);
    }

    [Fact]
    public void Status_EnumSerializesAsString()
    {
        var record = ScheduledEventRecord.CreateNew("test", 0, 0, new(), EffectPhase.TurnStart, 0, 0, null, 0, "{}", 0, "id");
        var json = JsonSerializer.Serialize(record, JsonOptions);
        Assert.Contains("\"status\":\"Active\"", json);

        record = record with { Status = EventCancellation.Cancelled };
        json = JsonSerializer.Serialize(record, JsonOptions);
        Assert.Contains("\"status\":\"Cancelled\"", json);
    }

    [Fact]
    public void EmptyPlayerTurnCounts_SerializesAsEmptyObject()
    {
        var record = ScheduledEventRecord.CreateNew("test", 0, 0, new(), EffectPhase.TurnStart, 0, 0, null, 0, "{}", 0, "id");
        var json = JsonSerializer.Serialize(record, JsonOptions);
        Assert.Contains("\"duePlayerTurnCounts\":{}", json);
    }
}