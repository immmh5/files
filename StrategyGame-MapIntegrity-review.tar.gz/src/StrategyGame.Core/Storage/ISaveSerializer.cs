namespace StrategyGame.Core.Storage;

using StrategyGame.Core.Domain;

/// <summary>
/// Serialization interface for persisting and restoring game state.
/// No Godot dependencies.
/// </summary>
public interface ISaveSerializer
{
    /// <summary>Serializes the game state to a byte array.</summary>
    byte[] Serialize(Core.GameState.GameState state);

    /// <summary>Deserializes game state from a byte array.</summary>
    Core.GameState.GameState Deserialize(byte[] data);

    /// <summary>Serializes a map definition to JSON for external tools.</summary>
    string ExportMapJson(MapDefinition map);
}

/// <summary>
/// Map loader interface. Loads map definitions from files or streams.
/// </summary>
public interface IMapLoader
{
    /// <summary>
    /// Loads a map definition from the given path (JSON format supported).
    /// Returns null if the map is not found or invalid.
    /// </summary>
    MapDefinition? LoadMap(string path);

    /// <summary>
    /// Lists all available map files in the given directory.
    /// </summary>
    IReadOnlyList<string> ListAvailableMaps(string directory);
}
