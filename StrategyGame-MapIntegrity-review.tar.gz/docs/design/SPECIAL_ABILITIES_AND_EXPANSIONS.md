# SPECIAL_ABILITIES_AND_EXPANSIONS.md

**Status:** PROPOSED DESIGN

---

## 1. Framework Design

Special abilities are modular, independently configurable, and loaded from data files. No ability code is hardcoded into game rules.

## 2. Ability Architecture

```
Ability
  ├─ trigger (event-based)
  ├─ conditions (state predicates)
  ├─ effects (state modifications)
  └─ cooldown (rounds)
```

## 3. Category 2 — Planned Expansion

### 3.1 Cards
- Action cards with one-time effects
- Draw from deck each turn
- Play during Planning phase

### 3.2 Random Events
- Scheduled with probability
- Environmental effects (flood, plague)
- Fictional strategic events

### 3.3 Technology
- Faction-wide tech tree
- Economic and military branches
- Unlocks new abilities

### 3.4 Environmental Effects
- Terrain changes
- Weather effects
- Supply disruption

## 4. Category 3 — Optional Experimental

### 4.1 Scenario-Specific Rules
- Custom victory conditions
- Unique map rules
- Special faction abilities

### 4.2 Advanced Diplomacy
- Alliance formation
- Trade agreements
- Betrayal mechanics

## 5. Implementation Guidance

- All abilities are data-driven
- No ability code in game rules
- Testable via unit tests
- Modular loading system