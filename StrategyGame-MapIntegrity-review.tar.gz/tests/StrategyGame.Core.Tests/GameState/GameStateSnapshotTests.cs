namespace StrategyGame.Core.Tests.GameState;

using StrategyGame.Core.Domain;
using StrategyGame.Core.GameState;
using Xunit;

public class GameStateSnapshotTests
{
    private static GameState CreateTestState()
    {
        var map = new MapDefinition("test-map", "Test Map", new[]
        {
            new Territory("A", "Alpha", ["B"]),
            new Territory("B", "Bravo", ["A"]),
        });

        var player1 = new Player("p1", "Alice", new Faction("f1", "Red", "#FF0000"), true);
        var player2 = new Player("p2", "Bob", new Faction("f2", "Blue", "#0000FF"), false);

        var state = new GameState("g1", map, new List<Player> { player1, player2 }, "p1", 1, "Reinforce");

        state.GetTerritory("A").SetOwner("p1", 5);
        state.GetTerritory("B").SetOwner("p2", 3);

        return state;
    }

    [Fact]
    public void Snapshot_PlayerArmiesToPlace_NotSharedWithOriginal()
    {
        var state = CreateTestState();
        var player = state.GetPlayer("p1");
        player.AddArmies(5);

        var snapshot = state.Snapshot();

        // Modify original after snapshot
        player.AddArmies(10);

        // Snapshot should have the value at snapshot time (5), not the modified value (15)
        var snapshotPlayer = snapshot.GetPlayer("p1");
        Assert.Equal(5, snapshotPlayer.ArmiesToPlace);
    }

    [Fact]
    public void Snapshot_TerritoryOwnership_NotSharedWithOriginal()
    {
        var state = CreateTestState();

        var snapshot = state.Snapshot();

        // Modify original after snapshot
        state.GetTerritory("A").SetOwner("p2", 10);

        // Snapshot should retain original ownership
        var snapshotTerritory = snapshot.GetTerritory("A");
        Assert.Equal("p1", snapshotTerritory.OwnerPlayerId);
        Assert.Equal(5, snapshotTerritory.Armies);
    }

    [Fact]
    public void Snapshot_TerritoryArmies_NotSharedWithOriginal()
    {
        var state = CreateTestState();

        var snapshot = state.Snapshot();

        // Modify original after snapshot
        state.GetTerritory("A").AddArmies(10);

        // Snapshot should retain original army count
        var snapshotTerritory = snapshot.GetTerritory("A");
        Assert.Equal(5, snapshotTerritory.Armies);
    }

    [Fact]
    public void Snapshot_PlayerName_NotSharedWithOriginal()
    {
        var state = CreateTestState();
        var player = state.GetPlayer("p1");

        var snapshot = state.Snapshot();

        // Modify original after snapshot (via reflection since Name has private setter)
        // Note: Name has private setter, but we can test that snapshot captures the value
        var originalName = player.Name;
        var snapshotName = snapshot.GetPlayer("p1").Name;
        Assert.Equal(originalName, snapshotName);
    }

    [Fact]
    public void Snapshot_IsDeepCopy_DifferentReferences()
    {
        var state = CreateTestState();

        var snapshot = state.Snapshot();

        Assert.NotSame(state, snapshot);
        Assert.NotSame(state.GetPlayer("p1"), snapshot.GetPlayer("p1"));
        Assert.NotSame(state.GetTerritory("A"), snapshot.GetTerritory("A"));
    }

    [Fact]
    public void Snapshot_PlayersCollection_NotShared()
    {
        var state = CreateTestState();

        var snapshot = state.Snapshot();

        // The collections should be different instances
        Assert.NotSame(state.Players, snapshot.Players);

        // Modifying original collection shouldn't affect snapshot
        // (though Players is IReadOnlyList, the underlying list could be cast)
        var originalList = state.Players as List<Player>;
        if (originalList != null)
        {
            // This tests that the snapshot has its own copy of the list
            Assert.NotSame(originalList, snapshot.Players);
        }
    }

    [Fact]
    public void Snapshot_TerritoriesDictionary_NotShared()
    {
        var state = CreateTestState();

        var snapshot = state.Snapshot();

        Assert.NotSame(state.Territories, snapshot.Territories);
    }

    [Fact]
    public void Snapshot_MutationDoesNotAffectOriginalOrOtherSnapshots()
    {
        var state = CreateTestState();
        var player = state.GetPlayer("p1");
        player.AddArmies(5);

        // Create two snapshots
        var snapshot1 = state.Snapshot();
        var snapshot2 = state.Snapshot();

        // Mutate player in first snapshot
        var snapshot1Player = snapshot1.GetPlayer("p1");
        snapshot1Player.AddArmies(10);

        // Original state should be unchanged (still 5)
        var originalPlayer = state.GetPlayer("p1");
        Assert.Equal(5, originalPlayer.ArmiesToPlace);

        // Second snapshot should be unchanged (still 5)
        var snapshot2Player = snapshot2.GetPlayer("p1");
        Assert.Equal(5, snapshot2Player.ArmiesToPlace);

        // First snapshot should reflect mutation (15)
        Assert.Equal(15, snapshot1Player.ArmiesToPlace);
    }
}