# IMPLEMENTATION_ROADMAP.md

**Status:** PROPOSED IMPLEMENTATION PLAN
**Purpose:** Ordered, independently testable tasks to implement the hybrid turn system.

> **⚠️ SUPERSEDED IN PART:** the current milestone-to-milestone dependency plan lives in
> [`M1_ROADMAP.md`](M1_ROADMAP.md) (M1.2–M1.5 and later). The task tables below remain the
> hybrid-turn-system implementation detail for M1.3 planning; reconcile before executing M1.3.

---

## 1. Implementation Principles

| Principle | Enforcement |
|---|---|
| **One task = one testable unit** | Each task has acceptance criteria and test commands |
| **Core first, App second** | Core logic complete before App integration |
| **No giant tasks** | Max 2–3 files per task |
| **Rollback ready** | Each task is reversible (git branch) |
| **No silent decisions** | Every design choice documented in code comments |

---

## 2. Task Sequence

### Phase 0: Foundation (0.5 days)
| Task | Scope | Files |
|---|---|---|
| **T0.1** Type definitions | `TurnStage`, `EffectPhase`, `TurnStage` enum | `Domain/TurnStage.cs`, `Domain/EffectPhase.cs` |
| **T0.2** Event/Effect DTOs | `ScheduledEvent`, `ActiveEffect`, `EffectFiredEvent`, `EffectExpiredEvent` | `Domain/ScheduledEvent.cs`, `Domain/ActiveEffect.cs`, `Events/*` |

### Phase 1: Core Simulation Engines (2 days)
| Task | Scope | Files |
|---|---|---|
| **T1.1** SupplyEngine | Flood-fill supply, attrition application | `Simulation/SupplyEngine.cs` |
| **T1.2** EventScheduler | Schedule/cancel/fire events; duration ticking | `Simulation/EventScheduler.cs` |
| **T1.3** ActionExecutor | Validate & execute move/attack/fortify/place | `Simulation/ActionExecutor.cs` |
| **T1.4** TurnEngine | Stage machine (A→B→C→D); orchestrates 1.1–1.3 | `Simulation/TurnEngine.cs` |

### Phase 2: Integration with Existing Code (1 day)
| Task | Scope | Files |
|---|---|---|
| **T2.1** GameState extension | Add `CurrentStage`, `CurrentTurnNumber`, `TurnEngineSnapshot` | `GameState/GameState.cs` |
| **T2.2** TurnManager migration | Replace string phases with `TurnStage` enum; `AdvanceTurn` uses turn number | `GameState/TurnManager.cs` |
| **T2.3** CombatSystem alignment | Ensure pure function signature matches `ActionExecutor` | `GameState/CombatSystem.cs` (verify only) |

### Phase 3: Tests (1.5 days)
| Task | Scope | Files |
|---|---|---|
| **T3.1** Core unit tests | Combat, Supply, EventScheduler, TurnEngine stages | `tests/StrategyGame.Core.Tests/Simulation/*.cs` |
| **T3.2** Property tests | Combat, Supply, EventScheduler invariants | `tests/StrategyGame.Core.Tests/Property/*.cs` |
| **T3.3** Integration tests | Full turn cycle, 2-player, save/load | `tests/Integration.Tests/Simulation/*.cs` |

### Phase 4: App Integration (1 day)
| Task | Scope | Files |
|---|---|---|
| **T4.1** App TurnController | Bridge `TurnEngine` → Godot; UI callbacks | `Scripts/TurnController.cs` |
| **T4.2** EventBus bridge | Core `IEventBus` → Godot signals | `Scripts/CoreEventBus.cs` |
| **T4.3** UI binding | Turn stage display, action buttons, timer | `Scripts/UI/TurnHUD.cs` |

### Phase 5: Multiplayer Foundation (1 day)
| Task | Scope | Files |
|---|---|---|
| **T5.1** Loopback transport | In-process `INetworkTransport` for testing | `Networking/LoopbackTransport.cs` |
| **T5.2** Host turn sync | Snapshot after each stage; pending event queue sync | `Networking/HostTurnSync.cs` |
| **T5.3** Client mirror | Apply snapshots; render events | `Scripts/ClientGameMirror.cs` |

### Phase 6: Polish & Docs (0.5 days)
| Task | Scope | Files |
|---|---|---|
| **T6.1** Performance profiling | Baseline measurements | N/A |
| **T6.2** Update docs | Architecture docs reflect implementation | `docs/architecture/*.md` |

---

## 3. Detailed Task Specifications

### T1.1 SupplyEngine

**Scope:** Flood-fill supply from capitals/coasts; apply attrition to unsupplied groups.

**Dependencies:** T0.1 (types), existing `MapDefinition`, `Territory`

**Files to Create:**
- `src/StrategyGame.Core/Simulation/SupplyEngine.cs`
- `src/StrategyGame.Core/Simulation/SupplyResult.cs`

**Public API:**
```csharp
public static class SupplyEngine
{
    public static SupplyResult CalculateSupply(GameState state, string playerId);
    public static int ApplyAttrition(GameState state, string playerId);
}
```

**Acceptance Criteria:**
- [ ] Flood-fill from all supply sources (capitals + coasts)
- [ ] Correctly identifies unsupplied groups
- [ ] Attrition: 1 army/territory/turn, min 1 garrison
- [ ] Territory at 0 armies becomes neutral
- [ ] All unit tests pass (`SupplyEngineTests`)

**Test Command:**
```bash
dotnet test tests/StrategyGame.Core.Tests --filter "FullyQualifiedName~SupplyEngine"
```

**Rollback:** Delete `SupplyEngine.cs`, `SupplyResult.cs`; revert any `GameState` changes.

---

### T1.2 EventScheduler

**Scope:** Schedule/cancel/fire events; manage effect durations.

**Dependencies:** T0.1 (types), `GameEvent`, `IEventBus`

**Files to Create:**
- `src/StrategyGame.Core/Simulation/EventScheduler.cs`
- `src/StrategyGame.Core/Simulation/ScheduledEvent.cs` (also in Domain)

**Public API:**
```csharp
public sealed class EventScheduler
{
    public string Schedule(EffectPhase phase, int turnOffset, Action<GameState> execute, Action<GameState>? onExpire = null);
    public bool Cancel(string eventId);
    public IReadOnlyList<ScheduledEvent> GetDueEvents(int currentTurn, EffectPhase phase);
    public void ProcessTurn(int currentTurn, GameState state, IEventBus bus);
    public IEnumerable<ScheduledEvent> GetAllPending();
}
```

**Acceptance Criteria:**
- [ ] Schedule with `(phase, turnOffset)` fires at correct turn/phase
- [ ] Cancel removes event before firing
- [ ] Due events ordered by `(turn, phase, insertionOrder)`
- [ ] Duration effects decrement once per turn in `ProcessTurn`
- [ ] Expired effects fire `OnExpire` and removed
- [ ] `GetAllPending` returns serializable list for save
- [ ] All unit tests pass

**Test Command:**
```bash
dotnet test tests/StrategyGame.Core.Tests --filter "FullyQualifiedName~EventScheduler"
```

---

### T1.3 ActionExecutor

**Scope:** Validate and execute move/attack/fortify/place orders.

**Dependencies:** T1.1 (supply for movement legality), `CombatSystem`, `TurnManager`

**Files to Create:**
- `src/StrategyGame.Core/Simulation/ActionExecutor.cs`
- `src/StrategyGame.Core/Simulation/OrderResult.cs`

**Public API:**
```csharp
public static class ActionExecutor
{
    public static Result<OrderResult> Execute(GameState state, Order order);
    public static IReadOnlyList<Order> GetLegalOrders(GameState state, string playerId);
}
```

**Acceptance Criteria:**
- [ ] Move: validates ownership, armies ≥ 2, adjacency, same player target
- [ ] Attack: validates ownership, armies ≥ 2, adjacency, enemy target
- [ ] Fortify: validates ownership, armies ≥ 2, adjacency, same player, not front line
- [ ] PlaceArmies: validates ownership, `ArmiesToPlace >= armies`
- [ ] All invalid orders return `Result.Fail` with descriptive error
- [ ] Valid orders mutate state, return `Result.Ok` with details
- [ ] All unit tests pass

**Test Command:**
```bash
dotnet test tests/StrategyGame.Core.Tests --filter "FullyQualifiedName~ActionExecutor"
```

---

### T1.4 TurnEngine

**Scope:** Stage machine (A→B→C→D); orchestrates SupplyEngine, ActionExecutor, EventScheduler.

**Dependencies:** T1.1, T1.2, T1.3, `TurnManager`, `VictoryChecker`, `IEventBus`

**Files to Create:**
- `src/StrategyGame.Core/Simulation/TurnEngine.cs`
- `src/StrategyGame.Core/Simulation/TurnEngineSnapshot.cs`

**Public API:**
```csharp
public sealed class TurnEngine
{
    public GameState State { get; }
    public TurnStage CurrentStage => state.CurrentStage;
    public string CurrentPlayerId => state.CurrentTurnPlayerId;
    
    public TurnStartResult ExecuteTurnStart(string playerId);
    public Result<OrderResult> SubmitOrder(Order order);
    public void EndPlayerActions();  // Player clicks "Ready" or timer expires
    public EventProcessingResult ExecuteEventProcessing();
    public TurnEndResult ExecuteTurnEnd();
    
    public TurnEngineSnapshot Snapshot();
    public static TurnEngine Restore(GameState state, TurnEngineSnapshot snap);
}
```

**Acceptance Criteria:**
- [ ] `ExecuteTurnStart` → income, start effects, attrition, advances to B
- [ ] `SubmitOrder` validates, executes, marks territory acted, advances only on `EndPlayerActions`
- [ ] `ExecuteEventProcessing` fires due events, decrements durations, expires effects, advances to D
- [ ] `ExecuteTurnEnd` → end effects, victory check, advances turn/player, advances to A
- [ ] Invalid stage transitions throw `InvalidOperationException`
- [ ] `Snapshot()` / `Restore()` round-trip identical
- [ ] All unit tests pass

**Test Command:**
```bash
dotnet test tests/StrategyGame.Core.Tests --filter "FullyQualifiedName~TurnEngine"
```

---

### T2.1–T2.3 Integration

**Scope:** Wire new engines into existing `GameState`, `TurnManager`, `CombatSystem`.

**Acceptance Criteria:**
- [ ] `GameState` has `CurrentStage` (`TurnStage`), `CurrentTurnNumber` (int), `TurnEngineSnapshot`
- [ ] `TurnManager.AdvanceTurn` returns `(nextPlayerId, nextTurnNumber)` using turn number
- [ ] `TurnManager` no longer uses string phases
- [ ] `CombatSystem` signature unchanged; pure function
- [ ] All existing tests still pass

**Test Command:**
```bash
dotnet test tests/StrategyGame.Core.Tests
dotnet test tests/Integration.Tests
```

---

### T3.1–T3.3 Tests

**Scope:** Complete test coverage for new simulation code.

**Minimum Coverage:**
| Module | Unit Tests | Property Tests |
|---|---|---|
| SupplyEngine | 8 | 2 |
| EventScheduler | 10 | 3 |
| ActionExecutor | 12 | 2 |
| TurnEngine | 15 | 4 |
| TurnEngine (integration) | 5 | 0 |

**Test Command:**
```bash
dotnet test tests/StrategyGame.Core.Tests --filter "Category=Unit"
dotnet test tests/StrategyGame.Core.Tests --filter "Category=Property"
dotnet test tests/Integration.Tests
```

---

### T4.1–T4.3 App Integration

**Scope:** Bridge `TurnEngine` to Godot UI.

**Files to Create:**
| File | Purpose |
|---|---|
| `Scripts/TurnController.cs` | Calls `TurnEngine` stages; manages timer |
| `Scripts/CoreEventBus.cs` | Implements `IEventBus`; forwards to Godot signals |
| `Scripts/UI/TurnHUD.cs` | Displays stage, timer, turn number, player |
| `Scripts/AIPlayerBridge.cs` | Implements `IAIPlayer`; calls `ActionExecutor.GetLegalOrders` |

**Acceptance Criteria:**
- [ ] Editor launch: `run-editor.sh` works
- [ ] Game launch: `run-game.sh` shows turn HUD
- [ ] Turn stages visible in UI
- [ ] Human player can submit orders via UI
- [ ] AI player takes turn automatically
- [ ] Turn timer works (optional, configurable)

**Test Command:**
```bash
./scripts/run-game.sh  # Manual verification
./scripts/verify.sh    # Automated
```

---

### T5.1–T5.3 Multiplayer Foundation

**Scope:** Loopback transport + host-authoritative sync with event queue.

**Files to Create:**
| File | Purpose |
|---|---|
| `Networking/LoopbackTransport.cs` | In-process `INetworkTransport` for testing |
| `Networking/HostTurnSync.cs` | Host: snapshots after each stage + pending event queue |
| `Scripts/ClientGameMirror.cs` | Client: applies snapshots, renders events |

**Acceptance Criteria:**
- [ ] Two clients + host (loopback) complete 10 turns
- [ ] Client state matches host after each snapshot
- [ ] Pending event queue synchronized on reconnect
- [ ] Disconnected client: events pause, resume on reconnect

---

## 4. Dependency Graph

```
T0.1 ──► T1.1 (SupplyEngine)
   │       │
   │       ├────► T1.4 (TurnEngine)
   │       │
   ├──────► T1.2 (EventScheduler)
   │             │
   ├─────────────► T1.4
   │
   └────────────► T1.3 (ActionExecutor)
                     │
                     └────► T1.4

T1.4 ──► T2.1/T2.2/T2.3 (Integration)
           │
           ├────► T3.1/T3.2/T3.3 (Tests)
           │
           └────► T4.1/T4.2/T4.3 (App)
                     │
                     └────► T5.1/T5.2/T5.3 (MP)
```

---

## 5. Rollback Strategy

Each task is on a feature branch `feature/T{N}.{M}-{name}`. Rollback = `git checkout main && git branch -D feature/...`

| Task | Rollback Impact |
|---|---|
| T0.1–T0.2 | Delete 4–6 new files |
| T1.1–T1.4 | Delete 8–12 new files; revert `GameState`/`TurnManager` |
| T2.1–T2.3 | Revert `GameState.cs`, `TurnManager.cs` |
| T3.1–T3.3 | Delete test files |
| T4.1–T4.3 | Delete 4 App scripts |
| T5.1–T5.3 | Delete 3 networking files |

---

## 6. Milestone Gate

**Milestone 2 Ready When:**
- [ ] All T1–T4 tasks complete with passing tests
- [ ] `./scripts/verify.sh` passes (7 steps)
- [ ] `run-editor.sh` and `run-game.sh` work
- [ ] Multiplayer loopback test passes 10 turns
- [ ] No source code in `docs/architecture/` (docs only)
- [ ] No modifications to `src/StrategyGame.Core` outside new files + `GameState`/`TurnManager` updates

---

## 7. Estimated Timeline

| Phase | Duration | Cumulative |
|---|---|---|
| Phase 0: Foundation | 0.5 days | 0.5 |
| Phase 1: Core Engines | 2 days | 2.5 |
| Phase 2: Integration | 1 day | 3.5 |
| Phase 3: Tests | 1.5 days | 5 |
| Phase 4: App Integration | 1 day | 6 |
| Phase 5: MP Foundation | 1 day | 7 |
| Phase 6: Polish | 0.5 days | 7.5 |

**Total: ~7.5 working days** (2 weeks with buffer)