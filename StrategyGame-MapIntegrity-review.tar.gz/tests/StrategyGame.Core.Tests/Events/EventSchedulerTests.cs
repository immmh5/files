namespace StrategyGame.Core.Tests.Events;

using System.Text.Json;
using StrategyGame.Core.Events;
using System.Collections.Generic;
using Xunit;

/// <summary>
/// R4.5 regression tests: EventScheduler Core scheduling, queries, cancellation, rescheduling.
/// </summary>
public class EventSchedulerTests
{
    private static ScheduledEventRecord MakeRoundEvent(
        string id, int dueRound, int priority = 0, long seq = 0)
    {
        var record = ScheduledEventRecord.CreateWithPayload(
            id, "autumn_attrition", 1,
            new RoundTiming(dueRound), null,
            new() { ["regions"] = JsonSerializer.SerializeToElement(new[] { "north" }) });
        return record with { Priority = priority, SequenceNumber = seq };
    }

    private static ScheduledEventRecord MakePlayerEvent(
        string id, string playerId, int dueTurn, int priority = 0, long seq = 0)
    {
        var record = ScheduledEventRecord.CreateWithPayload(
            id, "berserk_rage", 1,
            null, new PlayerTurnTiming(playerId, dueTurn),
            new() { ["attackBonus"] = JsonSerializer.SerializeToElement(2) });
        return record with { Priority = priority, SequenceNumber = seq };
    }

    // -------------------------------------------------------------
    // 1. Valid scheduling
    // -------------------------------------------------------------
    [Fact]
    public void Schedule_ValidRecord_Accepted()
    {
        var scheduler = new EventScheduler();
        var record = MakeRoundEvent("evt_1", 3);

        scheduler.Schedule(record);

        Assert.True(scheduler.Contains("evt_1"));
        Assert.Equal(1, scheduler.Count);
    }

    // -------------------------------------------------------------
    // 2. Invalid scheduling arguments
    // -------------------------------------------------------------
    [Fact]
    public void Schedule_NullRecord_Throws()
    {
        var scheduler = new EventScheduler();
        Assert.Throws<ArgumentNullException>(() => scheduler.Schedule(null!));
    }

    [Fact]
    public void Schedule_EmptyEventId_Throws()
    {
        var scheduler = new EventScheduler();
        var record = MakeRoundEvent("", 3);
        Assert.Throws<ScheduledEventValidationException>(() => scheduler.Schedule(record));
    }

    // -------------------------------------------------------------
    // 3. Duplicate EventId rejection
    // -------------------------------------------------------------
    [Fact]
    public void Schedule_DuplicateEventId_Throws()
    {
        var scheduler = new EventScheduler();
        var record = MakeRoundEvent("evt_1", 3);
        scheduler.Schedule(record);

        var duplicate = MakeRoundEvent("evt_1", 5);
        Assert.Throws<ArgumentException>(() => scheduler.Schedule(duplicate));
    }

    // -------------------------------------------------------------
    // 4. Due-event lookup
    // -------------------------------------------------------------
    [Fact]
    public void GetDueEvents_RoundTimed_ReturnsOnlyDue()
    {
        var scheduler = new EventScheduler();
        scheduler.Schedule(MakeRoundEvent("evt_1", 3));
        scheduler.Schedule(MakeRoundEvent("evt_2", 5));
        scheduler.Schedule(MakeRoundEvent("evt_3", 7));

        var due = scheduler.GetDueEvents(new SchedulerQuery { CurrentRoundIndex = 5, CurrentStage = ExecutionStage.EventProcessing });

        Assert.Equal(2, due.Count);
        Assert.Contains(due, e => e.EventId == "evt_1");
        Assert.Contains(due, e => e.EventId == "evt_2");
        Assert.DoesNotContain(due, e => e.EventId == "evt_3");
    }

    [Fact]
    public void GetDueEvents_PlayerTimed_ReturnsOnlyDue()
    {
        var scheduler = new EventScheduler();
        scheduler.Schedule(MakePlayerEvent("evt_1", "p1", 3));
        scheduler.Schedule(MakePlayerEvent("evt_2", "p1", 6));
        scheduler.Schedule(MakePlayerEvent("evt_3", "p2", 4));

        var due = scheduler.GetDueEvents(new SchedulerQuery
        {
            CurrentPlayerTurnCounts = new Dictionary<string, int> { ["p1"] = 4, ["p2"] = 4 }
        });

        Assert.Equal(2, due.Count);
        Assert.Contains(due, e => e.EventId == "evt_1");
        Assert.Contains(due, e => e.EventId == "evt_3");
        Assert.DoesNotContain(due, e => e.EventId == "evt_2");
    }

    // -------------------------------------------------------------
    // 5. Future events excluded from due results
    // -------------------------------------------------------------
    [Fact]
    public void GetDueEvents_FutureEvents_Excluded()
    {
        var scheduler = new EventScheduler();
        scheduler.Schedule(MakeRoundEvent("evt_1", 10));

        var due = scheduler.GetDueEvents(new SchedulerQuery { CurrentRoundIndex = 5, CurrentStage = ExecutionStage.EventProcessing });
        Assert.Empty(due);
    }

    // -------------------------------------------------------------
    // 6. Stable ordering: due-time → priority → sequence number
    // -------------------------------------------------------------
    [Fact]
    public void GetDueEvents_StableOrdering_DueTimeThenPriorityThenSequence()
    {
        var scheduler = new EventScheduler();
        // Same due time (round 5), different priorities
        scheduler.Schedule(MakeRoundEvent("evt_low", 5, priority: 5, seq: 1));
        scheduler.Schedule(MakeRoundEvent("evt_high", 5, priority: 1, seq: 2));
        scheduler.Schedule(MakeRoundEvent("evt_mid", 5, priority: 3, seq: 3));

        var due = scheduler.GetDueEvents(new SchedulerQuery { CurrentRoundIndex = 5, CurrentStage = ExecutionStage.EventProcessing });

        // Priority 1 (high) should come first, then 3, then 5
        Assert.Equal(new[] { "evt_high", "evt_mid", "evt_low" },
            due.Select(e => e.EventId).ToArray());
    }

    [Fact]
    public void GetDueEvents_TieOnPriority_SequenceNumberBreaks()
    {
        var scheduler = new EventScheduler();
        scheduler.Schedule(MakeRoundEvent("evt_1", 5, priority: 1, seq: 10));
        scheduler.Schedule(MakeRoundEvent("evt_2", 5, priority: 1, seq: 5));
        scheduler.Schedule(MakeRoundEvent("evt_3", 5, priority: 1, seq: 15));

        var due = scheduler.GetDueEvents(new SchedulerQuery { CurrentRoundIndex = 5, CurrentStage = ExecutionStage.EventProcessing });

        // SequenceNumber ascending breaks tie
        Assert.Equal(new[] { "evt_2", "evt_1", "evt_3" },
            due.Select(e => e.EventId).ToArray());
    }

    // -------------------------------------------------------------
    // 7. Equal timing and sequence tie cases (fully equal ordering)
    // -------------------------------------------------------------
    [Fact]
    public void GetDueEvents_AllEqual_ReturnsDeterministicOrder()
    {
        var scheduler = new EventScheduler();
        // Due-time, priority, sequence all equal — stable order by EventId
        scheduler.Schedule(MakeRoundEvent("evt_b", 5, priority: 1, seq: 1));
        scheduler.Schedule(MakeRoundEvent("evt_a", 5, priority: 1, seq: 1));

        var due = scheduler.GetDueEvents(new SchedulerQuery { CurrentRoundIndex = 5, CurrentStage = ExecutionStage.EventProcessing });

        // Should be deterministic (EventId comparison as final tie-break)
        Assert.Equal(2, due.Count);
        Assert.Equal(new[] { "evt_a", "evt_b" }, due.Select(e => e.EventId).ToArray());
    }

    // -------------------------------------------------------------
    // 8. Cancellation
    // -------------------------------------------------------------
    [Fact]
    public void Cancel_ExistingEvent_ReturnsTrueAndMarksCancelled()
    {
        var scheduler = new EventScheduler();
        scheduler.Schedule(MakeRoundEvent("evt_1", 3));

        var cancelled = scheduler.Cancel("evt_1");

        Assert.True(cancelled);
        Assert.True(scheduler.Contains("evt_1")); // Event still exists but is Cancelled
        Assert.Equal(0, scheduler.Count); // Count only counts Pending
        var evt = scheduler.TryGetEvent("evt_1");
        Assert.NotNull(evt);
        Assert.Equal(ScheduledEventStatus.Cancelled, evt!.Status);
    }

    [Fact]
    public void Cancel_NonexistentEvent_ReturnsFalse()
    {
        var scheduler = new EventScheduler();
        var cancelled = scheduler.Cancel("nonexistent");
        Assert.False(cancelled);
    }

    [Fact]
    public void Cancel_EmptyId_ReturnsFalse()
    {
        var scheduler = new EventScheduler();
        var cancelled = scheduler.Cancel("");
        Assert.False(cancelled);
    }

    [Fact]
    public void Cancel_AlreadyCancelled_ReturnsFalse()
    {
        var scheduler = new EventScheduler();
        scheduler.Schedule(MakeRoundEvent("evt_1", 3));
        scheduler.Cancel("evt_1");

        var secondCancel = scheduler.Cancel("evt_1");
        Assert.False(secondCancel); // event is removed, second call returns false
        Assert.Equal(0, scheduler.Count);
    }

    // -------------------------------------------------------------
    // 9. Unknown event cancellation
    // -------------------------------------------------------------
    [Fact]
    public void Cancel_UnknownEventId_DoesNotThrow()
    {
        var scheduler = new EventScheduler();
        scheduler.Cancel("unknown"); // should not throw
    }

    // -------------------------------------------------------------
    // 10. Rescheduling
    // -------------------------------------------------------------
    [Fact]
    public void Reschedule_ExistingEvent_UpdatesTiming()
    {
        var scheduler = new EventScheduler();
        scheduler.Schedule(MakeRoundEvent("evt_1", 3));

        var updated = scheduler.Reschedule("evt_1", new RoundTiming(7));

        Assert.NotNull(updated);
        Assert.Equal(7, updated!.RoundTiming!.DueRoundIndex);
        Assert.Equal("evt_1", updated.EventId);
    }

    [Fact]
    public void Reschedule_NonexistentEvent_ReturnsNull()
    {
        var scheduler = new EventScheduler();
        var updated = scheduler.Reschedule("missing", new RoundTiming(5));
        Assert.Null(updated);
    }

    [Fact]
    public void Reschedule_EmptyId_ReturnsNull()
    {
        var scheduler = new EventScheduler();
        var updated = scheduler.Reschedule("", new RoundTiming(5));
        Assert.Null(updated);
    }

    [Fact]
    public void Reschedule_PlayerEvent_UpdatesPlayerTurnCount()
    {
        var scheduler = new EventScheduler();
        scheduler.Schedule(MakePlayerEvent("evt_1", "p1", 3));

        var updated = scheduler.Reschedule("evt_1", new PlayerTurnTiming("p1", 10));

        Assert.NotNull(updated);
        Assert.Equal(10, updated!.PlayerTiming!.DuePlayerTurnCount);
        Assert.Equal("p1", updated.PlayerTiming.PlayerId);
    }

    // -------------------------------------------------------------
    // 11. Rescheduling collision handling
    // -------------------------------------------------------------
    [Fact]
    public void Reschedule_ToDuplicateTiming_AllowsMultipleEvents()
    {
        var scheduler = new EventScheduler();
        scheduler.Schedule(MakeRoundEvent("evt_1", 3));
        scheduler.Schedule(MakeRoundEvent("evt_2", 5));

        var updated = scheduler.Reschedule("evt_1", new RoundTiming(5));

        // Both evt_1 and evt_2 now due at round 5 — both should appear
        var due = scheduler.GetDueEvents(new SchedulerQuery { CurrentRoundIndex = 5, CurrentStage = ExecutionStage.EventProcessing });
        Assert.Equal(2, due.Count);
    }

    // -------------------------------------------------------------
    // 12. Queries
    // -------------------------------------------------------------
    [Fact]
    public void TryGetEvent_ExistingEvent_ReturnsRecord()
    {
        var scheduler = new EventScheduler();
        scheduler.Schedule(MakeRoundEvent("evt_1", 3));

        var record = scheduler.TryGetEvent("evt_1");

        Assert.NotNull(record);
        Assert.Equal("evt_1", record!.EventId);
    }

    [Fact]
    public void TryGetEvent_MissingEvent_ReturnsNull()
    {
        var scheduler = new EventScheduler();
        var record = scheduler.TryGetEvent("missing");
        Assert.Null(record);
    }

    [Fact]
    public void GetScheduledEvents_ReturnsAllEventsIncludingCancelled()
    {
        var scheduler = new EventScheduler();
        scheduler.Schedule(MakeRoundEvent("evt_1", 3));
        scheduler.Schedule(MakeRoundEvent("evt_2", 5));
        scheduler.Cancel("evt_1");

        var all = scheduler.GetScheduledEvents();

        Assert.Equal(2, all.Count); // Both evt_1 (cancelled) and evt_2 (pending)
        Assert.Contains(all, e => e.EventId == "evt_1" && e.Status == ScheduledEventStatus.Cancelled);
        Assert.Contains(all, e => e.EventId == "evt_2" && e.Status == ScheduledEventStatus.Pending);
    }

    // -------------------------------------------------------------
    // 13. Defensive collection ownership
    // -------------------------------------------------------------
    [Fact]
    public void GetDueEvents_ReturnsReadOnlyCollection()
    {
        var scheduler = new EventScheduler();
        scheduler.Schedule(MakeRoundEvent("evt_1", 3));

        var due = scheduler.GetDueEvents(new SchedulerQuery { CurrentRoundIndex = 5, CurrentStage = ExecutionStage.EventProcessing });

        Assert.IsAssignableFrom<IReadOnlyList<ScheduledEventRecord>>(due);
        // The returned collection should be isolated
        Assert.False(due is List<ScheduledEventRecord>);
    }

    [Fact]
    public void GetScheduledEvents_ReturnsReadOnlyCollection()
    {
        var scheduler = new EventScheduler();
        scheduler.Schedule(MakeRoundEvent("evt_1", 3));

        var all = scheduler.GetScheduledEvents();

        Assert.IsAssignableFrom<IReadOnlyList<ScheduledEventRecord>>(all);
        Assert.False(all is List<ScheduledEventRecord>);
    }

    // -------------------------------------------------------------
    // 14. Repeated queries producing identical ordering
    // -------------------------------------------------------------
    [Fact]
    public void GetDueEvents_RepeatedQueries_IdenticalOrdering()
    {
        var scheduler = new EventScheduler();
        scheduler.Schedule(MakeRoundEvent("evt_1", 5, priority: 1, seq: 1));
        scheduler.Schedule(MakeRoundEvent("evt_2", 5, priority: 1, seq: 2));

        var order1 = scheduler.GetDueEvents(new SchedulerQuery { CurrentRoundIndex = 5, CurrentStage = ExecutionStage.EventProcessing });
        var order2 = scheduler.GetDueEvents(new SchedulerQuery { CurrentRoundIndex = 5, CurrentStage = ExecutionStage.EventProcessing });

        Assert.Equal(order1.Select(e => e.EventId), order2.Select(e => e.EventId));
    }

    // -------------------------------------------------------------
    // 15. Empty scheduler behavior
    // -------------------------------------------------------------
    [Fact]
    public void EmptyScheduler_GetDueEvents_ReturnsEmpty()
    {
        var scheduler = new EventScheduler();
        var due = scheduler.GetDueEvents(new SchedulerQuery { CurrentRoundIndex = 5, CurrentStage = ExecutionStage.EventProcessing });
        Assert.Empty(due);
    }

    [Fact]
    public void EmptyScheduler_GetScheduledEvents_ReturnsEmpty()
    {
        var scheduler = new EventScheduler();
        var all = scheduler.GetScheduledEvents();
        Assert.Empty(all);
    }

    [Fact]
    public void EmptyScheduler_Count_ReturnsZero()
    {
        var scheduler = new EventScheduler();
        Assert.Equal(0, scheduler.Count);
    }

    [Fact]
    public void EmptyScheduler_TryGetEvent_ReturnsNull()
    {
        var scheduler = new EventScheduler();
        var record = scheduler.TryGetEvent("any");
        Assert.Null(record);
    }

    [Fact]
    public void EmptyScheduler_Cancel_ReturnsFalse()
    {
        var scheduler = new EventScheduler();
        Assert.False(scheduler.Cancel("any"));
    }

    [Fact]
    public void EmptyScheduler_Reschedule_ReturnsNull()
    {
        var scheduler = new EventScheduler();
        var updated = scheduler.Reschedule("any", new RoundTiming(5));
        Assert.Null(updated);
    }

    // -------------------------------------------------------------
    // 16. Reschedule validation
    // -------------------------------------------------------------

    [Fact]
    public void Reschedule_RoundTiming_NegativeDueRoundIndex_Throws()
    {
        var scheduler = new EventScheduler();
        scheduler.Schedule(MakeRoundEvent("evt_1", 5));

        var ex = Assert.Throws<ArgumentException>(() => scheduler.Reschedule("evt_1", new RoundTiming(-1)));
        Assert.Contains("DueRoundIndex must be >= 0", ex.Message);
    }

    [Fact]
    public void Reschedule_PlayerTurnTiming_NegativeDuePlayerTurnCount_Throws()
    {
        var scheduler = new EventScheduler();
        scheduler.Schedule(MakePlayerEvent("evt_1", "p1", 5));

        var ex = Assert.Throws<ArgumentException>(() => scheduler.Reschedule("evt_1", new PlayerTurnTiming("p1", -1)));
        Assert.Contains("DuePlayerTurnCount must be >= 0", ex.Message);
    }

    [Fact]
    public void Reschedule_RoundTiming_NegativeFails_OriginalTimingPreserved()
    {
        var scheduler = new EventScheduler();
        scheduler.Schedule(MakeRoundEvent("evt_1", 5));

        Assert.Throws<ArgumentException>(() => scheduler.Reschedule("evt_1", new RoundTiming(-1)));

        var record = scheduler.TryGetEvent("evt_1");
        Assert.NotNull(record);
        Assert.Equal(5, record!.RoundTiming!.DueRoundIndex);
    }

    [Fact]
    public void Reschedule_PlayerTurnTiming_NegativeFails_OriginalTimingPreserved()
    {
        var scheduler = new EventScheduler();
        scheduler.Schedule(MakePlayerEvent("evt_1", "p1", 5));

        Assert.Throws<ArgumentException>(() => scheduler.Reschedule("evt_1", new PlayerTurnTiming("p1", -1)));

        var record = scheduler.TryGetEvent("evt_1");
        Assert.NotNull(record);
        Assert.Equal(5, record!.PlayerTiming!.DuePlayerTurnCount);
    }

    [Fact]
    public void Reschedule_RoundTiming_NegativeFails_OriginalRecordUnchanged()
    {
        var scheduler = new EventScheduler();
        var original = MakeRoundEvent("evt_1", 5, priority: 2, seq: 100);
        scheduler.Schedule(original);

        Assert.Throws<ArgumentException>(() => scheduler.Reschedule("evt_1", new RoundTiming(-1)));

        var record = scheduler.TryGetEvent("evt_1");
        Assert.NotNull(record);
        Assert.Equal(original.EventId, record!.EventId);
        Assert.Equal(original.EventTypeKey, record.EventTypeKey);
        Assert.Equal(original.SchemaVersion, record.SchemaVersion);
        Assert.Equal(original.ScheduledAtTurnSequence, record.ScheduledAtTurnSequence);
        Assert.Equal(original.ExecutionStage, record.ExecutionStage);
        Assert.Equal(original.Priority, record.Priority);
        Assert.Equal(original.SequenceNumber, record.SequenceNumber);
        Assert.Equal(original.Status, record.Status);
        Assert.Equal(original.RoundTiming, record.RoundTiming);
        Assert.Null(record.PlayerTiming);
    }

    [Fact]
    public void Reschedule_PlayerTurnTiming_NegativeFails_OriginalRecordUnchanged()
    {
        var scheduler = new EventScheduler();
        var original = MakePlayerEvent("evt_1", "p1", 5, priority: 2, seq: 100);
        scheduler.Schedule(original);

        Assert.Throws<ArgumentException>(() => scheduler.Reschedule("evt_1", new PlayerTurnTiming("p1", -1)));

        var record = scheduler.TryGetEvent("evt_1");
        Assert.NotNull(record);
        Assert.Equal(original.EventId, record!.EventId);
        Assert.Equal(original.EventTypeKey, record.EventTypeKey);
        Assert.Equal(original.SchemaVersion, record.SchemaVersion);
        Assert.Equal(original.ScheduledAtTurnSequence, record.ScheduledAtTurnSequence);
        Assert.Equal(original.ExecutionStage, record.ExecutionStage);
        Assert.Equal(original.Priority, record.Priority);
        Assert.Equal(original.SequenceNumber, record.SequenceNumber);
        Assert.Equal(original.Status, record.Status);
        Assert.Equal(original.PlayerTiming, record.PlayerTiming);
        Assert.Null(record.RoundTiming);
    }

    [Fact]
    public void Reschedule_RoundTiming_NegativeFails_EventStillQueryable()
    {
        var scheduler = new EventScheduler();
        scheduler.Schedule(MakeRoundEvent("evt_1", 5));

        Assert.Throws<ArgumentException>(() => scheduler.Reschedule("evt_1", new RoundTiming(-1)));

        Assert.True(scheduler.Contains("evt_1"));
        Assert.Equal(1, scheduler.Count);

        var due = scheduler.GetDueEvents(new SchedulerQuery { CurrentRoundIndex = 5, CurrentStage = ExecutionStage.EventProcessing });
        Assert.Single(due);
        Assert.Equal("evt_1", due[0].EventId);
    }

    [Fact]
    public void Reschedule_ValidRoundTiming_Succeeds()
    {
        var scheduler = new EventScheduler();
        scheduler.Schedule(MakeRoundEvent("evt_1", 3));

        var updated = scheduler.Reschedule("evt_1", new RoundTiming(7));

        Assert.NotNull(updated);
        Assert.Equal(7, updated!.RoundTiming!.DueRoundIndex);
        Assert.Equal("evt_1", updated.EventId);
    }

    [Fact]
    public void Reschedule_ValidPlayerTurnTiming_Succeeds()
    {
        var scheduler = new EventScheduler();
        scheduler.Schedule(MakePlayerEvent("evt_1", "p1", 3));

        var updated = scheduler.Reschedule("evt_1", new PlayerTurnTiming("p1", 10));

        Assert.NotNull(updated);
        Assert.Equal(10, updated!.PlayerTiming!.DuePlayerTurnCount);
        Assert.Equal("p1", updated.PlayerTiming.PlayerId);
        Assert.Equal("evt_1", updated.EventId);
    }
}