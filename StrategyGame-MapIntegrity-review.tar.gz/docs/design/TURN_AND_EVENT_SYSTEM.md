# TURN_AND_EVENT_SYSTEM.md

**Status:** USER-APPROVED PROVISIONAL DESIGN (hybrid turn system)
**Supersedes:** earlier simultaneous-planning round loop in `CORE_GAME_LOOP.md`
**Approved by:** user selection of "HYBRID TURN SYSTEM" (Milestone 1.1)

---

## 1. Mandatory Distinctions

The hybrid system separates five concerns. They must never be conflated:

| Concern | What it is | Who drives it | Timing |
|---|---|---|---|
| **Player-controlled turn actions** | Move / attack / fortify / placement orders | Active player (or AI acting for them) | During Player Action Phase only |
| **Scheduled gameplay events** | Effects with triggers, conditions, or round-based timers | Simulation (event scheduler) | Turn Start (start-of-turn effects) and Persistent Event Processing |
| **Visual animations** | Presentation of battle, movement, attrition, glows | Rendering layer | Any time; NEVER affects authoritative state |
| **Authoritative simulation updates** | State mutations (ownership, armies, supply, victory) | Simulation core only | Turn Start / Action resolution / Event Processing / Turn End |
| **Multiplayer synchronization** | Snapshot broadcast + order relay | Host (authoritative) | After each simulation update batch |

## 2. Hybrid Turn Structure (A–D)

The active player's turn consists of four sequential stages. Persistent events span turns; they are processed at fixed points, not continuously.

### A. Turn Start
- Calculate reinforcements (income = territories/3 + region bonuses)
- Apply scheduled **start-of-turn** effects
- Update relevant resources (income credited, attrition from unsupplied groups applied)
- Deterministic; no player input required

### B. Player Action Phase
- Active player issues strategic commands (move / attack / fortify / placement)
- Actions resolve **as issued** per approved combat rules — no batch planning phase
- One action per territory per turn; territory needs ≥ 2 armies to act
- Turn timer optional (default OFF in SP, 60s in MP); timer is a flow control, not a simulation clock

### C. Persistent Event Processing
- Process events whose conditions or scheduled times have been reached
- Maintain effects that span multiple turns (decrement remaining duration)
- Remove expired effects
- Deterministic; no player input required

### D. Turn End
- Apply **end-of-turn** effects
- Check victory and elimination conditions
- Advance active-player pointer; prepare next player's Turn Start

```
Player N turn:  [A: Turn Start] → [B: Player Actions] → [C: Event Processing] → [D: Turn End]
                                                                          │
Persistent events (multi-turn) ──────────────────────────────────────────┘
                    ▲                                                   │
                    └────────────── processed each turn in C ───────────┘
Player N+1 turn: [A: Turn Start] → ...
```

## 3. Event Scheduling

Events are scheduled with explicit **turn** offsets (not round offsets — turns are now per-player):

- `Schedule(event, turnOffset, phase)` — fires during phase `A` or `C` after N turns
- `Cancel(eventId)` — explicit cancellation only; no implicit cancellation
- Ordering: scheduled turn, then phase (A before C), then insertion order
- Events whose condition (not time) triggers are evaluated during C only

## 4. Temporary / Timed Status Effects

- Status effects (supply disruption, morale) have a duration in turns
- Duration decrements once per turn during stage C — regardless of which player is active
- Effects are attached to the game, not the player; they persist across turn boundaries
- Expired effects are removed during C; their removal publishes an event

## 5. Visual Event Animations

- Animations are a **presentation concern only**
- Battle animations play when the authoritative battle result event arrives
- Attrition visuals play when authoritative attrition events arrive
- Region bonus glows update when authoritative ownership events arrive
- **Rule:** animations may lag, speed up, or be skipped without changing simulation state
- The rendering loop must never advance simulation time

## 6. Pause / Save / Load / Reconnection

| Scenario | Behavior |
|---|---|
| Pause (SP) | Simulation halts at the current stage boundary; no timers advance; rendering continues |
| Save | Persist: schema version, map hash, current state snapshot, ordered command log, **pending event queue with remaining durations**, active-player pointer, current stage |
| Load | Restore snapshot, rebuild event queue from save, resume at saved stage |
| Reconnect (MP) | Client requests snapshot; host sends state + pending event queue; client resumes as mirror |

The pending event queue is part of authoritative state — it is saved and synchronized exactly like territories and armies.

## 7. Deterministic State Updates

All state updates are pure functions of (state, orders, events). No frame-dependent logic, no wall-clock dependency in authoritative simulation.