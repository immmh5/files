namespace StrategyGame.Core.Tests.Events;

using System.Text.Json;
using StrategyGame.Core.Events;
using Xunit;

/// <summary>
/// R4.7 — Tests for EventScheduler / EventBus integration and EffectFailedEvent.
/// </summary>
public class EventSchedulerEventBusTests
{
    private static ScheduledEventRecord MakeRoundEvent(string id, int dueRound, string typeKey = "autumn_attrition")
    {
        var record = ScheduledEventRecord.CreateWithPayload(
            id, typeKey, 1,
            new RoundTiming(dueRound), null,
            new Dictionary<string, JsonElement>());
        return record;
    }

    private static ScheduledEventRecord MakeDueEvent(
        string id, string typeKey, int dueRound = 0, int priority = 0, long seq = 0)
    {
        var record = ScheduledEventRecord.CreateWithPayload(
            id, typeKey, 1,
            new RoundTiming(dueRound), null,
            new Dictionary<string, JsonElement>());
        return record with { Priority = priority, SequenceNumber = seq };
    }

    private static readonly SchedulerQuery Query = new()
    {
        CurrentRoundIndex = 10,
        CurrentStage = ExecutionStage.EventProcessing,
    };

    private static void ResetRegistry()
    {
        EventHandlerRegistry.ClearHandlersForTesting();
        EventTypeRegistrar.ClearForTesting();
        EventTypeRegistrar.RegisterAll();
    }

    // -----------------------------------------------------------------
    // 1. DomainEvent implements GameEvent and is publishable via IEventBus
    // -----------------------------------------------------------------

    [Fact]
    public void DomainEvent_ImplementsGameEvent()
    {
        var evt = new TurnStartedEvent(1, DateTime.UtcNow, "p1", 1, "TurnStart", 5);
        Assert.IsAssignableFrom<GameEvent>(evt);
    }

    [Fact]
    public void EffectAppliedEvent_PublishableThroughIEventBus()
    {
        var bus = new EventBus();
        EffectAppliedEvent? received = null;
        bus.Subscribe<EffectAppliedEvent>(e => received = e);

        var published = new EffectAppliedEvent(1, DateTime.UtcNow, "sched_1", "autumn_attrition", null);
        bus.Publish(published);

        Assert.NotNull(received);
        Assert.Equal(published, received);
    }

    [Fact]
    public void EffectFailedEvent_PublishableThroughIEventBus()
    {
        var bus = new EventBus();
        EffectFailedEvent? received = null;
        bus.Subscribe<EffectFailedEvent>(e => received = e);

        var published = new EffectFailedEvent(
            1, DateTime.UtcNow, "sched_1", "autumn_attrition", EffectFailureReason.HandlerReturnedFalse);
        bus.Publish(published);

        Assert.NotNull(received);
        Assert.Equal(published, received);
    }

    // -----------------------------------------------------------------
    // 2. Successful execution publishes exactly one EffectAppliedEvent
    // -----------------------------------------------------------------

    [Fact]
    public void FireDueEvents_Success_PublishesExactlyOneEffectAppliedEvent()
    {
        ResetRegistry();
        var bus = new EventBus();
        var idSource = new EventIdSource();
        var scheduler = new EventScheduler(bus, idSource);

        var appliedEvents = new List<EffectAppliedEvent>();
        bus.Subscribe<EffectAppliedEvent>(e => appliedEvents.Add(e));

        EventHandlerRegistry.RegisterHandler("autumn_attrition", r => true);

        scheduler.Schedule(MakeRoundEvent("sched_1", 5));
        var firedCount = scheduler.FireDueEvents(Query);

        Assert.Equal(1, firedCount);
        Assert.Single(appliedEvents);

        var evt = appliedEvents[0];
        Assert.Equal("sched_1", evt.EffectEventId);
        Assert.Equal("autumn_attrition", evt.EffectTypeKey);
    }

    [Fact]
    public void FireDueEvents_Success_UsesInjectedSharedEventIdSource()
    {
        ResetRegistry();
        var bus = new EventBus();
        var idSource = new EventIdSource();
        var scheduler = new EventScheduler(bus, idSource);

        var appliedEvents = new List<EffectAppliedEvent>();
        bus.Subscribe<EffectAppliedEvent>(e => appliedEvents.Add(e));

        EventHandlerRegistry.RegisterHandler("autumn_attrition", r => true);
        scheduler.Schedule(MakeRoundEvent("sched_1", 5));
        scheduler.FireDueEvents(Query);

        Assert.Single(appliedEvents);
        Assert.Equal(1L, appliedEvents[0].EventId);
        Assert.Equal(2L, idSource.Peek); // One ID consumed
    }

    // -----------------------------------------------------------------
    // 3. Failure classification
    // -----------------------------------------------------------------

    [Fact]
    public void FireDueEvents_HandlerReturnsFalse_PublishesHandlerReturnedFalse()
    {
        ResetRegistry();
        var bus = new EventBus();
        var idSource = new EventIdSource();
        var scheduler = new EventScheduler(bus, idSource);

        var failedEvents = new List<EffectFailedEvent>();
        bus.Subscribe<EffectFailedEvent>(e => failedEvents.Add(e));

        // Registered handler returning false (unimplemented handler contract)
        EventHandlerRegistry.RegisterHandler("autumn_attrition", r => false);

        scheduler.Schedule(MakeRoundEvent("sched_1", 5));
        scheduler.FireDueEvents(Query);

        Assert.Single(failedEvents);
        Assert.Equal(EffectFailureReason.HandlerReturnedFalse, failedEvents[0].FailureReason);
        Assert.Equal("sched_1", failedEvents[0].EffectEventId);
        Assert.Equal("autumn_attrition", failedEvents[0].EffectTypeKey);
    }

    [Fact]
    public void FireDueEvents_HandlerException_PublishesHandlerException()
    {
        ResetRegistry();
        var bus = new EventBus();
        var idSource = new EventIdSource();
        var scheduler = new EventScheduler(bus, idSource);

        var failedEvents = new List<EffectFailedEvent>();
        bus.Subscribe<EffectFailedEvent>(e => failedEvents.Add(e));

        EventHandlerRegistry.RegisterHandler("autumn_attrition", r =>
            throw new InvalidOperationException("Handler exploded"));

        scheduler.Schedule(MakeRoundEvent("sched_1", 5));
        scheduler.FireDueEvents(Query);

        Assert.Single(failedEvents);
        Assert.Equal(EffectFailureReason.HandlerException, failedEvents[0].FailureReason);
        Assert.Equal("sched_1", failedEvents[0].EffectEventId);
    }

    // -----------------------------------------------------------------
    // 4. Fired count not incremented on failures
    // -----------------------------------------------------------------

    [Fact]
    public void FireDueEvents_HandlerReturnsFalse_DoesNotIncrementFiredCount()
    {
        ResetRegistry();
        var bus = new EventBus();
        var idSource = new EventIdSource();
        var scheduler = new EventScheduler(bus, idSource);

        EventHandlerRegistry.RegisterHandler("autumn_attrition", r => false);
        scheduler.Schedule(MakeRoundEvent("sched_1", 5));

        var firedCount = scheduler.FireDueEvents(Query);
        Assert.Equal(0, firedCount);
    }

    [Fact]
    public void FireDueEvents_HandlerException_DoesNotIncrementFiredCount()
    {
        ResetRegistry();
        var bus = new EventBus();
        var idSource = new EventIdSource();
        var scheduler = new EventScheduler(bus, idSource);

        EventHandlerRegistry.RegisterHandler("autumn_attrition", r =>
            throw new InvalidOperationException("Handler exploded"));
        scheduler.Schedule(MakeRoundEvent("sched_1", 5));

        var firedCount = scheduler.FireDueEvents(Query);
        Assert.Equal(0, firedCount);
    }

    // -----------------------------------------------------------------
    // 5. Missing handler: Pending + no publication
    // -----------------------------------------------------------------

    [Fact]
    public void FireDueEvents_MissingHandler_LeavesPending_PublishesNothing()
    {
        ResetRegistry();
        var bus = new EventBus();
        var idSource = new EventIdSource();
        var scheduler = new EventScheduler(bus, idSource);

        var appliedEvents = new List<EffectAppliedEvent>();
        var failedEvents = new List<EffectFailedEvent>();
        bus.Subscribe<EffectAppliedEvent>(e => appliedEvents.Add(e));
        bus.Subscribe<EffectFailedEvent>(e => failedEvents.Add(e));

        // Use a type key with NO registered handler.
        // autumn_attrition's default handler was re-registered by ResetRegistry;
        // remove it so this event has no handler.
        EventHandlerRegistry.ClearHandlersForTesting();

        scheduler.Schedule(MakeRoundEvent("sched_missing", 5, "autumn_attrition"));
        var firedCount = scheduler.FireDueEvents(Query);

        Assert.Equal(0, firedCount);

        var evt = scheduler.TryGetEvent("sched_missing");
        Assert.NotNull(evt);
        Assert.Equal(ScheduledEventStatus.Pending, evt!.Status);

        Assert.Empty(appliedEvents);
        Assert.Empty(failedEvents);
    }

    // -----------------------------------------------------------------
    // 6. Parameterless scheduler preserves no-EventBus behavior
    // -----------------------------------------------------------------

    [Fact]
    public void ParameterlessScheduler_WorksBackwardCompatibly()
    {
        ResetRegistry();
        var scheduler = new EventScheduler();

        EventHandlerRegistry.RegisterHandler("autumn_attrition", r => true);
        scheduler.Schedule(MakeRoundEvent("sched_1", 5));
        var firedCount = scheduler.FireDueEvents(Query);

        Assert.Equal(1, firedCount);
        var evt = scheduler.TryGetEvent("sched_1");
        Assert.Equal(ScheduledEventStatus.Fired, evt!.Status);
    }

    [Fact]
    public void ParameterlessScheduler_HandlerReturnsFalse_TransitionsToFailed_NoPublication()
    {
        ResetRegistry();
        var scheduler = new EventScheduler();

        EventHandlerRegistry.RegisterHandler("autumn_attrition", r => false);
        scheduler.Schedule(MakeRoundEvent("sched_1", 5));
        var firedCount = scheduler.FireDueEvents(Query);

        Assert.Equal(0, firedCount);
        var evt = scheduler.TryGetEvent("sched_1");
        Assert.Equal(ScheduledEventStatus.Failed, evt!.Status);
    }

    // -----------------------------------------------------------------
    // 7. Shared EventIdSource produces unique IDs across notifications
    // -----------------------------------------------------------------

    [Fact]
    public void SharedEventIdSource_ProducesUniqueIdsAcrossNotifications()
    {
        ResetRegistry();
        var bus = new EventBus();
        var idSource = new EventIdSource();
        var scheduler = new EventScheduler(bus, idSource);

        var allEvents = new List<DomainEvent>();
        bus.Subscribe<EffectAppliedEvent>(e => allEvents.Add(e));
        bus.Subscribe<EffectFailedEvent>(e => allEvents.Add(e));

        EventHandlerRegistry.RegisterHandler("autumn_attrition", r => true);
        EventHandlerRegistry.RegisterHandler("berserk_rage", r => false);

        scheduler.Schedule(MakeRoundEvent("sched_ok", 5, "autumn_attrition"));
        scheduler.Schedule(MakeRoundEvent("sched_fail", 5, "berserk_rage"));

        scheduler.FireDueEvents(Query);

        Assert.Equal(2, allEvents.Count);
        Assert.NotEqual(allEvents[0].EventId, allEvents[1].EventId);
        Assert.True(allEvents[0].EventId < allEvents[1].EventId);
    }

    // -----------------------------------------------------------------
    // 8. Status committed before publication
    // -----------------------------------------------------------------

    [Fact]
    public void FireDueEvents_StatusCommittedBeforePublication()
    {
        ResetRegistry();
        var bus = new EventBus();
        var idSource = new EventIdSource();
        var scheduler = new EventScheduler(bus, idSource);

        ScheduledEventStatus? observedStatus = null;
        bus.Subscribe<EffectAppliedEvent>(_ =>
        {
            // Subscriber inspects the scheduler record during publication.
            var record = scheduler.TryGetEvent("sched_1");
            observedStatus = record?.Status;
        });

        EventHandlerRegistry.RegisterHandler("autumn_attrition", r => true);
        scheduler.Schedule(MakeRoundEvent("sched_1", 5));
        scheduler.FireDueEvents(Query);

        Assert.NotNull(observedStatus);
        Assert.Equal(ScheduledEventStatus.Fired, observedStatus);
    }

    // -----------------------------------------------------------------
    // 9. Subscriber exception does not roll back status or re-run handler
    // -----------------------------------------------------------------

    [Fact]
    public void FireDueEvents_SubscriberThrows_StatusRemainsTerminal_HandlerNotReexecuted()
    {
        ResetRegistry();
        var bus = new EventBus();
        var idSource = new EventIdSource();
        var scheduler = new EventScheduler(bus, idSource);

        int handlerCallCount = 0;
        EventHandlerRegistry.RegisterHandler("autumn_attrition", r =>
        {
            handlerCallCount++;
            return true;
        });

        bus.Subscribe<EffectAppliedEvent>(_ => throw new InvalidOperationException("Subscriber boom"));

        scheduler.Schedule(MakeRoundEvent("sched_1", 5));

        // Subscriber exception propagates (fail-fast contract)...
        Assert.Throws<InvalidOperationException>(() => scheduler.FireDueEvents(Query));

        // ...but the lifecycle status remains committed...
        var evt = scheduler.TryGetEvent("sched_1");
        Assert.NotNull(evt);
        Assert.Equal(ScheduledEventStatus.Fired, evt!.Status);

        // ...and the handler ran exactly once (never re-executed).
        Assert.Equal(1, handlerCallCount);

        // A subsequent FireDueEvents must not re-fire the terminal event.
        var firedCount = scheduler.FireDueEvents(Query);
        Assert.Equal(0, firedCount);
        Assert.Equal(1, handlerCallCount);
    }

    // -----------------------------------------------------------------
    // 10. JSON round-trip serialization
    // -----------------------------------------------------------------

    [Fact]
    public void EffectFailedEvent_SurvivesPolymorphicJsonRoundTrip()
    {
        var original = new EffectFailedEvent(
            42, new DateTime(2026, 11, 6, 12, 0, 0, DateTimeKind.Utc),
            "sched_1", "autumn_attrition", EffectFailureReason.HandlerReturnedFalse);

        var json = JsonSerializer.Serialize<DomainEvent>(original);
        var restored = JsonSerializer.Deserialize<DomainEvent>(json);

        Assert.IsType<EffectFailedEvent>(restored);
        var typed = (EffectFailedEvent)restored!;
        Assert.Equal(original.EventId, typed.EventId);
        Assert.Equal(original.EffectEventId, typed.EffectEventId);
        Assert.Equal(original.EffectTypeKey, typed.EffectTypeKey);
        Assert.Equal(original.FailureReason, typed.FailureReason);
        Assert.Equal(original.SchemaVersion, typed.SchemaVersion);
    }

    [Fact]
    public void EffectAppliedEvent_SerializationRemainsCompatible()
    {
        var original = new EffectAppliedEvent(
            7, new DateTime(2026, 11, 6, 12, 0, 0, DateTimeKind.Utc),
            "sched_1", "autumn_attrition", "target_1");

        var json = JsonSerializer.Serialize<DomainEvent>(original);
        var restored = JsonSerializer.Deserialize<DomainEvent>(json);

        Assert.IsType<EffectAppliedEvent>(restored);
        var typed = (EffectAppliedEvent)restored!;
        Assert.Equal(original.EventId, typed.EventId);
        Assert.Equal(original.EffectEventId, typed.EffectEventId);
        Assert.Equal(original.EffectTypeKey, typed.EffectTypeKey);
        Assert.Equal(original.TargetEntityId, typed.TargetEntityId);
        Assert.Equal(original.SchemaVersion, typed.SchemaVersion);
    }
}
