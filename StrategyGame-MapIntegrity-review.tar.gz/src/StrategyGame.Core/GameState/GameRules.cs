namespace StrategyGame.Core.GameState;

/// <summary>
/// Game rule configuration (army allocation, turn parameters, etc.).
/// Immutable once set; can be swapped for different game modes.
/// </summary>
public sealed class GameRules
{
    public int InitialArmiesPerPlayer { get; }
    public int ArmyRatioForReinforcement { get; }
    public int MinimumTerritoriesForReinforcement { get; }
    public int MaximumReinforcements { get; }
    public bool AllowFortifyInAttackPhase { get; }

    public GameRules(
        int initialArmiesPerPlayer = 5,
        int armyRatioForReinforcement = 3,
        int minimumTerritoriesForReinforcement = 1,
        int maximumReinforcements = 10,
        bool allowFortifyInAttackPhase = false)
    {
        InitialArmiesPerPlayer = initialArmiesPerPlayer;
        ArmyRatioForReinforcement = armyRatioForReinforcement;
        MinimumTerritoriesForReinforcement = minimumTerritoriesForReinforcement;
        MaximumReinforcements = maximumReinforcements;
        AllowFortifyInAttackPhase = allowFortifyInAttackPhase;
    }

    /// <summary>
    /// Computes the number of armies available for reinforcement.
    /// </summary>
    public int ComputeReinforcements(int territoryCount)
    {
        var count = Math.Max(1, territoryCount / ArmyRatioForReinforcement);
        return Math.Min(count, MaximumReinforcements);
    }
}
