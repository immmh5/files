namespace StrategyGame.Core.Tests.Simulation;

using StrategyGame.Core.Actions;
using StrategyGame.Core.Domain;
using StrategyGame.Core.Events;
using StrategyGame.Core.GameState;
using StrategyGame.Core.Simulation;
using Xunit;

/// <summary>
/// M1.3 — End-to-end Core gameplay integration test.
/// Tests a full turn cycle with reinforcement, attack, event processing, and victory evaluation.
/// </summary>
public class TurnEngineEndToEndTests
{
    private MapDefinition CreateTestMap()
    {
        var territories = new List<Territory>
        {
            new Territory("t1", "Alpha", ["t2"], TerrainType.Plains, null, true), // supply source for p1
            new Territory("t2", "Bravo", ["t1", "t3"], TerrainType.Hills, null, false),
            new Territory("t3", "Charlie", ["t2", "t4"], TerrainType.Plains, null, false),
            new Territory("t4", "Delta", ["t3", "t5"], TerrainType.Plains, null, false),
            new Territory("t5", "Echo", ["t4", "t6"], TerrainType.Plains, null, false),
            new Territory("t6", "Foxtrot", ["t5"], TerrainType.Plains, null, false),
        };
        return new MapDefinition("e2e-map", "E2E Test Map", territories);
    }

    [Fact]
    public void FullTurnCycle_ReinforcementAndCombatWorkCorrectly()
    {
        var p1 = new Player("p1", "Player 1", new Faction("f1", "Red", "#FF0000"), isHuman: true);
        var p2 = new Player("p2", "Player 2", new Faction("f2", "Blue", "#0000FF"), isHuman: false);
        var map = CreateTestMap();

        // Set up initial state - p1 owns 3 territories (50%), p2 owns 3 (50%) to prevent early victory
        var state = new GameState("g1", map, [p1, p2], "p1", 1, TurnManager.PhaseReinforce);
        state.GetTerritory("t1").SetOwner("p1", 4); // Start territory with supply source
        state.GetTerritory("t2").SetOwner("p2", 2); // Enemy territory (adjacent to t1)
        state.GetTerritory("t3").SetOwner("p1", 3); // Additional territory
        state.GetTerritory("t4").SetOwner("p1", 2); // Third territory for income
        state.GetTerritory("t5").SetOwner("p2", 2); // Another enemy territory
        state.GetTerritory("t6").SetOwner("p2", 1); // Another enemy

        var scheduler = new EventScheduler();
        var engine = new TurnEngine(state, scheduler, new EventIdSource(1));

        // Stage A: Execute TurnStart (reinforcements)
        var stageA = engine.ExecuteTurnStart();
        Assert.True(stageA.Success, stageA.ErrorMessage);
        Assert.Equal(TurnStage.PlayerActions, engine.CurrentStageInternal);

        // Verify p1 got reinforcements (owns 3 territories, so income = 1)
        var p1AfterStart = state.GetPlayer("p1");
        Assert.True(p1AfterStart.ArmiesToPlace >= 1, $"Player should have received at least 1 reinforcement, got {p1AfterStart.ArmiesToPlace}");

        // Stage B: Execute Attack action
        var attackAction = new AttackAction("atk1", "p1", "t1", "t2"); // Attack adjacent enemy territory
        var attackResult = engine.ExecutePlayerAction(attackAction);
        Assert.True(attackResult.Success, attackResult.ErrorMessage);

        // Verify combat result - attacker strength = 3, defender strength = 2 + hills(2) = 4
        // Defender wins tie, so p2 keeps t2
        var payload = attackResult.Payload as dynamic;
        Assert.False(payload?.AttackerWon ?? false);

        // Stage C: Execute EventProcessing (no scheduled events in this test)
        _ = engine.AdvanceStage(); // Move from PlayerActions to EventProcessing
        var stageC = engine.ExecuteEventProcessing();
        Assert.True(stageC.Success, stageC.ErrorMessage);
        Assert.Equal(TurnStage.TurnEnd, engine.CurrentStage);

        // Stage D: Execute TurnEnd (victory check, advance to next player)
        var stageD = engine.ExecuteTurnEnd();
        Assert.True(stageD.Success, stageD.ErrorMessage);

        // Verify turn advanced
        Assert.Equal("p2", state.CurrentTurnPlayerIdInternal);
        Assert.Equal(TurnStage.TurnStart, engine.CurrentStageInternal);
    }

    [Fact]
    public void VictoryEvaluation_DominationTriggersGameOver()
    {
        var map = new MapDefinition("map", "M", new List<Territory>
        {
            new Territory("a", "A", ["b"], TerrainType.Plains, null, false),
            new Territory("b", "B", ["a"], TerrainType.Plains, null, false),
        });
        var p1 = new Player("p1", "P1", new Faction("f1", "R", "#F00"), isHuman: true);
        var p2 = new Player("p2", "P2", new Faction("f2", "B", "#00F"), isHuman: false);
        var state = new GameState("g", map, [p1, p2], "p1", 1, TurnManager.PhaseReinforce);

        // p1 owns both territories (100% > 60% threshold)
        state.GetTerritory("a").SetOwner("p1", 3);
        state.GetTerritory("b").SetOwner("p1", 2);

        var scheduler = new EventScheduler();
        var engine = new TurnEngine(state, scheduler, new EventIdSource(1));

        // Run full turn cycle: A -> B -> C -> D
        _ = engine.ExecuteTurnStart(); // Now in PlayerActions
        _ = engine.AdvanceStage(); // Now in EventProcessing  
        _ = engine.ExecuteEventProcessing(); // Now in TurnEnd
        
        var result = engine.ExecuteTurnEnd();

        Assert.True(result.Success);
        Assert.True(engine.IsGameOver);
        Assert.Equal(TurnManager.PhaseGameOver, state.CurrentPhaseInternal);
    }

    [Fact]
    public void StateIntegrity_InvalidActionsLeaveGameStateUnchanged()
    {
        var map = new MapDefinition("m", "M", new List<Territory>
        {
            new Territory("a", "A", ["b"], TerrainType.Plains, null, false),
            new Territory("b", "B", ["a"], TerrainType.Plains, null, false),
        });
        var p1 = new Player("p1", "P1", new Faction("f1", "R", "#F00"), isHuman: true);
        var p2 = new Player("p2", "P2", new Faction("f2", "B", "#00F"), isHuman: false);
        var state = new GameState("g", map, [p1, p2], "p1", 1, TurnManager.PhaseAttack);
        state.GetTerritory("a").SetOwner("p1", 5);
        state.GetTerritory("b").SetOwner("p2", 3);

        int armyBeforeA = state.GetTerritory("a").Armies;
        int armyBeforeB = state.GetTerritory("b").Armies;
        string? ownerBefore = state.GetTerritory("b").OwnerPlayerId;

        // Try invalid attack from non-adjacent (should fail)
        // Actually a and b ARE adjacent. Let's try wrong ownership instead
        var badAction = new ReinforceAction("bad", "p2", "a", 1); // p2 trying to reinforce on p1's territory
        var result = ActionExecutor.Execute(state, badAction);

        Assert.False(result.Success);
        Assert.Equal(armyBeforeA, state.GetTerritory("a").Armies);
        Assert.Equal(armyBeforeB, state.GetTerritory("b").Armies);
        Assert.Equal(ownerBefore, state.GetTerritory("b").OwnerPlayerId);
    }
}