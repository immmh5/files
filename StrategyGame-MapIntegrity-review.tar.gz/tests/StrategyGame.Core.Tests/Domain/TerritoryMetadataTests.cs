namespace StrategyGame.Core.Tests.Domain;

using StrategyGame.Core.Domain;
using Xunit;

/// <summary>
/// M1.1 — Territory metadata: terrain, region membership, supply-source flag,
/// legacy-ctor compatibility and defensive adjacency copying.
/// </summary>
public class TerritoryMetadataTests
{
    [Fact]
    public void LegacyCtor_AssignsDocumentedDefaults()
    {
        var territory = new Territory("A", "Alpha", ["B"]);

        Assert.Equal(TerrainType.Plains, territory.Terrain);
        Assert.Null(territory.RegionId);
        Assert.False(territory.IsSupplySource);
    }

    [Fact]
    public void MetadataCtor_AssignsAllMetadataValues()
    {
        var territory = new Territory("A", "Alpha", ["B"],
            TerrainType.Mountains, "northlands", isSupplySource: true);

        Assert.Equal(TerrainType.Mountains, territory.Terrain);
        Assert.Equal("northlands", territory.RegionId);
        Assert.True(territory.IsSupplySource);
        Assert.Equal(0, territory.Armies); // starts owned by nobody
        Assert.Null(territory.OwnerPlayerId);
    }

    [Fact]
    public void StateCopyCtor_PreservesMetadata()
    {
        var source = new Territory("A", "Alpha", ["B"],
            TerrainType.Marsh, "southlands", isSupplySource: true);
        source.SetOwner("p1", 4);

        var copy = new Territory(source.Id, source.Name, source.AdjacentTerritoryIds,
            source.OwnerPlayerId, source.Armies, source.Terrain, source.RegionId, source.IsSupplySource);

        Assert.Equal(TerrainType.Marsh, copy.Terrain);
        Assert.Equal("southlands", copy.RegionId);
        Assert.True(copy.IsSupplySource);
        Assert.Equal("p1", copy.OwnerPlayerId);
        Assert.Equal(4, copy.Armies);
    }

    [Fact]
    public void Snapshot_IncludesMetadata()
    {
        var territory = new Territory("A", "Alpha", ["B", "C"],
            TerrainType.Coast, "southlands", isSupplySource: true);

        var snapshot = territory.Snapshot();

        Assert.Equal(TerrainType.Coast, snapshot.Terrain);
        Assert.Equal("southlands", snapshot.RegionId);
        Assert.True(snapshot.IsSupplySource);
    }

    [Fact]
    public void AllSixPlannedTerrainCategories_AreRepresentable()
    {
        TerrainType[] expected =
        [
            TerrainType.Plains, TerrainType.Forest, TerrainType.Hills,
            TerrainType.Mountains, TerrainType.Marsh, TerrainType.Coast,
        ];

        foreach (var terrain in expected)
        {
            var territory = new Territory("A", "Alpha", [], terrain, null, false);
            Assert.Equal(terrain, territory.Terrain);
        }
    }

    [Fact]
    public void Adjacency_InputListMutatedAfterwards_TerritoryUnaffected()
    {
        var adjacency = new List<string> { "B", "C" };
        var territory = new Territory("A", "Alpha", adjacency);

        adjacency.Add("D");
        adjacency.RemoveAt(0);

        Assert.False(territory.IsAdjacentTo("D"));
        Assert.Equal(2, territory.AdjacentTerritoryIds.Count);
        Assert.True(territory.IsAdjacentTo("C")); // original content preserved
    }

    [Fact]
    public void UndefinedTerrainValue_ThrowsArgumentOutOfRange()
    {
        const TerrainType undefined = (TerrainType)999;
        Assert.Throws<ArgumentOutOfRangeException>(() =>
            new Territory("A", "Alpha", [], undefined, null, false));
    }
}
