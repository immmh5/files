# StrategyGame

A desktop-native 2.5D territorial strategy game built with **Godot Engine 4.7.2** (.NET) and **C#**.

## Status

**Milestone 0 Complete — Foundation Ready**

See [docs/MILESTONES.md](docs/MILESTONES.md) for the full roadmap.

## Technology Stack

| Component | Technology |
|---|---|
| Game Engine | Godot 4.7.2 stable (mono) |
| Language | C# (.NET 8) |
| Unit Testing | xUnit |
| Build System | dotnet CLI + Godot .NET SDK |
| Target Platforms | Windows x64, Linux x64 |

## Prerequisites

### Required Tools

- **Godot 4.7.2 Mono** — Download from [godotengine.org/download](https://godotengine.org/download). Select the `.NET` edition for your platform.
- ****.NET SDK 8.0** — Install from [dotnet.microsoft.com/download](https://dotnet.microsoft.com/download). The project uses SDK 8.0.427.
- **Bash** (Linux/macOS) or **PowerShell 7+** (Windows) for verification scripts.

### Local Installation Paths

The project detects tools from these locations in order:

| Tool | Priority 1 (explicit) | Priority 2 (PATH) | Priority 3 (user-local) |
|---|---|---|---|
| Godot | `GODOT_BIN` env var | `godot` on PATH | `~/.local/godot/4.7.2/Godot_v4.7.2-stable_mono_linux.x86_64` (Linux) · `C:\Games\Godot\Godot_v4.7.2-stable_mono_win64.exe` (Windows) |
| .NET SDK | `DOTNET_ROOT` env var | `dotnet` on PATH | `~/.local/dotnet` (Linux) · `%USERPROFILE%\.local\dotnet` (Windows) |

If neither explicit env vars nor PATH have the tools, the scripts attempt known user-local installations.

## Quick Start

### One-Command Editor Launch

```bash
./scripts/run-editor.sh
```

This script:
- Auto-detects Godot and .NET SDK locations
- Builds the project before launching
- Opens the Godot editor with the project loaded
- Forwards any extra arguments to Godot: `./scripts/run-editor.sh --editor --debug`

### One-Command Game Launch

```bash
./scripts/run-game.sh
```

This script launches the game directly without opening the editor. Press **Escape** to quit.

### Full Verification

```bash
./scripts/verify.sh          # Linux / macOS
pwsh scripts/verify.ps1      # Windows
```

Runs all checks: builds, tests, Godot import validation, and headless startup.

### Manual Build & Test

```bash
# Build Core
dotnet build src/StrategyGame.Core/StrategyGame.Core.csproj -c Release

# Build App
dotnet build src/StrategyGame.App/StrategyGame.App.csproj -c Release

# Run all tests
dotnet test --nologo

# Godot headless startup (requires GODOT_BIN or godot on PATH)
$GODOT_BIN --headless --path src/StrategyGame.App --quit
```

## KDE Desktop Launcher

Install a desktop shortcut to launch the editor from your application menu:

```bash
./scripts/install-desktop-launcher.sh
```

This creates `~/.local/share/applications/strategygame-editor.desktop`. After installation:
1. Log out and back in (or run `update-desktop-database ~/.local/share/applications`)
2. Search for "StrategyGame" in your application menu

To remove: `rm ~/.local/share/applications/strategygame-editor.desktop`

## Project Structure

```
src/
  StrategyGame.Core/     ← Pure C# game domain (no Godot refs)
  StrategyGame.App/       ← Godot application project
tests/
  StrategyGame.Core.Tests/   ← Unit tests (22 tests)
  Integration.Tests/          ← Smoke/integration tests (7 tests)
docs/                    ← Architecture & design docs
scripts/
  run-editor.sh          ← One-command editor launch
  run-game.sh            ← One-command game launch
  install-desktop-launcher.sh  ← KDE desktop shortcut installer
  verify.sh              ← Linux verification (7 steps)
  verify.ps1             ← Windows verification (7 steps)
.github/workflows/
  ci.yml                 ← Linux CI pipeline
  ci-windows.yml         ← Windows CI pipeline
```

See [docs/PROJECT_STRUCTURE.md](docs/PROJECT_STRUCTURE.md) for the full directory layout.

## Documentation

| Document | Purpose |
|---|---|
| `docs/MASTER_SPEC.md` | Project identity and locked decisions |
| `docs/ARCHITECTURE.md` | System design and module responsibilities |
| `docs/PROJECT_STRUCTURE.md` | Directory layout and conventions |
| `docs/RENDERING_AND_2.5D.md` | 2.5D strategy map rendering design |
| `docs/NETWORKING_DESIGN.md` | Networking architecture (host-authoritative) |
| `docs/MODULARITY_AND_RESOURCES.md` | Modular architecture and resource loading |
| `docs/PERFORMANCE_STRATEGY.md` | Performance budgets and strategy |
| `docs/QA_AND_TESTING.md` | Testing layers and quality gates |
| `docs/BUILD_AND_EXPORT.md` | Build pipeline and export targets |
| `docs/MILESTONES.md` | Full project roadmap |
| `docs/AGENT_RULES.md` | AI agent operating rules |
| `docs/adr/` | Architecture Decision Records |

## Troubleshooting

### Godot: "Cannot instantiate C# script"

- Ensure `AssemblyName` in `StrategyGame.App.csproj` matches `config/name` in `project.godot`.
- The `[GlobalClass]` attribute on the root script class is required for Godot to resolve it.
- Rebuild after changing the assembly name: `dotnet build src/StrategyGame.App/StrategyGame.App.csproj`

### Godot: "Failed to load project assembly"

- This usually means the DLL name doesn't match what Godot expects. Check that `AssemblyName` equals the project name in `project.godot`.
- Make sure `<EnableDynamicLoading>true</EnableDynamicLoading>` is set in the `.csproj`.

### "Godot not found" errors

```bash
# Set the path explicitly
export GODOT_BIN=/path/to/Godot_v4.7.2-stable_mono_linux.x86_64

# Or add to PATH
export PATH="$HOME/.local/godot/4.7.2:$PATH"
```

### ".NET SDK not found" errors

```bash
# Set the root explicitly
export DOTNET_ROOT=$HOME/.local/dotnet
export PATH="$HOME/.local/dotnet:$PATH"
```

### Godot editor won't open (display/server error)

The headless startup test works without a display. To run the full editor, ensure X11/Wayland is available:

```bash
# Check display
echo $DISPLAY        # X11
echo $WAYLAND_DISPLAY  # Wayland
```

## Architecture Highlights

- **Core-first:** `StrategyGame.Core` is a pure C# library — testable without Godot.
- **Event-driven:** Domain changes flow through typed `GameEvent` objects.
- **Transport-agnostic networking:** `INetworkTransport` interface; LAN first, no mandatory cloud.
- **No premature complexity:** No plugins, no cloud, no C++ in Milestone 0.

## License

Project under development. All original artwork and code. No proprietary game assets.

## Contributing

Follow the rules in `docs/AGENT_RULES.md`. All AI agents must adhere to the architecture decisions in `docs/adr/`.
