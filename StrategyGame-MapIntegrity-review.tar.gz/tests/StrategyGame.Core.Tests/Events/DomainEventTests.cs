namespace StrategyGame.Core.Tests.Events;

using System.Text.Json;
using System.Text.Json.Serialization;
using StrategyGame.Core.Events;
using StrategyGame.Core.Domain;
using Xunit;

public class DomainEventTests
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = false,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        Converters = { new JsonStringEnumConverter() }
    };

    [Fact]
    public void TurnStartedEvent_JsonRoundTrip_PreservesAllFields()
    {
        var original = new TurnStartedEvent(1, DateTime.UtcNow, "p1", 5, "TurnStart", 3);

        var json = JsonSerializer.Serialize(original, JsonOptions);
        var deserialized = JsonSerializer.Deserialize<TurnStartedEvent>(json, JsonOptions);

        Assert.NotNull(deserialized);
        Assert.Equal(original.EventId, deserialized.EventId);
        Assert.Equal(original.PlayerId, deserialized.PlayerId);
        Assert.Equal(original.TurnNumber, deserialized.TurnNumber);
        Assert.Equal(original.Phase, deserialized.Phase);
        Assert.Equal(original.ReinforcementsAvailable, deserialized.ReinforcementsAvailable);
        Assert.Equal(original.SchemaVersion, deserialized.SchemaVersion);
    }

    [Fact]
    public void OrderSubmittedEvent_JsonRoundTrip_PreservesAllFields()
    {
        var original = new OrderSubmittedEvent(2, DateTime.UtcNow, "p1", "order-1", OrderType.Attack, "t1", "t2", 3);

        var json = JsonSerializer.Serialize(original, JsonOptions);
        var deserialized = JsonSerializer.Deserialize<OrderSubmittedEvent>(json, JsonOptions);

        Assert.NotNull(deserialized);
        Assert.Equal(original.EventId, deserialized.EventId);
        Assert.Equal(original.PlayerId, deserialized.PlayerId);
        Assert.Equal(original.OrderId, deserialized.OrderId);
        Assert.Equal(original.Type, deserialized.Type);
        Assert.Equal(original.FromTerritoryId, deserialized.FromTerritoryId);
        Assert.Equal(original.ToTerritoryId, deserialized.ToTerritoryId);
        Assert.Equal(original.Armies, deserialized.Armies);
    }

    [Fact]
    public void TerritoryCapturedEvent_JsonRoundTrip_PreservesAllFields()
    {
        var original = new TerritoryCapturedEvent(3, DateTime.UtcNow, "t1", "p2", 5);

        var json = JsonSerializer.Serialize(original, JsonOptions);
        var deserialized = JsonSerializer.Deserialize<TerritoryCapturedEvent>(json, JsonOptions);

        Assert.NotNull(deserialized);
        Assert.Equal(original.TerritoryId, deserialized.TerritoryId);
        Assert.Equal(original.NewOwnerPlayerId, deserialized.NewOwnerPlayerId);
        Assert.Equal(original.ArmiesOnCapture, deserialized.ArmiesOnCapture);
    }

    [Fact]
    public void BattleResolvedEvent_JsonRoundTrip_PreservesAllFields()
    {
        var original = new BattleResolvedEvent(
            4, DateTime.UtcNow, "p1", "p2", "t1", "t2",
            5, 3, 2, 1, true, "t2");

        var json = JsonSerializer.Serialize(original, JsonOptions);
        var deserialized = JsonSerializer.Deserialize<BattleResolvedEvent>(json, JsonOptions);

        Assert.NotNull(deserialized);
        Assert.Equal(original.AttackerPlayerId, deserialized.AttackerPlayerId);
        Assert.Equal(original.DefenderPlayerId, deserialized.DefenderPlayerId);
        Assert.Equal(original.AttackerArmiesCommitted, deserialized.AttackerArmiesCommitted);
        Assert.Equal(original.DefenderArmies, deserialized.DefenderArmies);
        Assert.Equal(original.AttackerLosses, deserialized.AttackerLosses);
        Assert.Equal(original.DefenderLosses, deserialized.DefenderLosses);
        Assert.Equal(original.AttackerWon, deserialized.AttackerWon);
        Assert.Equal(original.CapturedTerritoryId, deserialized.CapturedTerritoryId);
    }

    [Fact]
    public void GameOverEvent_JsonRoundTrip_PreservesAllFields()
    {
        var original = new GameOverEvent(5, DateTime.UtcNow, "p1", "Domination", "Player p1 controls 60% of territories");

        var json = JsonSerializer.Serialize(original, JsonOptions);
        var deserialized = JsonSerializer.Deserialize<GameOverEvent>(json, JsonOptions);

        Assert.NotNull(deserialized);
        Assert.Equal(original.WinningPlayerId, deserialized.WinningPlayerId);
        Assert.Equal(original.Reason, deserialized.Reason);
        Assert.Equal(original.ReasonText, deserialized.ReasonText);
    }

    [Fact]
    public void SupplyAttritionEvent_JsonRoundTrip_PreservesAllFields()
    {
        var original = new SupplyAttritionEvent(6, DateTime.UtcNow, "t1", 2);

        var json = JsonSerializer.Serialize(original, JsonOptions);
        var deserialized = JsonSerializer.Deserialize<SupplyAttritionEvent>(json, JsonOptions);

        Assert.NotNull(deserialized);
        Assert.Equal(original.TerritoryId, deserialized.TerritoryId);
        Assert.Equal(original.ArmiesLost, deserialized.ArmiesLost);
    }

    [Fact]
    public void EffectAppliedEvent_JsonRoundTrip_PreservesAllFields()
    {
        var original = new EffectAppliedEvent(7, DateTime.UtcNow, "effect-1", "attrition", "t1");

        var json = JsonSerializer.Serialize(original, JsonOptions);
        var deserialized = JsonSerializer.Deserialize<EffectAppliedEvent>(json, JsonOptions);

        Assert.NotNull(deserialized);
        Assert.Equal(original.EffectEventId, deserialized.EffectEventId);
        Assert.Equal(original.EffectTypeKey, deserialized.EffectTypeKey);
        Assert.Equal(original.TargetEntityId, deserialized.TargetEntityId);
    }

    [Fact]
    public void PolymorphicSerialization_IncludesTypeDiscriminator()
    {
        // Test polymorphic serialization through base type
        DomainEvent original = new TurnStartedEvent(1, DateTime.UtcNow, "p1", 5, "TurnStart", 3);
        var json = JsonSerializer.Serialize(original, JsonOptions);
        Assert.Contains("\"$type\":\"turnStarted\"", json);

        DomainEvent battle = new BattleResolvedEvent(1, DateTime.UtcNow, "p1", "p2", "t1", "t2", 5, 3, 2, 1, true, "t2");
        json = JsonSerializer.Serialize(battle, JsonOptions);
        Assert.Contains("\"$type\":\"battleResolved\"", json);
    }
}