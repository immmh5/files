namespace StrategyGame.Core.Networking;

/// <summary>
/// Transport type for network messages (reliability guarantee).
/// </summary>
public enum TransmissionType
{
    Unreliable,
    Reliable,
    ReliableOrdered
}

/// <summary>
/// Packet envelope sent across the network.
/// All packet payloads are MessagePack-serialised byte arrays.
/// </summary>
public readonly struct GamePacket
{
    public PacketType Type { get; }
    public byte[] Payload { get; }
    public string SenderId { get; }
    public long SequenceNumber { get; }
    public DateTime Timestamp { get; }

    public GamePacket(PacketType type, byte[] payload, string senderId, long sequenceNumber)
    {
        Type = type;
        Payload = payload;
        SenderId = senderId;
        SequenceNumber = sequenceNumber;
        Timestamp = DateTime.UtcNow;
    }
}

/// <summary>
/// Packet type discriminator — not transport-dependent.
/// </summary>
public enum PacketType
{
    JoinRequest,
    JoinAccept,
    Leave,
    OrderSubmit,
    OrderAck,
    StateSnapshot,
    Heartbeat,
    RoomDiscovery,
    ChatMessage
}
