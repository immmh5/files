# PLAYER_AND_FACTION_DESIGN.md

**Status:** PROPOSED DESIGN

---

## 1. Player Types

| Type | Description |
|---|---|
| Human | Controls one faction via UI |
| AI | Computer opponent; deterministic, no external APIs |

## 2. Faction Design

Six factions at release. Each has one mild passive bonus.

| Faction | Bonus | Rationale |
|---|---|---|
| **Aethelgard** (Red) | Plains defense +1 | Defensive core faction |
| **Varkul Clan** (Black) | Marsh attrition -1 | Irregular warfare |
| **Sapphire Covenant** (Blue) | Coast supply radius +1 | Naval orientation |
| **Verdant League** (Green) | Forest movement cost -1 | Mobility |
| **Ironstone Dominion** (Grey) | Hills income +10% | Economic powerhouse |
| **Crimson Ascendancy** (Orange) | Mountain attack penalty -1 | Siege specialist |

## 3. Player Resources

- **Armies** — integer count per territory
- **Income** — armies earned per turn
- **Supply** — boolean per territory (connected to source)
- **Turn status** — active / eliminated / ready

## 4. Elimination

A player is eliminated when they own zero territories. The last player standing wins. Eliminated players cannot act.

## 5. Alliances & Diplomacy

**Deferred to Category 2.** Not in first playable version.

## 6. Optional Player Abilities

**Deferred to Category 3.** Not in first playable version.