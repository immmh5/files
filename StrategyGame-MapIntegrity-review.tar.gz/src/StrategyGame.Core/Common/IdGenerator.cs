namespace StrategyGame.Core.Common;

using System.Globalization;
using System.Security.Cryptography;
using System.Text;

/// <summary>
/// Deterministic and random identifier generator.
///
/// Identifier strategy: SHA-256 (FIPS 180-4) truncated to 128 bits, rendered as
/// lowercase hex. Truncation of a cryptographic hash is the standard shortened-
/// digest construction (same technique Git uses for abbreviated object IDs).
///
/// CANONICAL INPUT ENCODING (identical on every platform):
///   input = namespace + 0x00 + seed-decimal + 0x00 + sequence-decimal
///   bytes = UTF-8(input), InvariantCulture digits — no locale dependence.
///
/// BYTE ORDER: none used. The SHA-256 output is consumed byte-by-byte in its
/// native big-endian order; BitConverter (endian-dependent) is NOT used anywhere.
///
/// LIMITS AND GUARANTEES:
/// - 128-bit space: ~3.4 × 10^38 values. Birthday collision reaches 50% only at
///   ~2 × 10^19 generations. Probabilistic identifiers do NOT mathematically
///   guarantee uniqueness; collisions are possible but astronomically unlikely.
/// - Sequence is validated, never silently wrapped. int.MaxValue is the hard limit
///   per (namespace, seed); exceeding it throws rather than duplicating inputs.
/// - Deterministic generation has NO process-global state: results depend only on
///   (namespace, seed, sequence), never on previously generated IDs.
/// </summary>
public static class IdGenerator
{
    /// <summary>Separator byte between canonical input fields (NUL).</summary>
    private const char FieldSeparator = '\0';

    /// <summary>Hard upper bound for deterministic sequences.</summary>
    public const int MaxSequence = int.MaxValue;

    // ---------------------------------------------------------------------------
    // Deterministic mode — pure function of (namespace, seed, sequence).
    // No shared counters, no retry loops, no process-global state.
    // ---------------------------------------------------------------------------

    /// <summary>
    /// Generates a deterministic ID from an explicit namespace, seed, and sequence.
    /// The same triple always yields the same ID in any process, on Windows or Linux.
    /// Throws instead of wrapping when the sequence exceeds <see cref="MaxSequence"/>.
    /// </summary>
    /// <param name="namespaceName">Non-empty subsystem namespace (e.g. "order", "event").</param>
    /// <param name="seed">Match/simulation seed. Negative values are valid and distinct.</param>
    /// <param name="sequence">Caller-owned counter value. Must be ≥ 0.</param>
    public static string NewDeterministicId(string namespaceName, int seed, int sequence)
    {
        ValidateNamespace(namespaceName);
        if (sequence < 0)
            throw new ArgumentOutOfRangeException(nameof(sequence), sequence, "Sequence must be >= 0.");

        var raw = CanonicalInput(namespaceName, seed, sequence);
        return Format(namespaceName, StableHash.GetStableHashCode(Encoding.UTF8.GetBytes(raw)));
    }

    /// <summary>
    /// Overload preserving the R3 ref-sequence API shape. Increments the caller's
    /// sequence AFTER validation; throws <see cref="OverflowException"/> at
    /// int.MaxValue rather than silently wrapping into duplicate deterministic inputs.
    /// </summary>
    public static string NewDeterministicId(string namespaceName, int seed, ref int sequence)
    {
        ValidateNamespace(namespaceName);
        if (sequence < 0)
            throw new ArgumentOutOfRangeException(nameof(sequence), sequence, "Sequence must be >= 0.");
        if (sequence == int.MaxValue)
            throw new OverflowException(
                $"Sequence exhausted for namespace '{namespaceName}' seed {seed}. " +
                "Start a new seed/match; silent wrap would produce duplicate deterministic inputs.");

        var id = NewDeterministicId(namespaceName, seed, sequence);
        sequence++;
        return id;
    }

    // ---------------------------------------------------------------------------
    // Non-deterministic modes — entropy sources documented per method.
    // ---------------------------------------------------------------------------

    /// <summary>
    /// Cryptographically random ID. Not deterministic — use NewDeterministicId for replay.
    /// Entropy: 128 CSPRNG bytes (RandomNumberGenerator), mixed with the namespace
    /// via the canonical NUL-separated encoding before hashing.
    /// Uniqueness: probabilistic; CSPRNG makes practical collisions negligible.
    /// </summary>
    public static string NewRandomId(string namespaceName)
    {
        ValidateNamespace(namespaceName);
        Span<byte> entropy = stackalloc byte[16];
        RandomNumberGenerator.Fill(entropy);

        var nsBytes = Encoding.UTF8.GetBytes(namespaceName);
        var combined = new byte[nsBytes.Length + 1 + 16];
        nsBytes.CopyTo(combined, 0);
        combined[nsBytes.Length] = (byte)FieldSeparator;
        entropy.CopyTo(combined.AsSpan(nsBytes.Length + 1));

        return Format(namespaceName, StableHash.GetStableHashCode(combined));
    }

    /// <summary>
    /// Timestamp + PID + process-local monotonic counter ID.
    /// Within one process, uniqueness comes from the Interlocked counter.
    /// Across processes, PID separation plus the 128-bit hash space makes
    /// collisions negligible — but probabilistic, not guaranteed.
    /// </summary>
    public static string NewId(string namespaceName)
    {
        ValidateNamespace(namespaceName);
        var raw = $"{namespaceName}{FieldSeparator}{Environment.ProcessId}{FieldSeparator}" +
                  $"{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}{FieldSeparator}" +
                  $"{Interlocked.Increment(ref _globalCounter)}";
        return Format(namespaceName, StableHash.GetStableHashCode(Encoding.UTF8.GetBytes(raw)));
    }

    private static int _globalCounter;

    // ---------------------------------------------------------------------------
    // Canonical encoding helpers
    // ---------------------------------------------------------------------------

    /// <summary>
    /// Builds the canonical input string: namespace NUL seed-decimal NUL sequence-decimal.
    /// Invariant culture formatting guarantees identical digits on all locales/platforms.
    /// NUL separators make field boundaries unambiguous (namespaces cannot contain NUL).
    /// </summary>
    private static string CanonicalInput(string namespaceName, int seed, int sequence) =>
        string.Format(CultureInfo.InvariantCulture,
            "{0}" + FieldSeparator + "{1}" + FieldSeparator + "{2}",
            namespaceName, seed, sequence);

    private static void ValidateNamespace(string namespaceName)
    {
        ArgumentException.ThrowIfNullOrEmpty(namespaceName);
        if (namespaceName.Contains('\0'))
            throw new ArgumentException("Namespace must not contain NUL characters.", nameof(namespaceName));
    }

    private static string Format(string namespaceName, byte[] digest128)
    {
        var hex = Convert.ToHexString(digest128).ToLowerInvariant();
        return $"{namespaceName}_{hex}";
    }
}

/// <summary>
/// Stable hash producing 128-bit digests via SHA-256 truncation.
/// Deterministic across processes and platforms; independent of .NET's
/// randomized string hashing. Supports probabilistic identifiers — NOT a
/// uniqueness guarantee.
/// </summary>
public static class StableHash
{
    /// <summary>Truncated digest width in bytes (128 bits).</summary>
    public const int DigestWidthBytes = 16;

    /// <summary>SHA-256 of the UTF-8 bytes of <paramref name="input"/>, truncated to 128 bits.</summary>
    public static byte[] GetStableHashCode(string input) =>
        GetStableHashCode(Encoding.UTF8.GetBytes(input));

    /// <summary>SHA-256 of <paramref name="input"/>, truncated to 128 bits (big-endian byte order, as defined by FIPS 180-4).</summary>
    public static byte[] GetStableHashCode(byte[] input)
    {
        var full = SHA256.HashData(input);
        var truncated = new byte[DigestWidthBytes];
        Array.Copy(full, truncated, DigestWidthBytes);
        return truncated;
    }

    /// <summary>Lowercase hex rendering of a digest (32 chars for 128 bits).</summary>
    public static string ToHex(byte[] digest) =>
        Convert.ToHexString(digest).ToLowerInvariant();
}