# EVENT_LIFECYCLE.md

**Status:** USER-APPROVED LIFECYCLE — R4.2.2. Seven event-system decisions (DR-R4-1…7) were explicitly approved by the project owner on 2026-11-04. The lifecycle states and transitions here are USER-APPROVED; implementation (R4.3) awaits separate authorization.
**Companion:** `docs/architecture/EVENT_ARCHITECTURE.md` (record fields), `docs/design/EVENT_SYSTEM_SPECIFICATION.md` (rules, open questions), `docs/design/EVENT_SYSTEM_DECISIONS.md` (approved decisions DR-R4-1…7).

---

## 1. Scheduled Event State Machine (PROPOSED)

```
                 ┌────────────┐
   schedule()    │  Draft     │  validation failure → Rejected (terminal)
  ──────────────▶│ (inserted) │
                 └─────┬──────┘
                       │ accepted into pending queue
                 ┌─────▼──────┐   reschedule()      ┌─────────────┐
                 │  Pending   │ ───────────────────▶│ Pending'    │ (new due tick,
                 └─────┬──────┘                     │ (re-issued) │  lineage preserved)
                       │                            └─────────────┘
        cancel() ──────┤ due tick reached in matching phase
       ┌───────────────┼────────────────┐
  ┌────▼─────┐   ┌─────▼──────┐    ┌────▼──────────┐
  │Cancelled │   │  Executing │───▶│ Fired / Active │ (one-shot vs recurring)
  │(terminal)│   │ (handler)  │    └────┬──────────┘
  └──────────┘   └─────┬──────┘         │ duration expires / condition ends
                       │ handler error  ▼
                       ▼          ┌──────────┐
                 Failed/Terminal  │ Expired  │ (terminal; cleanup via registry)
                                  └──────────┘
```

| Transition | Trigger | Atomicity rule |
|---|---|---|
| ∅ → Pending | `Schedule(record)` | Insert validated synchronously; duplicate id rejected |
| Pending → Executing | Scheduler reaches due record at phase boundary | Selection snapshot taken FIRST; execution mutates state per handler |
| Executing → Fired | Handler completes | Effect application + status write are one logical step |
| Executing → Failed | Handler throws | Policy OPEN: fail-fast (tests/dev) vs log-and-skip (release) — ARCH §6 |
| Pending/Fired(recurring) → Cancelled | Explicit `Cancel(eventId)` | Never implicit |
| Fired(one-shot)/Expired → pruned | Housekeeping in Stage C | Removed from queue; watermark journal retains `(tick, seq)` |
| Pending → Pending' | Reschedule = cancel + re-issue | Original becomes Cancelled tombstone until prune |

**Terminal states:** Cancelled, Expired, Failed, pruned-Fired. No resurrection; replay of history comes from logs, not revived records.

## 2. Lifecycle Positions Within A–D Turn Stages

| Stage | Lifecycle work performed |
|---|---|
| A Turn Start | Fire due `Phase=TurnStart` records (in total order); apply start effects |
| B Player Actions | New schedules may be INSERTED (as side effects of executed commands); no firing during B (Q-R4-3 default) |
| C Event Processing | Main pass: fire due `Phase=EventProcessing` records; decrement durations of Active effects; expire; prune tombstones |
| D Turn End | Fire due `Phase=TurnEnd` records; victory check; clock advance point (OPEN Q-R4-1) |

Clock advance point determines when "due" means due; recorded as OPEN, not decided here.

## 3. Save/Restore Lifecycle Rules

| Rule | Behavior | Status |
|---|---|---|
| Save boundary | Snapshot only at completed stage boundaries; mid-B saves capture command sub-log + queue atomically | PROPOSED (inherits TURN_AND_EVENT_SYSTEM §6) |
| Restored statuses mapping | Pending→Pending; Active→Active w/ saved remaining duration; Cancelled/Expired/Fired NOT restored (journal watermark instead) | PROPOSED |
| Due-in-the-past on load | Fires at next matching phase in total order; never silently skipped or backdated | PROPOSED |
| Duplicate suppression | Watermark = last processed `(logicalTick, sequenceNumber)`; scheduler drops ≤ watermark | PROPOSED |
| Validation on restore | Targets exist, schema version migratable, statuses legal; illegal ⇒ load fails loudly (unknown-type policy OPEN Q-R4-6) | PROPOSED |

## 4. Pause / Resume

- Simulation-side: pause halts the authoritative clock at stage boundary; nothing fires while paused; queue frozen. (Multiplayer disconnect behavior OPEN Q-R4-4.)
- Presentation-side: unaffected by simulation pause; animations may continue cosmetically.
- Resume: processing continues exactly where the watermark says; no catch-up firing of "missed" real-world time because logical clock did not advance.

## 5. Command Lifecycle (Category A — trivial)

`Created → Submitted → [Host: Validated] → Accepted | Rejected(reason) → Executed → Logged`

Rejected commands are terminal but logged for diagnostics/replay-of-attempts display. Accepted+Executed produce domain facts and possibly new schedules.

## 6. Domain Fact Lifecycle (Category B — trivial)

`Emitted (immutable) → Dispatched to subscribers → Broadcast (MP) → Journal append → Pruned by ring-buffer cap`

Facts never change state after emission; consumers must treat them as read-only values.

## 7. Presentation Event Lifecycle (Category D — transient)

`Derived from fact → Queued app-side → Consumed by renderer/audio/UI OR superseded/dropped → Discarded`

No persistence, no authority, no ordering guarantee beyond best-effort FIFO. Overflow policy: coalesce or drop oldest cosmetic events under load (never blocks gameplay).

## 8. Error Handling Matrix

| Failure | Detection | Response | Recovery |
|---|---|---|---|
| Duplicate schedule insert | Id uniqueness check | Reject insert, diagnostic | Caller decides retry |
| Handler exception | Try/catch at Executing | Policy: fail-fast dev/test, log-skip release (OPEN) | Record Failed; watermark advances so replay stays consistent |
| Missing handler registry key | At fire time or load time | Load-time: reject save. Fire-time: impossible if load validated (same assembly) | Version migration |
| Queue overflow beyond cap | Insert | Hard design cap candidate (e.g. 10⁴ pending) → throw + telemetry | Investigate leak scenario |
| Bus handler mutation during dispatch | Prevented structurally (snapshot copy, ARCH §6) | n/a | n/a |
| Clock regression (due < current on insert) | Validate at Schedule | Treat as due-now OR reject negative offset — **OPEN choice**; recommend reject caller error, since scheduling "in the past" signals logic bugs | Fix producer |

## 9. Invariants (testable assertions for future implementation)

1. Every fired event was Pending before its firing phase within the same match.
2. Total order of firings reproducible from (queue snapshot, clock, registry) alone.
3. No wall-clock value influences any transition.
4. Cancelled/Expired records never execute.
5. Save→load round-trip preserves pending set exactly (modulo migration).
6. Watermark guarantees no double-execution after restore.
7. Presentation completion never observed by simulation code (enforceable by layering: Core has no reference to presentation types).
