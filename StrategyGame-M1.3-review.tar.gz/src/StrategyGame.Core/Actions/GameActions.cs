namespace StrategyGame.Core.Actions;

using StrategyGame.Core.Domain;

/// <summary>
/// M1.3 — Base interface for all player actions.
/// </summary>
public interface IGameAction
{
    /// <summary>Unique action identifier for logging/diagnostics.</summary>
    string ActionId { get; }

    /// <summary>Player who submitted this action.</summary>
    string PlayerId { get; }

    /// <summary>Action type for validation and execution routing.</summary>
    ActionType Type { get; }
}

/// <summary>
/// M1.3 — Player action types.
/// </summary>
public enum ActionType
{
    Reinforce = 0,
    Attack = 1,
    Fortify = 2,
}

/// <summary>
/// M1.3 — Reinforce action: place armies on owned territory during Turn Start or Player Action Phase.
/// </summary>
public sealed record ReinforceAction(
    string ActionId,
    string PlayerId,
    string TerritoryId,
    int Armies)
    : IGameAction
{
    public ActionType Type => ActionType.Reinforce;
}

/// <summary>
/// M1.3 — Attack action: commit armies from owned territory to attack adjacent enemy/neutral territory.
/// </summary>
public sealed record AttackAction(
    string ActionId,
    string PlayerId,
    string FromTerritoryId,
    string ToTerritoryId)
    : IGameAction
{
    public ActionType Type => ActionType.Attack;
}

/// <summary>
/// M1.3 — Fortify action: move armies between adjacent owned territories (non-front-line only per design).
/// </summary>
public sealed record FortifyAction(
    string ActionId,
    string PlayerId,
    string FromTerritoryId,
    string ToTerritoryId,
    int Armies)
    : IGameAction
{
    public ActionType Type => ActionType.Fortify;
}