# EVENT_SYSTEM_DECISIONS.md

**Status:** USER-APPROVED DECISIONS — R4.2.2. All seven decisions were explicitly approved by the project owner on 2026-11-04. These are now the authoritative record for implementation (R4.3+).
**Scope:** The seven open questions recorded in `docs/design/EVENT_SYSTEM_SPECIFICATION.md` §6 (Q-R4-1 … Q-R4-7). Mechanism details live in `docs/architecture/EVENT_ARCHITECTURE.md`; lifecycle states in `docs/design/EVENT_LIFECYCLE.md`. This document contains the approved decision analysis — no duplication of those designs.

---

## DR-R4-1 — Clock Granularity — **USER-APPROVED**

**Problem.** Scheduled events need a "due time," but the unit of game time is undefined: player turns, rounds, ticks, or frames? The authoritative clock decides when effects tick and must never be the render loop. Additionally, the hybrid turn structure's A–D phases span *player turns* and complete *rounds* — two notions of time are needed but not yet separated.

**Approved Clock Model [USER-APPROVED]:**
- **`TurnSequence`** — `int`, monotonically increasing by 1 at every Stage-D transition (end of any player's turn). Serves as the primary deterministic timestamp for scheduled-event ordering and persistence.
- **`RoundIndex`** — `int`, stored explicitly, NOT derived as `TurnSequence / PlayerCount`. Rationale: deriving rounds breaks under elimination (a player removed mid-round changes the quotient unpredictably). RoundIndex is incremented at Stage D of whichever player's turn *completes the round*.
- **PresentationTime** — local `float` on the App side; used by visual interpolation only; never referenced by Core code or persisted.

**Round Advancement Semantics [USER-APPROVED]:** a round consists of one turn per currently-active player in their established order. When a player's turn reaches Stage D:
1. Determine whether any player still needs to act this round (those with `CurrentTurnNumber % playerOrder.Count != currentSeatIndex` AND whose seat isn't frozen/disconnected-eliminated).
2. If some remain → stay in `RoundIndex`; `TurnSequence` increments.
3. If none remain → `RoundIndex` increments; `TurnSequence` also increments (now entering next player's first turn of the new round).

This makes round progression deterministic despite eliminations and disconnections. `RoundIndex` is serialized alongside `TurnSequence` so saves capture the exact in-round position.

**Approved Decision [USER-APPROVED]:** **(a)+(d) as refined above** — two explicit integers (`TurnSequence` + `RoundIndex`) plus a local-only `PresentationTime`. Elimination-safe round tracking without arithmetic derivation.

**Gameplay example.** P1 conquers a region during their turn; a "fortified border" effect scheduled with duration 2 expires after exactly 2 subsequent *rounds* (measured by RoundIndex), not 2 subsequent player turns — so the duration means the same thing in a 2-player match as in a 6-player match even if players are eliminated along the way. If instead the designer wanted duration 2 in *player turns*, a separate `PlayerTurnDuration` field (not the global clock) carries that semantic; the global clock is only for round-aligned effects.

**Depends on:** none. **Blocks:** DR-R4-2 (effect-cadence choice), DR-R4-5 (victory checkpoint).

---

## DR-R4-2 — Cross-Player Effect Advancement — **USER-APPROVED**

**Problem.** Do multi-turn effects tick down during OTHER players' turns, or only during the owner's? Fairness question: with unequal remaining turns (eliminations, disconnects), different answers produce different effective durations. Refined to account for the dual-clock model from DR-R4-1.

**Approved Decision [USER-APPROVED] — two distinct effect classes:**

1. **Global round-based effects** — e.g., "autumn attrition fires at round start," "continent bonus at round end." These use `RoundIndex` exclusively (DR-R4-1). Scheduled via `ScheduledEventRecord.DueRoundIndex`. Deterministic ordering at round boundaries is guaranteed by total order (§5 in EVENT_ARCHITECTURE.md: due tick → priority → sequence → id). No ambiguity: if two global effects are due in the same round, they fire in priority/sequence order in Stage A or Stage C.

2. **Player-specific turn-based effects** — e.g., "P2's fortification buff lasts 2 of P2's own turns," "P3's cooldown recovers one turn after P3 acts." These use `PlayerTurnCounter[playerId]` — a per-player monotonic integer incremented at each Stage D of that player's turn. Such effects store `DuePlayerTurnCount = PlayerTurnCounter[playerId] + duration` in their record and check against that player's current counter during Stage C of *any* player's turn.

**Performance:** identical for both classes — one pass over pending effects at Stage C, comparing a single integer field. **Multiplayer:** both counters are owned by the host and part of GameState. **Save/Load:** `RoundIndex`, `TurnSequence`, and all `PlayerTurnCounter[N]` values are serialized alongside the queue.

**Approved Decision [USER-APPROVED]:** **(b) for global effects via `RoundIndex`; per-player counter for personal effects.** This cleanly separates the two use-cases, gives designers the right unit for each effect, and eliminates the unfairness of (c) for personal effects (an enemy's buff still ticks for their enemy even if that enemy is idle) while preserving predictability when the *owner* of the effect is idle.

**Gameplay example.** Round 3 Stage A: "harvest festival" (global, due RoundIndex=3) fires for everyone simultaneously. Meanwhile P2's personal "berserk rage" (personal, duePlayerTurnCount=P2TurnCounter+2) waits until P2's second subsequent turn, regardless of how many rounds P3 and P4 spend deliberating in between.

**Depends on:** DR-R4-1. **Blocks:** balance tuning, DR-R4-3 interaction analysis.

---

## DR-R4-3 — Scheduled Events During Stage B — **USER-APPROVED**

**Problem.** While the active player is choosing actions (Stage B), may the scheduler fire gameplay events? Three distinct things get conflated: (i) immediate command consequences (attack resolves when issued — already approved provisional), (ii) scheduled gameplay events (data records due at some tick), (iii) presentation animations (cosmetic, always allowed).

**Approved Decision [USER-APPROVED]:** **(a).** Scheduled events execute exclusively at defined phase boundaries (A/C/D). Commands still resolve immediately upon submission (unchanged provisional rule) — that is category-A consequence, not category-C firing. Presentations of due-but-unfired effects may show "pending" indicators derived from the snapshot queue (read-only data, already synced).

**Gameplay example.** At the start of P2's turn, an "autumn attrition" scheduled 3 rounds ago fires in Stage A: all unsupplied groups lose 1 army, then P2 plans actions against the settled numbers. Nothing changes while P2 deliberates.

**Depends on:** DR-R4-1. **Blocks:** EventScheduler execution-loop shape in R4.3.

---

## DR-R4-4 — Disconnect & Pause Policy — **USER-APPROVED**

**Problem.** Define behavior for six scenarios without assuming every client drop should freeze the table. Refined with the constraint that an already-crashed host cannot perform a new autosave (no magical recovery from nothing).

**Approved Policy [USER-APPROVED]:**

| Scenario | Approved Policy [USER-APPROVED] |
|---|---|
| **Host disconnect (unexpected crash)** | **(h1)** — restart host process and replay from the last completed stage boundary's save file + event watermark. If the last save was an entire round ago, that's the recovery point. **Explicitly documented limitation: no in-memory autosave from a crashed host.** |
| **Host graceful shutdown** | **Checkpoint at current stage boundary, then pause.** Players may pause the host; the paused state persists in the save file. No simulation advances. |
| **Non-current client disconnect** | **(c2) default**: game continues, seat frozen (no orders accepted); reconnect restores control within N turns, else convert to AI/idle per host setting. **Never implicit global pause.** Their scheduled effects still tick under DR-R4-2 rules. |
| **Current player disconnect** | **(p2)**: bounded grace (configurable, default e.g. 60 s action-phase timer already proposed in D-03 covers this), then turn auto-ends with no orders. Their scheduled effects still tick (DR-R4-2 fairness preserved). If disconnected for K rounds where K > grace threshold, seat freezes and round-end logic advances normally. |
| **Brief network interruption** | **No simulation response at all**; transport reconnects silently. Only confirmed disconnection (grace expired) triggers policies above. |
| **Reconnection** | Existing design stands: host sends authoritative snapshot + pending-event queue + watermark; client rejoins as mirror. Snapshot captures state *at the last stage boundary*, so reconnecting players see a consistent world. |
| **Manual game suspension** | Keep: pause only ever occurs at boundaries — consistent with DR-R4-3's boundary-execution model. |

**Approved Critical Distinction [USER-APPROVED]:** **Graceful shutdown vs. unexpected crash are distinct.** A crashed host cannot perform a new autosave. Recovery always reads the last persisted checkpoint + event watermark. No in-memory autosave from a crashed host. No automatic host migration approved.

**Gameplay example.** In a 4-player LAN game, P3's laptop sleeps during P1's turn. Play continues. P3's "border fortification" effect still ticks down each player turn (DR-R4-2 global round-based) and P3's personal "berserk rage" counts down each P3 turn (DR-R4-2 personal). When P3 returns within the grace window, they reconnect via snapshot and resume normally; had they stayed away through their own turn twice past the threshold, the host auto-ended those turns and converted their seat. If the host itself crashes during P2's turn, no in-memory autosave is possible — the game recovers from the last completed-boundary save file and resumes from there.

**Depends on:** DR-R4-2 (effects ticking for absent players). **Blocks:** MP UX specs only; not R4.3 core scheduler.

---

## DR-R4-5 — Victory Evaluation Timing — **USER-APPROVED**

**Problem.** When is `VictoryChecker.CheckVictory` invoked? Current code checks whenever called; D-07 says "at round start" (unapproved); hybrid structure places a victory check at Stage D. **The 60% threshold itself remains unapproved — this decision is purely about WHEN, not WHAT.** Refined to respect the explicit `RoundIndex` from DR-R4-1.

**Approved Decision [USER-APPROVED]:** **(b) Stage D**, consistent with R4.2. The existence of an explicit `RoundIndex` (DR-R4-1) makes (c) feasible if owners later decide round-aligned victory is preferable, but the incremental complexity (extra sync point, stale mid-round state) doesn't outweigh the simplicity of Stage D. **Explicitly decoupled from the 60% threshold, which remains unapproved** — recommend splitting D-07's entangled sentence into separate timing + threshold approvals (same as R4.2).

**Gameplay example.** P1's attack during Stage B captures P2's last territory — P2 is eliminated factually at capture, but the game announces victory/elimination in Stage D's summary screen, matching the save point and the multiplayer sync batch.

**Depends on:** DR-R4-1, DR-R4-3. **Related:** R2.1 OPEN list (threshold/denominator/priority remain separate unapproved items).

---

## DR-R4-6 — Unknown Scheduled Events During Load — **USER-APPROVED**

**Problem.** A save references an event type key the running build doesn't know (downgrade, corrupted file, mod removed). Authoritative gameplay events and presentation events must NOT share a policy.

**Approved Policy [USER-APPROVED] — layered policy:**
1. **Known-type, old-schema-version → (d)** run registered migrators; failure falls through to (a).
2. **Unknown-type AUTHORITATIVE event → (a) reject load** with a diagnostic listing keys (protects determinism; users can try an older build).
3. **Unknown-type PRESENTATION event → (c) drop silently** (log at debug level only) — cosmetics carry no state.

Note (b) rejected for authoritative events specifically because "quarantined gameplay" breaks the invariant that restored pending-queue ≡ saved pending-queue.

**Performance:** load-time dictionary probe only. **Multiplayer:** host validates before announcing a session; clients never see invalid queues. **Save/Load:** policy belongs in the loader, orthogonal to payload format (DR-R4-7).

**Gameplay example.** Build 0.3 removes the "harvest festival" scenario event type. Loading a 0.2 save containing a live festival event fails with "unknown event type: harvest_festival.v1" rather than quietly continuing a world where an announced festival never happens.

**Depends on:** handler registry design (ARCH §4). **Blocks:** persistence milestone loader spec.

---

## DR-R4-7 — Event Payload Format — **USER-APPROVED**

**Problem.** Choose serialization for scheduled-event payloads (and eventually saves/network). Constraint honored: **no new packages** — System.Text.Json is in-box; MessagePack is not.

**Approved Decision [USER-APPROVED]:** **(b)+(a): strongly typed DTO records serialized as versioned JSON via System.Text.Json** for BOTH saves and LAN networking initially. Add `SchemaVersion` per payload type. Revisit binary formats only if profiling demonstrates need (per MASTER_SPEC performance rules).

**Gameplay example.** A "border fortification" pending event serializes as readable JSON inside the save file: `{"typeKey":"border_fort","schema":1,"dueRoundIndex":17,"duePlayerTurnCount":{"p2":3},"payload":{"territoryId":"t12","bonus":2}}` — inspectable with any text editor during development, restorable without native libraries on Windows and Linux alike.

**Depends on:** DR-R4-6 shares the loader but not the format. **Blocks:** save-format milestone; MP packet encoding.

---

## Decision Dependency Map

```
DR-R4-1 (TurnSequence + RoundIndex + PresentationTime) ──▶ DR-R4-2 (global vs personal cadence) ──▶ DR-R4-4 (absent-player ticking)
        │
        ├──▶ DR-R4-3 (boundary execution) ──▶ DR-R4-5 (checkpoint = Stage D)
        │                    │
        └────────────────────┴──▶ scheduler shape for R4.3
        
DR-R4-6 (load policy) ── independent of clock; depends on registry design (R4.0)
DR-R4-7 (payload format) ── independent; consumed by DR-R4-6 loader and future save/MP
```

## Summary Of Approved Decisions (all USER-APPROVED)

| ID | Question | Approved |
|---|---|---|
| DR-R4-1 | Clock granularity | Dual authoritative clocks: monotonic `TurnSequence` (int, +1 each turn) + explicit `RoundIndex` (int, NOT derived) + local-only `PresentationTime`; round advances when last remaining active player completes their turn |
| DR-R4-2 | Cross-player effects | Global effects use `RoundIndex`; personal effects use per-player `PlayerTurnCounter`; two distinct classes, not one |
| DR-R4-3 | Events during Stage B | No — phase-boundary execution only; commands still resolve immediately |
| DR-R4-4 | Disconnect/pause | Host crash ⇒ recover from last persisted checkpoint (no in-memory autosave possible); host graceful shutdown ⇒ checkpoint+pause; non-current client drop ⇒ continue w/ idle seat; current player disconnect ⇒ grace timer then auto-EndTurn; no implicit global pauses |
| DR-R4-5 | Victory timing | Stage D only; timing approval decoupled from the still-unapproved 60% threshold |
| DR-R4-6 | Unknown events on load | Known-old schema ⇒ migrate; unknown-authoritative ⇒ reject save; unknown-presentation ⇒ drop silently |
| DR-R4-7 | Payload format | Typed DTOs + versioned JSON (System.Text.Json); binary deferred until measured need |

**Status:** All seven decisions are **USER-APPROVED**. Implementation (R4.3) may now begin per the project owner's future authorization.