# AI Agent Rules

These rules govern how AI agents (including this one) must operate within the repository.

## Working Rules

### Rule 1 — Inspect Before Changing

Always run environment inspection before creating or modifying files:
- Check git status (`git status`).
- Check if the project already exists in the target directory.
- Verify tool versions before building.
- Never assume prerequisites are installed.

### Rule 2 — Incremental Verification

After implementing any infrastructure component:
1. Build the project (`dotnet build`).
2. Run relevant tests (`dotnet test`).
3. Fix regressions immediately.
4. Do not postpone all testing until the end of the milestone.

### Rule 3 — Test Results Over Assumptions

Never claim something works unless you have **actually tested it**. Report test outputs verbatim or by excerpt. Do not hide failed tests. Never convert a failure into a success to make the pipeline green.

### Rule 4 — No Unnecessary Complexity

Do not introduce:
- Microservices or distributed architecture.
- Cloud dependencies or external databases.
- Multiple game engines or multiple primary languages.
- Premature optimization or elaborate plugin frameworks.
- C++ code without measured profiling evidence.

### Rule 5 — Protect Existing Work

- Check git status before modifying any file.
- Never delete or overwrite unrelated files.
- Never use `git reset --hard` or destructive operations.
- If a file is important and needs modification, read it first.

### Rule 6 — No Giant Source Files

- One class per file.
- Files under ~500 lines as a soft guideline.
- Use meaningful names; avoid `Manager`, `Helper` suffixes without justification.

### Rule 7 — Document Every Dependency

Every NuGet package, tool, extension, or plugin must have:
- A clear documented purpose.
- Version and compatibility note.
- Reason for inclusion (not "it might be useful").

### Rule 8 — No Silent Changes

- Every dependency added or removed must be documented in the relevant ADR or commit message.
- Compiler warnings are not silent — they must be explicitly acknowledged or fixed.

### Rule 9 — Scope Discipline

- Do not implement gameplay features during infrastructure milestones.
- Do not expand scope to add "nice-to-have" systems without approval.
- Finish the current milestone before starting the next.

### Rule 10 — Documentation Must Match Implementation

- When a major architectural decision changes, update the documentation.
- Implementation and documentation must not contradict each other.
- ADRs are the source of truth for technical decisions.

## Code Style

- **C#:** Follow `.editorconfig` settings. Enable nullable reference types. Use `readonly` structs for value objects.
- **GDScript (if used):** Use typed variables where possible. Avoid `var`.
- **Documentation:** Use `docs/` for architecture decisions; keep implementation details in code comments.
- **Naming:** `PascalCase` for types and methods; `_camelCase` for private fields; `CONSTANT_CASE` for statics.

## Test Naming

Use `[MethodUnderTest]_[Scenario]_[ExpectedResult]` format for test method names.

## Git Workflow

1. Create a branch per significant work item.
2. Commit early and often with meaningful messages.
3. Use conventional commit format: `feat:`, `fix:`, `docs:`, `chore:`, `test:`.
4. Open a PR when ready for review.
5. Never commit generated files (`.godot/`, `bin/`, `obj/`).

## Scope for Milestone 0

**The following are explicitly out of scope for Milestone 0:**
- Gameplay logic (territories, factions, turns, combat)
- AI implementations
- Networking implementations
- Save/load implementations
- Actual game maps or assets
- Export templates
- UI beyond a minimal smoke-test screen
