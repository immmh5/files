# Architecture — Strategy Game

## Overview

The project follows a **core-application separation** pattern: a pure C# class library (`StrategyGame.Core`) that contains all authoritative game logic, state, and domain rules; and a Godot application project (`StrategyGame.App`) that provides rendering, input, and UI by consuming the core library.

This separation enables:
- Unit testing of game rules without launching the Godot editor.
- Future replacement of the Godot rendering layer without touching game rules.
- Parallel development of the core game model and the presentation layer.

```
┌─────────────────────────────────────────────────────┐
│  StrategyGame.App (Godot 4.7.2 C# project)         │
│  - Scenes, UI, Input, Rendering                     │
│  - References StrategyGame.Core                     │
│  - GodotAssembly references: GodotSharp             │
└──────────────────────┬──────────────────────────────┘
                       │ References (compile-time)
                       ▼
┌─────────────────────────────────────────────────────┐
│  StrategyGame.Core (Pure C# class library)          │
│  - Domain/ (entities, value objects)                │
│  - GameState/ (state machines, snapshot)            │
│  - Events/ (typed event system)                     │
│  - Common/ (utilities, collections)                  │
│  - Networking/ (interfaces, not Godot)              │
│  - AI/ (interfaces, not Godot)                      │
│  - Storage/ (serialization interfaces)              │
│  NO Godot assemblies referenced                     │
└─────────────────────────────────────────────────────┘
```

---

## Module Responsibilities

### StrategyGame.Core

**Domain/** — Pure domain model. No external dependencies.
- `Player` — Player identity, faction, resources.
- `Territory` — Territory data (id, adjacency list, owner, armies).
- `Faction` — Faction definition, abilities, bonuses.
- `Orders` — Order objects (attack, fortify, reinforce).
- `MapDefinition` — Map topology, territory graph.

**GameState/** — Authoritative game state.
- `GameState` — Root game-state object; snapshot-copyable.
- `TurnManager` — Turn sequencing, phase management.
- `CombatSystem` — Resolution of attack orders (pure logic, no random).
- `VictoryChecker` — Win/loss condition evaluation.
- `GameRules` — Configuration for rules (army counts, phase order, etc.).

**Events/** — Immutable typed events.
- `GameEvent` — Base marker interface.
- `TerritoryCapturedEvent`, `TurnStartedEvent`, `OrderSubmittedEvent`, etc.
- `EventBus` — In-process pub/sub (no networking); used for UI sync.

**Common/** — Utilities.
- `IdGenerator`, `ReadOnlyList<T>`, `ValueObject<T>`, `Result<T>`.

**Networking/** — Connection interfaces only (no Godot refs).
- `INetworkTransport` — Send/receive unreliable/ordered byte[] messages.
- `INetworkDiscovery` — LAN room discovery service interface.
- `GamePacket` — Serializable packet envelope.

**AI/** — AI interfaces.
- `IAIPlayer` — `ChooseOrders(GameState) -> Order[]`.

**Storage/** — Persistence interfaces.
- `ISaveSerializer` — Serialize/deserialize `GameState`.
- `IMapLoader` — Load `MapDefinition` from disk.

---

### StrategyGame.App

**Scenes/** — Godot scene files (.tscn).
**Scripts/** — Godot C# nodes.
- `Main.cs` — Entry point, scene tree root.
- `GameController.cs` — Connects Core game state to Godot UI.
- `MapView.cs` — 2.5D strategy map rendering node.

**UI/** — UI scenes and scripts.
**Rendering/** — Custom render pipeline (2.5D effects).
**Input/** — Input handling and gesture processing.

---

## Rendering and 2.5D Strategy

The strategy map is rendered via **Node2D with a layered SubViewport approach**:

1. **Base layer:** `Node2D` with a `TileMap` or `Polygon2D` for territory shapes and terrain.
2. **Highlight layer:** Separate `SubViewport` for selection, hover, and attack visuals.
3. **Unit layer:** Sprite-based army markers positioned at territory centroids.
4. **UI overlay:** Godot `Control` nodes in the CanvasLayer above everything.
5. **Depth effects:** Per-territory shading via modulated ColorMasks, drop shadows via `Light2D` or custom draw.

Camera: `Camera2D` with smooth tween for pan/zoom.

The core library has no knowledge of render nodes — rendering is purely a presentation concern of `StrategyGame.App`.

---

## State Management

- `GameState` is the **single source of truth** for the current game.
- It is **immutable-for-inspection** after each game tick: methods that mutate do so on a working copy.
- `GameState.Snapshot()` creates a deep copy for UI binding or AI evaluation.
- `EventBus` publishes domain events after each state mutation so the App layer can update visuals.

---

## Networking Architecture (Design)

```
INetworkTransport (interface)
  └─ ENetTransport (initial implementation — LAN UDP)
  └─ WebRTCTransport (future — native WebRTC)
  └─ FakeTransport (testing)

INetworkDiscovery (interface)
  └─ LANBroadcastDiscovery (initial — UDP broadcast)
  └─ SignalingServiceDiscovery (future — optional cloud relay)

Authority Model: Host-Authoritative
  - The host holds the authoritative GameState.
  - Each turn, host broadcasts an OrderRequest event.
  - Clients submit orders (encrypted/packetized).
  - Host resolves, broadcasts state snapshot.
  - Clients apply snapshot to their local mirrored state.
```

---

## Build and Export

- `dotnet build` for both `StrategyGame.Core` and `StrategyGame.App`.
- `godot --headless --build-solutions` for Godot .NET build verification.
- Godot export templates for Windows (.exe) and Linux (.x86_64).

See `docs/BUILD_AND_EXPORT.md` for detailed build pipeline.
