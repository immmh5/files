namespace StrategyGame.Core.Tests.GameState;

using StrategyGame.Core.Domain;
using StrategyGame.Core.GameState;
using static StrategyGame.Core.GameState.VictoryChecker;
using Xunit;

public class VictoryCheckerTests
{
    private MapDefinition CreateThreeTerritoryMap()
    {
        return new MapDefinition("m1", "Three", new[]
        {
            new Territory("A", "A", new[] { "B" }),
            new Territory("B", "B", new[] { "A", "C" }),
            new Territory("C", "C", new[] { "B" }),
        });
    }

    private MapDefinition CreateFiveTerritoryMap()
    {
        return new MapDefinition("m2", "Five", new[]
        {
            new Territory("A", "A", new[] { "B" }),
            new Territory("B", "B", new[] { "A", "C" }),
            new Territory("C", "C", new[] { "B", "D" }),
            new Territory("D", "D", new[] { "C", "E" }),
            new Territory("E", "E", new[] { "D" }),
        });
    }

    private GameState CreateGameState(string p1, string p2,
        Dictionary<string, string> ownerMap)
    {
        var map = CreateThreeTerritoryMap();
        var players = new List<Player>
        {
            new Player(p1, "Player 1", new Faction("f1", "Red", "#FF0000"), isHuman: true),
            new Player(p2, "Player 2", new Faction("f2", "Blue", "#0000FF"), isHuman: false),
        };
        var state = new GameState("g1", map, players, p1, 1, TurnManager.PhaseReinforce);

        foreach (var kv in ownerMap)
        {
            var t = state.GetTerritory(kv.Key);
            t.SetOwner(kv.Value, 3);
        }
        return state;
    }

    private GameState CreateFiveTerritoryGameState(string p1, string p2,
        Dictionary<string, string> ownerMap)
    {
        var map = CreateFiveTerritoryMap();
        var players = new List<Player>
        {
            new Player(p1, "Player 1", new Faction("f1", "Red", "#FF0000"), isHuman: true),
            new Player(p2, "Player 2", new Faction("f2", "Blue", "#0000FF"), isHuman: false),
        };
        var state = new GameState("g1", map, players, p1, 1, TurnManager.PhaseReinforce);

        foreach (var kv in ownerMap)
        {
            var t = state.GetTerritory(kv.Key);
            t.SetOwner(kv.Value, 3);
        }
        return state;
    }

    [Fact]
    public void CheckVictory_OnePlayerOwnsAllTerritories_ReturnsDominationVictory()
    {
        var state = CreateGameState("p1", "p2",
            new Dictionary<string, string> { { "A", "p1" }, { "B", "p1" }, { "C", "p1" } });

        var info = VictoryChecker.CheckVictory(state);

        Assert.True(info.IsVictorious);
        Assert.Equal(VictoryCondition.Domination, info.Condition);
        Assert.Contains("100", info.Reason); // 100% control
    }

    [Fact]
    public void CheckVictory_SplitOwnership_ReturnsNoVictory()
    {
        // With 5 territories: p1 has 2 (40%), p2 has 2 (40%), 1 neutral (20%)
        // No one has ≥60%
        var state = CreateFiveTerritoryGameState("p1", "p2",
            new Dictionary<string, string>
            {
                { "A", "p1" }, { "B", "p1" },
                { "C", "p2" }, { "D", "p2" },
            });

        var info = VictoryChecker.CheckVictory(state);

        Assert.False(info.IsVictorious);
        Assert.Equal(VictoryCondition.None, info.Condition);
    }

    [Fact]
    public void CheckVictory_SinglePlayerEliminated_ReturnsEliminationVictory()
    {
        var map = new MapDefinition("m1", "Three", new[]
        {
            new Territory("A", "A", new[] { "B" }),
            new Territory("B", "B", new[] { "A", "C" }),
            new Territory("C", "C", new[] { "B" }),
        });
        var p1 = new Player("p1", "Player 1", new Faction("f1", "Red", "#FF0000"), true);
        var p2 = new Player("p2", "Player 2", new Faction("f2", "Blue", "#0000FF"), false);
        var state = new GameState("g1", map, new List<Player> { p1, p2 }, "p1", 1, TurnManager.PhaseReinforce);

        state.GetTerritory("A").SetOwner("p2", 3);
        state.GetTerritory("B").SetOwner("p2", 3);
        state.GetTerritory("C").SetOwner("p2", 3);

        var info = VictoryChecker.CheckVictory(state);

        Assert.True(info.IsVictorious);
        Assert.Equal(VictoryCondition.Domination, info.Condition);
    }

    [Fact]
    public void CheckVictory_EmptyTerritoryOwnership_ReturnsNoVictory()
    {
        var state = CreateGameState("p1", "p2",
            new Dictionary<string, string>());

        var info = VictoryChecker.CheckVictory(state);

        Assert.False(info.IsVictorious);
        Assert.Equal(VictoryCondition.None, info.Condition);
    }

    [Fact]
    public void CheckVictory_Domination_ReturnsWinningPlayerId()
    {
        var state = CreateGameState("p1", "p2",
            new Dictionary<string, string> { { "A", "p1" }, { "B", "p1" }, { "C", "p1" } });

        var info = VictoryChecker.CheckVictory(state);

        Assert.True(info.IsVictorious);
        Assert.Equal(VictoryCondition.Domination, info.Condition);
        Assert.Equal("p1", info.WinningPlayerId);
    }

    [Fact]
    public void CheckVictory_Elimination_ReturnsWinningPlayerId()
    {
        var map = new MapDefinition("m1", "Three", new[]
        {
            new Territory("A", "A", new[] { "B" }),
            new Territory("B", "B", new[] { "A", "C" }),
            new Territory("C", "C", new[] { "B" }),
        });
        var p1 = new Player("p1", "Player 1", new Faction("f1", "Red", "#FF0000"), true);
        var p2 = new Player("p2", "Player 2", new Faction("f2", "Blue", "#0000FF"), false);
        var state = new GameState("g1", map, new List<Player> { p1, p2 }, "p1", 1, TurnManager.PhaseReinforce);

        state.GetTerritory("A").SetOwner("p2", 3);
        state.GetTerritory("B").SetOwner("p2", 3);
        state.GetTerritory("C").SetOwner("p2", 3);

        var info = VictoryChecker.CheckVictory(state);

        Assert.True(info.IsVictorious);
        Assert.Equal("p2", info.WinningPlayerId);
    }

    [Fact]
    public void CheckVictory_Domination_AtLeast60Percent_Not100Percent()
    {
        var state = CreateFiveTerritoryGameState("p1", "p2",
            new Dictionary<string, string>
            {
                { "A", "p1" }, { "B", "p1" }, { "C", "p1" },
                { "D", "p2" }, { "E", "p2" }
            });

        var info = VictoryChecker.CheckVictory(state);

        Assert.True(info.IsVictorious);
        Assert.Equal(VictoryCondition.Domination, info.Condition);
        Assert.Equal("p1", info.WinningPlayerId);
    }

    [Fact]
    public void CheckVictory_Domination_Below60Percent_NoVictory()
    {
        var state = CreateFiveTerritoryGameState("p1", "p2",
            new Dictionary<string, string>
            {
                { "A", "p1" }, { "B", "p1" },
                { "C", "p2" }, { "D", "p2" }, { "E", "p2" }
            });

        var info = VictoryChecker.CheckVictory(state);

        Assert.True(info.IsVictorious);
        Assert.Equal(VictoryCondition.Domination, info.Condition);
        Assert.Equal("p2", info.WinningPlayerId);
    }

    [Fact]
    public void CheckVictory_NeutralTerritories_NotCountedTowardDomination()
    {
        var state = CreateFiveTerritoryGameState("p1", "p2",
            new Dictionary<string, string>
            {
                { "A", "p1" }, { "B", "p1" },
                { "C", "p2" }, { "D", "p2" },
            });

        var info = VictoryChecker.CheckVictory(state);

        Assert.False(info.IsVictorious);
        Assert.Equal(VictoryCondition.None, info.Condition);
    }

    [Fact]
    public void CheckVictory_Elimination_OnePlayerHasNoTerritories_ReturnsSurvivorId()
    {
        var map = new MapDefinition("m1", "Three", new[]
        {
            new Territory("A", "A", new[] { "B" }),
            new Territory("B", "B", new[] { "A", "C" }),
            new Territory("C", "C", new[] { "B" }),
        });
        var p1 = new Player("p1", "Player 1", new Faction("f1", "Red", "#FF0000"), true);
        var p2 = new Player("p2", "Player 2", new Faction("f2", "Blue", "#0000FF"), false);
        var state = new GameState("g1", map, new List<Player> { p1, p2 }, "p1", 1, TurnManager.PhaseReinforce);

        state.GetTerritory("A").SetOwner("p2", 3);
        state.GetTerritory("B").SetOwner("p2", 3);
        state.GetTerritory("C").SetOwner("p2", 3);

        var info = VictoryChecker.CheckVictory(state);

        Assert.True(info.IsVictorious);
        Assert.Equal("p2", info.WinningPlayerId);
    }

    [Fact]
    public void CheckVictory_AllTerritoriesNeutral_NoVictory()
    {
        var state = CreateGameState("p1", "p2", new Dictionary<string, string>());

        var info = VictoryChecker.CheckVictory(state);

        Assert.False(info.IsVictorious);
        Assert.Equal(VictoryCondition.None, info.Condition);
        Assert.Null(info.WinningPlayerId);
    }

    [Fact]
    public void CheckVictory_NoTerritories_NoVictory()
    {
        var map = new MapDefinition("empty", "Empty", Array.Empty<Territory>());
        var p1 = new Player("p1", "Player 1", new Faction("f1", "Red", "#FF0000"), true);
        var state = new GameState("g1", map, new List<Player> { p1 }, "p1", 1, TurnManager.PhaseReinforce);

        var info = VictoryChecker.CheckVictory(state);

        Assert.False(info.IsVictorious);
        Assert.Equal(VictoryCondition.None, info.Condition);
        Assert.Null(info.WinningPlayerId);
    }

    [Fact]
    public void CheckVictory_ThreePlayers_OneDominates()
    {
        var map = new MapDefinition("m1", "Three", new[]
        {
            new Territory("A", "A", new[] { "B" }),
            new Territory("B", "B", new[] { "A", "C" }),
            new Territory("C", "C", new[] { "B" }),
        });
        var p1 = new Player("p1", "Player 1", new Faction("f1", "Red", "#FF0000"), true);
        var p2 = new Player("p2", "Player 2", new Faction("f2", "Blue", "#0000FF"), false);
        var p3 = new Player("p3", "Player 3", new Faction("f3", "Green", "#00FF00"), false);
        var state = new GameState("g1", map, new List<Player> { p1, p2, p3 }, "p1", 1, TurnManager.PhaseReinforce);

        state.GetTerritory("A").SetOwner("p1", 3);
        state.GetTerritory("B").SetOwner("p1", 3);
        state.GetTerritory("C").SetOwner("p2", 3);

        var info = VictoryChecker.CheckVictory(state);

        Assert.True(info.IsVictorious);
        Assert.Equal(VictoryCondition.Domination, info.Condition);
        Assert.Equal("p1", info.WinningPlayerId);
    }

    [Fact]
    public void CheckVictory_Elimination_TwoPlayersEliminated()
    {
        var map = new MapDefinition("m1", "Three", new[]
        {
            new Territory("A", "A", new[] { "B" }),
            new Territory("B", "B", new[] { "A", "C" }),
            new Territory("C", "C", new[] { "B" }),
        });
        var p1 = new Player("p1", "Player 1", new Faction("f1", "Red", "#FF0000"), true);
        var p2 = new Player("p2", "Player 2", new Faction("f2", "Blue", "#0000FF"), false);
        var p3 = new Player("p3", "Player 3", new Faction("f3", "Green", "#00FF00"), false);
        var state = new GameState("g1", map, new List<Player> { p1, p2, p3 }, "p1", 1, TurnManager.PhaseReinforce);

        state.GetTerritory("A").SetOwner("p1", 3);
        state.GetTerritory("B").SetOwner("p1", 3);
        state.GetTerritory("C").SetOwner("p1", 3);

        var info = VictoryChecker.CheckVictory(state);

        Assert.True(info.IsVictorious);
        Assert.Equal("p1", info.WinningPlayerId);
    }
}