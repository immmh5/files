namespace StrategyGame.Core.Tests.Events;

using StrategyGame.Core.Events;
using Xunit;

/// <summary>
/// Regression tests for R4.1 EventBus re-entrancy and collection safety.
/// Each test verifies the DOCUMENTED dispatch semantics, not merely absence of exceptions.
/// </summary>
public class EventBusTests
{
    private readonly record struct TestEvent : GameEvent
    {
        public long EventId { get; init; }
        public DateTime Timestamp { get; init; }
    }

    private readonly record struct OtherEvent : GameEvent
    {
        public long EventId { get; init; }
        public DateTime Timestamp { get; init; }
    }

    // 1. Normal publication
    [Fact]
    public void Publish_InvokesSubscriber()
    {
        var bus = new EventBus();
        int count = 0;
        bus.Subscribe<TestEvent>(_ => count++);

        bus.Publish(new TestEvent());

        Assert.Equal(1, count);
    }

    [Fact]
    public void Publish_NoSubscribers_DoesNotThrow()
    {
        var bus = new EventBus();
        bus.Publish(new TestEvent());
    }

    [Fact]
    public void Subscribe_NullHandler_Throws()
    {
        var bus = new EventBus();
        Assert.Throws<ArgumentNullException>(() => bus.Subscribe<TestEvent>(null!));
    }

    // 2. Subscriber subscribes another subscriber during dispatch
    [Fact]
    public void SubscribeDuringDispatch_AffectsSubsequentPublishOnly()
    {
        var bus = new EventBus();
        int addedCount = 0;
        int outerCount = 0;

        bus.Subscribe<TestEvent>(_ =>
        {
            outerCount++;
            bus.Subscribe<TestEvent>(_ => addedCount++);   // registered mid-dispatch
        });

        bus.Publish(new TestEvent());
        Assert.Equal(1, outerCount);
        Assert.Equal(0, addedCount);   // snapshot: NOT called in this publish

        bus.Publish(new TestEvent());
        Assert.Equal(2, outerCount);
        Assert.Equal(1, addedCount);   // visible from next publish onward
    }

    // 3. Subscriber unsubscribes itself during dispatch
    [Fact]
    public void SelfUnsubscribeDuringDispatch_RunsOnceAndDoesNotThrow()
    {
        var bus = new EventBus();
        int selfCount = 0;
        Action<TestEvent> self = null!;
        self = _ => { selfCount++; bus.Unsubscribe(self); };
        bus.Subscribe(self);
        bus.Subscribe<TestEvent>(_ => { });

        bus.Publish(new TestEvent());          // pre-fix: InvalidOperationException
        Assert.Equal(1, selfCount);

        bus.Publish(new TestEvent());
        Assert.Equal(1, selfCount);            // unsubscribed; not invoked again
        Assert.Equal(1, bus.SubscriptionCount<TestEvent>());
    }

    // 4. Subscriber unsubscribes ANOTHER subscriber during dispatch
    [Fact]
    public void UnsubscribeOtherDuringDispatch_SnapshotStillRunsTargetThisPublish()
    {
        var bus = new EventBus();
        int targetCount = 0;
        Action<TestEvent> target = _ => targetCount++;

        bus.Subscribe(target);
        bus.Subscribe<TestEvent>(_ => bus.Unsubscribe(target));  // first in order

        bus.Publish(new TestEvent());
        Assert.Equal(1, targetCount);          // snapshot semantics: still runs now

        bus.Publish(new TestEvent());
        Assert.Equal(1, targetCount);          // removed for subsequent publishes
    }

    // 5. Nested Publish
    [Fact]
    public void NestedPublish_InnerCompletesBeforeOuterContinues()
    {
        var bus = new EventBus();
        var order = new List<string>();

        bus.Subscribe<TestEvent>(_ =>
        {
            order.Add("outer:start");
            bus.Publish(new OtherEvent());     // nested dispatch
            order.Add("outer:end");
        });
        bus.Subscribe<OtherEvent>(_ => order.Add("inner"));

        bus.Publish(new TestEvent());

        Assert.Equal(["outer:start", "inner", "outer:end"], order);
    }

    [Fact]
    public void NestedPublish_SubscribeInInnerAffectsNeitherLevel()
    {
        var bus = new EventBus();
        int lateCount = 0;

        bus.Subscribe<TestEvent>(_ =>
            bus.Subscribe<OtherEvent>(_ => lateCount++));       // subscribed during outer
        bus.Subscribe<TestEvent>(_ =>
            bus.Publish(new OtherEvent()));                       // inner publish after that

        bus.Publish(new TestEvent());
        // Outer snapshot taken before any handler ran: the OtherEvent subscriber
        // was registered mid-outer-dispatch, but the INNER publish snapshots at its
        // own start — which happens after registration — so it DOES see it.
        Assert.Equal(1, lateCount);
    }

    // 6. Duplicate subscription behavior
    [Fact]
    public void DuplicateSubscription_EachRegistrationInvokedPerPublish()
    {
        var bus = new EventBus();
        int count = 0;
        Action<TestEvent> dup = _ => count++;

        bus.Subscribe(dup);
        bus.Subscribe(dup);

        bus.Publish(new TestEvent());
        Assert.Equal(2, count);
        Assert.Equal(2, bus.SubscriptionCount<TestEvent>());

        bus.Unsubscribe(dup);                  // removes one occurrence (List.Remove)
        bus.Publish(new TestEvent());
        Assert.Equal(3, count);
        Assert.Equal(1, bus.SubscriptionCount<TestEvent>());
    }

    // 7. Handler execution order is deterministic (registration order, FIFO)
    [Fact]
    public void HandlerOrder_IsRegistrationOrder()
    {
        var bus = new EventBus();
        var order = new List<int>();

        for (int i = 0; i < 10; i++)
        {
            int captured = i;
            bus.Subscribe<TestEvent>(_ => order.Add(captured));
        }

        bus.Publish(new TestEvent());
        Assert.Equal(Enumerable.Range(0, 10), order);
    }

    // 8. Repeated publication after subscription changes
    [Fact]
    public void RepeatedPublish_AfterAddRemoveReflectsCurrentSet()
    {
        var bus = new EventBus();
        int a = 0, b = 0;
        Action<TestEvent> ha = _ => a++;
        Action<TestEvent> hb = _ => b++;

        bus.Subscribe(ha);
        bus.Publish(new TestEvent());          // a=1 b=0
        bus.Subscribe(hb);
        bus.Publish(new TestEvent());          // a=2 b=1
        bus.Unsubscribe(ha);
        bus.Publish(new TestEvent());          // a=2 b=2

        Assert.Equal(2, a);
        Assert.Equal(2, b);
        Assert.Equal(1, bus.SubscriptionCount<TestEvent>());
    }

    // 9. Exception behavior: documented fail-fast policy
    [Fact]
    public void ThrowingHandler_PropagatesAndSkipsRemainingHandlers()
    {
        var bus = new EventBus();
        int later = 0;

        bus.Subscribe<TestEvent>(_ => throw new InvalidOperationException("boom"));
        bus.Subscribe<TestEvent>(_ => later++);

        Assert.Throws<InvalidOperationException>(() => bus.Publish(new TestEvent()));
        Assert.Equal(0, later);                // fail-fast: remaining handlers skipped

        // Bus remains usable after a throwing publish
        var bus2 = new EventBus();
        int ok = 0;
        bus2.Subscribe<TestEvent>(_ => ok++);
        bus2.Publish(new TestEvent());
        Assert.Equal(1, ok);
    }

    // Isolation between event types
    [Fact]
    public void SubscribersAreIsolatedPerEventType()
    {
        var bus = new EventBus();
        int t = 0, o = 0;
        bus.Subscribe<TestEvent>(_ => t++);
        bus.Subscribe<OtherEvent>(_ => o++);

        bus.Publish(new TestEvent());
        Assert.Equal(1, t);
        Assert.Equal(0, o);
    }
}