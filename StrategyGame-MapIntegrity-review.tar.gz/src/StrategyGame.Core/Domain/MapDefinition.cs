namespace StrategyGame.Core.Domain;

using System.Collections.ObjectModel;

/// <summary>
/// Defines the topology and static properties of a game map.
///
/// M1.1: extended with regions, territory metadata (terrain / region membership /
/// supply-source) and optional per-territory visual geometry (polygon, centroid).
/// The instance is validated at construction: building an invalid map throws
/// <see cref="MapValidationException"/> with clear diagnostics.
///
/// Geometry data is presentation-only metadata; the logical territory model
/// remains independent of its visual representation.
/// </summary>
public sealed class MapDefinition
{
    public string Id { get; }
    public string Name { get; }
    public int Version { get; }
    public IReadOnlyDictionary<string, Territory> Territories { get; }
    public IReadOnlyDictionary<string, RegionDefinition> Regions { get; }

    /// <summary>
    /// Optional per-territory visual geometry, keyed by territory id.
    /// Absent entries are permitted (geometry is optional metadata).
    /// </summary>
    public IReadOnlyDictionary<string, TerritoryGeometry> Geometry { get; }

    public MapDefinition(string id, string name, IEnumerable<Territory> territories)
        : this(id, name, territories, [], null)
    {
    }

    public MapDefinition(string id, string name, IEnumerable<Territory> territories,
        IEnumerable<RegionDefinition> regions)
        : this(id, name, territories, regions, null)
    {
    }

    public MapDefinition(string id, string name, IEnumerable<Territory> territories,
        IEnumerable<RegionDefinition> regions,
        IReadOnlyDictionary<string, TerritoryGeometry>? geometry,
        int version = 1)
    {
        Id = id ?? throw new ArgumentNullException(nameof(id));
        Name = name ?? throw new ArgumentNullException(nameof(name));
        Version = version;

        var territoryList = (territories ?? throw new ArgumentNullException(nameof(territories))).ToList();
        var regionList = (regions ?? throw new ArgumentNullException(nameof(regions))).ToList();
        var geometryDict = geometry is null
            ? new Dictionary<string, TerritoryGeometry>()
            : new Dictionary<string, TerritoryGeometry>(geometry);

        // Build-time validation: an invalid map cannot exist. Diagnostics list every
        // detected problem, not just the first one.
        var diagnostics = MapValidator.Validate(id, name, territoryList, regionList, geometryDict);
        if (diagnostics.Count > 0)
        {
            throw new MapValidationException(
                $"Map '{id}' failed validation with {diagnostics.Count} diagnostic(s):",
                diagnostics);
        }

        Territories = new ReadOnlyDictionary<string, Territory>(territoryList.ToDictionary(t => t.Id, t => t));
        Regions = new ReadOnlyDictionary<string, RegionDefinition>(regionList.ToDictionary(r => r.Id, r => r));
        Geometry = new ReadOnlyDictionary<string, TerritoryGeometry>(geometryDict);
    }

    public Territory? GetTerritory(string id) => Territories.GetValueOrDefault(id);

    public IReadOnlyList<string> GetAdjacentTerritories(string id) =>
        Territories.TryGetValue(id, out var t) ? t.AdjacentTerritoryIds : [];

    /// <summary>
    /// Returns the region definition with the given id, or null when absent.
    /// </summary>
    public RegionDefinition? GetRegion(string id) => Regions.GetValueOrDefault(id);

    /// <summary>
    /// Total army bonus across all regions for which every territory is owned by playerId.
    /// PROVISIONAL region-bonus semantics per D-05 [PROPOSED].
    ///
    /// ⚠️ STATIC-DATA SEMANTICS (clarified in M1.2): this reads ownership from the
    /// map's OWN territory objects, which <see cref="GameState"/> copies at
    /// construction and never updates during a match. During an active game this
    /// value goes stale after any capture/loss. Compute LIVE ownership and
    /// region control with <see cref="Simulation.EconomyEngine"/> instead; this
    /// method remains only for static/setup-time data (the map is still the
    /// source of region membership and ArmyBonus configuration).
    /// Pure computation — does not depend on mutation order.
    /// </summary>
    public int GetRegionControlBonus(string playerId)
    {
        int total = 0;
        foreach (var region in Regions.Values)
        {
            int memberCount = 0;
            bool ownsAll = true;
            foreach (var t in Territories.Values)
            {
                if (!string.Equals(t.RegionId, region.Id, StringComparison.Ordinal))
                    continue;
                memberCount++;
                if (!string.Equals(t.OwnerPlayerId, playerId, StringComparison.Ordinal))
                {
                    ownsAll = false;
                    break;
                }
            }
            if (memberCount > 0 && ownsAll)
                total += region.ArmyBonus;
        }
        return total;
    }

    public int TerritoryCount => Territories.Count;
}

/// <summary>
/// Visual (presentation-only) geometry of a territory: its display polygon and
/// the centroid used for army markers.
/// </summary>
public sealed record TerritoryGeometry(IReadOnlyList<TerritoryPoint> Polygon, TerritoryPoint Centroid);

/// <summary>A 2D map-space point used only for visual geometry.</summary>
public readonly record struct TerritoryPoint(double X, double Y);
