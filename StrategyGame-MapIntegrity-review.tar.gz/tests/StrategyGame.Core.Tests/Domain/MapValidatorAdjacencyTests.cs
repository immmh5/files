namespace StrategyGame.Core.Tests.Domain;

using StrategyGame.Core.Domain;
using StrategyGame.Core.Storage;
using Xunit;

/// <summary>
/// M1.1 correction — MapValidator adjacency invariants:
/// 1. Symmetric adjacency (A→B requires B→A)
/// 2. No duplicate adjacency IDs within a territory
/// </summary>
public class MapValidatorAdjacencyTests
{
    private static readonly string[] EmptyAdj = [];

    private static Territory Make(string id, string name, params string[] adj)
        => new(id, name, adj, TerrainType.Plains, null, isSupplySource: false);

    private static RegionDefinition MakeRegion(string id) => new(id, id, 0);

    [Fact]
    public void Validate_SymmetricAdjacency_IsAccepted()
    {
        var territories = new[]
        {
            Make("a", "A", "b"),
            Make("b", "B", "a"),
        };
        var regions = new[] { MakeRegion("r1") };

        var diagnostics = MapValidator.Validate("map", "Map", territories, regions);

        Assert.Empty(diagnostics);
    }

    [Fact]
    public void Validate_OneWayAdjacency_IsRejected()
    {
        var territories = new[]
        {
            Make("a", "A", "b"),
            Make("b", "B"), // no adjacency
        };
        var regions = new[] { MakeRegion("r1") };

        var diagnostics = MapValidator.Validate("map", "Map", territories, regions);

        Assert.Contains(diagnostics, d => d.Contains("Asymmetric adjacency: territory 'a' references 'b' but 'b' does not reference 'a'."));
    }

    [Fact]
    public void Validate_DuplicateAdjacencyId_IsRejected()
    {
        var territories = new[]
        {
            Make("a", "A", "b", "b"),
            Make("b", "B", "a"),
        };
        var regions = new[] { MakeRegion("r1") };

        var diagnostics = MapValidator.Validate("map", "Map", territories, regions);

        Assert.Contains(diagnostics, d => d.Contains("Territory 'a' lists duplicate adjacent territory 'b'."));
    }

    [Fact]
    public void Validate_MultipleAdjacencyViolations_AreAllReported()
    {
        // a→b (ok), b→c (asymmetric: c does not reference b), c→c (self), c has duplicate "a", c→a (asymmetric: a does not reference c)
        var territories = new[]
        {
            Make("a", "A", "b"),
            Make("b", "B", "a", "c"),
            Make("c", "C", "c", "a", "a"), // self + duplicate + asymmetric
        };
        var regions = new[] { MakeRegion("r1") };

        var diagnostics = MapValidator.Validate("map", "Map", territories, regions);

        // Self adjacency
        Assert.Contains(diagnostics, d => d.Contains("Territory 'c' is adjacent to itself."));
        // Duplicate
        Assert.Contains(diagnostics, d => d.Contains("Territory 'c' lists duplicate adjacent territory 'a'."));
        // Asymmetric: b references c but c does not reference b
        Assert.Contains(diagnostics, d => d.Contains("Asymmetric adjacency: territory 'b' references 'c' but 'c' does not reference 'b'."));
        // Asymmetric: c references a but a does not reference c
        Assert.Contains(diagnostics, d => d.Contains("Asymmetric adjacency: territory 'c' references 'a' but 'a' does not reference 'c'."));
    }

    [Fact]
    public void Validate_SmallMapJson_RemainsValid()
    {
        var map = MapLoader.LoadFromFile(
            Path.Combine(AppContext.BaseDirectory, "TestData", "small_map.json"));

        Assert.NotNull(map);
        // MapDefinition constructor calls Validate and throws if invalid
        Assert.True(map.Territories.Count > 0);
    }
}