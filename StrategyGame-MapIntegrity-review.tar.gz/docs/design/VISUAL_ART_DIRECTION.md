# VISUAL_ART_DIRECTION.md

**Status:** PROPOSED DESIGN

---

## 1. Map Perspective

2.5D strategy map. Primarily 2D territory geometry with layered depth effects.

## 2. Layering

```
Layer 0: Map base (terrain textures)
Layer 1: Territory fills (faction colors)
Layer 2: Borders (ownership, thickness)
Layer 3: Shadows (elevation, offset)
Layer 4: Army markers (numbers at centroids)
Layer 5: Effects (animations, glows)
Layer 6: UI overlay (panels, menus)
```

## 3. Shadows

- Directional shadow offset per territory
- Darker for higher elevation
- Soft edges for natural look

## 4. Territory Borders

- Thick: owned by current player
- Medium: owned by other player
- Thin: neutral
- Color: faction color

## 5. Elevation Effects

- Higher territories: lighter fill, stronger shadow
- Lower territories: darker fill, softer shadow
- Visual cue for strategic value

## 6. Army Markers

- Number at territory centroid
- Size scales with army count (capped)
- Color: faction color
- Font: clear, legible at all zoom levels

## 7. Visual Hierarchy

1. Selected territory: glow ring
2. Contested territory: pulse animation
3. Region bonus: glow ring when controlled
4. Supply attrition: red tint on unsupplied territories

## 8. Color System

| Faction | Color |
|---|---|
| Aethelgard | Red |
| Varkul Clan | Black |
| Sapphire Covenant | Blue |
| Verdant League | Green |
| Ironstone Dominion | Grey |
| Crimson Ascendancy | Orange |

## 9. Animation Style

- Smooth transitions (0.2s tween)
- No jittery or flickering effects
- Battle animations: territory pulse on combat
- Region bonus: glow ring on control change

## 10. Performance-Conscious Rendering

- Static layers cached to viewport texture
- Dynamic layers (selection, effects) isolated
- Territory highlight updates only on state change
- Army marker positions precomputed