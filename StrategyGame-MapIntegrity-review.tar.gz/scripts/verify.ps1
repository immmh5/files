#!/usr/bin/env pwsh
# =============================================================================
# verify.ps1 — Complete project verification (Windows)
#
# Runs all required checks in order. Fails fast on any error.
# Exit code 0 = all checks passed; non-zero = one or more checks failed.
#
# Environment variables:
#   GODOT_BIN  — Full path to Godot 4.7.2 mono executable (optional)
#                Falls back to PATH lookup, then known Windows paths.
# =============================================================================
$ErrorActionPreference = "Stop"

$SCRIPT_DIR = Split-Path -Parent $MyInvocation.MyCommand.Path
$PROJECT_ROOT = Resolve-Path "$SCRIPT_DIR\.."
$env:PATH = "$env:USERPROFILE\.local\dotnet;$env:PATH"
$env:DOTNET_ROOT = "$env:USERPROFILE\.local\dotnet"

$PASS_COLOR = "Green"
$FAIL_COLOR = "Red"
$INFO_COLOR = "Yellow"

function Pass-Msg { Write-Host "[PASS]" -ForegroundColor $PASS_COLOR " $args" }
function Fail-Msg { Write-Host "[FAIL]" -ForegroundColor $FAIL_COLOR " $args"; exit 1 }
function Info-Msg { Write-Host "[INFO]" -ForegroundColor $INFO_COLOR " $args" }

Info-Msg "StrategyGame verification starting"
Info-Msg "Project root: $PROJECT_ROOT"

# ===================================================================
# Step 1: .NET SDK
# ===================================================================
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    Fail-Msg ".NET SDK not found. Install .NET SDK 8.0+ and ensure it is on PATH."
}
$dotnetVersion = & dotnet --version
if ($LASTEXITCODE -ne 0) { Fail-Msg "dotnet --version failed with exit code $LASTEXITCODE." }
Pass-Msg ".NET SDK: $dotnetVersion"

# ===================================================================
# Step 2: Build Core
# ===================================================================
Info-Msg "Building StrategyGame.Core..."
& dotnet build "$PROJECT_ROOT\src\StrategyGame.Core\StrategyGame.Core.csproj" -c Release --nologo -v quiet
if ($LASTEXITCODE -ne 0) { Fail-Msg "Core build failed (exit $LASTEXITCODE)." }
Pass-Msg "StrategyGame.Core built successfully."

# ===================================================================
# Step 3: Build App
# ===================================================================
Info-Msg "Building StrategyGame.App..."
& dotnet build "$PROJECT_ROOT\src\StrategyGame.App\StrategyGame.App.csproj" -c Release --nologo -v quiet
if ($LASTEXITCODE -ne 0) { Fail-Msg "App build failed (exit $LASTEXITCODE)." }
Pass-Msg "StrategyGame.App built successfully."

# ===================================================================
# Step 4: Unit tests
# ===================================================================
Info-Msg "Running Core unit tests..."
& dotnet test "$PROJECT_ROOT\tests\StrategyGame.Core.Tests\StrategyGame.Core.Tests.csproj" -c Release --nologo -v minimal
if ($LASTEXITCODE -ne 0) { Fail-Msg "Core unit tests failed (exit $LASTEXITCODE)." }
Pass-Msg "StrategyGame.Core.Tests passed."

# ===================================================================
# Step 5: Integration tests
# ===================================================================
Info-Msg "Running integration tests..."
& dotnet test "$PROJECT_ROOT\tests\Integration.Tests\Integration.Tests.csproj" -c Release --nologo -v minimal
if ($LASTEXITCODE -ne 0) { Fail-Msg "Integration tests failed (exit $LASTEXITCODE)." }
Pass-Msg "Integration tests passed."

# ===================================================================
# Step 6: Godot project import validation
# ===================================================================
$GodotBin = if ($env:GODOT_BIN) { $env:GODOT_BIN }
            elseif (Get-Command godot -ErrorAction SilentlyContinue) { (Get-Command godot).Source }
            else { $null }

# Fallback to common Windows Godot installations
if (-not $GodotBin) {
    $candidates = @(
        "$env:LOCALAPPDATA\Godot\app_data\export_templates\4.7.2.stable",
        "C:\Games\Godot\Godot_v4.7.2-stable_mono_win64.exe",
        "C:\Program Files\Godot\Godot_v4.7.2-stable_mono_win64.exe"
    )
    foreach ($c in $candidates) {
        if (Test-Path $c) { $GodotBin = $c; break }
    }
}

if (-not $GodotBin -or -not (Test-Path $GodotBin)) {
    Fail-Msg "Godot 4.7.2 mono executable not found."
    Fail-Msg "Set GODOT_BIN=<path> or place the Godot 4.7.2 mono binary on PATH."
}

# Validate exact Godot version: must match 4.7.2 prefix followed by non-digit or end-of-string

$godotVersionRaw = & $GodotBin --version 2>&1 | Out-String

if ($LASTEXITCODE -ne 0) { Fail-Msg "Godot --version failed with exit code $LASTEXITCODE." }

if ($godotVersionRaw -notmatch '^4\.7\.2(\.[a-zA-Z]|$)') {

    Fail-Msg "Expected Godot 4.7.2.x but got version: '$($godotVersionRaw.Trim())'. Must match semantic version prefix 4.7.2 followed by non-numeric suffix (e.g. 4.7.2.stable). Rejected: 4.7.20, 4.7.1, 4.8.0, 4.7.2.1."

}
Info-Msg "Godot executable: $GodotBin"
Info-Msg "Godot version: $($godotVersionRaw.Trim())"

Info-Msg "Running Godot project import validation..."
$importErr = "$env:TEMP\godot-import-err.txt"
$importOut = "$env:TEMP\godot-import-out.txt"
$importProc = Start-Process $GodotBin -ArgumentList "--headless", "--path", "`"$PROJECT_ROOT\src\StrategyGame.App`"", "--import" `
    -RedirectStandardError $importErr -RedirectStandardOutput $importOut `
    -PassThru -NoNewWindow -ErrorAction Stop
$importTimedOut = -not $importProc.WaitForExit(60000)
if ($importTimedOut) {
    $importProc.Kill()
    Fail-Msg "Godot project import timed out after 60 seconds."
}
$importCombined = Get-Content "$importOut","$importErr" -ErrorAction SilentlyContinue | Out-String
Remove-Item $importErr, $importOut -ErrorAction SilentlyContinue
if ($importProc.ExitCode -ne 0) {
    Write-Host $importCombined
    Fail-Msg "Godot project import failed with exit code $($importProc.ExitCode)."
}
Pass-Msg "Godot project import validation passed."

# ===================================================================
# Step 7: Godot application startup
# ===================================================================
Info-Msg "Running Godot headless application startup..."
$startupErr = "$env:TEMP\godot-startup-err.txt"
$startupOut = "$env:TEMP\godot-startup-out.txt"
$startupProc = Start-Process $GodotBin -ArgumentList "--headless", "--path", "`"$PROJECT_ROOT\src\StrategyGame.App`"", "--quit" `
    -RedirectStandardError $startupErr -RedirectStandardOutput $startupOut `
    -PassThru -NoNewWindow -ErrorAction Stop
$startupTimedOut = -not $startupProc.WaitForExit(30000)
if ($startupTimedOut) {
    $startupProc.Kill()
    Fail-Msg "Godot application startup timed out after 30 seconds."
}
$startupCombined = Get-Content "$startupOut","$startupErr" -ErrorAction SilentlyContinue | Out-String
Remove-Item $startupErr, $startupOut -ErrorAction SilentlyContinue
if ($startupProc.ExitCode -ne 0) {
    Write-Host $startupCombined
    Fail-Msg "Godot application startup failed with exit code $($startupProc.ExitCode)."
}
Pass-Msg "Godot application startup passed."

# ===================================================================
# Summary
# ===================================================================
Write-Host ""
Pass-Msg "All verifications passed."
Info-Msg "Git status:"
git -C $PROJECT_ROOT status --short
exit 0
