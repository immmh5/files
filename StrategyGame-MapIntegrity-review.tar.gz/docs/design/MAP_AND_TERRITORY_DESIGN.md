# MAP_AND_TERRITORY_DESIGN.md

**Status:** PROPOSED DESIGN (rules/thresholds [PROPOSED per DESIGN_DECISIONS.md D-05];
the *format and model* below are implemented in code as of 2026-11-10 — see "Implementation status")

---

## 0. Implementation status (M1.1, 2026-11-10)

| Design element | Implemented in | Notes |
|---|---|---|
| Logical territory model independent of visuals | `Domain/Territory.cs` + `MapDefinition.Geometry` (presentation-only) | CONFIRMED requirement honored |
| Region definitions with army bonuses | `Domain/RegionDefinition.cs` | Bonus amount still [PROPOSED], configurable per map |
| Territory terrain/region/supply metadata | `Domain/Territory.cs` (TerrainType, RegionId, IsSupplySource) | Defaults: Plains / none / false |
| Map JSON format §1.1 | `Storage/MapLoader.cs` + `Domain/MapValidator.cs` | snake_case keys as in §1.1; build-time validation; `MapValidationException` aggregates diagnostics |
| Geometry (polygon/centroid) §1.7 | parsed into `MapDefinition.Geometry` | optional per territory; centroid derived from polygon average when omitted |
| First playable map | `tests/StrategyGame.Core.Tests/TestData/small_map.json` (6 territories, 2 regions) | deterministic; format scales to the planned ~48-territory map |

Differences/additions vs. this proposal (intentional, documented):
- Each map carries a `version` (defaults 1 when omitted).
- Absent optional fields map to documented defaults (plains, no region, `supply_source: false`).
- Adjacency references and region references are validated at load; invalid maps cannot exist.

---

## 1. Map Architecture

Maps are defined by a JSON data model. The logical territory model is independent of its visual representation.

### 1.1 Map Data Format

```json
{
  "id": "map_continents_01",
  "name": "The Three Continents",
  "version": 1,
  "territories": [
    {
      "id": "t1",
      "name": "Red Coast",
      "region": "continent_a",
      "terrain": "plains",
      "polygon": [[0,0],[1,0],[1,1],[0,1]],
      "centroid": [0.5, 0.5],
      "adjacent": ["t2", "t5"],
      "supply_source": false
    }
  ],
  "regions": [
    {"id": "continent_a", "name": "Aethelgard", "bonus": 2}
  ]
}
```

### 1.2 Territory Properties

| Property | Type | Purpose |
|---|---|---|
| `id` | string | Unique within map |
| `name` | string | Display |
| `region` | string | Group for continent bonus |
| `terrain` | enum | Plains/Forest/Hills/Mountains/Marsh/Coast |
| `polygon` | [[x,y],...] | Convex or concave polygon |
| `centroid` | [x,y] | Army marker position |
| `adjacent` | [string] | Territory ID adjacency graph |
| `supply_source` | bool | Capital/port flag |

### 1.3 Terrain Types

| Terrain | Defense Bonus | Notes |
|---|---|---|
| Plains | 0 | Default; balanced |
| Forest | +1 | Ambush terrain |
| Hills | +2 | High ground |
| Mountains | +3 | Extreme defense |
| Marsh | +1 | Difficult supply |
| Coast | 0 | Port supply source |

### 1.4 Map Scale

- First map: ~48 territories, 6 regions
- Target range: 20–200 territories
- Regions: 3–8 per map

### 1.5 Ownership Visualization

- Territory fill color = faction color (modulated by terrain tint)
- Border thickness = ownership (thick = owned, thin = neutral)
- Army marker = number at centroid, size scales with count
- Region bonus = glow ring when controlled

### 1.6 Interaction

- Left click: select territory
- Right click: context menu (move/attack/fortify)
- Middle click + drag: pan camera
- Scroll: zoom (0.5x–4x)
- Keyboard: WASD pan, +/- zoom

### 1.7 Polygon Representation

Territories are stored as 2D polygons. The adjacency graph is explicit (not derived from polygon proximity). This ensures testability.

### 1.8 Custom Map Expansion

Maps are JSON files loaded at runtime. No map data is compiled into the game. Custom maps follow the same schema.