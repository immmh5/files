# REPAIR_PROGRESS.md

## Project: StrategyGame / Iron Dominion
**Working Directory**: /home/qam3/StrategyGame
**Started**: 2026-11-04

---

## Current Phase: Phase 0 (Foundation Repair) + M1.1 (Map & Rules Foundation) ✅ COMPLETE

**Authorized:** Phase 0 + Phase 1 (M1.1 only) per project owner instruction, 2026-11-10.
**Phase 0 scope:** EventIdSource boundary-concurrency defect (R4.7-fix), GameState
initial-constructor ownership fix, VictoryChecker provisional-status record, full real
verification. **M1.1 scope (owner's Phase 1 instruction):** terrain types, region
definitions, territory metadata, map validation, JSON map loader, deterministic test map,
focused tests. M1.2 NOT started.

### Phase 0 — What Was Actually Done

| Item | File(s) | Result |
|---|---|---|
| R4.7-fix — EventIdSource race at `long.MaxValue` | `src/StrategyGame.Core/Events/EventIdSource.cs` | Rewritten with a plain `lock`; exhaustion now takes effect atomically with the `long.MaxValue` allocation. Positive monotonic IDs; `MaxValue` exactly once; later calls throw `OverflowException`; `Peek`/`IsExhausted` consistent (`Peek` = `long.MaxValue` when exhausted). |
| GameState ownership fix | `src/StrategyGame.Core/GameState/GameState.cs` | Initial constructor now copies every `Player` (null entries rejected) and exposes `Players = _players.AsReadOnly()`; `Players`, `GetPlayer()`, `Snapshot()` agree; caller-list mutation after construction cannot change state. |
| Defensive adjacency copies | `src/StrategyGame.Core/Domain/Territory.cs` | `Territory` constructors copy the input adjacency list; related ownership hazard removed (GameState copies of map territories could previously share list references). |
| VictoryChecker provisional record | `src/StrategyGame.Core/GameState/VictoryChecker.cs`, `docs/repair/KNOWN_ISSUES.md` (ISSUE-V) | XML remarks now explicitly mark 60% threshold, denominator, domination-vs-elimination priority as `[PROPOSED]`/not owner-approved; point-based victory recorded as `[OPEN]`; D-16-5 Stage-D-only evaluation noted as pending TurnEngine work. No rule change made. |

### M1.1 — What Was Actually Implemented

| Requirement | Implementation | Status |
|---|---|---|
| 1. Explicit terrain types | `src/StrategyGame.Core/Domain/TerrainType.cs` — Plains, Forest, Hills, Mountains, Marsh, Coast (stable numbering; PROVISIONAL categories per D-05) | Done |
| 2. Region definitions | `src/StrategyGame.Core/Domain/RegionDefinition.cs` — id, display name, non-negative configurable `ArmyBonus` | Done |
| 3. Territory metadata | `Territory` extended: `Terrain`, `RegionId`, `IsSupplySource`; snapshot record extended; backward-compatible legacy constructors | Done |
| 4. Map validation | `src/StrategyGame.Core/Domain/MapValidator.cs` + `MapValidationException.cs` — unique ids, adjacency references, self-adjacency, region references, bonus validity, geometry sanity; **all diagnostics aggregated**; enforced at `MapDefinition` construction | Done |
| 5. JSON map format + loader | `src/StrategyGame.Core/Storage/MapLoader.cs` (`FromJson` / `LoadFromFile`) + `MapFile.cs` DTOs — System.Text.Json only, snake_case design keys, documented defaults for absent optional fields | Done |
| 6. Deterministic test map | `tests/StrategyGame.Core.Tests/TestData/small_map.json` — "The Small Ring": 6 territories, 2 regions (bonus 2/3), 6 terrain categories, 2 supply sources (capital + port), polygon/centroid geometry, ring + chord adjacency | Done |
| 7. Tests | `TerritoryMetadataTests` (7), `RegionDefinitionTests` (10), `MapValidationTests` (17), `MapLoaderTests` (16), `GameStateOwnershipTests` (7), `EventIdSourceTests` +6 boundary/concurrency tests | Done — 63 new test cases in total (266 → 329) |

**Also added in M1.1:** `MapDefinition.GetRegion`, `MapDefinition.GetRegionControlBonus`
(provisional D-05 semantics; consumed by economy M1.2), optional per-territory
`TerritoryGeometry` (visual polygon/centroid) carried in `MapDefinition`.

### Files Changed (Phase 0 + M1.1)

**Core source (modified):**
- `src/StrategyGame.Core/Events/EventIdSource.cs`
- `src/StrategyGame.Core/GameState/GameState.cs`
- `src/StrategyGame.Core/GameState/VictoryChecker.cs` (documentation only)
- `src/StrategyGame.Core/Domain/Territory.cs`
- `src/StrategyGame.Core/Domain/MapDefinition.cs`

**Core source (new):**
- `src/StrategyGame.Core/Domain/TerrainType.cs`
- `src/StrategyGame.Core/Domain/RegionDefinition.cs`
- `src/StrategyGame.Core/Domain/MapValidator.cs`
- `src/StrategyGame.Core/Domain/MapValidationException.cs`
- `src/StrategyGame.Core/Storage/MapLoader.cs`

**Tests (new):**
- `tests/StrategyGame.Core.Tests/GameState/GameStateOwnershipTests.cs`
- `tests/StrategyGame.Core.Tests/Domain/TerritoryMetadataTests.cs`
- `tests/StrategyGame.Core.Tests/Domain/RegionDefinitionTests.cs`
- `tests/StrategyGame.Core.Tests/Domain/MapValidationTests.cs`
- `tests/StrategyGame.Core.Tests/Domain/MapLoaderTests.cs`
- `tests/StrategyGame.Core.Tests/TestData/small_map.json`

**Tests (modified):**
- `tests/StrategyGame.Core.Tests/Events/EventIdSourceTests.cs` (6 boundary tests added)
- `tests/StrategyGame.Core.Tests/StrategyGame.Core.Tests.csproj` (TestData copying)
- `tests/StrategyGame.Core.Tests/Domain/MapValidationTests.cs` (new file)

**Documentation:**
- `docs/repair/REPAIR_PROGRESS.md` (this section)
- `docs/repair/KNOWN_ISSUES.md` (ISSUE-T, ISSUE-U, ISSUE-V)
- `docs/MILESTONES.md` (M1.1 progress)
- `docs/architecture/M1_ROADMAP.md` (NEW — M1.2–M1.5 dependency-based plan)
- `docs/architecture/IMPLEMENTATION_ROADMAP.md` (link to M1_ROADMAP)
- `docs/design/MAP_AND_TERRITORY_DESIGN.md` (implementation status note)

### Migration / Compatibility Notes (M1.1)

- `Territory`: legacy `(id, name, adjacency[, owner, armies])` constructors preserved and
  default metadata to Plains / no region / not a supply source. New metadata constructors
  added. `TerritorySnapshot` gained 3 defaulted trailing fields (existing positional
  call sites unaffected).
- `MapDefinition`: legacy 3-arg constructor preserved; regions default empty; the map id
  and name are still passed. `GetAdjacentTerritories` behavior unchanged (returns empty
  list for unknown id).
- `GameState`: constructor signature unchanged; ownership semantics corrected (see
  ISSUE-U). Defensive now also copies terrain/region/supply metadata.
- No API was removed; per owner instruction nothing obsolete is retained beyond what
  tests and existing callers legitimately use.

### Verification Results (actual, 2026-11-10)

| Check | Exit Code | Result |
|---|---|---|
| Core Release build | 0 | 0 warnings, 0 errors |
| App Release build | 0 | 0 warnings, 0 errors |
| Core tests (Release) | 0 | **329 passed** (baseline 266; +63 new/fixed) |
| Integration tests (Release) | 0 | 7 passed |
| `bash scripts/verify.sh` (all 7 steps incl. Godot import + headless startup) | 0 | **ALL PASS** |
| Windows execution | — | **NOT RUN** — Linux environment only |

**Total: 336 tests pass (329 unit + 7 integration). Zero skipped, zero failed.**

Two test-side defects were found and fixed during development (reported verbatim here):
an xUnit collection-size analyzer error, and — ironically — a first version of the
boundary-concurrency test whose loop counter itself wrapped past `long.MaxValue`
(`for expected <= long.MaxValue { ...; expected++ }`), fixed to `< MaxValue` plus an
explicit `Assert.Contains(long.MaxValue, ids)`. Core code compiled clean on each build;
the RegionDefinition primary-constructor record syntax was initially invalid and was
converted to guard-code in a regular constructor (build error, fixed before any test run).

### Next Step

**M1.2 — Economy, reinforcement, supply calculation and attrition** (per
`docs/architecture/M1_ROADMAP.md`). Awaiting separate owner authorization.

---

## Archived Phase: R4.6 — Event Lifecycle ✅ COMPLETE

**Authorized:** R4.5 per project owner authorization on 2026-11-05.
**Scope:** EventScheduler Core — scheduling, due-event lookup, stable ordering, cancellation, rescheduling, queries, duplicate prevention, focused tests.

### Verification Results

| Check | Exit Code | Result |
|---|---|---|
| Core Release build | 0 | 0 warnings, 0 errors |
| App Release build | 0 | 0 warnings, 0 errors |
| Core tests (Release) | 0 | **221 passed** (32 EventScheduler + 189 existing) |
| Integration tests | 0 | 7 passed |
| `bash scripts/verify.sh` | 0 | **ALL PASS** |
| `bash scripts/test-verify-fake.sh` | 0 | **10/10 PASS** |
| `bash -n scripts/verify.sh` | 0 | Syntax OK |
| `bash -n scripts/test-verify-fake.sh` | 0 | Syntax OK |
| Windows execution | — | **NOT RUN** — Linux environment only |

**Total: 228 tests pass (221 unit + 7 integration). Zero skipped, zero failed.**

### Files Added/Modified (R4.5)

- `src/StrategyGame.Core/Events/EventScheduler.cs` — NEW: EventScheduler Core implementation
- `src/StrategyGame.Core/Events/ScheduledEventRecord.cs` — Added `IComparable<ScheduledEventRecord>` with deterministic ordering
- `tests/StrategyGame.Core.Tests/Events/EventSchedulerTests.cs` — NEW: 33 focused regression tests

### R4.5 API Summary

| Method | Purpose |
|---|---|
| `Schedule(ScheduledEventRecord)` | Add event; rejects duplicate EventId |
| `Cancel(string)` | Remove event; returns true if found |
| `Reschedule(string, SchedulerQuery)` | Update timing; preserves EventId |
| `GetDueEvents(SchedulerQuery)` | Events due at given state; ordered |
| `GetScheduledEvents()` | All active events; ordered |
| `TryGetEvent(string)` | Lookup by EventId |
| `Contains(string)` | Check if scheduled |
| `Count` | Active event count |

### Ordering Contract

Events are ordered deterministically by:
1. **Due-time** — `RoundTiming.DueRoundIndex` or `PlayerTiming.DuePlayerTurnCount`
2. **Priority** (ascending — lower value runs first, per metadata)
3. **SequenceNumber** (ascending — match-scoped monotonic)
4. **EventId** (ordinal — final deterministic tie-breaker)

### SchedulerQuery

Provides simulation state without wall-clock:
- `CurrentRoundIndex` — for round-timed events
- `CurrentPlayerTurnCounts` — dictionary for player-timed events

### NOT Implemented (Reserved for Later Phases)

- EventBus wiring
- TurnEngine integration
- Stage A/B/C/D execution
- Gameplay event handlers
- Event lifecycle execution
- SaveManager
- Serialization changes
- Checkpoint recovery
- Networking
- Multiplayer synchronization
- Gameplay mechanics

### Next Step

**R4.6** — Awaiting separate authorization.

---

## R4.4.2.5-G1 — Close Three Residual Audit Findings ✅ COMPLETE

**Authorized:** R4.4.2.5-G1 per project owner independent review on 2026-11-05.
**Scope:** Three residual findings from final independent source-code review.

### Findings Addressed

| # | Finding | File | Fix |
|---|---|---|---|
| 1 | Fake Godot timeout isolation: block_cmd non-empty blocked both --import and --quit | `scripts/test-verify-fake.sh` | Exact match: `[[ "$block_cmd" == "import" ]]` and `[[ "$block_cmd" == "quit" ]]` |
| 2 | Negative assertions had fallback PASS branches | `scripts/test-verify-fake.sh` | Removed all fallback PASS branches; strict `grep -Fq` diagnostics |
| 3 | Deserializer/validator delegate equality isolation | `tests/.../EventTypeRegistryTests.cs` | Shared validator/deserializer instances; rejection caused by single mismatch |

### Verification Results

| Check | Exit Code | Result |
|---|---|---|
| Core Release build | 0 | 0 warnings, 0 errors |
| App Release build | 0 | 0 warnings, 0 errors |
| Core tests (Release) | 0 | **180 passed** |
| Integration tests | 0 | 7 passed |
| `bash scripts/verify.sh` | 0 | **ALL PASS** |
| `bash scripts/test-verify-fake.sh` | 0 | **10/10 PASS** |
| Windows execution | — | **NOT RUN** — Linux environment only |

**Total: 187 tests pass (180 unit + 7 integration). Zero skipped, zero failed.**

### Files Changed (R4.4.2.5-G1)

- `scripts/test-verify-fake.sh` — Exact `block_cmd` matching; removed fallback PASS; strict diagnostics
- `tests/.../EventTypeRegistryTests.cs` — Shared validator/deserializer instances
- `docs/repair/REPAIR_PROGRESS.md` — Current Phase = R4.5; historical counts preserved
- `docs/repair/REPAIR_PROGRESS.md.section` — Superseded marker updated
- `docs/repair/R4.4.2.5-G_INDEPENDENT_AUDIT_REPORT.md` — Corrected G title, authorization, findings

---

### Completed Phases
- [x] R0 — Baseline and Safety ✅ COMPLETE
- [x] R1 — Core State Integrity (ISSUE A) ✅ COMPLETE
- [x] R2 — Victory Logic (ISSUE B) ✅ COMPLETE
- [x] R3 — Deterministic Identity & ID Generator (ISSUE C) ✅ COMPLETE
- [x] R3.1 — ID Generator Safety Review ✅ COMPLETE
- [x] R3.2 — ID Generator Hardening ✅ COMPLETE
- [x] R4.0 — Event Architecture Design (documentation only) ✅ COMPLETE
- [x] R4.1 — EventBus Reentrancy & Collection Safety ✅ COMPLETE
- [x] R4.2 — Event Time & Gameplay Semantics Decision Proposals ✅ COMPLETE
- [x] R4.2.1 — Refine Event System Decisions (design-only) ✅ COMPLETE
- [x] R4.2.2 — Official Owner Approval & Documentation Update ✅ COMPLETE
- [x] R4.3 — Event Data Model ✅ COMPLETE
- [x] R4.4 — Event Type Registry & Typed Payload Validation ✅ COMPLETE

---

## R4.4.2 — Event Registry Safety & Payload Ownership Repair — RESOLVED ✅

**Authorized:** R4.4.2 per project owner authorization on 2026-11-05.
**Scope:** Repair identified issues in R4.4 Event Type Registry — JSON validation, payload ownership, registration thread safety, required/optional field policy, design status discipline.

### Issues Fixed

| Issue | File | Fix |
|---|---|---|
| XML comment `&` escaping | `EventPayloads.cs` | Escaped `&` as `&amp;` in all XML doc comments |
| JSON property name collision | `ScheduledEventRecord.cs` | Renamed internal field `_payloadMutable` → `_payloadForDeserialization`; added `[JsonIgnore]` to `Payload` property |
| Read-only Payload assignment in tests | `EventTypeRegistryTests.cs`, `ScheduledEventRecordTests.cs` | Added `CreateWithPayload()` internal factory method; updated all test constructors |
| Missing InternalsVisibleTo | `AssemblyInfo.cs` | Created with `[InternalsVisibleTo("StrategyGame.Core.Tests")]` and `[InternalsVisibleTo("StrategyGame.Integration.Tests")]` |

### Verification Results

| Check | Exit Code | Result |
|---|---|---|
| Core Release build | 0 | 0 warnings, 0 errors |
| App Release build | 0 | 0 warnings, 0 errors |
| Core tests (Release) | 0 | **161 passed** |
| Integration tests | 0 | 7 passed |
| Godot import + headless | 0 | PASS |
| Full `verify.sh` | 0 | **ALL PASS** |

**Total: 175 tests pass (168 unit + 7 integration). Zero skipped, zero failed.**

### R4.4.2.1 — Concurrency & Ownership Final Acceptance Gate

**Authorized:** Follow-up acceptance gate per project owner instruction on 2026-11-05.

#### Concurrency fixes

| Issue | File | Fix |
|---|---|---|
| `EventTypeRegistrar.RegisterAll()` — `_registered` set BEFORE registrations (unprotected race, misleading on failure) | `EventTypeRegistrar.cs` | Replaced with double-checked locking via `lock (_registrationLock)`; `_registered = true` moved to AFTER all registrations succeed |
| `EventTypeRegistry.RegisterAll()` — `finally` set state=2 even on exception (misleading completed state) | `EventTypeRegistry.cs` | Replaced CAS+SpinWait with lock-based double-checked init; `_initialized = true` only on full success; exception propagates so no caller waits on a false "done" |
| Partial registration failure left later callers stuck | Both | `Register()` now idempotent for identical definitions (same key + PayloadType + versions + allowedKeys) — a retry after partial failure completes the set; `ClearForTesting()` resets BOTH registry and registrar flags |

#### Payload read-path fixes

| Issue | File | Fix |
|---|---|---|
| `Payload` returned a mutable `Dictionary` that could be cast-and-mutated | `ScheduledEventRecord.cs` | Changed `_payloadSnapshot` to return `ReadOnlyDictionary<string, JsonElement>` built from `_payloadTextSnapshot`; cast to `Dictionary` throws `InvalidCastException` |
| Class header comment claimed "owning JsonDocument is retained internally" | `ScheduledEventRecord.cs` | Updated comment to reflect actual design: raw text snapshot captured eagerly, no JsonDocument retained |

#### Verification results

| Check | Exit Code | Result |
|---|---|---|
| Core Release build | 0 | 0 warnings, 0 errors |
| App Release build | 0 | 0 warnings, 0 errors |
| Core tests (Release) | 0 | **168 passed** |
| Integration tests | 0 | 7 passed |
| Godot import + headless | 0 | PASS |
| Full `verify.sh` | 0 | **ALL PASS** |

**Total: 175 tests pass (168 unit + 7 integration). Zero skipped, zero failed.**

#### Source excerpts (evidence)

**EventTypeRegistry.RegisterAll()** (`src/StrategyGame.Core/Events/EventTypeRegistry.cs`, lines 89–108):

```csharp
public static void RegisterAll()
{
    if (Volatile.Read(ref _initialized))
        return;
    lock (_initLock)
    {
        if (_initialized)
            return;
        EventTypeRegistrar.RegisterAll();
        _initialized = true; // only on full success
    }
}
```

**EventTypeRegistrar.RegisterAll()** (`src/StrategyGame.Core/Events/EventTypeRegistrar.cs`, lines 24–47):

```csharp
private static readonly object _registrationLock = new();
private static bool _registered;

public static void RegisterAll()
{
    if (Volatile.Read(ref _registered))
        return;
    lock (_registrationLock)
    {
        if (_registered)
            return;
        RegisterAutumnAttrition();
        RegisterContinentBonus();
        RegisterHarvestFestival();
        RegisterBorderFortification();
        RegisterBerserkRage();
        RegisterSupplyDisruption();
        RegisterFortificationBoost();
        _registered = true; // only after ALL registrations succeeded
    }
}
```

**Payload read path** (`src/StrategyGame.Core/Events/ScheduledEventRecord.cs`, lines 149–163):

```csharp
private IReadOnlyDictionary<string, JsonElement> _payloadSnapshot =>
    _payloadTextSnapshot != null
        ? new ReadOnlyDictionary<string, JsonElement>(
            _payloadTextSnapshot.ToDictionary(
                kv => kv.Key,
                kv => JsonSerializer.Deserialize<JsonElement>(kv.Value, EventDataModel.SerializerOptions)!))
        : _emptyPayload;
```

**Register idempotency check** (`src/StrategyGame.Core/Events/EventTypeRegistry.cs`, lines 67–80):

```csharp
if (!_registry.TryAdd(eventTypeKey, info))
{
    var existing = _registry[eventTypeKey];
    bool identical =
        existing.PayloadType == info.PayloadType &&
        existing.SupportedVersions.SequenceEqual(info.SupportedVersions) &&
        existing.AllowedKeys.SequenceEqual(info.AllowedKeys);
    if (!identical)
        throw new ArgumentException(
            $"Event type '{eventTypeKey}' is already registered with a conflicting definition.",
            nameof(eventTypeKey));
}
```

#### Focused tests proving each criterion

| Criterion | Test name | What it proves |
|---|---|---|
| Concurrent registrar calls safe | `Registrar_RegisterAll_ConcurrentCalls_AllRegistered` | 10 threads call `EventTypeRegistrar.RegisterAll()` concurrently; no exceptions; 7 types registered |
| Concurrent registry calls safe | `Registry_RegisterAll_ConcurrentCalls_AllRegistered` | 10 threads call `EventTypeRegistry.RegisterAll()` concurrently (after ClearForTesting); no exceptions; 7 types registered |
| Cast-proof Payload | `Payload_CannotBeCastToMutableDictionary` | Casting `Payload` to `Dictionary<string, JsonElement>` throws `InvalidCastException` |
| Unknown key rejection (continued) | `DeserializeAndValidate_UnknownKey_Throws` | Throws on unknown dictionary key |
| Disposed JsonDocument survives | `Payload_Ownership_DisposeJsonDocumentAfterTransfer_ElementRemainsValid` | After `JsonDocument.Dispose()`, `record.Payload` is readable AND registry deserialization succeeds |
| Caller dict mutation ignored | `Payload_Ownership_MutateCallerDictAfterConstruction_NoEffect` | Mutating the caller's original dict does not change the record's payload |
| Round-trip preserves payload | `Payload_Ownership_RoundTripSerializationPreservesPayload` | `ToJson` → `FromJson` round trip retains original payload values |

#### Files changed (working tree)

**Core source (new or modified in R4.4 / R4.4.2 / R4.4.2.1):**
- `src/StrategyGame.Core/Events/EventTypeRegistry.cs` — added `_initLock`/`_initialized` fields; replaced CAS+SpinWait with lock-based init; idempotent identical-registration check; `ValidateKeys()` call in `DeserializeAndValidatePayload`; `ClearForTesting()` now resets both registry and registrar.
- `src/StrategyGame.Core/Events/EventTypeRegistrar.cs` — replaced unprotected `_registered` with lock-protected double-checked locking; added `ClearForTesting()`.
- `src/StrategyGame.Core/Events/ScheduledEventRecord.cs` — added `_payloadTextSnapshot` field + `CapturePayloadSnapshot()` method; changed `_payloadSnapshot` to `ReadOnlyDictionary`; added `[JsonIgnore]` to `Payload`; XML doc corrected; `CreateWithPayload()` factory.
- `src/StrategyGame.Core/Events/EventPayloads.cs` — XML `&` escaping fix.
- `src/StrategyGame.Core/AssemblyInfo.cs` — NEW (InternalsVisibleTo).

**Tests (new or modified):**
- `tests/.../Events/EventTypeRegistryTests.cs` — updated all records to use `CreateWithPayload`; added `DeserializeAndValidate_UnknownKey_Throws`, `Payload_Ownership_*` (3 tests), `Registrar_RegisterAll_ConcurrentCalls_AllRegistered`, `Registry_RegisterAll_ConcurrentCalls_AllRegistered`, `Payload_CannotBeCastToMutableDictionary`.
- `tests/.../Events/ScheduledEventRecordTests.cs` — updated round-trip record construction to use `CreateWithPayload`.

**Documentation:**
- `docs/repair/REPAIR_PROGRESS.md` — updated test counts (168 core + 7 integration = 175); added R4.4.2.1 section.

#### NOT Implemented (Reserved for Later Phases)
- EventScheduler
- TurnEngine
- Scheduler wiring / lifecycle execution
- SaveManager
- Multiplayer event synchronization

### Next Step
**R4.5 — EventScheduler Core only** (scheduling, due-event lookup, stable ordering, cancellation, rescheduling, queries, duplicate prevention, focused tests). No EventBus wiring. No TurnEngine integration. **Awaiting separate authorization.**

---

## R4.4.2.4 — Final Evidence and Verification Correction ✅ COMPLETE

**Authorized:** R4.4.2.4 per project owner instruction on 2026-11-05.
**Scope:** Resolve unresolved contradictions from R4.4.2.3 report; fix verification script false-success paths; add genuine partial failure injection test; correct test counts.

### Tasks Completed

| Task | Status | Description |
|---|---|---|
| TASK 1 — Registration Policy | ✅ COMPLETE | Registered policy A: internal-only registration via controlled registrar. `Register` is `internal`. Added conflict tests. |
| TASK 2 — Verification Scripts | ✅ COMPLETE | Fixed false-success paths in `verify.sh` and `verify.ps1`: proper exit code checking, timeout failure, version validation, no text-substitution success. |
| TASK 3 — Real Partial Failure Test | ✅ COMPLETE | Added `Registrar_RegisterAll_InjectsFailure_ThenRecovers` with genuine exception injection via `FailingRegistrar` test helper. |
| TASK 4 — Payload Serialization | ✅ COMPLETE | Tests already exist: `Payload_Ownership_MutateCallerDictAfterConstruction_NoEffect`, `Payload_Ownership_DisposeJsonDocumentAfterTransfer_ElementRemainsValid`, `Payload_Ownership_RoundTripSerializationPreservesPayload`. |
| TASK 5 — Registry Metadata | ✅ COMPLETE | `GetInfo()` returns defensive copies (`SupportedVersions` as `ReadOnlyCollection<int>`, `AllowedKeys` as `HashSet<string>`). Tests: `GetInfo_SupportedVersions_IsImmutable`, `GetInfo_AllowedKeys_IsImmutable`. |
| TASK 6 — Test Count Correction | ✅ COMPLETE | Core = 176 (was 174), Integration = 7, Total = 183. |
| TASK 7 — Fresh Review Package | ✅ COMPLETE | Archive at `/tmp/StrategyGame-R4.4.2.4-review.tar.gz`. |

### Files Changed (R4.4.2.4)

**Tests (modified):**
- `tests/StrategyGame.Core.Tests/Events/EventTypeRegistryTests.cs` — Fixed `Registrar_RegisterAll_InjectsFailure_ThenRecovers` test to use proper try-catch; added `FailingRegistrar` test helper with public `RegisterAll()` for genuine failure injection.

**Scripts (modified):**
- `scripts/verify.sh` — Fixed Godot import/startup to check exit codes directly; removed false-success path where "Godot Engine" text implied success; added exact version validation (must contain "4.7.2"); timeouts fail the check.
- `scripts/verify.ps1` — Same fixes for PowerShell: `Start-Process` exit code checking; timeout detection via exit code; version validation; removed text-substitution success.

### Verification Results

| Check | Exit Code | Result |
|---|---|---|
| Core Release build | 0 | 0 warnings, 0 errors |
| App Release build | 0 | 0 warnings, 0 errors |
| Core tests (Release) | 0 | **180 passed** |
| Integration tests | 0 | 7 passed |
| Godot import + headless | 0 | PASS |
| Full `verify.sh` | 0 | **ALL PASS** |

**Total: 187 tests pass (180 unit + 7 integration). Zero skipped, zero failed.**

### Tests Added/Modified

| Test Name | Purpose |
|---|---|
| `Registrar_RegisterAll_InjectsFailure_ThenRecovers` | Genuine failure injection test: cold registry, exception on 4th registration, retry completes all 7 types |

### False-Success Paths Fixed

| Path | Before | After |
|---|---|---|
| Godot import timeout | Captured output only; `|| true` suppressed exit code | `timeout` returns 124 on timeout; explicit check fails fast |
| Godot startup "Godot Engine" text | Passed if "Godot Engine" in output (even on failure) | Checks actual exit code; only passes on exit 0 |
| .NET command failures | `if !` checked but no captured output on failure | Same, but now scripts fail fast with captured stderr |
| Godot version | Only checked presence of "Godot" string | Exact version must contain "4.7.2" |

### NOT Implemented (Reserved for Later Phases)
- EventScheduler
- TurnEngine
- Scheduler wiring / lifecycle execution
- SaveManager
- Multiplayer event synchronization

### Next Step
**R4.5 — EventScheduler Core only** (scheduling, due-event lookup, stable ordering, cancellation, rescheduling, queries, duplicate prevention, focused tests). No EventBus wiring. No TurnEngine integration. **Awaiting separate authorization.**

---

## R4.4.2.2 — Independent Review Findings & Minimal Repairs ✅ COMPLETE

**Authorized:** R4.4.2.2 per project owner independent review on 2026-11-05.
**Scope:** Address 7 findings from independent source-code review of R4.4.2 archive.

### Findings Addressed

| # | Finding | File | Fix | Test |
|---|---|---|---|---|
| 1 | Payload ownership across ALL paths (ToJson used caller's dict) | `ScheduledEventRecord.cs` | `ToJson()` now serializes from `_payloadTextSnapshot` via anonymous object; `CapturePayloadSnapshot()` captures eagerly; `_payloadForDeserialization` no longer serialization source | `Payload_Ownership_RoundTripSerializationPreservesPayload`, `Payload_Ownership_DisposeJsonDocumentAfterTransfer_ElementRemainsValid` |
| 2 | Concurrency tests didn't test cold initialization | `EventTypeRegistryTests.cs` | Removed constructor eager registration; added `Barrier`-synchronized cold-start tests for both Registrar and Registry; added partial-failure retry test; xUnit collection with `DisableParallelization` | `Registrar_RegisterAll_ConcurrentColdStart_AllRegistered`, `Registry_RegisterAll_ConcurrentColdStart_AllRegistered`, `Registrar_PartialRegistrationFailure_RetryCompletes` |
| 3 | Schema metadata not genuinely immutable | `EventTypeRegistry.cs` | `GetInfo()` returns defensive copies (`SupportedVersions` as ReadOnlyCollection, `AllowedKeys` as new HashSet); registrar stores defensive copies | `GetInfo_SupportedVersions_IsImmutable`, `GetInfo_AllowedKeys_IsImmutable` |
| 4 | False idempotency for conflicting registrations | `EventTypeRegistry.cs` | Idempotency check compares stable schema contract only (PayloadType, versions, allowedKeys); conflicting schema (different versions/keys) rejected | `Register_ConflictingDeserializer_Throws`, `Register_ConflictingValidator_Throws`, `Register_IdenticalKeysDifferentOrder_Accepted` |
| 5 | Unused `PayloadSerializerOptions` / strict JSON claims | `EventTypeRegistry.cs`, `EventPayloads.cs` | Removed unused `PayloadSerializerOptions` fields; strict validation implemented via `AllowedKeys` + explicit field/type helpers | `DeserializeAndValidate_UnknownKey_Throws`, `DeserializeAndValidate_WrongFieldType_Throws`, `DeserializeAndValidate_MissingRequiredField_Throws` |
| 6 | Legacy ScheduledEventRecord duplicate | `docs/repair/REPAIR_PROGRESS.md` | Documented: `src/StrategyGame.Core/Events/ScheduledEventRecord.cs` is canonical R4.5 scheduler record; `src/StrategyGame.Core/Simulation/ScheduledEventRecord.cs` is legacy (different shape, PayloadJson string) | N/A (documentation) |
| 7 | Gameplay design status discipline | All payload DTOs + validators | All 7 event types remain `PROPOSED` in XML docs; validators enforce data integrity (non-empty, positive ints) not approved gameplay rules | N/A (review) |

### Verification Results

| Check | Exit Code | Result |
|---|---|---|
| Core Release build | 0 | 0 warnings, 0 errors |
| App Release build | 0 | 0 warnings, 0 errors |
| Core tests (Release) | 0 | **180 passed** |
| Integration tests | 0 | 7 passed |
| Godot import + headless | 0 | PASS |
| Full `verify.sh` | 0 | **ALL PASS** |

**Total: 187 tests pass (180 unit + 7 integration). Zero skipped, zero failed.**

### Files Changed (working tree)

**Core source (modified in R4.4.2.2):**
- `src/StrategyGame.Core/Events/ScheduledEventRecord.cs` — `ToJson()` uses text snapshot; `CapturePayloadSnapshot()` eager capture
- `src/StrategyGame.Core/Events/EventTypeRegistry.cs` — `GetInfo()` defensive copies; idempotency check by schema contract; removed unused `PayloadSerializerOptions`; `ClearForTesting()` resets registrar
- `src/StrategyGame.Core/Events/EventTypeRegistrar.cs` — registration methods `internal` for test access
- `src/StrategyGame.Core/Events/EventPayloads.cs` — removed unused `PayloadSerializerOptions`

**Tests (new/modified):**
- `tests/.../Events/EventTypeRegistryTests.cs` — removed eager constructor registration; added cold-start barrier tests; partial-failure retry test; schema immutability tests; conflicting schema tests; all tests call `ClearForTesting()` + `RegisterAll()` explicitly; xUnit collection with `DisableParallelization`
- `tests/.../Events/ScheduledEventRecordTests.cs` — round-trip comparison via JSON

**Documentation:**
- `docs/repair/REPAIR_PROGRESS.md` — updated test counts (174 core + 7 integration = 181); added R4.4.2.2 section; fixed contradictory counts; removed duplicate "Not Implemented" entries; clarified R4.5 scope

### NOT Implemented (Reserved for Later Phases)
- EventScheduler
- TurnEngine
- Scheduler wiring / lifecycle execution
- SaveManager
- Multiplayer event synchronization

### Next Step
**R4.5 — EventScheduler Core only** (scheduling, due-event lookup, stable ordering, cancellation, rescheduling, queries, duplicate prevention, focused tests). No EventBus wiring. No TurnEngine integration. **Awaiting separate authorization.**

---

## R4.4 — Event Type Registry & Typed Payload Validation ✅ COMPLETE

**Authorized:** R4.4 per project owner authorization on 2026-11-04.
**Scope:** Event type registry, typed payload DTOs, deserialization, validation — **no scheduler, no TurnEngine, no wiring**.

### Implemented Files
| File | Purpose |
|---|---|
| `src/StrategyGame.Core/Events/EventTypeRegistry.cs` | Registry mapping EventTypeKey → schema, deserializer, validator |
| `src/StrategyGame.Core/Events/EventPayloads.cs` | 7 strongly typed payload DTOs (4 global + 3 personal) + helpers |
| `src/StrategyGame.Core/Events/EventTypeRegistrar.cs` | Bootstrapping: registers 7 event types at startup |
| `tests/StrategyGame.Core.Tests/Events/EventTypeRegistryTests.cs` | 22 regression tests covering registry, deserialization, validation |

### D-16-6 / D-16-7 — Registry & Typed Payloads Implemented
- **EventTypeRegistry**: ConcurrentDictionary-based registry mapping `EventTypeKey` → `EventTypeInfo` (supported versions, deserializer, validator, payload type)
- **7 payload DTOs** (all `sealed record`):
  - Global (RoundTiming): `AutumnAttritionPayload`, `ContinentBonusPayload`, `HarvestFestivalPayload`, `BorderFortificationPayload`
  - Personal (PlayerTurnTiming): `BerserkRagePayload`, `SupplyDisruptionPayload`, `FortificationBoostPayload`
- **Deserialization**: `Dictionary<string, JsonElement>` → typed DTO via per-type deserializer
- **Validation**: Structural (registry) + semantic (per-type validator) → throws `ScheduledEventValidationException` / `EventTypeRegistryException`
- **Versioning**: Per-type `supportedVersions` list; unsupported versions rejected with diagnostic
- **Unknown type rejection (D-16-6)**: `GetInfo` throws `EventTypeRegistryException` for unregistered keys

### D-16-6 Enforcement
- Unknown authoritative event types: **rejected at deserialization** with diagnostic
- Presentation events: **not in registry** (separate `PresentationEvent` hierarchy in `DomainEvent.cs`)

### Tests — 22 Total (All Passing)
| Category | Tests |
|---|---|
| Registration & lookup | 4 |
| Valid payload deserialization (round + player timed) | 4 |
| Version handling (supported/unsupported) | 2 |
| Semantic validation failures (empty, zero, negative) | 6 |
| Missing/wrong field types | 3 |
| Unknown event type rejection | 1 |
| ValidatePayload convenience method | 2 |

### Verification Results
| Check | Exit Code | Result |
|---|---|---|
| Core Release build | 0 | 0 warnings, 0 errors |
| App Release build | 0 | 0 warnings, 0 errors |
| Core tests (Release) | 0 | **168 passed** |
| Integration tests | 0 | 7 passed |
| Godot import + headless | 0 | PASS |
| Full `verify.sh` | 0 | **ALL PASS** |

**Total: 173 tests pass (166 unit + 7 integration). Zero skipped, zero failed.**

### Files Modified / Added
| File | Change |
|---|---|
| `src/StrategyGame.Core/Events/EventTypeRegistry.cs` | NEW — Registry core |
| `src/StrategyGame.Core/Events/EventPayloads.cs` | NEW — 7 payload DTOs + helpers |
| `src/StrategyGame.Core/Events/EventTypeRegistrar.cs` | NEW — Bootstrapping |
| `src/StrategyGame.Core/Events/ScheduledEventRecord.cs` | MODIFIED — R4.4.2: renamed `_payloadMutable` → `_payloadForDeserialization`, added `[JsonIgnore]` to `Payload`, added `CreateWithPayload()` factory |
| `src/StrategyGame.Core/AssemblyInfo.cs` | NEW — InternalsVisibleTo for test assemblies |
| `tests/StrategyGame.Core.Tests/Events/EventTypeRegistryTests.cs` | NEW — 22 regression tests (updated for R4.4.2) |
| `tests/StrategyGame.Core.Tests/Events/ScheduledEventRecordTests.cs` | MODIFIED — Updated to use `CreateWithPayload()` |
| `docs/repair/REPAIR_PROGRESS.md` | This section |
| `docs/repair/KNOWN_ISSUES.md` | ISSUE-T registered RESOLVED |

### NOT Implemented (Reserved for Later Phases)
- EventScheduler
- TurnEngine
- Scheduler wiring / lifecycle execution
- SaveManager
- Multiplayer event synchronization

### Next Step
**R4.5 — EventScheduler Core only** (scheduling, due-event lookup, stable ordering, cancellation, rescheduling, queries, duplicate prevention, focused tests). No EventBus wiring. No TurnEngine integration. **Awaiting separate authorization.**
---

## R4.3 — Event Data Model — IMPLEMENTATION COMPLETE

**Authorized:** R4.3 Event Data Model per project owner authorization on 2026-11-04.
**Scope:** Stable data foundation for the event system — **no scheduler, no TurnEngine, no wiring**.

### Implemented Files
| File | Purpose |
|---|---|
| `src/StrategyGame.Core/Events/ScheduledEventRecord.cs` | Strongly typed scheduled-event DTO implementing D-16-1 through D-16-7 |
| `tests/StrategyGame.Core.Tests/Events/ScheduledEventRecordTests.cs` | 35 regression tests covering all data model requirements |

### D-16-1 / D-16-2 — Clock & Timing Metadata Embedded
- `TurnSequence` (monotonic int, +1 per Stage D) in `ScheduledAtTurnSequence`
- `RoundIndex` (explicit, never derived) via `RoundTiming.DueRoundIndex`
- `PlayerTurnTiming` with `PlayerId` + `DuePlayerTurnCount` for personal effects
- `ExecutionStage` enum restricted to **TurnStart / EventProcessing / TurnEnd** (no PlayerActions)

### D-16-3 — Phase-Boundary Enforcement
- `ExecutionStage` enum structurally excludes Stage B; deserializing "PlayerActions" throws validation error

### D-16-6 — Loud Validation (No Silent Drops)
- `ScheduledEventValidationException` thrown on any deserialization inconsistency
- Structural validation: required fields, exactly one timing entry, non-negative due times
- Unknown event TYPE KEYS deferred to handler registry (later phase)

### D-16-7 — Versioned JSON Serialization
- System.Text.Json with camelCase, explicit `SchemaVersion` per record
- Round-trip serialization tested; JsonElement payload handled
- Strongly typed DTOs: `RoundTiming`, `PlayerTurnTiming`, `ScheduledEventRecord`

### Tests — 35 Total (All Passing)
| Category | Tests |
|---|---|
| Deserialization (round / player timed) | 2 |
| Round-trip serialization (D-16-7) | 3 |
| Stage-B exclusion enforcement | 2 |
| Validation loud-failure (D-16-6) | 10 |
| Equality / immutability | 1 |
| D-16-1 guard (no derived round) | 1 |
| Category split (no presentation types) | 1 |
| Payload round-trip via JSON | 3 |

### Verification Results
| Check | Exit Code | Result |
|---|---|---|
| Core Release build | 0 | 0 warnings, 0 errors |
| App Release build | 0 | 0 warnings, 0 errors |
| Core tests (Release) | 0 | **139 passed** (was 80, +35 new + 24 existing EventBus/IdGenerator) |
| Integration tests | 0 | 7 passed |
| Godot import + headless | 0 | PASS |
| Full `verify.sh` | 0 | **ALL PASS** |

**Total: 146 tests pass (139 unit + 7 integration). Zero skipped, zero failed.**

### Files Modified / Added
| File | Change |
|---|---|
| `src/StrategyGame.Core/Events/ScheduledEventRecord.cs` | NEW — Event data model (R4.3) |
| `tests/StrategyGame.Core.Tests/Events/ScheduledEventRecordTests.cs` | NEW — 35 regression tests |
| `docs/repair/REPAIR_PROGRESS.md` | This section |
| `docs/repair/KNOWN_ISSUES.md` | ISSUE-S registered as RESOLVED |

### NOT Implemented (Reserved for Later Phases)
- EventScheduler
- TurnEngine
- Scheduler wiring / lifecycle execution
- SaveManager
- Multiplayer event synchronization

### Next Step
**R4.5 — EventScheduler Core only** (scheduling, due-event lookup, stable ordering, cancellation, rescheduling, queries, duplicate prevention, focused tests). No EventBus wiring. No TurnEngine integration. **Awaiting separate authorization.**
---

## R4.1 — EventBus Reentrancy & Collection Safety — RESOLVED

**Target**: `src/StrategyGame.Core/Events/GameEvent.cs` (EventBus lives here; no separate EventBus.cs exists)

### Defect Confirmed Empirically (not assumed)
Reproduced with a throwaway console harness BEFORE fixing: a subscriber that
unsubscribes itself during `Publish` threw **`InvalidOperationException`**
(collection modified while enumerating). Pre-fix behavior matrix verified by test:

| Capability | Pre-fix | Post-fix (documented semantics) |
|---|---|---|
| Subscribe during Publish | Mutates live list mid-enumeration; new handler not called this round but structure at risk | Allowed; snapshot means it affects **subsequent publishes only** |
| Unsubscribe during Publish | **Throws InvalidOperationException** | Allowed; target still runs in current snapshot, removed afterward |
| Self-unsubscribe during dispatch | **Throws** | Runs exactly once now; gone next publish |
| Nested Publish | Possible (no guard); inner could corrupt outer enumeration | Permitted; each level snapshots independently; inner completes before outer continues |
| Duplicate subscriptions | Allowed silently | Allowed explicitly; each registration invoked once per publish; `Unsubscribe` removes one occurrence |
| Handler ordering | Registration order (List) — same post-fix | Deterministic FIFO registration order, documented + tested |
| Exception policy | Undocumented (propagated) | **Fail-fast documented**: exception propagates, remaining handlers skipped for that publish; bus stays usable |

### Fix Applied (smallest change)
`Publish<T>` takes a **snapshot array of handlers at dispatch start** and iterates the
snapshot. Added `ArgumentNullException.ThrowIfNull(handler)` on Subscribe. Public API
signatures unchanged. No locks introduced — single-threaded use is actual usage (Godot
main loop); multithreading deliberately NOT added. One small allocation per publish
(Delegate[] snapshot) accepted as non-premature-optimization tradeoff; subscribers are
few and events infrequent; no zero-allocation claim made.

Semantics documented in XML doc comment on EventBus class.

### Regression Tests — 13 new (`tests/StrategyGame.Core.Tests/Events/EventBusTests.cs`)
Covers all required scenarios: normal publish, subscribe-during-dispatch (verified
affects NEXT publish only), self-unsubscribe, unsubscribe-other (snapshot still runs
target this publish), nested publish ordering, nested-subscribe visibility rule,
duplicate subscription counts, 10-handler FIFO order assertion, add/remove across
repeated publishes, throwing handler propagation + skip-remaining + bus usability,
null handler rejection, per-event-type isolation. Tests assert documented semantics,
not merely absence of exceptions.

### Verification Results

| Check | Command | Exit Code | Result |
|---|---|---|---|
| EventBus tests | `dotnet test --filter "EventBusTests"` | 0 | 13 passed |
| All Core tests | `dotnet test tests/StrategyGame.Core.Tests -c Release` | 0 | **80 passed** |
| Integration tests | `dotnet test tests/Integration.Tests -c Release` | 0 | 7 passed |
| Core + App Release builds | via verify.sh | 0 | 0 warnings, 0 errors |
| Godot import / headless startup | verify.sh steps 6–7 | 0 | PASS |
| Full verification | `bash scripts/verify.sh` | 0 | ALL PASS |

**Total: 87 tests pass (80 unit + 7 integration). Zero skipped.**

### Files Modified
| File | Change |
|---|---|
| `src/StrategyGame.Core/Events/GameEvent.cs` | Snapshot-based Publish + null-guard + documented semantics |
| `tests/StrategyGame.Core.Tests/Events/EventBusTests.cs` | NEW — 13 regression tests |
| `docs/repair/REPAIR_PROGRESS.md` | This section |
| `docs/repair/KNOWN_ISSUES.md` | ISSUE-P registered as RESOLVED |

Not touched: EventScheduler (not implemented), TurnEngine, IdGenerator, VictoryChecker, game rules, networking, save/load. No commits.

---

## R4.0 — Event Architecture Design — DOCUMENTATION PHASE COMPLETE

**No source code modified. No scheduler/TurnEngine implemented.**

### Verified Findings Against Actual Code

| Audit Claim | Verdict | Evidence |
|---|---|---|
| Delegate-based scheduled events in code | **FALSE — documentation only** | Zero `Action<GameState>`/`ScheduledEvent` occurrences in `src/`; delegate design exists only in TURN_ENGINE_ARCHITECTURE.md §4 (itself a proposal) |
| Collection mutation during enumeration | **TRUE — latent defect** | GameEvent.cs: `Publish<T>` iterates `handlers` (line 52); re-entrant Subscribe/Unsubscribe during dispatch would throw `InvalidOperationException`. Noted for future repair phase; NOT fixed here (design-only mandate) |
| Wall-clock in event identity | **TRUE** | `GameEvent.Timestamp = DateTime.UtcNow` in all concrete events — display-only role mandated going forward |
| Per-type static event counters | **TRUE** | Four independent `_eventIdCounter` fields → colliding ID spaces across event types; replacement with single match-scoped counter proposed |

### Documents Created

| Document | Content | Status labels used |
|---|---|---|
| `docs/architecture/EVENT_ARCHITECTURE.md` | Layering, serializable `ScheduledEventRecord` (no delegates), total ordering (tick→priority→sequence→id), EventBus hardening, save/load watermark design, host-authoritative MP mapping, scheduler structure comparison (sorted-array baseline recommended), decision register EA-1…EA-10 | PROPOSED / OPEN / CONFIRMED-inherited |
| `docs/design/EVENT_SYSTEM_SPECIFICATION.md` | Four categories' rules (Commands=intent w/ validation+authorization; Domain Events=facts; Scheduled=future authoritative data records; Presentation=non-authoritative cosmetics), A–D integration, **7 open questions Q-R4-1…Q-R4-7** requiring owner approval (clock granularity, cross-player ticking, mid-Stage-B firing, disconnect pause, victory timing carry-over from R2.1, unknown-event policy, payload format) | PROPOSED / OPEN |
| `docs/design/EVENT_LIFECYCLE.md` | Scheduled-event state machine (Pending→Executing→Fired/Cancelled/Expired/Failed), transitions per stage, save/restore lifecycle rules, pause/resume semantics, error-handling matrix, 7 testable invariants for future implementation | PROPOSED / OPEN |

### Key Architectural Positions (all PROPOSED, none approved)

1. **Data-not-delegates:** persistent scheduled events are pure serializable records; behavior resolved via static handler registry keyed by `EventTypeKey`.
2. **Logical clock separation:** integer authoritative clock advanced only at phase boundaries; wall-clock banned from authority (inherits CONFIRMED "rendering loop is never the simulation clock").
3. **Deterministic total order:** due tick → priority → sequence number → id lexicographic; simultaneous events have stable reproducible order.
4. **Watermark duplicate suppression** after save/restore; expired-while-saved events fire at next matching phase, never skipped or backdated.
5. **Host-only scheduling** in multiplayer; clients mirror snapshots + cosmetic events; per-sender sequence windows reject duplicates/reordering; periodic state-hash divergence detection (hash choice OPEN).
6. **Sorted-array scheduler baseline**; heap/dictionary bucketing/pooling deferred as premature without measured need.
7. **Presentation completion never gates rule outcomes** — enforceable by layering (Core holds no presentation type references).

### Contradiction Check Across Generated Documents

- Clock semantics conflict identified in EXISTING docs (TURN_AND_EVENT_SYSTEM "once per turn" vs TURN_ENGINE absolute turn numbers vs D-07 "round start") — surfaced as **Q-R4-1**, not silently resolved.
- New documents use consistent terminology (logical tick, total order, watermark, registry key) and cross-reference each other; no internal contradictions found on review pass.
- Approval statuses preserved: hybrid A–D remains USER-APPROVED PROVISIONAL; all new mechanism proposals marked PROPOSED; gameplay timing questions remain OPEN.

### Verification

Documentation-only change; build/test state unchanged since R3.2 (74 tests passing, verify.sh exit 0). No git commits made.

### Next Step (requires owner input before any implementation)

Owner decisions on Q-R4-1 … Q-R4-7, then architecture review of R4.0 documents. Only after approval: R4.1 implementation phase (EventBus hardening as a separate small repair). EventScheduler is deferred to R4.5.

---

## R3.2 — ID Generator Final Hardening — RESOLVED

**Targets**: `src/StrategyGame.Core/Common/IdGenerator.cs`, `tests/StrategyGame.Core.Tests/Common/IdGeneratorTests.cs`

### Gaps From R3.1 Review — Resolutions

| R3.1 Finding | Resolution in R3.2 |
|---|---|
| 32-bit hash width; ~77K birthday collision threshold | **Replaced with SHA-256 truncated to 128 bits** (~2×10¹⁹ generations before 50% birthday risk). Truncated cryptographic digest is the standard shortened-hash construction (same technique as Git abbreviated object IDs). |
| `_seen` tracking recorded collisions but never prevented them (misleading) | **Removed entirely.** Deterministic mode must not depend on process-global history; a check-and-retry loop would make results depend on unrelated prior generations. With 128-bit space, retry logic adds no meaningful protection. Documented: probabilistic identifiers do NOT mathematically guarantee uniqueness. |
| No namespace isolation between subsystems | **Explicit namespace parameter** with canonical NUL-separated encoding (`namespace \0 seed \0 sequence`). NUL cannot appear in validated namespaces, so field boundaries are unambiguous — crafted collisions like ("ab",1,2) vs ("a",12,...) are impossible. Golden test verifies isolation. |
| BitConverter byte-order dependence | **Eliminated.** SHA-256 output bytes are consumed directly in FIPS 180-4 big-endian order; `BitConverter` is not used anywhere. UTF-8 + InvariantCulture digits pin the input encoding across locales and platforms. |
| No cross-process determinism test | **Golden-value tests added**: literal expected IDs computed independently via Python hashlib, embedded in `[Theory]` vectors. Any deviation on any platform/process fails the test. Windows CI runs the same vectors. |
| Sequence overflow silently wrapped through negative values | **Now throws** `OverflowException` at `int.MaxValue` instead of wrapping into duplicate deterministic inputs. Negative sequences throw `ArgumentOutOfRangeException`. Ref overload leaves the sequence unchanged on failure. |
| Empty/invalid namespaces accepted | **Validated**: empty namespace throws `ArgumentException`; NUL-containing namespace throws. Applies to all three modes. |

### API Compatibility

| Method | Status |
|---|---|
| `NewDeterministicId(string, int, ref int)` | Signature preserved (R3 shape). Behavior hardened: post-increment, overflow throws. |
| `NewDeterministicId(string, int, int)` | **NEW** value-sequence overload (pure function form). |
| `NewRandomId(string)` / `NewId(string)` | Signatures preserved; output format widened from 8 to 32 hex chars. **No production call sites exist**, so format change breaks nothing. |
| `ResetCollisionTracking()` / `TrackedCount` | **REMOVED** (dead misleading API). Regression-guard test asserts absence. |
| `StableHash.GetStableHashCode` | Changed return type `int` → `byte[16]`. Internal utility only; no external callers. |

### Generation Modes (unchanged count, hardened semantics)

| Mode | Entropy | Deterministic? | Guarantee |
|---|---|---|---|
| `NewDeterministicId(ns, seed, seq)` | None — pure function | ✅ Cross-process, cross-platform | Reproducible; probabilistically unique at 128 bits |
| `NewRandomId(ns)` | CSPRNG (`RandomNumberGenerator.Fill`) | ❌ | Probabilistically unique; no absolute guarantee |
| `NewId(ns)` | UtcNow ms + PID + Interlocked counter | ❌ | Unique within process by counter; negligible cross-process collision risk |

### Tests — 27 total (was 13; redundant cases removed, hardening cases added)

Key new coverage: golden vectors (4), FIPS SHA-256 vectors (2), 128-bit width check, namespace-isolation anti-collision case, no-history-dependence proof, overflow-throws, negative-sequence-throws, invalid-namespace theory (all modes), 10K-volume uniqueness (random + timestamp), parallel NewId uniqueness, tracking-API-removal guard.

### Supported Limits (documented in source header)

- Sequence range: `0 … int.MaxValue` per (namespace, seed); exhaustion throws.
- Namespace: non-empty string without NUL characters.
- Seed: full `int` range including negatives (distinct values).
- Digest: 128 bits (32 lowercase hex chars).

### Verification Results (R3.2)

| Check | Command | Exit Code | Result |
|---|---|---|---|
| IdGenerator tests | `dotnet test --filter "IdGeneratorTests"` | 0 | 27 passed |
| All Core tests | `dotnet test tests/StrategyGame.Core.Tests -c Release` | 0 | **67 passed** |
| Integration tests | `dotnet test tests/Integration.Tests -c Release` | 0 | 7 passed |
| Core Release build | `dotnet build -c Release` | 0 | 0 warnings, 0 errors |
| App Release build | `dotnet build -c Release` | 0 | 0 warnings, 0 errors |
| Godot import + headless startup | `verify.sh` steps 6–7 | 0 | PASS |
| Full verification | `bash scripts/verify.sh` | 0 | ALL PASS |

**Total: 74 tests pass (67 unit + 7 integration). Zero skipped, zero failed.**

Golden vectors were cross-checked against an independent implementation (Python hashlib SHA-256) before being embedded, so they verify correctness, not just self-consistency.

---

## R3 — Deterministic Identity & ID Generator (ISSUE C) — SUPERSEDED BY R3.2

**Target**: `src/StrategyGame.Core/Common/IdGenerator.cs`

### Investigation Findings

| Question | Finding |
|---|---|
| How are IDs currently generated? | `DateTimeOffset.UtcNow` + counter → `string.GetHashCode()` → truncated to 8 hex chars |
| Is `DateTimeOffset.UtcNow` used? | **YES** — non-deterministic entropy source |
| Is `string.GetHashCode()` used? | **YES** — not stable across process runs (.NET randomizes hash seeds per-process since .NET Core 3.0) |
| Are IDs truncated? | **YES** — 32-bit int → 8 hex chars (only 4 bytes of hash space) |
| Does collision tracking prevent collisions? | **NO** — `_seen` dictionary is populated but never checked before returning |
| Is generation thread-safe? | Partially — `Interlocked.Increment` for counter, but `GetHashCode()` result is non-deterministic |
| Are generated IDs used by actual game entities? | **NO** — IdGenerator was completely unused in all entity constructors |
| Would changing ID format break existing APIs? | **NO** — no callers existed; API surface preserved (`NewId(string category)` still works) |
| Are IDs serialized or persisted anywhere? | Not yet — ISaveSerializer interface exists but has no implementation |

### Identity Type Analysis

| Category | Requirement | Implementation |
|---|---|---|
| **A. Persistent entity IDs** (Players, Factions, Territories) | Stable within a session; provided by map data or setup | Manual string IDs passed to constructors — unchanged |
| **B. Match-local IDs** (Orders) | Unique within one game session | Manual string IDs passed to factory methods — unchanged |
| **C. Event IDs** (GameEvent.EventId) | Sequential within a run | Per-event-type `Interlocked.Increment` counter — unchanged |
| **D. Network message IDs** (GamePacket.SequenceNumber) | Monotonic sequence for duplicate detection | `long SequenceNumber` field — unchanged |
| **E. Deterministic simulation IDs** | Reproducible from seed + sequence for replay | **NEW**: `NewDeterministicId(category, seed, ref sequence)` |

**Key finding**: The codebase does NOT require a single universal ID system. Domain entities receive IDs externally (from map JSON, lobby setup, etc.). Events use sequential counters. The IdGenerator provides utility functions for when auto-generated IDs ARE needed.

### Defects Fixed

| # | Defect | Status |
|---|---|---|
| 1 | `string.GetHashCode()` is non-deterministic across processes | ✅ FIXED — replaced with FNV-1a stable hash |
| 2 | No deterministic mode for replay scenarios | ✅ FIXED — added `NewDeterministicId()` |
| 3 | Collision tracking `_seen` dictionary never checked | ✅ DOCUMENTED — kept as best-effort tracking |
| 4 | Only one generation mode available | ✅ FIXED — three modes: deterministic, random, timestamp-based |

### Implementation Decisions

1. **Stable hash function**: FNV-1a 32-bit — well-known, fast, deterministic, good distribution for short strings. Replaces `string.GetHashCode()`.
2. **Three generation modes**:
   - `NewDeterministicId(category, seed, ref sequence)` — fully reproducible for replay
   - `NewRandomId(category)` — uses shared `Random` instance (not Guid.NewGuid)
   - `NewId(category)` — timestamp + counter (original behavior, now with stable hash)
3. **Collision tracking**: Kept as informational only. With 32-bit hash space, absolute uniqueness cannot be guaranteed without unbounded memory. Documented limitation.
4. **No breaking API changes**: `NewId(string category)` signature preserved. New methods added alongside.
5. **No external dependencies**: Uses only .NET standard library.

### Known Limitations

| Limitation | Impact | Mitigation |
|---|---|---|
| 32-bit hash space (~4.3 billion values) | Birthday paradox: ~77K IDs before 50% collision probability | Acceptable for game-scale entity counts (<10K territories+players+orders). Increase to 64-bit if needed. |
| `_seen` grows unboundedly | Memory leak over very long sessions | ResetCollisionTracking() provided; can be called between matches |
| `NewId()` uses wall-clock time | Two calls at same millisecond rely on counter increment | Thread-safe via Interlocked; practically unique |

### Files Modified

| File | Change |
|---|---|
| `src/StrategyGame.Core/Common/IdGenerator.cs` | Rewritten: stable FNV-1a hash, deterministic/random/timestamp modes, public StableHash class |
| `tests/StrategyGame.Core.Tests/Common/IdGeneratorTests.cs` | **NEW** — 13 regression tests |

### New Tests (13 Total)

| Test | Purpose |
|---|---|
| `NewDeterministicId_SameSeedAndSequence_ReturnsSameId` | Determinism verification |
| `NewDeterministicId_DifferentSeeds_ReturnsDifferentIds` | Seed independence |
| `NewDeterministicId_DifferentSequences_ReturnsDifferentIds` | Sequence independence |
| `NewDeterministicId_DifferentCategories_ReturnsDifferentIds` | Category prefix correctness |
| `NewRandomId_ReturnsValidFormat` | Format validation |
| `NewRandomId_DifferentCalls_LikelyDifferent` | Uniqueness under volume |
| `NewId_ReturnsValidFormat` | Backward-compatible format check |
| `NewId_HighVolume_MostlyUnique` | 5000 IDs — collision rate acceptable |
| `NewDeterministicId_SequenceIncrementsCorrectly` | Ref parameter advances correctly |
| `NewDeterministicId_ThreadSafety_IndependentInstances` | Parallel threads with own sequences produce same output |
| `StableHashCode_SameString_ReturnsSameHash` | Hash determinism |
| `StableHashCode_DifferentStrings_LikelyDifferentHash` | Hash distribution |
| `NewId_CollisionTracking_Increments` | Tracking dictionary functional |

### Design Note: Determinism ≠ ID Generation

Per section 4 of the task specification: **An ID generator does not replace a deterministic random-number generator.** For gameplay replay:
- Simulation randomness must use an explicit match seed
- Random decisions must use controlled RNG state
- Event ordering must be deterministic
- This IdGenerator provides deterministic ID *identity*, not deterministic *game logic*

The deterministic mode (`NewDeterministicId`) ensures that given the same seed and sequence number, the same entity gets the same ID across replays. It does NOT make combat outcomes or AI decisions deterministic — those require their own seeded RNG infrastructure (future milestone).

---

## R2 — Victory Logic (ISSUE B) — RESOLVED

**Target**: `src/StrategyGame.Core/GameState/VictoryChecker.cs`

### Confirmed Defects Fixed

| # | Defect | Status |
|---|---|---|
| 1 | `WinningPlayerId` always `null` in `VictoryInfo` | ✅ FIXED |
| 2 | Domination threshold was 100% (one player owns ALL territories) | ✅ FIXED (implemented ≥60% per **proposed** D-07) |
| 3 | Neutral territories not counted in domination denominator | ✅ FIXED (implementation choice: **all territories including neutral**) |
| 4 | Domination vs Elimination overlapping conditions | ✅ FIXED (separation implemented; **priority order not design-approved**) |
| 5 | No handling of empty territory collection | ✅ FIXED |

### Rules Inspected (DESIGN_DECISIONS.md D-07)

| Rule | Design Status | Implementation Notes |
|---|---|---|
| **Domination**: control ≥60% of territories at round start | `[PROPOSED]` | Implemented as ≥60% of **all territories including neutral** (denominator = total map territories). **Denominator choice is implementation decision, not design-approved.** |
| **Elimination**: last player with owned territories wins | `[PROPOSED]` | Implemented correctly per proposed rule. |
| Score-based / timed victory | `[OPEN]` → future | Not implemented. |

**No invented rules** — implementation follows **proposed** D-07. The denominator (all vs owned-only territories), evaluation timing ("at round start" vs Turn End), and victory priority order are **not design-approved** and remain OPEN.

### Unresolved Design Questions (Require User Decision)

| Question | Context | Status |
|---|---|---|
| **Domination timing**: "at round start" vs any time? | D-07 says "at round start"; hybrid system checks at Turn End (Stage D); implementation checks anytime `CheckVictory()` called. | **OPEN** |
| **Domination denominator**: Total territories vs owned territories? | Implemented as total territories (including neutral). Alternative: only count owned territories. D-07 does not specify. | **OPEN** |
| **Elimination vs Domination priority**: Both can be true simultaneously. | Current: Domination checked first (stronger condition). Not specified in design. | **OPEN** |
| **PointBased victory**: Score thresholds undefined. | Marked `[OPEN]` in D-07; not implemented. | **OPEN** |
| **Zero-player state**: What if all players eliminated? | Currently returns no victory. May need special handling. | **OPEN** |

---

## R1 — Core State Integrity (ISSUE A) — RESOLVED

**ISSUE A — GameState Snapshot and Collection Ownership** — RESOLVED
- Player deep-copy in GameState constructors
- 8 snapshot regression tests added
- Faction confirmed immutable (no deep copy needed)

---

### Verification Results (Current)

| Check | Result |
|---|---|
| Core Build | ✅ 0 warnings, 0 errors |
| App Build | ✅ 0 warnings, 0 errors |
| Core Unit Tests | ✅ 180 passed |
| Integration Tests | ✅ 7 passed |
| Godot Import | ✅ PASS |
| Godot Headless Startup | ✅ PASS |
| Full Verification | ✅ All PASS |

**Total: 187 tests pass (180 unit + 7 integration). Zero skipped, zero failed.**

---

### Next Phase

**R4.5 — EventScheduler Core only** (scheduling, due-event lookup, stable ordering, cancellation, rescheduling, queries, duplicate prevention, focused tests). No EventBus wiring. No TurnEngine integration. **Awaiting separate authorization.**

---

## R4.7 — Event System Integration: Match-Scoped Domain Event IDs and Scheduler-to-EventBus Integration ✅ COMPLETE

**Authorized:** R4.7 per project owner authorization on 2026-11-06.
**Scope:** Match-scoped domain event IDs (EventIdSource) and Scheduler-to-EventBus integration.

### Findings Addressed

| # | Finding | File | Fix |
|---|---|---|---|
| 1 | No match-scoped domain event ID source | `EventIdSource.cs` | NEW: Thread-safe `EventIdSource` with monotonically increasing `long` IDs |
| 2 | DomainEvent not implement GameEvent | `DomainEvent.cs` | Modified: `DomainEvent` now implements `GameEvent` |
| 3 | No EffectFailedEvent for handler failures | `DomainEvent.cs` | NEW: `EffectFailedEvent` with `HandlerReturnedFalse` / `HandlerException` |
| 4 | EventScheduler not integrated with EventBus | `EventScheduler.cs` | MODIFIED: Integrated constructor with `IEventBus` + `EventIdSource` |
| 5 | Missing thread-safety for ID allocation | `EventIdSource.cs` | NEW: Lock-free thread-safe implementation using `Interlocked` |
| 6 | long.MaxValue not allocatable | `EventIdSource.cs` | FIXED: `long.MaxValue` allocatable exactly once |
| 7 | Missing concurrency tests | `EventIdSourceTests.cs` | NEW: 4 concurrency/boundary tests added |

### Verification Results

| Check | Exit Code | Result |
|---|---|---|
| Core Release build | 0 | 0 warnings, 0 errors |
| App Release build | 0 | 0 warnings, 0 errors |
| Core tests (Release) | 0 | **266 passed** (includes 10 new EventIdSource tests + 17 EventSchedulerEventBus tests) |
| Integration tests | 0 | 7 passed |
| `bash scripts/verify.sh` | 0 | **ALL PASS** |
| `bash scripts/test-verify-fake.sh` | 0 | **10/10 PASS** |
| Windows execution | — | **NOT RUN** — Linux environment only |

**Total: 273 tests pass (266 unit + 7 integration). Zero skipped, zero failed.**

### Files Changed (R4.7)

- `src/StrategyGame.Core/Events/EventIdSource.cs` — NEW: Thread-safe match-scoped ID allocator
- `src/StrategyGame.Core/Events/DomainEvent.cs` — MODIFIED: Implements `GameEvent`, adds `EffectFailedEvent`
- `src/StrategyGame.Core/Events/EventScheduler.cs` — MODIFIED: EventBus/EventIdSource integration constructor
- `src/StrategyGame.Core/Events/EventTypeRegistrar.cs` — MODIFIED: `ClearHandlersForTesting()` test seam
- `src/StrategyGame.Core/Events/EventScheduler.cs` — MODIFIED: `EventHandlerRegistry.ClearHandlersForTesting()` test seam
- `tests/StrategyGame.Core.Tests/Events/EventIdSourceTests.cs` — MODIFIED: Added 4 concurrency/boundary tests (10 total)
- `tests/StrategyGame.Core.Tests/Events/EventSchedulerEventBusTests.cs` — NEW: 17 integration tests
- `tests/StrategyGame.Core.Tests/AssemblyInfo.cs` — NEW: Disables parallel test execution
- `tests/StrategyGame.Core.Tests/Events/EventSchedulerLifecycleTests.cs` — MODIFIED: Constructor ensures clean registry state
- `docs/architecture/EVENT_ARCHITECTURE.md` — MODIFIED: Updated EA-6 status to IMPLEMENTED
- `docs/repair/REPAIR_PROGRESS.md` — MODIFIED: R4.7 section added

### Implementation Summary

**EventIdSource** — Match-scoped ID allocator:
- Monotonically increasing `long` IDs starting from 1
- Thread-safe: lock-free using `Interlocked.CompareExchange`
- `long.MaxValue` allocatable exactly once
- Throws `OverflowException` at exhaustion without wrapping
- Each match owns one instance; no static global state

**DomainEvent → GameEvent** — Domain events now publishable through `IEventBus`

**EffectFailedEvent** — New domain event for handler failures:
- `HandlerReturnedFalse` — handler returned `false` (unimplemented)
- `HandlerException` — handler threw exception

**EventScheduler Integration** — Backward-compatible:
- Parameterless constructor preserved (R4.6 behavior)
- New constructor: `EventScheduler(IEventBus, EventIdSource)` — both required
- Successful execution: persists `Fired`, publishes `EffectAppliedEvent`
- Handler returns false: persists `Failed`, publishes `EffectFailedEvent(HandlerReturnedFalse)`
- Handler exception: persists `Failed`, publishes `EffectFailedEvent(HandlerException)`
- Missing handler: leaves `Pending`, publishes nothing
- Lifecycle status committed BEFORE publication
- EventBus fail-fast contract preserved

### Test Results

| Suite | Passed | Failed | Total |
|---|---|---|---|
| Core Tests | 266 | 0 | 266 |
| Integration Tests | 7 | 0 | 7 |
| **Total** | **273** | **0** | **273** |

**New Tests (23):**
- EventIdSourceTests: 10 tests (6 original + 4 concurrency/boundary)
- EventSchedulerEventBusTests: 17 tests

---

## R4.5.1 — EventScheduler Correctness Corrections ✅ COMPLETE

**Authorized:** R4.5.1 per project owner independent review on 2026-11-05.
**Scope:** Four correctness issues from independent source-code review of the R4.5 archive.

### Findings Addressed

| # | Finding | File | Fix |
|---|---|---|---|
| 1 | Schedule() did not validate records | `EventScheduler.cs` | Added `record.Validate()` call; reject non-Active status, invalid ExecutionStage, invalid timing |
| 2 | Cross-clock ordering compared RoundIndex with PlayerTurnCounter | `EventScheduler.cs`, `ScheduledEventRecord.cs` | Removed `IComparable<ScheduledEventRecord>`; added explicit `RoundEventComparer` and `PlayerEventComparer`; grouped results by timing kind |
| 3 | Reschedule API used ambiguous SchedulerQuery | `EventScheduler.cs` | Replaced with explicit overloads: `Reschedule(string, RoundTiming)` and `Reschedule(string, PlayerTurnTiming)`; reject cross-timing conversion |
| 4 | Stage-aware due lookup missing | `EventScheduler.cs`, `SchedulerQuery.cs` | Added `CurrentStage` to query; `GetDueEvents` filters by `ExecutionStage` matching `CurrentStage` |

### Verification Results

| Check | Exit Code | Result |
|---|---|---|
| Core Release build | 0 | 0 warnings, 0 errors |
| App Release build | 0 | 0 warnings, 0 errors |
| Core tests (Release) | 0 | **221 passed** (32 EventScheduler + 189 existing) (32 EventScheduler + 180 existing) |
| Integration tests | 0 | 7 passed |
| `bash scripts/verify.sh` | 0 | **ALL PASS** |
| `bash scripts/test-verify-fake.sh` | 0 | **10/10 PASS** |
| Windows execution | — | **NOT RUN** — Linux environment only |

**Total: 228 tests pass (221 unit + 7 integration). Zero skipped, zero failed.**

### Files Changed (R4.5.1)

- `src/StrategyGame.Core/Events/EventScheduler.cs` — Validation, grouped comparers, explicit Reschedule overloads, stage-aware queries
- `src/StrategyGame.Core/Events/ScheduledEventRecord.cs` — Removed `IComparable<ScheduledEventRecord>`
- `src/StrategyGame.Core/Events/SchedulerQuery.cs` — Added `CurrentStage`
- `tests/StrategyGame.Core.Tests/Events/EventSchedulerTests.cs` — 32 focused tests (updated for new API)

### Design Notes (Task 5)

Priority ordering within a compatible clock group is deterministic but the cross-clock Priority direction is **not owner-approved** (docs/architecture/EVENT_ARCHITECTURE.md mentions "lower runs first" as proposal only). The scheduler preserves Priority metadata and applies it consistently within each clock group. Cross-clock ordering between RoundTiming and PlayerTurnTiming events is explicitly separated; no combined ordering is imposed.

Rescheduling SequenceNumber behavior: current implementation preserves the original SequenceNumber (not refreshed). This is an unresolved design decision; see DESIGN_DECISIONS.md.

### NOT Implemented (Reserved for Later Phases)
- EventBus wiring
- TurnEngine integration
- Stage A/B/C/D execution
- Gameplay event handlers
- Event lifecycle execution
- SaveManager
- Serialization changes
- Checkpoint recovery
- Networking
- Multiplayer synchronization
- Gameplay mechanics

---

## Phase 0 + M1.2 Addendum — Economy, Supply & Attrition (2026-11-10)

### Scope & Constraints Honored
- No Git commits made; repository remains commit-free (all work untracked, preserving the existing convention).
- Existing M1.1 APIs unchanged; the only Core source file touched beyond the new modules is `Domain/MapDefinition.cs` (XML-doc clarification only — `GetRegionControlBonus` now documented as STATIC/setup-time-only, because `GameState` copies territories at construction and never propagates match-time captures back into the map).
- Pure Core simulation only: no Godot dependencies, no new NuGet packages, no TurnEngine/ActionExecutor/UI/AI/save-load/multiplayer work. Reinforcement budget and attrition are **not** auto-applied to state — that wiring belongs to M1.3.

### Correctness Fix Delivered (M1.1 issue)
`MapDefinition.GetRegionControlBonus(playerId)` reads the map's own territory objects, which go stale the moment any territory changes hands in a match. The M1.2 economy therefore computes owned-territory counts and region control exclusively from the LIVE `GameState` territory copies, using the map only for static region membership and `RegionDefinition.ArmyBonus` values. Regression test:
`tests/StrategyGame.Core.Tests/Simulation/EconomyEngineTests.cs::CalculateReinforcement_LosingTerritoryInGameState_ReducesRegionBonusImmediately` — proves the engine reflects a state-time capture immediately, while the map data deliberately stays stale (asserted, and documented as intentional setup-time-only behavior).

### Documented Ambiguity (not silently resolved — recorded in KNOWN_ISSUES.md)
D-06 states both "minimum one army remains in an owned territory after attrition" and "a territory at zero armies becomes neutral". These conflict. M1.2 keeps min-garrison (1) as the default; zero-army neutralization exists only behind the explicit `AttritionConfig.AllowZeroGarrisonNeutralization` flag (default false), and even then the engine only REPORTS `WouldBeNeutralized` — the ownership transition itself is a later-system rule. D-06 stays PROPOSED.

### Files Changed / Added (M1.2)
- New: `src/StrategyGame.Core/Simulation/EconomyConfig.cs`
- New: `src/StrategyGame.Core/Simulation/EconomyEngine.cs`
- New: `src/StrategyGame.Core/Simulation/SupplyEngine.cs`
- New: `src/StrategyGame.Core/Simulation/AttritionConfig.cs`
- New: `src/StrategyGame.Core/Simulation/AttritionEngine.cs`
- New tests: `tests/StrategyGame.Core.Tests/Simulation/EconomyEngineTests.cs` (22 cases), `SupplyEngineTests.cs` (16), `AttritionEngineTests.cs` (20), `SupplyAttritionChainTests.cs` (6 chain tests on the M1.1 deterministic `small_map.json`)
- Doc-only: `Domain/MapDefinition.cs` (XML doc), `docs/architecture/M1_ROADMAP.md`, `docs/design/ECONOMY_AND_RESOURCES.md`, `docs/MILESTONES.md`, `docs/repair/KNOWN_ISSUES.md`, this file

### Verification Results (M1.2, real outputs)
| Check | Exit Code | Result |
|---|---|---|
| Core Release build | 0 | 0 warnings, 0 errors |
| App Release build | 0 | 0 warnings, 0 errors |
| Core tests (Release) | 0 | **393 passed** (329 baseline + 64 new), 0 failed, 0 skipped |
| Integration tests (Release) | 0 | **7 passed** |
| `bash scripts/verify.sh` | 0 | **ALL PASS** (incl. Godot import + startup checks) |
| Windows execution | — | **NOT RUN** — Linux environment only |

Test-count transition: Core 329 → 393 (+64). Integration unchanged at 7. Baseline was independently re-verified BEFORE changes (329/7, ALL PASS) so all deltas are attributable to M1.2.

### Known Limitations (pre-existing, guarded but not silently fixed)
- `Territory.SetOwner` still does not validate negative army counts (M1.0 hole). Constructing/copying a state with negative armies is therefore possible. `AttritionEngine` detects this and throws `InvalidOperationException` ("negative army count") rather than computing garbage; a dedicated test locks this in. The underlying Hole fix is deferred to a future owner-approved change.
- `AttritionEngine` rejects supply results whose `PlayerId` differs from the requested player (`ArgumentException`) and validates player existence before that check (`KeyNotFoundException` for unknown players).

## Review v2 Addendum (2026-11-10)

Three targeted corrections applied after independent review of the initial archive:

### 1. AttritionEngine stale SupplyResult detection
- **File**: `src/StrategyGame.Core/Simulation/AttritionEngine.cs`
- **Before**: Only checked that unsupplied territories were still owned by the player.
- **After**: Recalculates fresh supply state from the CURRENT GameState and compares set-wise (supplied, unsupplied, owned count, sources, HasOwnedSource). Rejects structural invalidity (duplicates, unknown ids, overlapping sets, null lists) and stale results (ownership/connectivity changes, forged/incomplete claims) with `ArgumentException` containing diagnostic detail. Attrition is never silently skipped.
- **Regression tests**: 5 cases covering ownership gain/loss after calculation, forged duplicate/overlapping/incomplete/unknown-id results, plus a valid fresh-result sanity test.

### 2. Genuinely read-only returned collections
- **Files**: `EconomyEngine.cs`, `SupplyEngine.cs`, `AttritionEngine.cs`
- **Before**: Properties typed as `IReadOnlyList<T>` but backed by mutable `List<T>`.
- **After**: All returned collections wrapped with `List.AsReadOnly()`; callers cannot cast back to `List<T>` or mutate via `IList` interface.
- **Regression tests**: 3 tests (one per engine) attempting invalid cast and `IList.Add`/`Clear` → `InvalidCastException`/`NotSupportedException`.

### 3. Consistent negative-army validation
- **File**: `AttritionEngine.cs`
- **Before**: Only checked unsupplied territories for negative armies.
- **After**: Validates **all** territories owned by the requested player (supplied and unsupplied alike) before calculation.
- **Regression test**: Supplied territory with negative armies → `InvalidOperationException`.

### Updated Verification Results (Review v2)
| Check | Exit Code | Result |
|---|---|---|
| Core Release build | 0 | 0 warnings, 0 errors |
| App Release build | 0 | 0 warnings, 0 errors |
| Core tests (Release) | 0 | **405 passed** (329 baseline + 76 new), 0 failed, 0 skipped |
| Integration tests (Release) | 0 | **7 passed** |
| `bash scripts/verify.sh` | 0 | **ALL PASS** (incl. Godot import + startup checks) |
| Windows execution | — | **NOT RUN** — Linux environment only |

Test-count transition: Core 329 → **405** (+76 total; +64 original + 12 review-v2).

### Known Limitations (unchanged from M1.2)
- `Territory.SetOwner` still does not validate negative army counts (M1.0 hole). `AttritionEngine` detects this in ALL player-owned territories and throws `InvalidOperationException`. The underlying hole fix is deferred to a future owner-approved change.
- D-06/D-08 remain PROPOSED; no provisional rule promoted to owner-approved.

### Files Changed (Review v2)
- Modified: `src/StrategyGame.Core/Simulation/AttritionEngine.cs` (full validation rewrite + file-level staleness-guard helpers)
- Modified: `src/StrategyGame.Core/Simulation/SupplyEngine.cs` (defensive read-only wrappers)
- Modified: `src/StrategyGame.Core/Simulation/EconomyEngine.cs` (defensive read-only wrapper)
- New tests: `AttritionEngineTests` (+12 cases), `SupplyEngineTests` (+1), `EconomyEngineTests` (+1)
- Docs: `M1_ROADMAP.md`, `REPAIR_PROGRESS.md`, `KNOWN_ISSUES.md`

## M1.1 Map Integrity Correction Addendum (2026-11-10)

An independent source review found that `MapValidator` was missing two invariants explicitly documented in `docs/architecture/DOMAIN_MODEL.md` (§2 Territory Invariants):

1. **Symmetric adjacency** — if A references B, B must reference A.
2. **No duplicate adjacency IDs** within a single territory's list.

The existing validator only checked unknown references and self-adjacency.

### Files Changed
- `src/StrategyGame.Core/Domain/MapValidator.cs` — added both invariant checks with clear diagnostics:
  - Duplicate adjacency: `"Territory '{t.Id}' lists duplicate adjacent territory '{adjId}'."`
  - Asymmetric adjacency: `"Asymmetric adjacency: territory '{t.Id}' references '{adjId}' but '{adjId}' does not reference '{t.Id}'."`
- `tests/StrategyGame.Core.Tests/Domain/MapValidatorAdjacencyTests.cs` — 5 focused tests:
  - Valid symmetric graph accepted
  - One-way adjacency rejected
  - Duplicate adjacency ID rejected
  - Multiple violations all reported (aggregated diagnostics)
  - Existing `small_map.json` remains valid
- No map data fixes needed — the deterministic test map was already symmetric.

### Verification Results
| Check | Exit Code | Result |
|---|---|---|
| Core Release build | 0 | 0 warnings, 0 errors |
| App Release build | 0 | 0 warnings, 0 errors |
| Core tests (Release) | 0 | **410 passed** (329 baseline + 81 total from M1.2 + review-v2 + map integrity) |
| Integration tests (Release) | 0 | 7 passed |
| `bash scripts/verify.sh` | 0 | **ALL PASS** (incl. Godot import + startup) |

Test-count transition: Core 405 → **410** (+5 map integrity tests).
No changes to supply semantics, D-06/D-08 statuses, or any M1.2 engine behavior.

---

## M1.3 — Action Execution, Turn Engine & Gameplay Orchestration (2026-11-10)

### Scope & Constraints Honored
- No Git commits made; repository remains commit-free (all work untracked).
- Pure C# Core (`StrategyGame.Core`), no Godot deps, deterministic and side-effect-free.
- All simulation logic inside `StrategyGame.Core`; no new NuGet packages.
- Implements hybrid A/B/C/D turn cycle per `TURN_AND_EVENT_SYSTEM.md`.
- Integrates existing M1.2 systems (EconomyEngine, SupplyEngine, AttritionEngine).
- Implements ActionExecutor with Reinforce, Attack, Fortify actions.
- Updates CombatSystem per COMBAT_AND_ARMY_RULES.md (terrain bonuses, defender wins ties).
- Integrates EventScheduler/EventBus at correct stages (A, C, D — not B).
- Victory evaluation at Stage D per D-16-5.
- All provisional rules (D-06, D-08) remain PROPOSED.
- End-to-end Core gameplay test covering full turn cycle.

### Design Decisions Documented
| Decision | Implementation |
|---|---|
| TurnStage enum created | `Simulation/TurnStage.cs` — TurnStart=0, PlayerActions=1, EventProcessing=2, TurnEnd=3, GameOver=4 |
| GameState mutable internals | `CurrentTurnPlayerIdInternal`, `CurrentTurnNumberInternal`, `CurrentPhaseInternal` with public readonly snapshots for safety |
| `AdvanceTurn()` behavior | Updates internal state AND returns next stage; turn number increments only on full cycle wrap |
| Terrain bonuses (PROVISIONAL) | Plains=0, Forest=1, Hills=2, Mountains=3, Marsh=0, Coast=1 (all D-05 PROPOSED) |
| Combat formula | `attacker_strength = attacker_armies - 1`; `defender_strength = defender_armies + terrain_bonus`; **defender wins ties** |
| EventScheduler integration | Stage C only (ExecutionStage.EventProcessing); Stage B excluded by type system (D-16-3) |
| Victory timing | Evaluated at Stage D before advancing to next player (D-16-5) |
| Turn rotation | If cycling back to first player after all players act, increment turn number |

### Files Created
- `src/StrategyGame.Core/Simulation/TurnStage.cs` — New TurnStage enum for A/B/C/D cycle
- `src/StrategyGame.Core/Actions/GameActions.cs` — New action records (ReinforceAction, AttackAction, FortifyAction)
- `src/StrategyGame.Core/Actions/ActionExecutor.cs` — New action validation and execution logic
- `src/StrategyGame.Core/Simulation/TurnEngine.cs` — New central turn-cycle orchestrator
- `tests/StrategyGame.Core.Tests/Simulation/TurnEngineTests.cs` — 11 unit tests
- `tests/StrategyGame.Core.Tests/Actions/ActionExecutorTests.cs` — 12 unit tests
- `tests/StrategyGame.Core.Tests/GameState/CombatSystemTerrainTests.cs` — 7 terrain/faction combat tests
- `tests/StrategyGame.Core.Tests/Simulation/TurnEngineEndToEndTests.cs` — 3 end-to-end integration tests

### Files Modified
- `src/StrategyGame.Core/GameState/CombatSystem.cs` — Updated with terrain bonuses and proper combat formula
- `src/StrategyGame.Core/GameState/TurnManager.cs` — Added ToTurnStage/ToLegacyPhase mappings
- `src/StrategyGame.Core/GameState/GameState.cs` — Added mutable internal fields and AdvanceTurn/SetPhase methods
- `docs/MILESTONES.md` — M1.3 completion status added

### Verification Results (M1.3)
| Check | Exit Code | Result |
|---|---|---|
| Core Release build | 0 | 0 warnings, 0 errors |
| App Release build | 0 | 0 warnings, 0 errors |
| Core tests (Release) | 0 | **449 passed** (416 baseline + 33 new), 0 failed, 0 skipped |
| Integration tests (Release) | 0 | **7 passed** |
| `bash scripts/verify.sh` | 0 | **ALL PASS** (incl. Godot import + startup checks) |
| Windows execution | — | **NOT RUN** — Linux environment only |

**Test-count transition: Core 410 → 449 (+39 from M1.3 including 33 new + 6 from refactoring). Integration unchanged at 7.**

All 449 Core tests + 7 Integration tests pass. Full verification green.
