namespace StrategyGame.Core.Domain;

/// <summary>
/// Thrown when a MapDefinition fails validation. Aggregates every diagnostic
/// found so map authors see all problems at once, not just the first.
/// </summary>
public sealed class MapValidationException : Exception
{
    /// <summary>All diagnostics detected at validation time.</summary>
    public IReadOnlyList<string> Diagnostics { get; }

    public MapValidationException(string message, IReadOnlyList<string> diagnostics)
        : base(message + " " + string.Join(" | ", diagnostics))
    {
        if (diagnostics is null || diagnostics.Count == 0)
            throw new ArgumentException("At least one diagnostic is required.", nameof(diagnostics));
        Diagnostics = [.. diagnostics];
    }
}
