namespace StrategyGame.Core.Tests.GameState;

using StrategyGame.Core.Domain;
using StrategyGame.Core.GameState;
using Xunit;

public class CombatSystemTerrainTests
{
    private MapDefinition CreateMapWithTerrain(TerrainType defenderTerrain, int defenderArmies = 3)
    {
        var territories = new List<Territory>
        {
            new Territory("attacker", "Attacker", ["defender"], TerrainType.Plains, null, false),
            new Territory("defender", "Defender", ["attacker"], defenderTerrain, null, false),
        };
        return new MapDefinition("terrain-test", "Terrain Test", territories);
    }

    [Fact]
    public void ResolveAttack_ParallelStrength_DefenderWinsTie()
    {
        // Attacker: 3 armies -> strength = 2
        // Defender: 2 armies, plains terrain -> strength = 2
        // Tie goes to defender
        var map = new MapDefinition("t", "T", new List<Territory>
        {
            new Territory("a", "A", ["b"], TerrainType.Plains, null, false),
            new Territory("b", "B", ["a"], TerrainType.Plains, null, false),
        });
        var p1 = new Player("p1", "P1", new Faction("f1", "R", "#F00"), isHuman: true);
        var p2 = new Player("p2", "P2", new Faction("f2", "B", "#00F"), isHuman: false);
        var state = new GameState("g", map, [p1, p2], "p1", 1, TurnManager.PhaseAttack);
        state.GetTerritory("a").SetOwner("p1", 3);
        state.GetTerritory("b").SetOwner("p2", 2);

        var result = CombatSystem.ResolveAttack(state, "a", "b");

        Assert.False(result.AttackerWon);
        Assert.Null(result.CapturedTerritoryId);
    }

    [Fact]
    public void ResolveAttack_MountainsBonus_DefenderWinsAgainstStrongerForce()
    {
        // Attacker: 5 armies -> strength = 4
        // Defender: 2 armies + mountains bonus (3) -> strength = 5
        // Defender wins despite having fewer raw armies
        var map = new MapDefinition("t", "T", new List<Territory>
        {
            new Territory("a", "A", ["b"], TerrainType.Plains, null, false),
            new Territory("b", "B", ["a"], TerrainType.Mountains, null, false),
        });
        var p1 = new Player("p1", "P1", new Faction("f1", "R", "#F00"), isHuman: true);
        var p2 = new Player("p2", "P2", new Faction("f2", "B", "#00F"), isHuman: false);
        var state = new GameState("g", map, [p1, p2], "p1", 1, TurnManager.PhaseAttack);
        state.GetTerritory("a").SetOwner("p1", 5);
        state.GetTerritory("b").SetOwner("p2", 2);

        var result = CombatSystem.ResolveAttack(state, "a", "b");

        Assert.False(result.AttackerWon);
        Assert.Null(result.CapturedTerritoryId);
    }

    [Fact]
    public void ResolveAttack_HillsBonus_AffordsVictory()
    {
        // Attacker: 4 armies -> strength = 3
        // Defender: 1 army + hills bonus (2) -> strength = 3
        // Tie goes to defender
        var map = new MapDefinition("t", "T", new List<Territory>
        {
            new Territory("a", "A", ["b"], TerrainType.Plains, null, false),
            new Territory("b", "B", ["a"], TerrainType.Hills, null, false),
        });
        var p1 = new Player("p1", "P1", new Faction("f1", "R", "#F00"), isHuman: true);
        var p2 = new Player("p2", "P2", new Faction("f2", "B", "#00F"), isHuman: false);
        var state = new GameState("g", map, [p1, p2], "p1", 1, TurnManager.PhaseAttack);
        state.GetTerritory("a").SetOwner("p1", 4);
        state.GetTerritory("b").SetOwner("p2", 1);

        var result = CombatSystem.ResolveAttack(state, "a", "b");

        // strength = 3 vs 3 -> tie -> defender wins
        Assert.False(result.AttackerWon);
    }

    [Fact]
    public void ResolveAttack_AttackerWinsWhenStrengthExceeds()
    {
        // Attacker: 6 armies -> strength = 5
        // Defender: 2 armies, forests (+1) -> strength = 3
        // Attacker wins
        var map = new MapDefinition("t", "T", new List<Territory>
        {
            new Territory("a", "A", ["b"], TerrainType.Plains, null, false),
            new Territory("b", "B", ["a"], TerrainType.Forest, null, false),
        });
        var p1 = new Player("p1", "P1", new Faction("f1", "R", "#F00"), isHuman: true);
        var p2 = new Player("p2", "P2", new Faction("f2", "B", "#00F"), isHuman: false);
        var state = new GameState("g", map, [p1, p2], "p1", 1, TurnManager.PhaseAttack);
        state.GetTerritory("a").SetOwner("p1", 6);
        state.GetTerritory("b").SetOwner("p2", 2);

        var result = CombatSystem.ResolveAttack(state, "a", "b");

        Assert.True(result.AttackerWon);
        Assert.Equal("b", result.CapturedTerritoryId);
    }

    [Fact]
    public void ResolveAttack_CoastBonus_TiesGoToDefender()
    {
        // Attacker: 3 armies -> strength = 2
        // Defender: 1 army + coast (+1) -> strength = 2
        // Tie -> defender wins
        var map = new MapDefinition("t", "T", new List<Territory>
        {
            new Territory("a", "A", ["b"], TerrainType.Plains, null, false),
            new Territory("b", "B", ["a"], TerrainType.Coast, null, false),
        });
        var p1 = new Player("p1", "P1", new Faction("f1", "R", "#F00"), isHuman: true);
        var p2 = new Player("p2", "P2", new Faction("f2", "B", "#00F"), isHuman: false);
        var state = new GameState("g", map, [p1, p2], "p1", 1, TurnManager.PhaseAttack);
        state.GetTerritory("a").SetOwner("p1", 3);
        state.GetTerritory("b").SetOwner("p2", 1);

        var result = CombatSystem.ResolveAttack(state, "a", "b");

        Assert.False(result.AttackerWon);
    }

    [Fact]
    public void ResolveAttack_MarshNoBonus_AttackerMustHaveStrictlyMore()
    {
        // Marsh gives no bonus. Same as plain.
        // Attacker: 3 -> 2, Defender: 2 -> 2, Tie -> defender wins
        var map = new MapDefinition("t", "T", new List<Territory>
        {
            new Territory("a", "A", ["b"], TerrainType.Plains, null, false),
            new Territory("b", "B", ["a"], TerrainType.Marsh, null, false),
        });
        var p1 = new Player("p1", "P1", new Faction("f1", "R", "#F00"), isHuman: true);
        var p2 = new Player("p2", "P2", new Faction("f2", "B", "#00F"), isHuman: false);
        var state = new GameState("g", map, [p1, p2], "p1", 1, TurnManager.PhaseAttack);
        state.GetTerritory("a").SetOwner("p1", 3);
        state.GetTerritory("b").SetOwner("p2", 2);

        var result = CombatSystem.ResolveAttack(state, "a", "b");

        Assert.False(result.AttackerWon);
    }

    [Fact]
    public void ResolveAttack_MinimumGarrisonPreservedAtSource()
    {
        // When attacker wins, they leave at least 1 army behind
        var map = new MapDefinition("t", "T", new List<Territory>
        {
            new Territory("a", "A", ["b"], TerrainType.Plains, null, false),
            new Territory("b", "B", ["a"], TerrainType.Plains, null, false),
        });
        var p1 = new Player("p1", "P1", new Faction("f1", "R", "#F00"), isHuman: true);
        var p2 = new Player("p2", "P2", new Faction("f2", "B", "#00F"), isHuman: false);
        var state = new GameState("g", map, [p1, p2], "p1", 1, TurnManager.PhaseAttack);
        state.GetTerritory("a").SetOwner("p1", 4); // strong enough to win
        state.GetTerritory("b").SetOwner("p2", 1); // weak defender

        var result = CombatSystem.ResolveAttack(state, "a", "b");

        Assert.True(result.AttackerWon);
        // Attacker should have at least 1 remaining
        Assert.True(result.AttackerRemaining >= 1);
    }
}