namespace StrategyGame.Core.Domain;

/// <summary>
/// M1.1 — Explicit terrain categories for a territory.
///
/// PROVISIONAL: The terrain list and all terrain-dependent gameplay values
/// (defense bonuses, income modifiers) are <c>[PROPOSED]</c> in
/// <c>docs/design/DESIGN_DECISIONS.md</c> D-05 and
/// <c>docs/design/MAP_AND_TERRITORY_DESIGN.md</c>, and are not owner-approved.
/// This enum fixes the category set so later systems (combat M1.3, supply M1.2,
/// rendering M1.5) have a stable vocabulary; values must not be reordered or
/// renumbered once maps reference them.
///
/// COMBAT NOTE: The current CombatSystem compares raw army counts only and does
/// NOT consume terrain data yet. Terrain defense bonuses remain unimplemented.
/// </summary>
public enum TerrainType
{
    Plains = 0,
    Forest = 1,
    Hills = 2,
    Mountains = 3,
    Marsh = 4,
    Coast = 5,
}
