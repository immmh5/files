# QA and Testing Strategy

## Testing Philosophy

**Test before you believe.** Every meaningful infrastructure change is verified with an actual test or build result. Assumptions are documented; they are not treated as facts.

## Test Layers

### Layer 1 — Unit Tests (StrategyGame.Core.Tests)

- xUnit test framework.
- Test the **pure C# domain logic** in isolation.
- No Godot references, no scene instantiation.
- Coverage targets:
  - `CombatSystem` resolution logic
  - `VictoryChecker` condition evaluation
  - `GameState` mutation and snapshot
  - `TurnManager` phase sequencing
  - Domain entity invariants (e.g., territory adjacency, army counts)

**Run:** `dotnet test tests/StrategyGame.Core.Tests/`

### Layer 2 — Integration Tests (Integration.Tests)

- Smoke tests that verify the application boots.
- Uses `GodotSharp` bindings to launch headless Godot and verify:
  - Application starts without errors
  - `Main` scene loads
  - `GameController` initializes correctly
  - Version string is accessible

**Run:** `dotnet test tests/Integration.Tests/`

### Layer 3 — Build Verification (scripts/verify.sh)

- Compiles both projects from scratch.
- Runs all unit tests.
- Checks exit codes.
- Verifies no compiler warnings (warnings as errors enabled).

**Run:** `./scripts/verify.sh` or `pwsh scripts/verify.ps1`

### Layer 4 — CI (GitHub Actions)

- Runs `verify.sh` on every push/PR.
- Linux x64 CI via `ci.yml`.
- Windows x64 CI via `ci-windows.yml` (on push, build only — no Godot on Windows runner needed for build-only).

## Quality Gates

All of the following must pass before a milestone is marked complete:

- [ ] `dotnet build` succeeds for `StrategyGame.Core` with zero warnings.
- [ ] `dotnet build` succeeds for `StrategyGame.App` with zero warnings.
- [ ] `dotnet test` (core unit tests) passes with 100% pass rate.
- [ ] Godot headless startup check succeeds (app launches, reports version, exits cleanly).
- [ ] No new compiler warnings introduced.
- [ ] CI pipeline green on both Linux and Windows.

## What Is NOT Tested (Yet)

- UI interaction tests (Selenium/Playwright not in scope for Milestone 0).
- Performance benchmarks (baseline will be established in Milestone 1 after functional features exist).
- Networking (no transport implemented yet).

## Test Naming

Test methods follow `[MethodUnderTest]_[Scenario]_[ExpectedResult]`:

```csharp
[Fact]
public void CombatSystem_AttackWithSufficientArmies_CapturesTerritory() { ... }

[Fact]
public void VictoryChecker_SinglePlayerOwnsAllTerritories_IsVictorious() { ... }
```

## Continuous Verification

The verification scripts (`verify.sh` / `verify.ps1`) are the single source of truth for "does the project build and pass tests?" — not manual checks, not assumptions, not documentation. They must return exit code 0 on success and non-zero on any failure.
