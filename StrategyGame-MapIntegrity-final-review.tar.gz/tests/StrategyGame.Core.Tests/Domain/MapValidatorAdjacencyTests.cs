namespace StrategyGame.Core.Tests.Domain;

using StrategyGame.Core.Domain;
using StrategyGame.Core.Storage;
using Xunit;

/// <summary>
/// M1.1 correction — MapValidator adjacency invariants:
/// 1. Symmetric adjacency (A→B requires B→A)
/// 2. No duplicate adjacency IDs within a territory
/// </summary>
public class MapValidatorAdjacencyTests
{
    private static readonly string[] EmptyAdj = [];

    private static Territory Make(string id, string name, params string[] adj)
        => new(id, name, adj, TerrainType.Plains, null, isSupplySource: false);

    private static RegionDefinition MakeRegion(string id) => new(id, id, 0);

    [Fact]
    public void Validate_SymmetricAdjacency_IsAccepted()
    {
        var territories = new[]
        {
            Make("a", "A", "b"),
            Make("b", "B", "a"),
        };
        var regions = new[] { MakeRegion("r1") };

        var diagnostics = MapValidator.Validate("map", "Map", territories, regions);

        Assert.Empty(diagnostics);
    }

    [Fact]
    public void Validate_OneWayAdjacency_IsRejected()
    {
        var territories = new[]
        {
            Make("a", "A", "b"),
            Make("b", "B"), // no adjacency
        };
        var regions = new[] { MakeRegion("r1") };

        var diagnostics = MapValidator.Validate("map", "Map", territories, regions);

        Assert.Contains(diagnostics, d => d.Contains("Asymmetric adjacency: territory 'a' references 'b' but 'b' does not reference 'a'."));
    }

    [Fact]
    public void Validate_DuplicateAdjacencyId_IsRejected()
    {
        var territories = new[]
        {
            Make("a", "A", "b", "b"),
            Make("b", "B", "a"),
        };
        var regions = new[] { MakeRegion("r1") };

        var diagnostics = MapValidator.Validate("map", "Map", territories, regions);

        Assert.Contains(diagnostics, d => d.Contains("Territory 'a' lists duplicate adjacent territory 'b'."));
    }

    [Fact]
    public void Validate_MultipleAdjacencyViolations_AreAllReported()
    {
        // a→b (ok), b→c (asymmetric: c does not reference b), c→c (self), c has duplicate "a", c→a (asymmetric: a does not reference c)
        var territories = new[]
        {
            Make("a", "A", "b"),
            Make("b", "B", "a", "c"),
            Make("c", "C", "c", "a", "a"), // self + duplicate + asymmetric
        };
        var regions = new[] { MakeRegion("r1") };

        var diagnostics = MapValidator.Validate("map", "Map", territories, regions);

        // Self adjacency
        Assert.Contains(diagnostics, d => d.Contains("Territory 'c' is adjacent to itself."));
        // Duplicate
        Assert.Contains(diagnostics, d => d.Contains("Territory 'c' lists duplicate adjacent territory 'a'."));
        // Asymmetric: b references c but c does not reference b
        Assert.Contains(diagnostics, d => d.Contains("Asymmetric adjacency: territory 'b' references 'c' but 'c' does not reference 'b'."));
        // Asymmetric: c references a but a does not reference c
        Assert.Contains(diagnostics, d => d.Contains("Asymmetric adjacency: territory 'c' references 'a' but 'a' does not reference 'c'."));
    }

    [Fact]
    public void Validate_SmallMapJson_RemainsValid()
    {
        var map = MapLoader.LoadFromFile(
            Path.Combine(AppContext.BaseDirectory, "TestData", "small_map.json"));

        Assert.NotNull(map);
        // MapDefinition constructor calls Validate and throws if invalid
        Assert.True(map.Territories.Count > 0);
    }

    // ================================================================
    // Hardened immutability / defensive copy tests
    // ================================================================

    [Fact]
    public void Territory_AdjacencyInputMutationAfterConstruction_DoesNotAffectTerritory()
    {
        var inputAdj = new List<string> { "b", "c" };
        var t = new Territory("a", "A", inputAdj, TerrainType.Plains, null, false);

        inputAdj.Add("d"); // mutate caller's list after construction

        Assert.Equal(["b", "c"], t.AdjacentTerritoryIds); // territory unchanged
    }

    [Fact]
    public void Territory_AdjacentTerritoryIds_CannotBeMutatedViaCast()
    {
        var t = new Territory("a", "A", ["b", "c"], TerrainType.Plains, null, false);

        // Cannot cast to string[]
        Assert.Throws<InvalidCastException>(() => (string[])t.AdjacentTerritoryIds);
        // Cannot cast to List<string>
        Assert.Throws<InvalidCastException>(() => (List<string>)t.AdjacentTerritoryIds);
        // IList mutation throws
        var asIList = (System.Collections.IList)t.AdjacentTerritoryIds;
        Assert.Throws<NotSupportedException>(() => asIList.Add("mutant"));
        Assert.Throws<NotSupportedException>(() => asIList.Clear());
        Assert.Equal(2, t.AdjacentTerritoryIds.Count);
    }

    [Fact]
    public void TerritorySnapshot_Adjacency_CannotBeMutated()
    {
        var t = new Territory("a", "A", ["b", "c"], TerrainType.Plains, null, false);
        var snap = t.Snapshot();

        Assert.Equal(["b", "c"], snap.AdjacentTerritoryIds);

        Assert.Throws<InvalidCastException>(() => (string[])snap.AdjacentTerritoryIds);
        Assert.Throws<InvalidCastException>(() => (List<string>)snap.AdjacentTerritoryIds);
        var asIList = (System.Collections.IList)snap.AdjacentTerritoryIds;
        Assert.Throws<NotSupportedException>(() => asIList.Add("mutant"));
        Assert.Throws<NotSupportedException>(() => asIList.Clear());
        Assert.Equal(2, snap.AdjacentTerritoryIds.Count);
    }

    [Fact]
    public void TerritorySnapshot_MutationDoesNotAffectOriginal()
    {
        var t = new Territory("a", "A", ["b", "c"], TerrainType.Plains, null, false);
        var snap = t.Snapshot();

        // Try to mutate snapshot's adjacency via reflection/cast - not possible
        // Verify original still intact
        Assert.Equal(["b", "c"], t.AdjacentTerritoryIds);
    }

    [Fact]
    public void MapDefinition_AsymmetricAdjacency_ThrowsMapValidationException()
    {
        var territories = new[]
        {
            new Territory("a", "A", ["b"], TerrainType.Plains, null, false),
            new Territory("b", "B", [], TerrainType.Plains, null, false), // no reference back
        };
        var regions = new[] { new RegionDefinition("r1", "R1", 0) };

        var ex = Assert.Throws<MapValidationException>(() =>
            new MapDefinition("map", "Map", territories, regions));

        Assert.Contains("Asymmetric adjacency", ex.Message);
        Assert.Contains("a", ex.Message);
        Assert.Contains("b", ex.Message);
    }

    [Fact]
    public void MapLoader_FromFile_AsymmetricAdjacency_ThrowsMapValidationException()
    {
        var asymmetricJson = """
        {
            "id": "asym",
            "name": "Asymmetric",
            "regions": [{ "id": "r1", "name": "R1", "bonus": 0 }],
            "territories": [
                { "id": "a", "name": "A", "region": "r1", "terrain": "plains", "adjacent": ["b"], "supply_source": false },
                { "id": "b", "name": "B", "region": "r1", "terrain": "plains", "adjacent": [], "supply_source": false }
            ]
        }
        """;
        var tempPath = Path.GetTempFileName();
        try
        {
            File.WriteAllText(tempPath, asymmetricJson);

            var ex = Assert.Throws<MapValidationException>(() =>
                MapLoader.LoadFromFile(tempPath));

            Assert.Contains("Asymmetric adjacency", ex.Message);
            Assert.Contains("a", ex.Message);
            Assert.Contains("b", ex.Message);
        }
        finally
        {
            if (File.Exists(tempPath))
                File.Delete(tempPath);
        }
    }
}