# AI_OPPONENT_DESIGN.md

**Status:** PROPOSED DESIGN

---

## 1. Architecture

Utility-based scoring AI. Deterministic. No ML, no external APIs.

## 2. Difficulty Levels

| Level | Strategy | Performance |
|---|---|---|
| Easy | Weighted random among top-N moves | < 1 ms |
| Normal | Greedy utility maximization | < 5 ms |
| Hard | Greedy + 1-ply opponent-response check | < 10 ms |

## 3. Territory Evaluation

Each territory is scored on:
- Strategic value (region bonus, terrain)
- Defensive value (border status)
- Economic value (income contribution)
- Supply status

## 4. Defensive Priorities

- Protect border territories
- Maintain supply lines
- Reinforce weak territories

## 5. Offensive Priorities

- Attack weak enemy territories
- Capture region bonuses
- Cut enemy supply lines

## 6. Resource Decisions

- Prioritize income-generating territories
- Balance offense vs defense
- Avoid overextension

## 7. Diplomacy Behavior

**Deferred to Category 2.** No diplomacy in first playable version.

## 8. Decision-Making Architecture

```
evaluateTerritories(state) → scores
  evaluateMoves(state, scores) → moveOptions
  evaluateAttacks(state, scores) → attackOptions
  selectBest(options) → orders
```

## 9. Performance Limits

- Decision budget: < 10 ms per phase
- No allocations in hot loop
- Pre-allocated buffers where possible