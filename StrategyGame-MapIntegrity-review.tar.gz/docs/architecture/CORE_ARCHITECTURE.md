# CORE_ARCHITECTURE.md

**Status:** PROPOSED ARCHITECTURE
**Purpose:** Define the system boundaries, component responsibilities, and data flow for StrategyGame.

---

## 1. Architectural Principles

| Principle | Enforcement |
|---|---|
| **Core-First** | `StrategyGame.Core` has zero Godot dependencies. All game rules, state, and logic live here. |
| **Host-Consumer** | `StrategyGame.App` references Core; Core never references App. |
| **Deterministic Simulation** | No RNG in authoritative paths. Combat, income, attrition, events are pure functions. |
| **Event-Driven** | State changes publish `GameEvent` via `IEventBus`. No polling, no per-frame rule evaluation. |
| **Testable by Default** | Core domain logic is covered by unit tests without Godot. |
| **Serialization-First** | Game state, events, and commands are serializable by design (event sourcing). |

---

## 2. Module Diagram

```
┌─────────────────────────────────────────────────────────────────────┐
│                    StrategyGame.App (Godot Host)                   │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌──────────────┐ │
│  │   Scenes    │ │  Scripts    │ │     UI      │ │  Rendering   │ │
│  │  (Main.tscn)│ │ (Controllers)│ │ (Panels,    │ │ (MapView,    │ │
│  └──────┬──────┘ └──────┬──────┘ │  HUD)       │ │  Effects)    │ │
│         │               │        └──────┬──────┘ └──────┬──────┘ │
│         └───────────────┼───────────────┼───────────────┘      │
└─────────────────────────┼───────────────┼──────────────────────┘
                          ▼               ▼
┌─────────────────────────────────────────────────────────────────────┐
│                 StrategyGame.Core (Pure C#)                        │
│  ┌────────────┐ ┌────────────┐ ┌────────────┐ ┌────────────────┐  │
│  │  Domain    │ │  GameState │ │  Events    │ │  Simulation    │  │
│  │ (Entity,   │ │ (GameState,│ │ (GameEvent,│ │ (TurnEngine,   │  │
│  │  ValueObj) │ │  TurnEngine,│ │  EventBus) │ │  EventScheduler,│  │
│  │            │ │  Combat,   │ │            │ │  CombatSystem, │  │
│  │            │ │  Victory)  │ │            │ │  SupplyEngine) │  │
│  └────────────┘ └────────────┘ └────────────┘ └────────────────┘  │
│  ┌────────────┐ ┌────────────┐ ┌────────────┐ ┌────────────────┐  │
│  │  Networking│ │     AI     │ │  Storage   │ │  Common        │  │
│  │ (Interfaces)│ │ (Interfaces)│ │ (Interfaces)│ │ (ValueObject,  │  │
│  └────────────┘ └────────────┘ └────────────┘ │  Result,       │  │
│                                              │  IdGenerator)  │  │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 3. Core Assembly Structure

### StrategyGame.Core (net8.0 Class Library)
- **No Godot references** — compiles without Godot
- **Public API surface:** Domain, GameState, Events, Simulation, Interfaces
- **Internal:** Implementation details of simulation engines

### StrategyGame.App (Godot.NET.Sdk/4.7.2)
- References `StrategyGame.Core`
- Godot scenes, UI controllers, rendering, input handling
- Implements Core interfaces (e.g., `IEventBus` with Godot-specific bridging)

---

## 4. Data Flow (Authoritative Path)

```
Player Input (App)
     │
     ▼
Order / Action DTO ───► TurnEngine.ValidateAndQueue()
     │
     ▼
TurnEngine.ExecuteStageB() ──► CombatSystem.Resolve() ──► State Mutation
     │                                                      │
     ▼                                                      ▼
EventScheduler.Schedule()                            EventBus.Publish()
     │                                                      │
     ▼                                                      ▼
Simulation advances ──────► StateSnapshot ──► App (EventBus) ──► UI Update
```

---

## 5. Key Interfaces (Core → App Contract)

| Interface | Purpose | Implemented By |
|---|---|---|
| `IEventBus` | Publish/subscribe domain events | App (bridges to Godot signals) |
| `INetworkTransport` | Send/receive orders & snapshots | App (ENet / WebRTC later) |
| `INetworkDiscovery` | LAN room discovery | App (UDP broadcast) |
| `IAIPlayer` | AI decision-making | Core (default) / App (custom) |
| `ISaveSerializer` | Serialize/deserialize state | App (MessagePack / JSON) |
| `IMapLoader` | Load map definitions | App (file system / resources) |

---

## 6. State Ownership Rules

| State | Owner | Mutability |
|---|---|---|
| `GameState` (territories, players, armies) | TurnEngine (single writer) | Mutable during stage execution; `Snapshot()` returns immutable copy |
| `TurnEngine` (current player, turn number, stage) | TurnEngine | Mutable; serialized in save |
| `EventScheduler` (pending event queue) | TurnEngine | Mutable; part of authoritative state |
| `GameState.Snapshot()` | TurnEngine | Immutable; used for AI, UI, network sync |
| `MapDefinition` | Loaded once at startup | Immutable after load |
| `Faction` definitions | Loaded once | Immutable |

---

## 7. Concurrency Model

- **Single-threaded authoritative simulation** — TurnEngine runs on one logical thread
- **App rendering/UI** runs on Godot main thread; reads only `GameState.Snapshot()`
- **Network I/O** (ENet) on background thread; enqueues orders to TurnEngine via thread-safe queue
- **No locks in hot path** — TurnEngine processes queued orders during stage boundaries only

---

## 8. Dependencies (Core Only)

| Package | Version | Purpose |
|---|---|---|
| `MessagePack` | 2.x | Binary serialization (state, events, commands) |
| `System.Collections.Immutable` | 8.0 | Immutable collections for snapshots |
| `System.Text.Json` | 8.0 | JSON for map definitions, config |
| `xunit` / `Moq` | test | Unit testing (test projects only) |

**No Godot, no networking, no UI, no reflection in hot path.**

---

## 9. Configuration (Design Targets)

| Parameter | Value | Rationale |
|---|---|---|
| Max territories | 200 | Design target for performance budgets |
| Max players | 6 | First playable scope |
| Turn stages | 4 (A–D) | Hybrid turn system |
| Event queue capacity | 10,000 | Pre-allocated to avoid allocations |
| Save schema version | 1 | Increment on breaking changes |