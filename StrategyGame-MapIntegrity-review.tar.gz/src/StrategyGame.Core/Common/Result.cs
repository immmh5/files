namespace StrategyGame.Core.Common;

/// <summary>
/// A discriminated union result for operations that can succeed or fail.
/// Avoids exceptions for expected failure conditions.
/// </summary>
public readonly record struct Result<T>(T? Value, string? Error, bool IsSuccess)
{
    public static Result<T> Ok(T value) => new(value, null, true);
    public static Result<T> Fail(string error) => new(default, error, false);
    public static Result<T> Failure => Fail("Operation failed without error message.");
    public static Result<T> Empty() => new(default, null, true);
}
