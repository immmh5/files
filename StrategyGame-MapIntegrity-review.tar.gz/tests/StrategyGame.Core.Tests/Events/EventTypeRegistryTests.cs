namespace StrategyGame.Core.Tests.Events;

using System.Collections.Concurrent;
using System.Text.Json;
using StrategyGame.Core.Events;
using Xunit;

/// <summary>
/// R4.4 regression tests: EventTypeRegistry, typed payload deserialization,
/// validation, and error handling.
/// </summary>
[CollectionDefinition("RegistryTests", DisableParallelization = true)]
public class RegistryTestCollection : ICollectionFixture<RegistryTestsFixture> { }

public class RegistryTestsFixture : IDisposable
{
    public void Dispose() => EventTypeRegistry.ClearForTesting();
}

/// <summary>
/// R4.4 regression tests: EventTypeRegistry, typed payload deserialization,
/// validation, and error handling.
/// </summary>
[Collection("RegistryTests")]
public class EventTypeRegistryTests
{
    // ------------------------------------------------------------------
    // Registration
    // ------------------------------------------------------------------

    [Fact]
    public void RegisterAll_RegistersAllKnownTypes()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        var keys = EventTypeRegistry.GetRegisteredKeys();

        Assert.Contains("autumn_attrition", keys);
        Assert.Contains("continent_bonus", keys);
        Assert.Contains("harvest_festival", keys);
        Assert.Contains("border_fortification", keys);
        Assert.Contains("berserk_rage", keys);
        Assert.Contains("supply_disruption", keys);
        Assert.Contains("fortification_boost", keys);
        Assert.Equal(7, keys.Count);
    }

    [Fact]
    public void DuplicateRegistration_Throws()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();
        // Registration is now idempotent; second call should not throw
        EventTypeRegistrar.RegisterAll();
    }

    // ------------------------------------------------------------------
    // Known type resolution
    // ------------------------------------------------------------------

    [Fact]
    public void GetInfo_KnownType_ReturnsInfo()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        var info = EventTypeRegistry.GetInfo("autumn_attrition");

        Assert.Equal("autumn_attrition", info.EventTypeKey);
        Assert.Contains(1, info.SupportedVersions);
        Assert.Equal(typeof(EventPayloads.AutumnAttritionPayload), info.PayloadType);
    }

    [Fact]
    public void GetInfo_UnknownType_ThrowsWithDiagnostic()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        var ex = Assert.Throws<EventTypeRegistryException>(() => EventTypeRegistry.GetInfo("unknown_type"));
        Assert.Contains("unknown_type", ex.Message);
        Assert.Contains("not registered", ex.Message);
    }

    [Fact]
    public void IsRegistered_KnownType_ReturnsTrue()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        Assert.True(EventTypeRegistry.IsRegistered("autumn_attrition"));
        Assert.True(EventTypeRegistry.IsRegistered("berserk_rage"));
    }

    [Fact]
    public void IsRegistered_UnknownType_ReturnsFalse()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        Assert.False(EventTypeRegistry.IsRegistered("not_a_real_type"));
        Assert.False(EventTypeRegistry.IsRegistered(""));
    }

    // ------------------------------------------------------------------
    // Payload deserialization + validation (valid cases)
    // ------------------------------------------------------------------

    [Fact]
    public void DeserializeAndValidate_AutumnAttrition_ValidPayload()
    {
        var record = ScheduledEventRecord.CreateWithPayload(
            "evt_1", "autumn_attrition", 1,
            new RoundTiming(3), null,
            new() { ["regions"] = JsonSerializer.SerializeToElement(new[] { "north", "south" }) });

        var payload = EventTypeRegistry.DeserializeAndValidatePayload(record);

        Assert.IsType<EventPayloads.AutumnAttritionPayload>(payload);
        var p = (EventPayloads.AutumnAttritionPayload)payload;
        Assert.Equal(new[] { "north", "south" }, p.AffectedRegions);
        Assert.Equal(1, p.ArmiesLostPerGroup); // default
    }

    [Fact]
    public void DeserializeAndValidate_AutumnAttrition_WithCustomArmiesLost()
    {
        var record = ScheduledEventRecord.CreateWithPayload(
            "evt_1", "autumn_attrition", 1,
            new RoundTiming(3), null,
            new() {
                ["regions"] = JsonSerializer.SerializeToElement(new[] { "north" }),
                ["armiesLostPerGroup"] = JsonSerializer.SerializeToElement(2)
            });

        var payload = (EventPayloads.AutumnAttritionPayload)EventTypeRegistry.DeserializeAndValidatePayload(record);
        Assert.Equal(2, payload.ArmiesLostPerGroup);
    }

    [Fact]
    public void DeserializeAndValidate_ContinentBonus_ValidPayload()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        var record = ScheduledEventRecord.CreateWithPayload(
            "evt_2", "continent_bonus", 1,
            new RoundTiming(5), null,
            new() {
                ["continentId"] = JsonSerializer.SerializeToElement("europe"),
                ["bonusArmies"] = JsonSerializer.SerializeToElement(5),
                ["controllingPlayerIds"] = JsonSerializer.SerializeToElement(new[] { "p1", "p2" })
            });

        var payload = (EventPayloads.ContinentBonusPayload)EventTypeRegistry.DeserializeAndValidatePayload(record);
        Assert.Equal("europe", payload.ContinentId);
        Assert.Equal(5, payload.BonusArmies);
        Assert.Equal(new[] { "p1", "p2" }, payload.ControllingPlayerIds);
    }

    [Fact]
    public void DeserializeAndValidate_BerserkRage_ValidPayload()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        var record = ScheduledEventRecord.CreateWithPayload(
            "evt_3", "berserk_rage", 1,
            null, new PlayerTurnTiming("p1", 3),
            new() {
                ["attackBonus"] = JsonSerializer.SerializeToElement(3),
                ["durationPlayerTurns"] = JsonSerializer.SerializeToElement(2)
            });

        var payload = (EventPayloads.BerserkRagePayload)EventTypeRegistry.DeserializeAndValidatePayload(record);
        Assert.Equal(3, payload.AttackBonus);
        Assert.Equal(2, payload.DurationPlayerTurns);
    }

    [Fact]
    public void DeserializeAndValidate_SupplyDisruption_ValidPayload()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        var record = ScheduledEventRecord.CreateWithPayload(
            "evt_4", "supply_disruption", 1,
            null, new PlayerTurnTiming("p2", 4),
            new() {
                ["armiesLostPerTurn"] = JsonSerializer.SerializeToElement(2),
                ["durationPlayerTurns"] = JsonSerializer.SerializeToElement(3)
            });

        var payload = (EventPayloads.SupplyDisruptionPayload)EventTypeRegistry.DeserializeAndValidatePayload(record);
        Assert.Equal(2, payload.ArmiesLostPerTurn);
        Assert.Equal(3, payload.DurationPlayerTurns);
    }

    // ------------------------------------------------------------------
    // Version handling
    // ------------------------------------------------------------------

    [Fact]
    public void DeserializeAndValidate_BerserkRage_Version2_Supported()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        var record = ScheduledEventRecord.CreateWithPayload(
            "evt_5", "berserk_rage", 2,
            null, new PlayerTurnTiming("p1", 2),
            new() {
                ["attackBonus"] = JsonSerializer.SerializeToElement(1),
                ["durationPlayerTurns"] = JsonSerializer.SerializeToElement(1)
            });

        var payload = EventTypeRegistry.DeserializeAndValidatePayload(record);
        Assert.IsType<EventPayloads.BerserkRagePayload>(payload);
    }

    [Fact]
    public void DeserializeAndValidate_UnsupportedVersion_ThrowsWithDiagnostic()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        var record = ScheduledEventRecord.CreateWithPayload(
            "evt_6", "autumn_attrition", 99,
            new RoundTiming(1), null,
            new() { ["regions"] = JsonSerializer.SerializeToElement(new[] { "north" }) });

        var ex = Assert.Throws<EventTypeRegistryException>(() => EventTypeRegistry.DeserializeAndValidatePayload(record));
        Assert.Contains("99", ex.Message);
        Assert.Contains("Supported:", ex.Message);
    }

    // ------------------------------------------------------------------
    // Validation failures (semantic)
    // ------------------------------------------------------------------

    [Fact]
    public void DeserializeAndValidate_AutumnAttrition_EmptyRegions_Throws()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        var record = ScheduledEventRecord.CreateWithPayload(
            "evt_7", "autumn_attrition", 1,
            new RoundTiming(1), null,
            new() { ["regions"] = JsonSerializer.SerializeToElement(Array.Empty<string>()) });

        var ex = Assert.Throws<ScheduledEventValidationException>(() => EventTypeRegistry.DeserializeAndValidatePayload(record));
        Assert.Contains("At least one affected region", ex.Message);
    }

    [Fact]
    public void DeserializeAndValidate_ContinentBonus_ZeroBonus_Throws()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        var record = ScheduledEventRecord.CreateWithPayload(
            "evt_8", "continent_bonus", 1,
            new RoundTiming(1), null,
            new() {
                ["continentId"] = JsonSerializer.SerializeToElement("asia"),
                ["bonusArmies"] = JsonSerializer.SerializeToElement(0),
                ["controllingPlayerIds"] = JsonSerializer.SerializeToElement(new[] { "p1" })
            });

        var ex = Assert.Throws<ScheduledEventValidationException>(() => EventTypeRegistry.DeserializeAndValidatePayload(record));
        Assert.Contains("BonusArmies must be >= 1", ex.Message);
    }

    [Fact]
    public void DeserializeAndValidate_BerserkRage_ZeroAttackBonus_Throws()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        var record = ScheduledEventRecord.CreateWithPayload(
            "evt_9", "berserk_rage", 1,
            null, new PlayerTurnTiming("p1", 2),
            new() {
                ["attackBonus"] = JsonSerializer.SerializeToElement(0),
                ["durationPlayerTurns"] = JsonSerializer.SerializeToElement(1)
            });

        var ex = Assert.Throws<ScheduledEventValidationException>(() => EventTypeRegistry.DeserializeAndValidatePayload(record));
        Assert.Contains("AttackBonus must be >= 1", ex.Message);
    }

    // ------------------------------------------------------------------
    // Missing / wrong field types
    // ------------------------------------------------------------------

    [Fact]
    public void DeserializeAndValidate_MissingRequiredField_Throws()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        var record = ScheduledEventRecord.CreateWithPayload(
            "evt_10", "autumn_attrition", 1,
            new RoundTiming(1), null,
            new() { }); // missing "regions"

        var ex = Assert.Throws<ScheduledEventValidationException>(() => EventTypeRegistry.DeserializeAndValidatePayload(record));
        Assert.Contains("Missing required field: regions", ex.Message);
    }

    [Fact]
    public void DeserializeAndValidate_WrongFieldType_Throws()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        var record = ScheduledEventRecord.CreateWithPayload(
            "evt_11", "autumn_attrition", 1,
            new RoundTiming(1), null,
            new() { ["regions"] = JsonSerializer.SerializeToElement("not-an-array") });

        var ex = Assert.Throws<ScheduledEventValidationException>(() => EventTypeRegistry.DeserializeAndValidatePayload(record));
        Assert.Contains("must be an array", ex.Message);
    }

    [Fact]
    public void DeserializeAndValidate_NullPayload_TreatedAsEmpty()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        var record = ScheduledEventRecord.CreateWithPayload(
            "evt_12", "autumn_attrition", 1,
            new RoundTiming(1), null,
            new() { }); // null payload -> treated as empty

        var ex = Assert.Throws<ScheduledEventValidationException>(() => EventTypeRegistry.DeserializeAndValidatePayload(record));
        Assert.Contains("Missing required field: regions", ex.Message);
    }

    // ------------------------------------------------------------------
    // Unknown event type rejection (D-16-6)
    // ------------------------------------------------------------------

    [Fact]
    public void DeserializeAndValidate_UnknownEventType_ThrowsWithDiagnostic()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        var record = ScheduledEventRecord.CreateWithPayload(
            "evt_13", "completely_unknown_type", 1,
            new RoundTiming(1), null,
            new() { });

        var ex = Assert.Throws<EventTypeRegistryException>(() => EventTypeRegistry.DeserializeAndValidatePayload(record));
        Assert.Contains("completely_unknown_type", ex.Message);
        Assert.Contains("not registered", ex.Message);
    }

    // ------------------------------------------------------------------
    // ValidatePayload convenience method
    // ------------------------------------------------------------------

    [Fact]
    public void ValidatePayload_ValidRecord_Passes()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        var record = ScheduledEventRecord.CreateWithPayload(
            "evt_14", "harvest_festival", 1,
            new RoundTiming(2), null,
            new() {
                ["bonusIncomePercent"] = JsonSerializer.SerializeToElement(25),
                ["durationRounds"] = JsonSerializer.SerializeToElement(3)
            });

        EventTypeRegistry.ValidatePayload(record); // should not throw
    }

    [Fact]
    public void ValidatePayload_InvalidRecord_Throws()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        var record = ScheduledEventRecord.CreateWithPayload(
            "evt_15", "harvest_festival", 1,
            new RoundTiming(2), null,
            new() { ["bonusIncomePercent"] = JsonSerializer.SerializeToElement(0) });

        Assert.Throws<ScheduledEventValidationException>(() => EventTypeRegistry.ValidatePayload(record));
    }

    // ------------------------------------------------------------------
    // Unknown key rejection (A)
    // ------------------------------------------------------------------

    [Fact]
    public void DeserializeAndValidate_UnknownKey_Throws()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        var record = ScheduledEventRecord.CreateWithPayload(
            "evt_16", "autumn_attrition", 1,
            new RoundTiming(1), null,
            new() {
                ["regions"] = JsonSerializer.SerializeToElement(new[] { "north" }),
                ["unknownField"] = JsonSerializer.SerializeToElement("oops")
            });

        var ex = Assert.Throws<ScheduledEventValidationException>(() => EventTypeRegistry.DeserializeAndValidatePayload(record));
        Assert.Contains("Unknown payload key 'unknownField'", ex.Message);
    }

    // ------------------------------------------------------------------
    // Payload ownership (B) — original-dictionary-mutation isolation
    // ------------------------------------------------------------------

    [Fact]
    public void Payload_Ownership_MutateCallerDictAfterConstruction_NoEffect()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        var callerDict = new Dictionary<string, JsonElement>
        {
            ["regions"] = JsonSerializer.SerializeToElement(new[] { "north" })
        };

        var record = ScheduledEventRecord.CreateWithPayload(
            "evt_17", "autumn_attrition", 1,
            new RoundTiming(1), null,
            callerDict);

        // Mutate the caller's original dictionary
        callerDict["regions"] = JsonSerializer.SerializeToElement(new[] { "south" });
        callerDict["extra"] = JsonSerializer.SerializeToElement(99);

        // The record's payload must remain unchanged
        var regions = JsonSerializer.Deserialize<string[]>(record.Payload!["regions"]!.GetRawText()!);
        Assert.Equal(new[] { "north" }, regions);
        Assert.DoesNotContain("extra", record.Payload!.Keys);
    }

    [Fact]
    public void Payload_Ownership_DisposeJsonDocumentAfterTransfer_ElementRemainsValid()
    {
        using var doc = JsonDocument.Parse("{\"regions\":[\"north\"],\"armiesLostPerGroup\":3}");
        var root = doc.RootElement;

        var callerDict = new Dictionary<string, JsonElement>
        {
            ["regions"] = root.GetProperty("regions"),
            ["armiesLostPerGroup"] = root.GetProperty("armiesLostPerGroup")
        };

        var record = ScheduledEventRecord.CreateWithPayload(
            "evt_18", "autumn_attrition", 1,
            new RoundTiming(1), null,
            callerDict);

        // Dispose the source document — record's payload must still work
        doc.Dispose();

        var payload = EventTypeRegistry.DeserializeAndValidatePayload(record);
        Assert.IsType<EventPayloads.AutumnAttritionPayload>(payload);
        var p = (EventPayloads.AutumnAttritionPayload)payload;
        Assert.Equal(new[] { "north" }, p.AffectedRegions);
        Assert.Equal(3, p.ArmiesLostPerGroup);
    }

    [Fact]
    public void Payload_Ownership_RoundTripSerializationPreservesPayload()
    {
        var record = ScheduledEventRecord.CreateWithPayload(
            "evt_19", "autumn_attrition", 1,
            new RoundTiming(1), null,
            new() { ["regions"] = JsonSerializer.SerializeToElement(new[] { "north", "south" }) });

        var json = record.ToJson();
        var restored = ScheduledEventRecord.FromJson(json);

        Assert.True(restored.Payload!.ContainsKey("regions"));
        Assert.Equal(new[] { "north", "south" },
            JsonSerializer.Deserialize<string[]>(restored.Payload!["regions"]!.GetRawText()!));
    }

    // ------------------------------------------------------------------
    // ToJson regression tests — serialized output reflects construction-time snapshot only
    // ------------------------------------------------------------------

    [Fact]
    public void ToJson_AfterCallerDictMutation_SerializedOnlyOriginalData()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        var callerDict = new Dictionary<string, JsonElement>
        {
            ["regions"] = JsonSerializer.SerializeToElement(new[] { "north" })
        };

        var record = ScheduledEventRecord.CreateWithPayload(
            "evt_20", "autumn_attrition", 1,
            new RoundTiming(1), null,
            callerDict);

        // Mutate the caller's dictionary after construction
        callerDict["regions"] = JsonSerializer.SerializeToElement(new[] { "south" });
        callerDict["extra_field"] = JsonSerializer.SerializeToElement(999);

        // ToJson must reflect the construction-time snapshot
        var json = record.ToJson();
        Assert.Contains("\"north\"", json);
        Assert.DoesNotContain("\"south\"", json);
        Assert.DoesNotContain("extra_field", json);
        Assert.DoesNotContain("999", json);
    }

    [Fact]
    public void ToJson_AfterExtraCallerKeyInserted_SerializedOnlyCapturedKeys()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        var callerDict = new Dictionary<string, JsonElement>
        {
            ["regions"] = JsonSerializer.SerializeToElement(new[] { "north", "south" }),
            ["armiesLostPerGroup"] = JsonSerializer.SerializeToElement(2)
        };

        var record = ScheduledEventRecord.CreateWithPayload(
            "evt_21", "autumn_attrition", 1,
            new RoundTiming(1), null,
            callerDict);

        // Insert extra key into caller's dictionary after construction
        callerDict["imposter"] = JsonSerializer.SerializeToElement("bad");

        var json = record.ToJson();
        Assert.Contains("\"regions\"", json);
        Assert.DoesNotContain("imposter", json);
        Assert.DoesNotContain("bad", json);
    }

    [Fact]
    public void ToJson_AfterJsonDocumentDisposed_NoException()
    {
        using var doc = JsonDocument.Parse("{\"regions\":[\"east\"],\"armiesLostPerGroup\":5}");
        var root = doc.RootElement;

        var callerDict = new Dictionary<string, JsonElement>
        {
            ["regions"] = root.GetProperty("regions"),
            ["armiesLostPerGroup"] = root.GetProperty("armiesLostPerGroup")
        };

        var record = ScheduledEventRecord.CreateWithPayload(
            "evt_22", "autumn_attrition", 1,
            new RoundTiming(1), null,
            callerDict);

        // Dispose the source document — ToJson must still work
        doc.Dispose();

        var json = record.ToJson();
        Assert.Contains("\"east\"", json);
        Assert.Contains("5", json);
        Assert.DoesNotContain("imposter", json);
    }

    // ------------------------------------------------------------------
    // Concurrent registration safety (C)
    // ------------------------------------------------------------------

    [Fact]
    public async Task Registrar_RegisterAll_ConcurrentColdStart_AllRegistered()
    {
        // Cold-start test: reset state, then release 10 concurrent callers simultaneously
        EventTypeRegistry.ClearForTesting();
        var barrier = new Barrier(10);
        var exceptions = new ConcurrentBag<Exception>();

        var tasks = Enumerable.Range(0, 10).Select(_ => Task.Run(async () =>
        {
            barrier.SignalAndWait(); // all threads wait here until all 10 arrive
            try { EventTypeRegistrar.RegisterAll(); }
            catch (Exception ex) { exceptions.Add(ex); }
            await Task.CompletedTask;
        })).ToArray();

        await Task.WhenAll(tasks);

        Assert.Empty(exceptions);
        var keys = EventTypeRegistry.GetRegisteredKeys();
        Assert.Equal(7, keys.Count);
    }

    [Fact]
    public async Task Registry_RegisterAll_ConcurrentColdStart_AllRegistered()
    {
        // Cold-start test at the higher-level registry entry point
        EventTypeRegistry.ClearForTesting();
        var barrier = new Barrier(10);
        var exceptions = new ConcurrentBag<Exception>();

        var tasks = Enumerable.Range(0, 10).Select(_ => Task.Run(async () =>
        {
            barrier.SignalAndWait();
            try { EventTypeRegistry.RegisterAll(); }
            catch (Exception ex) { exceptions.Add(ex); }
            await Task.CompletedTask;
        })).ToArray();

        await Task.WhenAll(tasks);

        Assert.Empty(exceptions);
        var keys = EventTypeRegistry.GetRegisteredKeys();
        Assert.Equal(7, keys.Count);
    }

    [Fact]
    public void Registrar_PrepopulatedRegistry_RetryCompletesAllTypes()
    {
        // Simulate partial registration by manually registering only 3 types,
        // then clearing the registrar's completion flag (but NOT the registry).
        // A subsequent RegisterAll call should complete the remaining 4.
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAutumnAttrition();
        EventTypeRegistrar.RegisterContinentBonus();
        EventTypeRegistrar.RegisterHarvestFestival();
        EventTypeRegistrar.ClearForTesting();

        EventTypeRegistrar.RegisterAll();

        var keys = EventTypeRegistry.GetRegisteredKeys();
        Assert.Equal(7, keys.Count);
    }

    [Fact]
    public void Registrar_RegisterAll_InjectsFailure_ThenRecovers()
    {
        // Genuine failure injection test exercising the real registrar initialization algorithm.
        // 1. Cold registry and registrar.
        // 2. Use the internal test seam to inject an exception before the 4th registration.
        // 3. Call the REAL EventTypeRegistrar.RegisterAll() — the seam causes an exception mid-init.
        // 4. Verify the completion flag remains false (no misleading completed state).
        // 5. Verify partially registered entries are preserved in the registry.
        // 6. Clear the seam and retry WITHOUT clearing the registry.
        // 7. Verify all seven types are registered exactly once.

        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.TestBeforeRegistration = key =>
        {
            if (key == "border_fortification")
                throw new InvalidOperationException($"Injected failure before registration of '{key}'.");
        };

        try
        {
            var ex = Assert.Throws<InvalidOperationException>(() => EventTypeRegistrar.RegisterAll());
            Assert.Contains("border_fortification", ex.Message);

            // Completion flag must remain false — no caller waits on a completed state
            Assert.False(IsRegistrarRegistered());

            // Partially registered entries preserved: first 3 types should be in registry
            var keys = EventTypeRegistry.GetRegisteredKeys();
            Assert.Equal(3, keys.Count);
            Assert.Contains("autumn_attrition", keys);
            Assert.Contains("continent_bonus", keys);
            Assert.Contains("harvest_festival", keys);
            Assert.DoesNotContain("border_fortification", keys);
        }
        finally
        {
            EventTypeRegistrar.TestBeforeRegistration = null;
        }

        // Retry WITHOUT clearing the registry — partial entries preserved, remaining 4 registered
        EventTypeRegistrar.RegisterAll();

        var allKeys = EventTypeRegistry.GetRegisteredKeys();
        Assert.Equal(7, allKeys.Count);
        Assert.Contains("autumn_attrition", allKeys);
        Assert.Contains("continent_bonus", allKeys);
        Assert.Contains("harvest_festival", allKeys);
        Assert.Contains("border_fortification", allKeys);
        Assert.Contains("berserk_rage", allKeys);
        Assert.Contains("supply_disruption", allKeys);
        Assert.Contains("fortification_boost", allKeys);
    }

    private static bool IsRegistrarRegistered() => typeof(EventTypeRegistrar)
        .GetField("_registered", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static)
        ?.GetValue(null) is bool b && b;

    [Fact]
    public void Payload_CannotBeCastToMutableDictionary()
    {
        var record = ScheduledEventRecord.CreateWithPayload(
            "evt_23", "autumn_attrition", 1,
            new RoundTiming(1), null,
            new() { ["regions"] = JsonSerializer.SerializeToElement(new[] { "north" }) });

        // ReadOnlyDictionary — cast to concrete Dictionary must fail.
        var ex = Assert.Throws<InvalidCastException>(() =>
            ((Dictionary<string, JsonElement>)record.Payload)!);
        Assert.Contains("ReadOnlyDictionary", ex.Message);
    }

    // ------------------------------------------------------------------
    // Schema metadata defensive copies (GetInfo returns isolated copies)
    // ------------------------------------------------------------------

    [Fact]
    public void GetInfo_SupportedVersions_ReturnsDefensiveCopy()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        var info = EventTypeRegistry.GetInfo("autumn_attrition");
        var versions = info.SupportedVersions;

        // The returned IReadOnlyList<int> is a ReadOnlyCollection<int> internally.
        // Verify it cannot be mutated through the IList<int> interface.
        Assert.IsNotType<List<int>>(versions);
        var list = versions.ToList();
        list.Add(999);

        // Fetch again and confirm the registry is untouched.
        var info2 = EventTypeRegistry.GetInfo("autumn_attrition");
        Assert.DoesNotContain(999, info2.SupportedVersions);
    }

    [Fact]
    public void GetInfo_SupportedVersions_IsReadOnly()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        var info = EventTypeRegistry.GetInfo("autumn_attrition");
        var versions = info.SupportedVersions;

        // Direct mutation attempt through IList<int> must throw NotSupportedException.
        var ex = Assert.Throws<NotSupportedException>(() => ((IList<int>)versions).Add(999));
        Assert.Matches("(?i)read-only", ex.Message);

        // The registry remains unaffected.
        var info2 = EventTypeRegistry.GetInfo("autumn_attrition");
        Assert.Equal([1], info2.SupportedVersions);
    }

    [Fact]
    public void GetInfo_AllowedKeys_ReturnsDefensiveCopy()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        var info = EventTypeRegistry.GetInfo("autumn_attrition");
        // GetInfo returns a new HashSet<string>; mutating THIS object directly
        // must not affect the registry.
        ((HashSet<string>)(ISet<string>)info.AllowedKeys).Add("evil");

        var info2 = EventTypeRegistry.GetInfo("autumn_attrition");
        Assert.DoesNotContain("evil", info2.AllowedKeys);
    }

    // ------------------------------------------------------------------
    // Delegate equality: closures with identical Method but different Target
    // These tests prove that Delegate.Equals (used by the registry) rejects
    // delegates that share the same method body but capture different state,
    // distinguishing them from simple Method-name comparison.
    // ------------------------------------------------------------------

    // Factory: returns a deserializer delegate capturing the given attackBonus value.
    // Each call produces a delegate with the SAME Method (the lambda expression)
    // but a DIFFERENT Target (the closure instance holding the captured variable).
    private static Func<Dictionary<string, System.Text.Json.JsonElement>, int, object>
        MakeDeserializer(int attackBonus)
        => (payload, version) => new EventPayloads.BerserkRagePayload(attackBonus, 1);

    [Fact]
    public void Register_ConflictingDeserializer_Closure_DelegateEquals_Rejects()
    {
        // Prove: two closures over the same lambda expression have same Method,
        // different Target, and Delegate.Equals returns false.
        var first = MakeDeserializer(3);
        var second = MakeDeserializer(5);
        Assert.Equal(first.Method, second.Method);
        Assert.NotSame(first.Target, second.Target);
        Assert.NotEqual(first, second); // Delegate.Equals differs

        // Register first under a unique key.
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        // ONE shared validator instance passed to BOTH registration calls, so the
        // rejection is caused by the deserializer mismatch alone (identical everything else).
        Action<object> sharedValidator = static _ => { };

        EventTypeRegistry.Register(
            eventTypeKey: "test_berserk_first",
            supportedVersions: [1],
            deserializer: first,
            validator: sharedValidator,
            payloadType: typeof(EventPayloads.BerserkRagePayload),
            allowedKeys: new HashSet<string> { "attackBonus", "durationPlayerTurns" });

        // Register second with the SAME schema contract and the SAME validator,
        // but a DIFFERENT deserializer delegate (same Method, different Target).
        var ex = Assert.Throws<ArgumentException>(() => EventTypeRegistry.Register(
            "test_berserk_first",
            [1],
            second,
            sharedValidator,
            typeof(EventPayloads.BerserkRagePayload),
            new HashSet<string> { "attackBonus", "durationPlayerTurns" }));

        Assert.Contains("conflicting definition", ex.Message);
    }

    // Factory: returns a validator delegate capturing the given minAttackBonus value.
    private static Action<object> MakeValidator(int minAttackBonus)
        => p =>
        {
            var berserk = (EventPayloads.BerserkRagePayload)p;
            if (berserk.AttackBonus < minAttackBonus)
                throw new ScheduledEventValidationException("test_validator", $"AttackBonus too low: {berserk.AttackBonus}");
        };

    [Fact]
    public void Register_ConflictingValidator_Closure_DelegateEquals_Rejects()
    {
        // Prove: two closures over the same lambda expression have same Method,
        // different Target, and Delegate.Equals returns false.
        var first = MakeValidator(1);
        var second = MakeValidator(99);
        Assert.Equal(first.Method, second.Method);
        Assert.NotSame(first.Target, second.Target);
        Assert.NotEqual(first, second); // Delegate.Equals differs

        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        // ONE shared deserializer instance used in BOTH registration calls, so the
        // rejection is caused by the validator mismatch alone.
        var sharedDeserializer = EventTypeRegistrar.DeserializeBerserkRage;

        EventTypeRegistry.Register(
            eventTypeKey: "test_validator_first",
            supportedVersions: [1],
            deserializer: sharedDeserializer,
            validator: first,
            payloadType: typeof(EventPayloads.BerserkRagePayload),
            allowedKeys: new HashSet<string> { "attackBonus", "durationPlayerTurns" });

        var ex = Assert.Throws<ArgumentException>(() => EventTypeRegistry.Register(
            "test_validator_first",
            [1],
            sharedDeserializer,
            second,
            typeof(EventPayloads.BerserkRagePayload),
            new HashSet<string> { "attackBonus", "durationPlayerTurns" }));

        Assert.Contains("conflicting definition", ex.Message);
    }

    [Fact]
    public void Register_IdenticalKeysDifferentOrder_Accepted()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        // Register with same key, same allowed keys but different insertion order
        // Accepted as identical — same deserializer/validator delegates, same schema contract
        EventTypeRegistry.Register(
            "autumn_attrition",
            [1],
            EventTypeRegistrar.DeserializeAutumnAttrition, // SAME deserializer
            EventTypeRegistrar.ValidateAutumnAttrition,   // SAME validator
            typeof(EventPayloads.AutumnAttritionPayload),
            new HashSet<string> { "armiesLostPerGroup", "regions" }); // different order

        var keys = EventTypeRegistry.GetRegisteredKeys();
        Assert.Equal(7, keys.Count);
    }

    [Fact]
    public void Register_SameDeserializerValidator_Accepted()
    {
        EventTypeRegistry.ClearForTesting();
        EventTypeRegistrar.RegisterAll();

        // Register with exactly the same deserializer and validator as the original
        // Accepted as identical (idempotent)
        EventTypeRegistry.Register(
            "autumn_attrition",
            [1],
            EventTypeRegistrar.DeserializeAutumnAttrition,
            EventTypeRegistrar.ValidateAutumnAttrition,
            typeof(EventPayloads.AutumnAttritionPayload),
            new HashSet<string> { "regions", "armiesLostPerGroup" });

        var keys = EventTypeRegistry.GetRegisteredKeys();
        Assert.Equal(7, keys.Count);
    }
}