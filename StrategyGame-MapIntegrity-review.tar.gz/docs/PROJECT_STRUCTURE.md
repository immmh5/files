# Project Structure

```
StrategyGame/                        # Git repository root
│
├── src/
│   ├── StrategyGame.App/            # Godot application project
│   │   ├── project.godot            # Godot project file
│   │   ├── StrategyGame.App.csproj   # .NET project file
│   │   ├── Scenes/                   # Godot .tscn scene files
│   │   │   └── Main.tscn
│   │   ├── Scripts/                  # Godot C# behaviour scripts
│   │   │   ├── Main.cs
│   │   │   ├── GameController.cs
│   │   │   └── MapView.cs
│   │   ├── UI/                      # HUD, menus, dialogs
│   │   ├── Rendering/               # Custom rendering components
│   │   ├── Input/                   # Input handlers and gestures
│   │   └── Assets/                  # Project-local assets (textures, fonts)
│   │
│   └── StrategyGame.Core/            # Pure C# game domain library
│       ├── StrategyGame.Core.csproj  # net8.0 class library
│       ├── Domain/
│       │   ├── Player.cs
│       │   ├── Territory.cs
│       │   ├── Faction.cs
│       │   ├── Order.cs
│       │   ├── OrderType.cs
│       │   └── MapDefinition.cs
│       ├── GameState/
│       │   ├── GameState.cs
│       │   ├── TurnManager.cs
│       │   ├── CombatSystem.cs
│       │   ├── VictoryChecker.cs
│       │   └── GameRules.cs
│       ├── Events/
│       │   ├── GameEvent.cs
│       │   ├── IEventBus.cs
│       │   └── Events/
│       │       ├── TerritoryCapturedEvent.cs
│       │       ├── TurnStartedEvent.cs
│       │       ├── OrderSubmittedEvent.cs
│       │       └── GameOverEvent.cs
│       ├── Common/
│       │   ├── ValueObject.cs
│       │   ├── Entity.cs
│       │   ├── Result.cs
│       │   └── IdGenerator.cs
│       ├── Networking/
│       │   ├── INetworkTransport.cs
│       │   ├── INetworkDiscovery.cs
│       │   └── GamePacket.cs
│       ├── AI/
│       │   └── IAIPlayer.cs
│       └── Storage/
│           ├── ISaveSerializer.cs
│           └── IMapLoader.cs
│
├── tests/
│   ├── StrategyGame.Core.Tests/     # xUnit unit tests
│   │   ├── StrategyGame.Core.Tests.csproj
│   │   ├── Domain/
│   │   │   └── TerritoryTests.cs
│   │   └── GameState/
│   │       ├── CombatSystemTests.cs
│   │       └── VictoryCheckerTests.cs
│   │
│   └── Integration.Tests/            # Integration/smoke tests
│       ├── Integration.Tests.csproj
│       └── AppStartupTests.cs
│
├── docs/                             # Architecture and design docs
│   ├── MASTER_SPEC.md
│   ├── ARCHITECTURE.md
│   ├── PROJECT_STRUCTURE.md         # This file
│   ├── RENDERING_AND_2.5D.md
│   ├── NETWORKING_DESIGN.md
│   ├── MODULARITY_AND_RESOURCES.md
│   ├── PERFORMANCE_STRATEGY.md
│   ├── QA_AND_TESTING.md
│   ├── BUILD_AND_EXPORT.md
│   ├── MILESTONES.md
│   ├── AGENT_RULES.md
│   └── adr/                          # Architecture Decision Records
│       ├── 0001-godot-engine.md
│       ├── 0002-core-domain-separation.md
│       ├── 0003-csharp-first.md
│       ├── 0004-networking-model.md
│       └── 0005-rendering-2.5d.md
│
├── scripts/
│   ├── verify.sh                     # Linux verification entry point
│   └── verify.ps1                    # Windows verification entry point
│
├── .editorconfig                     # Code style (EditorConfig)
├── .gitignore
├── README.md
│
└── .github/
    └── workflows/
        ├── ci.yml                   # Linux CI (build + test)
        └── ci-windows.yml           # Windows CI (build + test)
```

## Naming Conventions

- C# namespaces: `StrategyGame.Core.{Subnamespace}` / `StrategyGame.App.{Subnamespace}`
- Class files: `ClassName.cs` (one class per file)
- Godot scenes: `SceneName.tscn`
- Godot scripts: `SceneName.cs` (same name as the root scene node)
- Test classes: `ClassNameTests.cs`
- ADRs: `NNNN-title-slug.md`

## What's NOT Here (Yet)

- Gameplay feature implementations (territories, factions, turns)
- AI implementations
- Networking transport implementations
- Save/load implementations
- Export templates
- Game maps and assets
