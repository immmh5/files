namespace StrategyGame.Core.Domain;

/// <summary>
/// M1.1 — A named region (continent) grouping territories, with an army bonus
/// granted to the player controlling every territory in the region.
///
/// The bonus amount is <c>[PROPOSED]</c> (D-05: "Continent/region control bonuses
/// 2–5 armies; tuned per region size") and configurable per map. This type only
/// carries the data; bonus application is implemented in the economy system (M1.2).
/// </summary>
public sealed class RegionDefinition
{
    public string Id { get; }
    public string Name { get; }
    public int ArmyBonus { get; }

    /// <param name="id">Unique region identifier within a map (e.g. "continent_a").</param>
    /// <param name="name">Display name.</param>
    /// <param name="armyBonus">Armies granted per round for full region control. Must be >= 0.</param>
    public RegionDefinition(string id, string name, int armyBonus)
    {
        Id = string.IsNullOrWhiteSpace(id)
            ? throw new ArgumentException("Region id must not be null, empty or whitespace.", nameof(id))
            : id;
        Name = string.IsNullOrWhiteSpace(name)
            ? throw new ArgumentException("Region name must not be null, empty or whitespace.", nameof(name))
            : name;
        if (armyBonus < 0)
            throw new ArgumentOutOfRangeException(nameof(armyBonus), armyBonus,
                "Region army bonus must be non-negative.");
        ArmyBonus = armyBonus;
    }
}
