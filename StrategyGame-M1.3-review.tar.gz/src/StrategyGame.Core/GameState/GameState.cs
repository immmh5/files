namespace StrategyGame.Core.GameState;

using System.Collections.ObjectModel;
using StrategyGame.Core.Domain;

/// <summary>
/// Authoritative game state. Mutable during active turn resolution; snapshotted for testing and synchronization.
///
/// Phase 0 (R-GameState) ownership rules:
/// - The input player list is defensively copied; later mutation of the caller's
///   list or its Player objects never reaches game state.
/// - <see cref="Players"/> is a read-only view of the same internal collection,
///   so <see cref="Players"/>, <see cref="GetPlayer"/> and <see cref="Snapshot"/>
///   always agree.
/// - Territory objects (including adjacency lists and M1.1 metadata) are copied
///   from the map, never shared.
/// </summary>
public sealed class GameState
{
    public string GameId { get; }
    public MapDefinition Map { get; }
    public IReadOnlyList<Player> Players { get; }
    public IReadOnlyDictionary<string, Territory> Territories { get; }
    public string CurrentTurnPlayerId { get; }
    public int CurrentTurnNumber { get; }
    public string CurrentPhase { get; }

    private readonly Dictionary<string, Territory> _territories;
    private readonly List<Player> _players;

    // M1.3 — Mutable turn state fields for active turn resolution
    /// <summary>Current active player ID (mutable during turn progression).</summary>
    internal string CurrentTurnPlayerIdInternal { get; private set; } = "";

    /// <summary>Current turn number (mutable during turn progression).</summary>
    internal int CurrentTurnNumberInternal { get; private set; } = 0;

    /// <summary>Current game phase (mutable during turn progression).</summary>
    internal string CurrentPhaseInternal { get; private set; } = "";

    public GameState(string gameId, MapDefinition map, IReadOnlyList<Player> players,
        string currentTurnPlayerId, int currentTurnNumber, string currentPhase)
    {
        GameId = gameId ?? throw new ArgumentNullException(nameof(gameId));
        Map = map ?? throw new ArgumentNullException(nameof(map));
        if (players is null) throw new ArgumentNullException(nameof(players));
        CurrentTurnPlayerId = currentTurnPlayerId;
        CurrentTurnNumber = currentTurnNumber;
        CurrentPhase = currentPhase ?? throw new ArgumentNullException(nameof(currentPhase));

        // Initialize mutable internal state from constructor parameters
        CurrentTurnPlayerIdInternal = currentTurnPlayerId;
        CurrentTurnNumberInternal = currentTurnNumber;
        CurrentPhaseInternal = currentPhase;

        _territories = new Dictionary<string, Territory>(map.Territories.Count);
        foreach (var kv in map.Territories)
        {
            var t = kv.Value;
            // Territory's constructor defensively copies adjacency and metadata, so
            // the map's territory objects are never shared with this state.
            _territories[kv.Key] = new Territory(t.Id, t.Name, t.AdjacentTerritoryIds,
                t.OwnerPlayerId, t.Armies, t.Terrain, t.RegionId, t.IsSupplySource);
        }

        // Defensive copy: the caller keeps ownership of its own list and Player
        // objects; later mutation of either must not change this state. Players is
        // exposed as a read-only view of the internal copy.
        _players = new List<Player>(players.Count);
        foreach (var p in players)
        {
            if (p is null)
                throw new ArgumentNullException(nameof(players), "Player list contains a null entry.");
            _players.Add(new Player(p.Id, p.Name, p.Faction, p.IsHuman, p.ArmiesToPlace));
        }

        Territories = new ReadOnlyDictionary<string, Territory>(_territories);
        Players = _players.AsReadOnly();
    }

    private GameState(GameState source)
    {
        GameId = source.GameId;
        Map = source.Map;
        CurrentTurnPlayerId = source.CurrentTurnPlayerId;
        CurrentTurnNumber = source.CurrentTurnNumber;
        CurrentPhase = source.CurrentPhase;

        _territories = new Dictionary<string, Territory>(source._territories.Count);
        foreach (var kv in source._territories)
        {
            var t = kv.Value;
            _territories[kv.Key] = new Territory(t.Id, t.Name, t.AdjacentTerritoryIds,
                t.OwnerPlayerId, t.Armies, t.Terrain, t.RegionId, t.IsSupplySource);
        }
        _players = new List<Player>(source._players.Count);
        foreach (var p in source._players)
        {
            var newPlayer = new Player(p.Id, p.Name, p.Faction, p.IsHuman, p.ArmiesToPlace);
            _players.Add(newPlayer);
        }

        Territories = new ReadOnlyDictionary<string, Territory>(_territories);
        Players = _players.AsReadOnly();

        // Copy mutable internal state
        CurrentTurnPlayerIdInternal = source.CurrentTurnPlayerIdInternal;
        CurrentTurnNumberInternal = source.CurrentTurnNumberInternal;
        CurrentPhaseInternal = source.CurrentPhaseInternal;
    }

    /// <summary>
    /// Creates an immutable snapshot of the current game state for AI evaluation or synchronization.
    /// </summary>
    public GameState Snapshot() => new(this);

    public Territory GetTerritory(string id) =>
        _territories.TryGetValue(id, out var t) ? t : throw new KeyNotFoundException($"Territory '{id}' not found.");

    public Player GetPlayer(string playerId) =>
        _players.FirstOrDefault(p => p.Id == playerId) ?? throw new KeyNotFoundException($"Player '{playerId}' not found.");

    public IReadOnlyList<Territory> GetAllTerritories() => [.. _territories.Values];

    public bool TerritoryBelongsTo(string territoryId, string playerId) =>
        _territories.TryGetValue(territoryId, out var t) && t.OwnerPlayerId == playerId;

    /// <summary>Advances to the next player's turn, updating turn number if all players have acted.</summary>
    public void AdvanceTurn(IEnumerable<string> allPlayerIds)
    {
        var playerList = new List<string>(allPlayerIds);
        var currentIndex = Math.Max(0, playerList.IndexOf(CurrentTurnPlayerIdInternal));
        var nextIndex = (currentIndex + 1) % playerList.Count;
        CurrentTurnPlayerIdInternal = playerList[nextIndex];

        // If we've cycled back to the first player, increment the turn number (round)
        if (nextIndex == 0 && currentIndex == playerList.Count - 1)
        {
            CurrentTurnNumberInternal++;
        }

        // Reset phase to start-of-turn
        CurrentPhaseInternal = TurnManager.PhaseReinforce;
    }

    /// <summary>Sets the current phase (called by TurnEngine when transitioning stages).</summary>
    internal void SetPhase(string phase) => CurrentPhaseInternal = phase;

    /// <summary>Deep copy for mutation during order execution.</summary>
    internal GameState DeepCopy() => new(this);
}
