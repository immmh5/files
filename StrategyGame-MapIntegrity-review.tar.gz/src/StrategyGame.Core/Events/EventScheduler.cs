namespace StrategyGame.Core.Events;

using System.Collections.Generic;
using System.Collections.ObjectModel;
using System;

/// <summary>
/// Delegate for executing scheduled events.
/// Implementors should execute the event's behavior and return whether execution was successful.
/// </summary>
/// <param name="record">The scheduled event to execute.</param>
/// <returns>True if execution succeeded; false if the handler threw an exception.</returns>
public delegate bool ScheduledEventHandler(ScheduledEventRecord record);

/// <summary>
/// Registry of event handlers keyed by event type.
/// Maps EventTypeKey to a handler that executes the event.
/// </summary>
public static class EventHandlerRegistry
{
    private static readonly Dictionary<string, ScheduledEventHandler> _handlers = new();

    /// <summary>
    /// Registers a handler for an event type.
    /// </summary>
    public static void RegisterHandler(string eventTypeKey, ScheduledEventHandler handler)
    {
        _handlers[eventTypeKey] = handler;
    }

    /// <summary>
    /// Gets the handler for an event type, if registered.
    /// </summary>
    public static bool TryGetHandler(string eventTypeKey, out ScheduledEventHandler handler)
    {
        return _handlers.TryGetValue(eventTypeKey, out handler!);
    }

    /// <summary>
    /// Executes the handler for an event, returning whether execution succeeded.
    /// </summary>
    public static bool ExecuteHandler(string eventTypeKey, ScheduledEventRecord record)
    {
        if (TryGetHandler(eventTypeKey, out var handler))
        {
            return handler(record);
        }

        return false;
    }

    /// <summary>
    /// Test seam: clears all registered handlers. For testing only.
    /// </summary>
    internal static void ClearHandlersForTesting()
    {
        _handlers.Clear();
    }
}

/// <summary>
/// Provides query parameters for the EventScheduler, including the current simulation state.
/// </summary>
public sealed record SchedulerQuery
{
    /// <summary>Current round index for evaluating RoundTiming events.</summary>
    public int CurrentRoundIndex { get; init; }

    /// <summary>Current turn counts per player for evaluating PlayerTurnTiming events.</summary>
    public IReadOnlyDictionary<string, int> CurrentPlayerTurnCounts { get; init; }
        = new ReadOnlyDictionary<string, int>(new Dictionary<string, int>());

    /// <summary>Execution stage being inspected (D-16-3).</summary>
    public ExecutionStage CurrentStage { get; init; } = ExecutionStage.EventProcessing;
}

/// <summary>
/// R4.6 — EventLifecycle.
/// Manages the lifecycle of ScheduledEventRecord instances:
/// scheduling, executing, cancelling, rescheduling, querying, and duplicate prevention.
/// Deterministic, single-threaded, no Godot dependency.
/// </summary>
public sealed class EventScheduler
{
    private readonly Dictionary<string, ScheduledEventRecord> _events = new();
    private readonly IEventBus? _eventBus;
    private readonly EventIdSource? _idSource;

    /// <summary>
    /// Static constructor ensures handler registration before any instance use.
    /// </summary>
    static EventScheduler()
    {
        EventTypeRegistrar.RegisterAll();
    }

    /// <summary>
    /// Parameterless constructor (backward-compatible, R4.6 behavior).
    /// No EventBus publication; no shared EventIdSource.
    /// </summary>
    public EventScheduler()
    {
    }

    /// <summary>
    /// Integrated constructor (R4.7). Requires both EventBus and EventIdSource together.
    /// Both arguments are required; null is rejected.
    /// The match composition owner creates one EventIdSource and passes it here.
    /// </summary>
    public EventScheduler(IEventBus eventBus, EventIdSource idSource)
    {
        _eventBus = eventBus ?? throw new ArgumentNullException(nameof(eventBus));
        _idSource = idSource ?? throw new ArgumentNullException(nameof(idSource));
    }

    /// <summary>
    /// Schedules a new event. Rejects duplicate EventId and structurally invalid records.
    /// </summary>
    public void Schedule(ScheduledEventRecord record)
    {
        ArgumentNullException.ThrowIfNull(record);

        // Validate the record (D-16-6: loud rejection of invalid data).
        record.Validate();

        if (record.Status != ScheduledEventStatus.Pending)
            throw new ArgumentException(
                $"Cannot schedule event '{record.EventId}': status must be Pending (got {record.Status}).",
                nameof(record));

        if (record.ExecutionStage is not (ExecutionStage.TurnStart or ExecutionStage.EventProcessing or ExecutionStage.TurnEnd))
            throw new ArgumentException(
                $"Cannot schedule event '{record.EventId}': ExecutionStage '{record.ExecutionStage}' is not a valid scheduled-event stage.",
                nameof(record));

        if (string.IsNullOrWhiteSpace(record.EventId))
            throw new ArgumentException("EventId is required.", nameof(record));

        if (_events.ContainsKey(record.EventId))
            throw new ArgumentException(
                $"Event with ID '{record.EventId}' is already scheduled.", nameof(record));

        _events[record.EventId] = record;
    }

    /// <summary>
    /// Cancels an event by ID. Returns true if found and cancelled.
    /// </summary>
    public bool Cancel(string eventId)
    {
        if (string.IsNullOrWhiteSpace(eventId))
            return false;

        if (!_events.TryGetValue(eventId, out var existing))
            return false;

        // Only allow cancellation of Pending events
        if (existing.Status != ScheduledEventStatus.Pending)
            return false;

        var cancelled = existing with { Status = ScheduledEventStatus.Cancelled };
        _events[eventId] = cancelled;
        return true;
    }

    /// <summary>
    /// Reschedules a round-timed event to a new due round.
    /// Preserves EventId and timing category.
    /// </summary>
    public ScheduledEventRecord? Reschedule(string eventId, RoundTiming newTiming)
    {
        if (string.IsNullOrWhiteSpace(eventId))
            return null;

        if (newTiming is null)
            throw new ArgumentNullException(nameof(newTiming));

        if (!_events.TryGetValue(eventId, out var existing))
            return null;

        if (existing.RoundTiming is null)
            throw new InvalidOperationException(
                $"Cannot reschedule event '{eventId}' with RoundTiming: event is not round-timed.");

        // Validate new timing before applying
        if (newTiming.DueRoundIndex < 0)
            throw new ArgumentException(
                $"DueRoundIndex must be >= 0 (got {newTiming.DueRoundIndex}).", nameof(newTiming));

        // Create candidate record and validate atomically
        var updated = existing with { RoundTiming = newTiming };
        updated.Validate();

        _events[eventId] = updated;
        return updated;
    }

    /// <summary>
    /// Reschedules a player-timed event to a new due turn count.
    /// Preserves EventId and timing category.
    /// </summary>
    public ScheduledEventRecord? Reschedule(string eventId, PlayerTurnTiming newTiming)
    {
        if (string.IsNullOrWhiteSpace(eventId))
            return null;

        if (newTiming is null)
            throw new ArgumentNullException(nameof(newTiming));

        if (!_events.TryGetValue(eventId, out var existing))
            return null;

        if (existing.PlayerTiming is null)
            throw new InvalidOperationException(
                $"Cannot reschedule event '{eventId}' with PlayerTurnTiming: event is not player-timed.");

        if (string.IsNullOrWhiteSpace(newTiming.PlayerId))
            throw new ArgumentException("PlayerTurnTiming requires a non-empty PlayerId.", nameof(newTiming));

        // Validate new timing before applying
        if (newTiming.DuePlayerTurnCount < 0)
            throw new ArgumentException(
                $"DuePlayerTurnCount must be >= 0 (got {newTiming.DuePlayerTurnCount}).", nameof(newTiming));

        // Create candidate record and validate atomically
        var updated = existing with { PlayerTiming = newTiming };
        updated.Validate();

        _events[eventId] = updated;
        return updated;
    }

    /// <summary>
    /// Returns all scheduled events (including cancelled/fired for auditing).
    /// Ordered deterministically:
    ///   - RoundTiming events: DueRoundIndex → Priority → SequenceNumber → EventId
    ///   - PlayerTurnTiming events: grouped by PlayerId, then DuePlayerTurnCount → Priority → SequenceNumber → EventId
    /// </summary>
    public IReadOnlyList<ScheduledEventRecord> GetScheduledEvents()
    {
        var allEvents = _events.Values.ToList();

        var roundEvents = allEvents.Where(e => e.RoundTiming is not null)
            .OrderBy(e => e, new RoundEventComparer())
            .ToList();

        var playerEvents = allEvents.Where(e => e.PlayerTiming is not null)
            .OrderBy(e => e, new PlayerEventComparer())
            .ToList();

        // Round events come before player events for deterministic grouping
        var result = new List<ScheduledEventRecord>(allEvents.Count);
        result.AddRange(roundEvents);
        result.AddRange(playerEvents);

        return result.AsReadOnly();
    }

    /// <summary>
    /// Returns events due at the given simulation state and execution stage.
    /// Only events whose clock condition is due AND whose ExecutionStage matches
    /// the queried stage are returned.
    /// </summary>
    public IReadOnlyList<ScheduledEventRecord> GetDueEvents(SchedulerQuery query)
    {
        var due = _events.Values
            .Where(e => e.Status == ScheduledEventStatus.Pending)
            .Where(e => e.ExecutionStage == query.CurrentStage)
            .Where(e => IsDue(e, query))
            .ToList();

        var roundEvents = due.Where(e => e.RoundTiming is not null)
            .OrderBy(e => e, new RoundEventComparer())
            .ToList();

        var playerEvents = due.Where(e => e.PlayerTiming is not null)
            .OrderBy(e => e, new PlayerEventComparer())
            .ToList();

        var result = new List<ScheduledEventRecord>(due.Count);
        result.AddRange(roundEvents);
        result.AddRange(playerEvents);

        return result.AsReadOnly();
    }

    /// <summary>
    /// Returns the scheduled event with the given ID, or null.
    /// </summary>
    public ScheduledEventRecord? TryGetEvent(string eventId)
    {
        if (string.IsNullOrWhiteSpace(eventId))
            return null;

        _events.TryGetValue(eventId, out var record);
        return record;
    }

    /// <summary>
    /// Returns the count of pending scheduled events.
    /// </summary>
    public int Count => _events.Values.Count(e => e.Status == ScheduledEventStatus.Pending);

    /// <summary>
    /// Returns true if an event with the given ID is scheduled.
    /// </summary>
    public bool Contains(string eventId)
    {
        if (string.IsNullOrWhiteSpace(eventId))
            return false;
        return _events.ContainsKey(eventId);
    }

    /// <summary>
    /// Directly inserts an event into the scheduler (for testing).
    /// </summary>
    internal void InsertEventForTesting(ScheduledEventRecord record)
    {
        _events[record.EventId] = record;
    }

    /// <summary>
    /// Fires all due events for the given query. Executes their handlers and updates their status.
    /// R4.7: When an EventBus and EventIdSource are injected, publishes EffectAppliedEvent on
    /// successful execution and EffectFailedEvent on failure. Lifecycle status is committed
    /// BEFORE publication; a throwing subscriber never rolls back the transition.
    /// </summary>
    /// <returns>The number of events that were successfully fired.</returns>
    public int FireDueEvents(SchedulerQuery query)
    {
        var dueEvents = GetDueEvents(query);
        int firedCount = 0;

        foreach (var evt in dueEvents)
        {
            // Check if handler exists - missing handlers leave event as Pending
            if (!EventHandlerRegistry.TryGetHandler(evt.EventTypeKey, out var handler))
            {
                continue; // Do not execute or change state for missing handlers
            }

            // Persist Executing state BEFORE invoking handler
            var executing = evt with { Status = ScheduledEventStatus.Executing };
            _events[evt.EventId] = executing;

            // Execute the handler
            bool executionSucceeded = false;
            Exception? handlerException = null;
            try
            {
                executionSucceeded = handler(executing);
            }
            catch (Exception ex)
            {
                handlerException = ex;
            }

            if (executionSucceeded)
            {
                // Handler returned true — persist Fired, then publish EffectAppliedEvent.
                var fired = executing with { Status = ScheduledEventStatus.Fired };
                _events[executing.EventId] = fired;
                firedCount++;

                // Publish AFTER status is committed.
                if (_eventBus is not null && _idSource is not null)
                {
                    var domainId = _idSource.Next();
                    var applied = new EffectAppliedEvent(
                        domainId,
                        DateTime.UtcNow,
                        executing.EventId,
                        executing.EventTypeKey,
                        TargetEntityId: null);
                    PublishDomainEvent(applied);
                }
            }
            else if (handlerException is not null)
            {
                // Handler threw — persist Failed, then publish EffectFailedEvent with HandlerException.
                var failed = executing with { Status = ScheduledEventStatus.Failed };
                _events[executing.EventId] = failed;

                if (_eventBus is not null && _idSource is not null)
                {
                    var domainId = _idSource.Next();
                    var failedEvent = new EffectFailedEvent(
                        domainId,
                        DateTime.UtcNow,
                        executing.EventId,
                        executing.EventTypeKey,
                        EffectFailureReason.HandlerException);
                    PublishDomainEvent(failedEvent);
                }
            }
            else
            {
                // Handler returned false — persist Failed, then publish EffectFailedEvent with HandlerReturnedFalse.
                var failed = executing with { Status = ScheduledEventStatus.Failed };
                _events[executing.EventId] = failed;

                if (_eventBus is not null && _idSource is not null)
                {
                    var domainId = _idSource.Next();
                    var failedEvent = new EffectFailedEvent(
                        domainId,
                        DateTime.UtcNow,
                        executing.EventId,
                        executing.EventTypeKey,
                        EffectFailureReason.HandlerReturnedFalse);
                    PublishDomainEvent(failedEvent);
                }
            }
        }

        return firedCount;
    }

    /// <summary>
    /// Publishes a domain event through the injected EventBus.
    /// The EventBus fail-fast contract is preserved: a throwing subscriber propagates
    /// its exception to the caller. The lifecycle status remains committed regardless.
    /// </summary>
    private void PublishDomainEvent(DomainEvent domainEvent)
    {
        if (_eventBus is null) return;

        try
        {
            // Explicit typed dispatch — no reflection, no dynamic.
            switch (domainEvent)
            {
                case EffectAppliedEvent applied:
                    _eventBus.Publish(applied);
                    break;
                case EffectFailedEvent failed:
                    _eventBus.Publish(failed);
                    break;
                default:
                    // R4.7 publishes only EffectAppliedEvent and EffectFailedEvent.
                    break;
            }
        }
        catch (Exception)
        {
            // EventBus publication failure must not roll back the committed lifecycle.
            // The scheduled handler is not re-executed; the status remains terminal.
            // Re-throw to preserve the fail-fast contract for the caller.
            throw;
        }
    }

    private static bool IsDue(ScheduledEventRecord record, SchedulerQuery query)
    {
        if (record.RoundTiming is { } round)
        {
            return round.DueRoundIndex <= query.CurrentRoundIndex;
        }
        if (record.PlayerTiming is { } player)
        {
            return query.CurrentPlayerTurnCounts.TryGetValue(player.PlayerId, out var current)
                && player.DuePlayerTurnCount <= current;
        }
        return false;
    }
}

/// <summary>
/// Comparer for round-timed events: DueRoundIndex → Priority → SequenceNumber → EventId
/// </summary>
internal sealed class RoundEventComparer : IComparer<ScheduledEventRecord>
{
    public int Compare(ScheduledEventRecord? x, ScheduledEventRecord? y)
    {
        if (x is null && y is null) return 0;
        if (x is null) return -1;
        if (y is null) return 1;

        var xDue = x.RoundTiming?.DueRoundIndex ?? long.MaxValue;
        var yDue = y.RoundTiming?.DueRoundIndex ?? long.MaxValue;
        var cmp = xDue.CompareTo(yDue);
        if (cmp != 0) return cmp;

        cmp = x.Priority.CompareTo(y.Priority);
        if (cmp != 0) return cmp;

        cmp = x.SequenceNumber.CompareTo(y.SequenceNumber);
        if (cmp != 0) return cmp;

        return string.CompareOrdinal(x.EventId, y.EventId);
    }
}

/// <summary>
/// Comparer for player-timed events: grouped by PlayerId, then DuePlayerTurnCount → Priority → SequenceNumber → EventId
/// </summary>
internal sealed class PlayerEventComparer : IComparer<ScheduledEventRecord>
{
    public int Compare(ScheduledEventRecord? x, ScheduledEventRecord? y)
    {
        if (x is null && y is null) return 0;
        if (x is null) return -1;
        if (y is null) return 1;

        // Different players are incomparable; group by PlayerId first
        var xPlayer = x.PlayerTiming?.PlayerId ?? "";
        var yPlayer = y.PlayerTiming?.PlayerId ?? "";
        var playerCmp = string.CompareOrdinal(xPlayer, yPlayer);
        if (playerCmp != 0) return playerCmp;

        var xDue = x.PlayerTiming?.DuePlayerTurnCount ?? long.MaxValue;
        var yDue = y.PlayerTiming?.DuePlayerTurnCount ?? long.MaxValue;
        var cmp = xDue.CompareTo(yDue);
        if (cmp != 0) return cmp;

        cmp = x.Priority.CompareTo(y.Priority);
        if (cmp != 0) return cmp;

        cmp = x.SequenceNumber.CompareTo(y.SequenceNumber);
        if (cmp != 0) return cmp;

        return string.CompareOrdinal(x.EventId, y.EventId);
    }
}