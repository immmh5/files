#!/usr/bin/env bash
# =============================================================================
# run-game.sh — One-command game launch for StrategyGame
#
# Usage:
#   ./scripts/run-game.sh            # Launch the game normally
#   GODOT_BIN=/path/to/godot ./scripts/run-game.sh
#   ./scripts/run-game.sh --verbose  # Forward arguments to Godot
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
PROJECT_GODOT="$PROJECT_ROOT/src/StrategyGame.App/project.godot"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
NC='\033[0m'

die() { echo -e "${RED}ERROR:${NC} $*" >&2; exit 1; }
info() { echo -e "${YELLOW}INFO:${NC} $*"; }
ok()  { echo -e "${GREEN}OK:${NC} $*"; }

# --- Resolve Godot executable ---
if [[ -n "${GODOT_BIN:-}" ]]; then
    GODOT="$GODOT_BIN"
elif command -v godot &>/dev/null; then
    GODOT="$(command -v godot)"
else
    GODOT="$HOME/.local/godot/4.7.2/Godot_v4.7.2-stable_mono_linux.x86_64"
fi

if [[ ! -x "$GODOT" ]]; then
    die "Godot executable not found at: $GODOT"
    die "Set GODOT_BIN=<path> or place a Godot 4.7.2 mono binary on PATH."
fi

GODOT_VERSION=$("$GODOT" --version 2>&1) || true
info "Using Godot: $GODOT"
info "Godot version: $GODOT_VERSION"

# --- Resolve .NET SDK ---
if [[ -z "${DOTNET_ROOT:-}" ]]; then
    for candidate in "$HOME/.local/dotnet" "$HOME/.dotnet" /usr/local/dotnet /usr/share/dotnet; do
        if [[ -x "$candidate/dotnet" ]]; then
            DOTNET_ROOT="$candidate"
            break
        fi
    done
fi

if [[ -z "${DOTNET_ROOT:-}" ]]; then
    die ".NET SDK not found. Install .NET SDK 8.0+ and set DOTNET_ROOT=..."
fi

if [[ ! -x "$DOTNET_ROOT/dotnet" ]]; then
    die ".NET dotnet executable not found at: $DOTNET_ROOT/dotnet"
fi

export DOTNET_ROOT
export PATH="$DOTNET_ROOT:$PATH"
DOTNET_VERSION="$("$DOTNET_ROOT/dotnet" --version)"
ok ".NET SDK: $DOTNET_VERSION (root=$DOTNET_ROOT)"

# --- Verify project ---
if [[ ! -f "$PROJECT_GODOT" ]]; then
    die "Project file not found: $PROJECT_GODOT"
fi

# --- Build before launching ---
info "Building project..."
if ! "$DOTNET_ROOT/dotnet" build "$PROJECT_ROOT/src/StrategyGame.App/StrategyGame.App.csproj" -c Release --nologo -v quiet; then
    die "Build failed. Fix compilation errors before launching."
fi
ok "Build succeeded."

# --- Launch game (non-headless, no --quit) ---
info "Launching game from: $PROJECT_ROOT/src/StrategyGame.App"
info "Press Escape in-game to quit."
exec "$GODOT" --path "$PROJECT_ROOT/src/StrategyGame.App" "$@"
