namespace StrategyGame.Core.Tests.Simulation;

using StrategyGame.Core.Domain;
using StrategyGame.Core.GameState;
using StrategyGame.Core.Simulation;
using Xunit;

/// <summary>
/// M1.2 — AttritionEngine tests: pure per-territory calculation over the
/// SupplyEngine result; min-garrison, configurability, explicit zero-army
/// neutralization reporting, determinism, validation.
/// </summary>
public class AttritionEngineTests
{
    private static GameState CreateState()
    {
        var map = new MapDefinition(
            "attrition-map", "Attrition Test Map", new[]
            {
                new Territory("a1", "One", ["a2"], TerrainType.Plains, "r1", isSupplySource: true),
                new Territory("a2", "Two", ["a1", "a3"], TerrainType.Plains, "r1", isSupplySource: false),
                new Territory("a3", "Three", ["a2"], TerrainType.Hills, "r1", isSupplySource: false),
                new Territory("cut1", "Cut1", [], TerrainType.Forest, null, isSupplySource: false),
                new Territory("cut2", "Cut2", [], TerrainType.Marsh, null, isSupplySource: false),
            },
            [new RegionDefinition("r1", "Region One", 2)]);

        var players = new List<Player>
        {
            new("p1", "One", new Faction("f1", "Red", "#FF0000"), true),
            new("p2", "Two", new Faction("f2", "Blue", "#0000FF"), false),
        };
        return new GameState("g", map, players, "p1", 1, "Reinforce");
    }

    private static void Own(GameState state, string playerId, string id, int armies)
        => state.GetTerritory(id).SetOwner(playerId, armies);

    // ---------------------------------------------------------------
    // Core behaviour
    // ---------------------------------------------------------------

    [Fact]
    public void CalculateAttrition_SuppliedTerritoriesNotInReport()
    {
        var state = CreateState();
        Own(state, "p1", "a1", 5); // source
        Own(state, "p1", "a2", 4); // connected → supplied
        Own(state, "p1", "a3", 3);

        var supply = SupplyEngine.CalculateSupply(state, "p1");
        var report = AttritionEngine.CalculateAttrition(state, "p1", supply);

        Assert.Empty(report.TerritoryResults);
        Assert.Equal(0, report.TotalArmiesLost);
        Assert.Equal(0, report.TerritoriesWouldBeNeutralized);
    }

    [Fact]
    public void CalculateAttrition_UnsuppliedTerritoryLosesConfiguredAmount()
    {
        var state = CreateState();
        Own(state, "p1", "a1", 5);        // source
        Own(state, "p1", "a2", 4);
        Own(state, "p1", "cut1", 3);      // isolated → unsupplied

        var supply = SupplyEngine.CalculateSupply(state, "p1");
        var report = AttritionEngine.CalculateAttrition(state, "p1", supply);

        var result = Assert.Single(report.TerritoryResults);
        Assert.Equal("cut1", result.TerritoryId);
        Assert.Equal(3, result.ArmiesBefore);
        Assert.Equal(1, result.ArmiesLost);
        Assert.Equal(2, result.ArmiesAfter);
        Assert.False(result.WouldBeNeutralized);
        Assert.Equal(1, report.TotalArmiesLost);
    }

    [Fact]
    public void CalculateAttrition_MinimumGarrisonIsRespected()
    {
        var state = CreateState();
        Own(state, "p1", "a1", 1);        // source with exactly min garrison
        Own(state, "p1", "cut1", 1);      // unsupplied with min garrison

        var supply = SupplyEngine.CalculateSupply(state, "p1");
        var report = AttritionEngine.CalculateAttrition(state, "p1", supply);

        var result = Assert.Single(report.TerritoryResults);
        Assert.Equal(1, result.ArmiesBefore);
        Assert.Equal(0, result.ArmiesLost);
        Assert.Equal(1, result.ArmiesAfter);
        Assert.False(result.WouldBeNeutralized);
    }

    [Fact]
    public void CalculateAttrition_UnsuppliedWithGarrisonEqualMinimum_NoLoss()
    {
        var state = CreateState();
        Own(state, "p1", "a1", 2);
        Own(state, "p1", "cut1", 3);
        Own(state, "p1", "cut2", 3);

        var supply = SupplyEngine.CalculateSupply(state, "p1");
        var report = AttritionEngine.CalculateAttrition(state, "p1", supply,
            new AttritionConfig(armiesLostPerUnsuppliedTerritory: 2, minimumGarrison: 2));

        Assert.Equal(2, report.TerritoryResults.Count);
        Assert.All(report.TerritoryResults, r =>
        {
            Assert.Equal(3, r.ArmiesBefore);
            Assert.Equal(1, r.ArmiesLost);   // min(garrison-2=1)
            Assert.Equal(2, r.ArmiesAfter);  // garrison floor 2 respected
        });
        Assert.Equal(2, report.TotalArmiesLost);
    }

    [Fact]
    public void CalculateAttrition_NeutralTerritoriesAreNeverTouched()
    {
        var state = CreateState();
        Own(state, "p1", "a1", 4);
        Own(state, "p1", "a2", 4);
        // a3 neutral.

        var supply = SupplyEngine.CalculateSupply(state, "p1");
        var report = AttritionEngine.CalculateAttrition(state, "p1", supply);

        Assert.Empty(report.TerritoryResults);
        Assert.Null(state.GetTerritory("a3").OwnerPlayerId); // still neutral
        Assert.Equal(0, state.GetTerritory("a3").Armies);
    }

    [Fact]
    public void CalculateAttrition_MultipleUnsuppliedTerritoriesCalculatedIndependently()
    {
        var state = CreateState();
        Own(state, "p1", "a1", 5);
        Own(state, "p1", "a2", 5);
        Own(state, "p1", "cut1", 4);
        Own(state, "p1", "cut2", 2);

        var supply = SupplyEngine.CalculateSupply(state, "p1");
        var report = AttritionEngine.CalculateAttrition(state, "p1", supply);

        Assert.Equal(2, report.TerritoryResults.Count);
        Assert.All(report.TerritoryResults, r => Assert.Equal(1, r.ArmiesLost));
        Assert.Equal(2, report.TotalArmiesLost);
        Assert.All(report.TerritoryResults, r => Assert.False(r.WouldBeNeutralized));
    }

    [Fact]
    public void CalculateAttrition_EnemyAndNeutralAreNotInPlayerReport()
    {
        var state = CreateState();
        Own(state, "p1", "a1", 4);
        Own(state, "p2", "cut1", 4);
        // a3 & cut2 neutral.

        var p1Supply = SupplyEngine.CalculateSupply(state, "p1");
        var p1Report = AttritionEngine.CalculateAttrition(state, "p1", p1Supply);
        Assert.Empty(p1Report.TerritoryResults);

        var p2Supply = SupplyEngine.CalculateSupply(state, "p2");
        var p2Report = AttritionEngine.CalculateAttrition(state, "p2", p2Supply);
        // p2 owns cut1 with no owned source → unsupplied.
        var r = Assert.Single(p2Report.TerritoryResults);
        Assert.Equal("cut1", r.TerritoryId);
        Assert.Equal(3, r.ArmiesAfter);
    }

    // ---------------------------------------------------------------
    // Zero-army neutralization is EXPLICIT, config-gated, and never applied to state here
    // ---------------------------------------------------------------

    [Fact]
    public void CalculateAttrition_DefaultRule_NeverReachesZero_AlwaysKeepsMinGarrison()
    {
        var state = CreateState();
        Own(state, "p1", "a1", 2);
        Own(state, "p1", "cut1", 1);

        var supply = SupplyEngine.CalculateSupply(state, "p1");
        var report = AttritionEngine.CalculateAttrition(state, "p1", supply, AttritionConfig.Default);

        var r = Assert.Single(report.TerritoryResults);
        Assert.Equal(0, r.ArmiesLost);
        Assert.Equal(1, r.ArmiesAfter);
        Assert.False(r.WouldBeNeutralized);
    }

    [Fact]
    public void CalculateAttrition_ExplicitNeutralizationConfig_ReportsWouldBeNeutralized()
    {
        var state = CreateState();
        Own(state, "p1", "a1", 2);
        Own(state, "p1", "cut1", 1);

        var config = new AttritionConfig(
            armiesLostPerUnsuppliedTerritory: 1,
            minimumGarrison: 1,
            allowZeroGarrisonNeutralization: true);
        var supply = SupplyEngine.CalculateSupply(state, "p1");
        var report = AttritionEngine.CalculateAttrition(state, "p1", supply, config);

        var r = Assert.Single(report.TerritoryResults);
        Assert.Equal(1, r.ArmiesLost);
        Assert.Equal(0, r.ArmiesAfter);
        Assert.True(r.WouldBeNeutralized);
        Assert.Equal(1, report.TerritoriesWouldBeNeutralized);

        // The calculation itself NEVER mutates state, even when neutralization is allowed:
        // the ownership transition remains a later-system (M1.3) responsibility.
        Assert.Equal("p1", state.GetTerritory("cut1").OwnerPlayerId);
        Assert.Equal(1, state.GetTerritory("cut1").Armies);
    }

    [Fact]
    public void CalculateAttrition_ZeroLossConfig_IsLegalAndLossless()
    {
        var state = CreateState();
        Own(state, "p1", "a1", 2);
        Own(state, "p1", "cut1", 3);

        var supply = SupplyEngine.CalculateSupply(state, "p1");
        var report = AttritionEngine.CalculateAttrition(state, "p1", supply,
            new AttritionConfig(armiesLostPerUnsuppliedTerritory: 0));

        var r = Assert.Single(report.TerritoryResults);
        Assert.Equal(0, r.ArmiesLost);
        Assert.Equal(3, r.ArmiesAfter);
    }

    [Fact]
    public void CalculateAttrition_CalculationIsDeterministic()
    {
        var state = CreateState();
        Own(state, "p1", "a1", 4);
        Own(state, "p1", "a2", 4);
        Own(state, "p1", "cut1", 2);
        Own(state, "p1", "cut2", 2);

        var supply1 = SupplyEngine.CalculateSupply(state, "p1");
        var report1 = AttritionEngine.CalculateAttrition(state, "p1", supply1);
        var supply2 = SupplyEngine.CalculateSupply(state, "p1");
        var report2 = AttritionEngine.CalculateAttrition(state, "p1", supply2);

        Assert.Equal(report1.PlayerId, report2.PlayerId);
        Assert.Equal(report1.TotalArmiesLost, report2.TotalArmiesLost);
        Assert.Equal(
            report1.TerritoryResults.Select(r => (r.TerritoryId, r.ArmiesBefore, r.ArmiesLost, r.ArmiesAfter, r.WouldBeNeutralized)),
            report2.TerritoryResults.Select(r => (r.TerritoryId, r.ArmiesBefore, r.ArmiesLost, r.ArmiesAfter, r.WouldBeNeutralized)));
    }

    // ---------------------------------------------------------------
    // Overflow / underflow safety
    // ---------------------------------------------------------------

    [Fact]
    public void CalculateAttrition_TotalLossOverflow_ThrowsCheckedOverflow()
    {
        // Two unsupplied territories near int.MaxValue armies; loss per territory at
        // int.MaxValue with garrison floor 0 → per-territory loss is capped at the
        // garrison (no underflow), but the checked total exceeds int.MaxValue.
        var state = CreateState();
        Own(state, "p1", "a1", int.MaxValue); // p1 owns a source: a1 (itself supplied)
        Own(state, "p1", "cut1", int.MaxValue - 1); // isolated unsupplied
        Own(state, "p1", "cut2", int.MaxValue - 1); // isolated unsupplied

        var config = new AttritionConfig(
            armiesLostPerUnsuppliedTerritory: int.MaxValue,
            minimumGarrison: 0);
        var supply = SupplyEngine.CalculateSupply(state, "p1");
        Assert.Equal(["cut1", "cut2"], supply.UnsuppliedTerritoryIds);

        var ex = Assert.Throws<OverflowException>(() =>
            AttritionEngine.CalculateAttrition(state, "p1", supply, config));
        Assert.Contains("overflow", ex.Message, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void CalculateAttrition_PerTerritoryLossIsCapped_NoUnderflowToNegative()
    {
        var state = CreateState();
        Own(state, "p1", "a1", int.MaxValue);
        Own(state, "p1", "cut1", 3); // isolated unsupplied

        var config = new AttritionConfig(
            armiesLostPerUnsuppliedTerritory: int.MaxValue,
            minimumGarrison: 0);
        var supply = SupplyEngine.CalculateSupply(state, "p1");
        var report = AttritionEngine.CalculateAttrition(state, "p1", supply, config);

        var r = Assert.Single(report.TerritoryResults);
        Assert.Equal(3, r.ArmiesLost);   // capped at garrison, never below 0
        Assert.Equal(0, r.ArmiesAfter);
        Assert.Equal(3, report.TotalArmiesLost);
    }

    [Fact]
    public void CalculateAttrition_NegativeArmiesInState_IsRejected()
    {
        // Governance guard: GameState construction copies armies without validating
        // negativity (a pre-existing Territory hole recorded in repair docs), so the
        // engine must detect corrupt input loudly instead of computing garbage.
        var map = new MapDefinition(
            "corrupt", "Corrupt", new[]
            {
                new Territory("cutX", "CutX", [], TerrainType.Forest, null, isSupplySource: false),
            },
            []);
        var players = new List<Player>
        {
            new("p1", "One", new Faction("f1", "Red", "#FF0000"), true),
        };
        var state = new GameState("g", map, players, "p1", 1, "Reinforce");
        state.GetTerritory("cutX").SetOwner("p1", -5); // corrupt (no validation in SetOwner yet)

        var supply = SupplyEngine.CalculateSupply(state, "p1");

        var ex = Assert.Throws<InvalidOperationException>(() =>
            AttritionEngine.CalculateAttrition(state, "p1", supply));
        Assert.Contains("negative army count", ex.Message, StringComparison.OrdinalIgnoreCase);
    }

    // ---------------------------------------------------------------
    // Validation
    // ---------------------------------------------------------------

    [Fact]
    public void CalculateAttrition_SupplyResultForDifferentPlayer_IsRejected()
    {
        var state = CreateState();
        Own(state, "p1", "a1", 3);

        var p1Supply = SupplyEngine.CalculateSupply(state, "p1");
        var ex = Assert.Throws<ArgumentException>(
            () => AttritionEngine.CalculateAttrition(state, "p2", p1Supply));
        Assert.Contains("supply result belongs to player 'p1'", ex.Message, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void CalculateAttrition_MissingSupplyResult_Throws()
    {
        var state = CreateState();
        Own(state, "p1", "a1", 3);

        Assert.Throws<ArgumentNullException>(() =>
            AttritionEngine.CalculateAttrition(state, "p1", null!));
    }

    [Fact]
    public void CalculateAttrition_UnknownPlayer_ThrowsKeyNotFound()
    {
        var state = CreateState();
        Own(state, "p1", "a1", 3);
        var supply = SupplyEngine.CalculateSupply(state, "p1");

        Assert.Throws<KeyNotFoundException>(() =>
            AttritionEngine.CalculateAttrition(state, "ghost", supply));
    }

    [Theory]
    [InlineData(-1)]
    [InlineData(-3)]
    public void AttritionConfig_NegativeLoss_ThrowsArgumentOutOfRange(int loss)
    {
        Assert.Throws<ArgumentOutOfRangeException>(() =>
            new AttritionConfig(armiesLostPerUnsuppliedTerritory: loss));
    }

    [Fact]
    public void AttritionConfig_NegativeMinimumGarrison_ThrowsArgumentOutOfRange()
    {
        Assert.Throws<ArgumentOutOfRangeException>(() =>
            new AttritionConfig(1, minimumGarrison: -1));
    }

    // ---------------------------------------------------------------
    // REVIEW v2 REGRESSIONS: stale / inconsistent supply results are
    // rejected — attrition is NEVER silently skipped for a territory that
    // became (un)sulpplied after the supply result was produced.
    // ---------------------------------------------------------------

    [Fact]
    public void CalculateAttrition_EnemyTerritoryBecomesPlayerOwnedAfterCalculation_IsRejectedAsStale()
    {
        var state = CreateState();
        Own(state, "p1", "a1", 5);
        Own(state, "p1", "a2", 4);
        var supply = SupplyEngine.CalculateSupply(state, "p1"); // fresh at this moment

        // After the supply result was produced, p1 captures the isolated cut1
        // through some other mechanic — it is now owned AND unsupplied. A stale
        // result would silently skip its attrition; the engine must reject.
        state.GetTerritory("cut1").SetOwner("p1", 2);

        var ex = Assert.Throws<ArgumentException>(() =>
            AttritionEngine.CalculateAttrition(state, "p1", supply));
        Assert.Contains("stale", ex.Message, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void CalculateAttrition_ConnectingTerritoryCapturedByEnemyAfterCalculation_IsRejectedAsStale()
    {
        var state = CreateState();
        Own(state, "p1", "a1", 5);  // source
        Own(state, "p1", "a2", 4);  // connector
        Own(state, "p1", "a3", 3);
        Own(state, "p1", "cut1", 2); // isolated → unsupplied already
        var supply = SupplyEngine.CalculateSupply(state, "p1");
        Assert.Equal(["cut1"], supply.UnsuppliedTerritoryIds);

        // The connector a2 is captured; a3 becomes a disconnected pocket that
        // must now suffer attrition. The stale result omits it → reject.
        state.GetTerritory("a2").SetOwner("p2", 4);

        var ex = Assert.Throws<ArgumentException>(() =>
            AttritionEngine.CalculateAttrition(state, "p1", supply));
        Assert.Contains("stale", ex.Message, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void CalculateAttrition_FormerlyUnsuppliedTerritoryCapturedByEnemyAfterCalculation_IsRejectedAsStale()
    {
        var state = CreateState();
        Own(state, "p1", "a1", 5);
        Own(state, "p1", "a2", 4);
        Own(state, "p1", "cut1", 2);
        var supply = SupplyEngine.CalculateSupply(state, "p1");
        Assert.Equal(["cut1"], supply.UnsuppliedTerritoryIds);

        // The unsupplied territory is lost to the enemy after calculation —
        // the stale result still claims p1 owns 3 territories → reject.
        state.GetTerritory("cut1").SetOwner("p2", 9);

        var ex = Assert.Throws<ArgumentException>(() =>
            AttritionEngine.CalculateAttrition(state, "p1", supply));
        Assert.Contains("stale", ex.Message, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void CalculateAttrition_ForgedResultWithDuplicateIds_IsRejectedStructurally()
    {
        var state = CreateState();
        Own(state, "p1", "a1", 5);
        Own(state, "p1", "a2", 4);
        Own(state, "p1", "cut1", 2);
        var fresh = SupplyEngine.CalculateSupply(state, "p1");

        // Forged: duplicate id in the supplied list (content still current).
        var forged = fresh with
        {
            SuppliedTerritoryIds = [.. fresh.SuppliedTerritoryIds, fresh.SuppliedTerritoryIds[0]],
        };

        var ex = Assert.Throws<ArgumentException>(() =>
            AttritionEngine.CalculateAttrition(state, "p1", forged));
        Assert.Contains("duplicate", ex.Message, StringComparison.OrdinalIgnoreCase);

        // Forged: duplicate id in the source list too.
        var forgedSources = fresh with
        {
            SourceTerritoryIds = [.. fresh.SourceTerritoryIds, fresh.SourceTerritoryIds[0]],
        };
        Assert.Throws<ArgumentException>(() =>
            AttritionEngine.CalculateAttrition(state, "p1", forgedSources));
    }

    [Fact]
    public void CalculateAttrition_ForgedResultWithIncompleteCoverage_IsRejectedAsStale()
    {
        var state = CreateState();
        Own(state, "p1", "a1", 5);
        Own(state, "p1", "a2", 4);
        Own(state, "p1", "cut1", 2);
        Own(state, "p1", "cut2", 2);
        var fresh = SupplyEngine.CalculateSupply(state, "p1");
        Assert.Equal(["cut1", "cut2"], fresh.UnsuppliedTerritoryIds);

        // Forged: one unsupplied territory removed from the claim — attrition
        // would silently skip cut2 → reject via set comparison.
        var incomplete = fresh with
        {
            UnsuppliedTerritoryIds = [fresh.UnsuppliedTerritoryIds[0]],
        };

        var ex = Assert.Throws<ArgumentException>(() =>
            AttritionEngine.CalculateAttrition(state, "p1", incomplete));
        Assert.Contains("stale", ex.Message, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void CalculateAttrition_ForgedResultOverlappingSets_IsRejected()
    {
        var state = CreateState();
        Own(state, "p1", "a1", 5);
        Own(state, "p1", "a2", 4);
        Own(state, "p1", "cut1", 2);
        var fresh = SupplyEngine.CalculateSupply(state, "p1");

        var overlapping = fresh with
        {
            UnsuppliedTerritoryIds = [.. fresh.UnsuppliedTerritoryIds, fresh.SuppliedTerritoryIds[0]],
        };

        var ex = Assert.Throws<ArgumentException>(() =>
            AttritionEngine.CalculateAttrition(state, "p1", overlapping));
        Assert.Contains("BOTH supplied and unsupplied", ex.Message, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void CalculateAttrition_ForgedResultWithUnknownTerritoryId_IsRejected()
    {
        var state = CreateState();
        Own(state, "p1", "a1", 5);
        var fresh = SupplyEngine.CalculateSupply(state, "p1");

        var unknown = fresh with
        {
            SuppliedTerritoryIds = [.. fresh.SuppliedTerritoryIds, "ghost-territory"],
        };

        var ex = Assert.Throws<ArgumentException>(() =>
            AttritionEngine.CalculateAttrition(state, "p1", unknown));
        Assert.Contains("unknown territory", ex.Message, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void CalculateAttrition_CurrentValidSupplyResult_StillProducesExpectedCalculation()
    {
        var state = CreateState();
        Own(state, "p1", "a1", 5);   // source; supplied
        Own(state, "p1", "a2", 4);   // supplied
        Own(state, "p1", "cut1", 3); // unsupplied

        var supply = SupplyEngine.CalculateSupply(state, "p1");
        var report = AttritionEngine.CalculateAttrition(state, "p1", supply); // pass the FRESH result
        var recalculated = SupplyEngine.CalculateSupply(state, "p1");
        _ = AttritionEngine.CalculateAttrition(state, "p1", recalculated);

        var result = Assert.Single(report.TerritoryResults);
        Assert.Equal("cut1", result.TerritoryId);
        Assert.Equal(3, result.ArmiesBefore);
        Assert.Equal(1, result.ArmiesLost);
        Assert.Equal(2, result.ArmiesAfter);
        Assert.Equal(1, report.TotalArmiesLost);
    }

    [Fact]
    public void CalculateAttrition_SuppliedTerritoryWithNegativeArmies_IsRejected()
    {
        // Corruption in a SUPPLIED territory (not just unsupplied ones) must be
        // rejected too: the guard scans ALL player-owned territories.
        var state = CreateState();
        state.GetTerritory("a1").SetOwner("p1", -3); // source; SUPPLIED; corrupt
        Own(state, "p1", "a2", 4);
        Own(state, "p1", "cut1", 2);

        var supply = SupplyEngine.CalculateSupply(state, "p1"); // supply itself is army-agnostic
        Assert.Equal(["cut1"], supply.UnsuppliedTerritoryIds);   // a1/a2 supplied

        var ex = Assert.Throws<InvalidOperationException>(() =>
            AttritionEngine.CalculateAttrition(state, "p1", supply));
        Assert.Contains("negative army count", ex.Message, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("a1", ex.Message, StringComparison.Ordinal);
    }

    // ---------------------------------------------------------------
    // REVIEW v2 REGRESSIONS: returned collections are genuinely read-only.
    // ---------------------------------------------------------------

    [Fact]
    public void AttritionReport_TerritoryResults_AreDefensivelyReadOnly()
    {
        var state = CreateState();
        Own(state, "p1", "a1", 5);
        Own(state, "p1", "cut1", 3);
        var supply = SupplyEngine.CalculateSupply(state, "p1");
        var report = AttritionEngine.CalculateAttrition(state, "p1", supply);

        // Cannot cast back to a mutable List<T>.
        Assert.Throws<InvalidCastException>(
            () => (List<AttritionEngine.TerritoryAttritionResult>)report.TerritoryResults);

        // The read-only wrapper also blocks IList-level mutation attempts.
        var asIList = (System.Collections.IList)report.TerritoryResults;
        Assert.Throws<NotSupportedException>(() =>
            asIList.Add(new AttritionEngine.TerritoryAttritionResult("x", 1, 0, 1, false)));
        Assert.Throws<NotSupportedException>(() =>
            asIList.Clear());
        Assert.Single(report.TerritoryResults);
    }
}
