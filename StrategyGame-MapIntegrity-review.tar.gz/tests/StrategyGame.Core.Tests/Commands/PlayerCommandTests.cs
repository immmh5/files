namespace StrategyGame.Core.Tests.Commands;

using System.Text.Json;
using System.Text.Json.Serialization;
using StrategyGame.Core.Commands;
using StrategyGame.Core.Events;
using Xunit;

public class PlayerCommandTests
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = false,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        Converters = { new JsonStringEnumConverter() }
    };

    [Fact]
    public void ReinforceCommand_Creation_AllFieldsSet()
    {
        var cmd = new ReinforceCommand("cmd-1", "p1", 10, "territory_1", 5);

        Assert.Equal("cmd-1", cmd.CommandId);
        Assert.Equal("p1", cmd.PlayerId);
        Assert.Equal(10, cmd.IssuedAtTurnSequence);
        Assert.Equal("territory_1", cmd.TerritoryId);
        Assert.Equal(5, cmd.Armies);
        Assert.Equal(1, cmd.SchemaVersion);
    }

    [Fact]
    public void AttackCommand_Creation_AllFieldsSet()
    {
        var cmd = new AttackCommand("cmd-2", "p1", 10, "t1", "t2", 3);

        Assert.Equal("cmd-2", cmd.CommandId);
        Assert.Equal("t1", cmd.FromTerritoryId);
        Assert.Equal("t2", cmd.ToTerritoryId);
        Assert.Equal(3, cmd.CommitArmies);
    }

    [Fact]
    public void FortifyCommand_Creation_AllFieldsSet()
    {
        var cmd = new FortifyCommand("cmd-3", "p1", 10, "t1", "t2", 2);

        Assert.Equal("t1", cmd.FromTerritoryId);
        Assert.Equal("t2", cmd.ToTerritoryId);
        Assert.Equal(2, cmd.Armies);
    }

    [Fact]
    public void EndTurnCommand_Creation_AllFieldsSet()
    {
        var cmd = new EndTurnCommand("cmd-4", "p1", 10);

        Assert.Equal("cmd-4", cmd.CommandId);
        Assert.Equal("p1", cmd.PlayerId);
        Assert.Equal(10, cmd.IssuedAtTurnSequence);
    }

    [Fact]
    public void ReinforceCommand_JsonRoundTrip_PreservesAllFields()
    {
        var original = new ReinforceCommand("cmd-1", "p1", 10, "t1", 5);

        var json = JsonSerializer.Serialize(original, JsonOptions);

        var deserialized = JsonSerializer.Deserialize<ReinforceCommand>(json, JsonOptions);

        Assert.NotNull(deserialized);
        Assert.Equal(original.CommandId, deserialized.CommandId);
        Assert.Equal(original.PlayerId, deserialized.PlayerId);
        Assert.Equal(original.IssuedAtTurnSequence, deserialized.IssuedAtTurnSequence);
        Assert.Equal(original.TerritoryId, deserialized.TerritoryId);
        Assert.Equal(original.Armies, deserialized.Armies);
        Assert.Equal(original.SchemaVersion, deserialized.SchemaVersion);
    }

    [Fact]
    public void AttackCommand_JsonRoundTrip_PreservesAllFields()
    {
        var original = new AttackCommand("cmd-2", "p1", 10, "t1", "t2", 3);

        var json = JsonSerializer.Serialize(original, JsonOptions);

        var deserialized = JsonSerializer.Deserialize<AttackCommand>(json, JsonOptions);

        Assert.NotNull(deserialized);
        Assert.Equal(original.CommandId, deserialized.CommandId);
        Assert.Equal(original.FromTerritoryId, deserialized.FromTerritoryId);
        Assert.Equal(original.ToTerritoryId, deserialized.ToTerritoryId);
        Assert.Equal(original.CommitArmies, deserialized.CommitArmies);
    }

    [Fact]
    public void PolymorphicSerialization_IncludesTypeDiscriminator()
    {
        // Test polymorphic serialization through base type
        PlayerCommand cmd = new ReinforceCommand("cmd-1", "p1", 10, "t1", 5);

        var json = JsonSerializer.Serialize(cmd, JsonOptions);

        Assert.Contains("\"$type\":\"reinforce\"", json);
    }

    [Fact]
    public void CommandValidationResult_Creation_ValidAndInvalid()
    {
        var valid = new CommandValidationResult(true, null, null);
        Assert.True(valid.IsValid);
        Assert.Null(valid.ErrorCode);
        Assert.Null(valid.ErrorMessage);

        var invalid = new CommandValidationResult(false, "INVALID_TERRITORY", "Territory not owned by player");
        Assert.False(invalid.IsValid);
        Assert.Equal("INVALID_TERRITORY", invalid.ErrorCode);
        Assert.Equal("Territory not owned by player", invalid.ErrorMessage);
    }

    [Fact]
    public void CommandExecutionResult_Creation_SuccessAndFailure()
    {
        var success = new CommandExecutionResult(true, null, null, Array.Empty<DomainEvent>());
        Assert.True(success.Success);
        Assert.Null(success.ErrorCode);

        var failure = new CommandExecutionResult(false, "INSUFFICIENT_ARMIES", "Not enough armies", Array.Empty<DomainEvent>());
        Assert.False(failure.Success);
        Assert.Equal("INSUFFICIENT_ARMIES", failure.ErrorCode);
        Assert.Equal("Not enough armies", failure.ErrorMessage);
    }
}