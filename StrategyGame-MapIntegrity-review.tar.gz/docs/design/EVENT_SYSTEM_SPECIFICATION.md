# EVENT_SYSTEM_SPECIFICATION.md

**Status:** USER-APPROVED SPECIFICATION — R4.2.2. Seven event-system decisions (DR-R4-1…7) were explicitly approved by the project owner on 2026-11-04. The category rules and semantics here are USER-APPROVED; implementation (R4.3) awaits separate authorization.
**Technical companion:** `docs/architecture/EVENT_ARCHITECTURE.md` (records, ordering, scheduler, save/MP design). This document defines the four categories' *rules and semantics*. Approved clock/effect/disconnect/victory timing/load/format decisions are recorded in `docs/design/EVENT_SYSTEM_DECISIONS.md` (DR-R4-1…7, all USER-APPROVED).

---

## 1. Category A — Player Commands (intent)

**Definition.** A request by a player (human or AI controller) for the game to do something. Not yet true; may be refused.

| Property | Specification | Status |
|---|---|---|
| Examples (candidates) | MoveUnits, AttackTerritory, EndTurn, PlayCard | PROPOSED — `PlayCard` presumes card system which is Category-2 expansion (FIRST_PLAYABLE_VERSION.md); excluded from first playable command set |
| First-playable command set | Reinforce / Attack / Fortify (+ EndTurn control signal), per CORE_GAME_LOOP & COMBAT_AND_ARMY_RULES | Inherited `[PROPOSED]` gameplay rules |
| Validation | Structural (well-formed, correct phase, actor identity) then rule-level (ownership, adjacency, army counts, one-action-per-territory `[PROPOSED]` D-03) | PROPOSED pipeline |
| Authorization | Host-authoritative: only host execution mutates state (D-11 `[CONFIRMED]`) | CONFIRMED inheritance |
| Failure handling | Rejected command returns typed `Result` with reason code; never silently dropped | PROPOSED |
| Persistence | Append-only command log (event-sourced saves, D-13 `[PROPOSED]`) | PROPOSED inheritance |
| Determinism role | Commands are THE replay input; same seed + same ordered commands ⇒ same outcome | Design invariant |

**Canonical example shapes (data candidates, not approved rules):**
```
Reinforce(playerId, territoryId, count)
Attack(playerId, fromId, toId, commitCount)
Fortify(playerId, fromId, toId, count)
EndTurn(playerId)
```

## 2. Category B — Domain Events (facts)

**Definition.** Immutable statements that something HAS happened as a result of authoritative execution. Never causative; never re-run.

| Property | Specification | Status |
|---|---|---|
| Examples | TerritoryCaptured, PlayerEliminated, BattleResolved, ResourceChanged | PROPOSED set; existing code has TerritoryCapturedEvent, OrderSubmittedEvent, TurnStartedEvent, GameOverEvent |
| Emission source | Simulation/core execution paths ONLY. UI/AI controllers emit commands, not facts | PROPOSED invariant |
| Ordering | Total order induced by execution sequence within stage processing | PROPOSED |
| Consumers | EventBus handlers: logging, analytics hooks, presentation derivation, MP broadcast | PROPOSED |
| Persistence | Derived-reconstructible from command log; full event journal optional/bounded | PROPOSED |
| Identity | Match-global monotonic id (single counter replacing per-type static counters — see ARCH EA finding §1) | PROPOSED |

## 3. Category C — Scheduled Gameplay Events (future authoritative changes)

**Definition.** Registered data describing a change to authoritative state at a future logical time, possibly recurring or expiring.

| Property | Specification | Status |
|---|---|---|
| Examples (generic, no invented effects) | Temporary effect expiration; delayed strategic action; scheduled scenario event; periodic abstract effect | Categories mandated by brief; **no concrete gameplay effect is designed or approved here** |
| Storage form | Serializable record only — delegates/closures/lambdas forbidden in persistent payloads | PROPOSED (fixes doc-only delegate design in TURN_ENGINE_ARCHITECTURE.md §4) |
| Firing condition | Logical clock reaches due value AND matching phase occurs | PROPOSED; clock granularity OPEN (Q-R4-1) |
| Duration semantics | Candidate: decrement once per turn during Stage C, independent of active player (inherits TURN_AND_EVENT_SYSTEM.md §4 `[USER-APPROVED PROVISIONAL]` structure but duration unit itself is unapproved) | PROVISIONAL-inherit / details OPEN (Q-R4-2) |
| Expiration | Terminal transition; emits EffectExpired domain fact; cleanup handler runs via registry | PROPOSED |
| Cancellation | Explicit only; no implicit cancellation (inherits TURN_AND_EVENT_SYSTEM.md §3) | PROVISIONAL inheritance |
| Rescheduling | Cancel + re-issue preserving lineage id | PROPOSED |
| Duplicate prevention | Unique event id per match; scheduler rejects re-insert | PROPOSED |
| Save/restore | Queue saved at stage boundaries; watermark prevents re-execution | PROPOSED |

## 4. Category D — Presentation Events (non-authoritative reaction)

**Definition.** App-layer instructions/piggybacks for animation, sound, highlight, notification. Derived from domain facts.

| Property | Specification | Status |
|---|---|---|
| Examples | ShowAnimation, HighlightTerritory, PlaySound, DisplayNotification | PROPOSED |
| Authority | **NONE.** May lag, skip, or be suppressed without changing simulation (inherits TURN_AND_EVENT_SYSTEM.md §5 `[USER-APPROVED PROVISIONAL]`) | CONFIRMED-grade rule (project brief §5) |
| Completion coupling | Animation completion must NEVER gate rule resolution. If UX needs "wait for battle animation", the flow waits in the app layer while state is already final | PROPOSED enforcement pattern |
| Frame-rate independence | Presentation timing uses render/animation clocks; simulation ignores them entirely | CONFIRMED inheritance |
| Networking | Not sent as state. Optional cosmetic sync messages later | PROPOSED |
| Persistence | Never saved | PROPOSED |

## 5. Integration With Hybrid A–D Stages

Provisional structure (unchanged): A Turn Start → B Player Actions → C Persistent Event Processing → D Turn End. `[USER-APPROVED PROVISIONAL]`.

Architecture mapping lives in ARCHITECTURE.md §10. The remaining GAMEPLAY questions are below — deliberately NOT decided.

## 6. Open Questions Requiring Owner Approval

| ID | Question | Alternatives & tradeoffs | Recommendation |
|---|---|---|---|
| **Q-R4-1** | What advances the authoritative clock? | (a) Per-player turn increments (hybrid-consistent; effects "tick" every player turn — fast attrition). (b) Per-round increment (classic Risk feel; durations mean rounds). (c) Dedicated tick counter incremented at chosen boundaries (max flexibility, more complexity). Existing docs conflict: TURN_AND_EVENT_SYSTEM says "once per turn"; TURN_ENGINE pseudo-code uses absolute turn numbers; D-07 domination says "round start". | (a) for consistency with approved hybrid wording; rename D-07 "round start" → clarify intended boundary. |
| **Q-R4-2** | Do multi-turn effects advance during OTHER players' turns? | (a) Yes, each player turn decrements (current provisional text implies this). (b) Only at round boundaries. Changes balance materially. | Keep (a) as provisional default; requires user confirmation. |
| **Q-R4-3** | Can scheduled events execute during Stage B (player actions)? | (a) Phase-boundary only — predictable, save-safe. (b) Immediate on trigger mid-actions — livelier but complicates action atomicity and validation windows. | (a). |
| **Q-R4-4** | Pause behavior in multiplayer disconnects | (a) Host pauses global clock for all. (b) Clock continues; disconnected player's effects still tick. (c) Grace window then auto-resume. | Needs product decision; suggest (c) later, (a) for LAN MVP. |
| **Q-R4-5** | Victory evaluation timing (carried over from R2.1) | Interacts with clock choice Q-R4-1 ("at round start" vs Stage D). | Resolve together with Q-R4-1. |
| **Q-R4-6** | Unknown event type at load: hard-fail vs quarantine | Hard-fail protects integrity; quarantine allows degraded play. | Hard-fail default. |
| **Q-R4-7** | Payload serialization format (MessagePack vs JSON) | Performance vs debuggability. Deferred until persistence milestone. | Defer consciously. |

## 7. Non-Goals Of This Specification

- No concrete gameplay effects, durations, or abilities defined (would be inventing rules).
- No scheduler/TurnEngine implementation.
- No networking code.
- No changes to VictoryChecker, IdGenerator, or any entity model.
