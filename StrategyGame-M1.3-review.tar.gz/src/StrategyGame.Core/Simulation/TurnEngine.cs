namespace StrategyGame.Core.Simulation;

using System.Collections.Generic;
using StrategyGame.Core.Domain;
using StrategyGame.Core.GameState;
using StrategyGame.Core.Events;
using StrategyGame.Core.Actions;

/// <summary>
/// M1.3 — Result of executing a turn stage.
/// </summary>
public sealed record StageResult(
    bool Success,
    TurnStage CompletedStage,
    string? ErrorMessage = null,
    object? Payload = null);

/// <summary>
/// M1.3 — Result of the full turn cycle.
/// </summary>
public sealed record TurnCycleResult(
    bool Success,
    TurnStage FinalStage,
    string? ErrorMessage = null,
    object? Payload = null);

    /// <summary>
    /// M1.3 — Central orchestration component for the hybrid A/B/C/D turn cycle.
    /// 
    /// Stage A (TurnStart): EconomyEngine, SupplyEngine, AttritionEngine
    /// Stage B (PlayerActions): ActionExecutor for player commands
    /// Stage C (EventProcessing): EventScheduler fires due events at ExecutionStage.EventProcessing
    /// Stage D (TurnEnd): VictoryChecker, advance to next player
    /// </summary>
    public sealed class TurnEngine
    {
        private readonly GameState _state;
        private readonly EventScheduler _eventScheduler;
        private readonly EventIdSource _eventIdSource;
        private readonly IEventBus? _eventBus;
        private TurnStage _currentStage;
        private bool _stageAExecutedThisTurn;
        private bool _stageCExecutedThisTurn;
        private bool _stageDExecutedThisTurn;

        // Test seams: exposed internally for unit testing
        internal TurnStage CurrentStageInternal { get => _currentStage; set => _currentStage = value; }
        internal bool StageAExecuted { get => _stageAExecutedThisTurn; set => _stageAExecutedThisTurn = value; }
        internal bool StageCExecuted { get => _stageCExecutedThisTurn; set => _stageCExecutedThisTurn = value; }
        internal bool StageDExecuted { get => _stageDExecutedThisTurn; set => _stageDExecutedThisTurn = value; }

        /// <summary>
        /// Creates a TurnEngine for the given game state.
        /// </summary>
        /// <param name="state">The authoritative game state.</param>
        /// <param name="eventScheduler">Event scheduler for Stage C processing.</param>
        /// <param name="eventIdSource">Match-scoped event ID source for domain events.</param>
        /// <param name="eventBus">Optional event bus for domain event publication.</param>
        public TurnEngine(GameState state, EventScheduler eventScheduler, EventIdSource eventIdSource, IEventBus? eventBus = null)
        {
            _state = state ?? throw new ArgumentNullException(nameof(state));
            _eventScheduler = eventScheduler ?? throw new ArgumentNullException(nameof(eventScheduler));
            _eventIdSource = eventIdSource ?? throw new ArgumentNullException(nameof(eventIdSource));
            _eventBus = eventBus;
            _currentStage = TurnManager.ToTurnStage(state.CurrentPhase);
            _stageAExecutedThisTurn = false;
            _stageCExecutedThisTurn = false;
            _stageDExecutedThisTurn = false;
        }

        /// <summary>
        /// Current turn stage.
        /// </summary>
        public TurnStage CurrentStage => _currentStage;

        /// <summary>
        /// Whether the game is over.
        /// </summary>
        public bool IsGameOver => _state.CurrentPhaseInternal == TurnManager.PhaseGameOver || _currentStage == TurnStage.GameOver;

        /// <summary>
        /// Executes Stage A (TurnStart) for the active player.
        /// Calculates reinforcement via EconomyEngine, applies to Player.ArmiesToPlace.
        /// Calculates fresh supply via SupplyEngine, attrition via AttritionEngine.
        /// Applies army changes (attrition losses and neutralizations).
        /// </summary>
        public StageResult ExecuteTurnStart()
        {
            if (IsGameOver)
                return new StageResult(false, _currentStage, "Game has ended; no further turns.");

            if (_stageAExecutedThisTurn)
                return new StageResult(false, _currentStage, "TurnStart already executed this turn.");

            if (_currentStage != TurnStage.TurnStart)
                return new StageResult(false, _currentStage, $"Cannot execute TurnStart from stage {_currentStage}.");

            var activePlayerId = _state.CurrentTurnPlayerIdInternal;
            var reports = new List<object>();

            // 1. Calculate reinforcement budget using EconomyEngine
            var economyReport = EconomyEngine.CalculateReinforcement(_state, activePlayerId);
            reports.Add(economyReport);

            // Apply reinforcement budget to player's ArmiesToPlace
            var player = _state.GetPlayer(activePlayerId);
            player.AddArmies(economyReport.TotalReinforcementBudget);

            // 2. Calculate fresh supply from current GameState
            var supplyResult = SupplyEngine.CalculateSupply(_state, activePlayerId);
            reports.Add(supplyResult);

            // 3. Calculate attrition from fresh supply result
            var attritionReport = AttritionEngine.CalculateAttrition(_state, activePlayerId, supplyResult);
            reports.Add(attritionReport);

            // 4. Apply attrition army changes
            foreach (var territoryResult in attritionReport.TerritoryResults)
            {
                var territory = _state.GetTerritory(territoryResult.TerritoryId);
                if (territoryResult.ArmiesLost > 0)
                {
                    territory.RemoveArmies(territoryResult.ArmiesLost);
                }

                // Handle neutralization (territory reaches 0 armies)
                if (territoryResult.WouldBeNeutralized)
                {
                    territory.SetOwner(null, 0);
                }
            }

            // 5. Mark stage A as executed and advance to Stage B
            _stageAExecutedThisTurn = true;
            _currentStage = TurnStage.PlayerActions;
            _state.SetPhase(TurnManager.ToLegacyPhase(_currentStage));

            // Publish TurnStartedEvent
            if (_eventBus is not null)
            {
                var turnStarted = new TurnStartedEvent(
                    _eventIdSource.Next(),
                    DateTime.UtcNow,
                    activePlayerId,
                    _state.CurrentTurnNumberInternal,
                    TurnManager.ToLegacyPhase(_currentStage),
                    economyReport.TotalReinforcementBudget);
                _eventBus.Publish(turnStarted);
            }

            return new StageResult(true, TurnStage.TurnStart, null,
                new { ActivePlayerId = activePlayerId, Reports = reports });
        }

        /// <summary>
        /// Executes Stage B (PlayerActions) - validates and executes a single player action.
        /// Returns the action result.
        /// </summary>
        public ActionResult ExecutePlayerAction(IGameAction action)
        {
            if (IsGameOver)
                return new ActionResult(false, "Game has ended; no further actions allowed.");

            if (_currentStage != TurnStage.PlayerActions)
                return new ActionResult(false, $"Cannot execute actions in stage {_currentStage}.");

            // ActionExecutor handles validation and execution
            var result = ActionExecutor.Execute(_state, action);
            return result;
        }

        /// <summary>
        /// Executes Stage C (EventProcessing) - fires due scheduled events at ExecutionStage.EventProcessing.
        /// </summary>
        public StageResult ExecuteEventProcessing()
        {
            if (IsGameOver)
                return new StageResult(false, _currentStage, "Game has ended; no event processing.");

            if (_stageCExecutedThisTurn)
                return new StageResult(false, _currentStage, "EventProcessing already executed this turn.");

            if (_currentStage != TurnStage.EventProcessing)
                return new StageResult(false, _currentStage, $"Cannot execute EventProcessing from stage {_currentStage}.");

            // Build scheduler query
            var playerTurnCounts = new Dictionary<string, int>();
            foreach (var p in _state.Players)
            {
                playerTurnCounts[p.Id] = _state.CurrentTurnNumberInternal;
            }

            var query = new SchedulerQuery
            {
                CurrentRoundIndex = _state.CurrentTurnNumberInternal,
                CurrentPlayerTurnCounts = playerTurnCounts,
                CurrentStage = ExecutionStage.EventProcessing
            };

            // Fire due events
            int firedCount = _eventScheduler.FireDueEvents(query);

            _stageCExecutedThisTurn = true;
            _currentStage = TurnStage.TurnEnd;
            _state.SetPhase(TurnManager.ToLegacyPhase(_currentStage));

            return new StageResult(true, TurnStage.EventProcessing, null,
                new { EventsFired = firedCount });
        }

        /// <summary>
        /// Executes Stage D (TurnEnd) - evaluates victory, advances to next player.
        /// </summary>
        public StageResult ExecuteTurnEnd()
        {
            if (IsGameOver)
                return new StageResult(false, _currentStage, "Game has already ended.");

            if (_stageDExecutedThisTurn)
                return new StageResult(false, _currentStage, "TurnEnd already executed this turn.");

            if (_currentStage != TurnStage.TurnEnd)
                return new StageResult(false, _currentStage, $"Cannot execute TurnEnd from stage {_currentStage}.");

            // 1. Evaluate victory at Stage D (per D-16-5)
            var victoryInfo = VictoryChecker.CheckVictory(_state);

            if (victoryInfo.IsVictorious)
            {
                _currentStage = TurnStage.GameOver;
                _state.SetPhase(TurnManager.PhaseGameOver);

                // Publish GameOverEvent
                if (_eventBus is not null)
                {
                    var gameOverEvent = new GameOverEvent(
                        _eventIdSource.Next(),
                        DateTime.UtcNow,
                        victoryInfo.WinningPlayerId!,
                        victoryInfo.Condition.ToString(),
                        victoryInfo.Reason);
                    _eventBus.Publish(gameOverEvent);
                }

                return new StageResult(true, TurnStage.TurnEnd, null,
                    new { GameOver = true, Victory = victoryInfo });
            }

            // 2. Advance to next player
            var allPlayerIds = _state.Players.Select(p => p.Id).ToList();
            _state.AdvanceTurn(allPlayerIds);

            // Reset for next player's turn
            _currentStage = TurnStage.TurnStart;
            _stageAExecutedThisTurn = false;
            _stageCExecutedThisTurn = false;
            _stageDExecutedThisTurn = false;

            // Publish TurnStartedEvent for next player
            if (_eventBus is not null)
            {
                var turnStarted = new TurnStartedEvent(
                    _eventIdSource.Next(),
                    DateTime.UtcNow,
                    _state.CurrentTurnPlayerIdInternal,
                    _state.CurrentTurnNumberInternal,
                    TurnManager.PhaseReinforce,
                    0); // Budget will be calculated in next TurnStart
                _eventBus.Publish(turnStarted);
            }

            return new StageResult(true, TurnStage.TurnEnd, null,
                new { NextPlayerId = _state.CurrentTurnPlayerIdInternal, NextTurnNumber = _state.CurrentTurnNumberInternal, Victory = victoryInfo });
        }

        /// <summary>
        /// Advances to the next turn stage. Returns the new stage and updates internal state.
        /// Valid transitions: TurnStart → PlayerActions → EventProcessing → TurnEnd → TurnStart(next player)
        /// </summary>
        public TurnStage AdvanceStage()
        {
            var next = _currentStage switch
            {
                TurnStage.TurnStart when _stageAExecutedThisTurn => TurnStage.PlayerActions,
                TurnStage.PlayerActions => TurnStage.EventProcessing,
                TurnStage.EventProcessing when _stageCExecutedThisTurn => TurnStage.TurnEnd,
                TurnStage.TurnEnd when _stageDExecutedThisTurn => TurnStage.TurnStart,
                _ => throw new InvalidOperationException($"Cannot advance from {_currentStage}; required stage not executed."),
            };
            _currentStage = next;
            return next;
        }
    }