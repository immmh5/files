# TURN_ENGINE_ARCHITECTURE.md

**Status:** PROPOSED ARCHITECTURE
**Purpose:** Detailed specification of the hybrid turn engine (A–D stages), event scheduler, and state machine.

---

## 1. TurnEngine Responsibilities

The `TurnEngine` is the **single authoritative writer** of `GameState`. It owns:

- Current player turn pointer and turn number
- Current stage (A: TurnStart, B: PlayerActions, C: EventProcessing, D: TurnEnd)
- Pending event queue (scheduled effects with remaining durations)
- Validation and execution of player actions
- Deterministic simulation of combat, supply, income, events

**No other component mutates `GameState`.** All mutations go through `TurnEngine` public methods.

---

## 2. Stage State Machine

```
┌────────────────────────────────────────────────────────────────────┐
│                     TURN ENGINE STATE MACHINE                      │
│                                                                    │
│   ┌──────────┐     Validate & Execute     ┌──────────────────┐   │
│   │          │ ─────────────────────────► │                  │   │
│   │ TurnStart│                            │  PlayerActions │   │
│   │ (A)      │                            │      (B)        │   │
│   └────┬─────┘                            └───────┬────────┘   │
│        │                                        │              │
│        │ Valid transitions:                     │ Valid trans:  │
│        │   A → B (always)                       │   B → C (player|
│        │                                        │   ends/times   │
│        │                                        │   out)         │
│        ▼                                        ▼              │
│   ┌──────────────────┐                  ┌──────────────────┐   │
│   │                  │                  │                  │   │
│   │  EventProcessing │                  │     TurnEnd      │   │
│   │      (C)         │                  │      (D)         │   │
│   │                  │                  │                  │   │
│   └────────┬─────────┘                  └────────┬─────────┘   │
│            │                                     │              │
│            │ Valid: C → D (always)               │ Valid:       │
│            │                                     │   D → A      │
│            ▼                                     ▼              │
│        Next Player's TurnStart ◄─────────────────┘              │
└────────────────────────────────────────────────────────────────────┘
```

### Invalid Transitions (Throw `InvalidOperationException`)
- `TurnStart` → `TurnEnd` (skip actions/events)
- `PlayerActions` → `TurnStart` (skip events/end)
- `EventProcessing` → `PlayerActions` (backwards)
- `TurnEnd` → `PlayerActions` / `EventProcessing`
- Any transition during an active player action batch

---

## 3. Stage Specifications

### A. TurnStart (`TurnStage.TurnStart`)

**Responsibilities:**
1. Calculate reinforcement income for active player
2. Apply scheduled **start-of-turn** effects
3. Apply supply attrition to unsupplied groups
3. Credit income to `Player.ArmiesToPlace`

**Deterministic; no player input.**

```csharp
public TurnStartResult ExecuteTurnStart(string playerId)
{
    var player = state.GetPlayer(playerId);
    
    // 1. Income
    int income = CalculateIncome(player);
    player.AddArmies(income);
    
    // 2. Start-of-turn effects
    var startEffects = eventQueue.Where(e => e.Phase == EffectPhase.TurnStart);
    foreach (var effect in startEffects) effect.Apply(state);
    
    // 3. Supply attrition
    int attrition = SupplyEngine.ApplyAttrition(state, playerId);
    
    // 4. Advance stage
    state.CurrentStage = TurnStage.PlayerActions;
    
    // 5. Publish events
    eventBus.Publish(new TurnStartedEvent(playerId, state.CurrentTurnNumber, income, attrition));
    
    return new TurnStartResult(income, attrition);
}
```

**Output Events:**
- `TurnStartedEvent` (playerId, turnNumber, income, attritionApplied)
- `SupplyAttritionEvent` (per territory)
- `EffectAppliedEvent` (for start-of-turn effects)

---

### B. PlayerActions (`TurnStage.PlayerActions`)

**Responsibilities:**
1. Accept and validate orders from active player (or AI)
2. Resolve each action **as issued** (no batch planning)
3. Mutate state immediately per action
4. Publish `OrderResolvedEvent` per action

**Player-controlled; turn timer applies only as flow control.**

```csharp
public Result<OrderResult> SubmitOrder(Order order)
{
    // 1. Validate phase
    if (state.CurrentStage != TurnStage.PlayerActions)
        return Result.Fail("Not in PlayerActions phase");
    
    // 2. Validate ownership
    if (order.PlayerId != state.CurrentTurnPlayerId)
        return Result.Fail("Not your turn");
    
    // 3. Validate action (per rules in COMBAT_AND_ARMY_RULES)
    var validation = ValidateOrder(order);
    if (!validation.IsSuccess) return validation;
    
    // 4. Execute & mutate state
    var result = ExecuteAction(order);
    
    // 5. Publish resolution
    eventBus.Publish(new OrderResolvedEvent(order.Id, result.Success, result.Details));
    
    // 6. Check action limit (1 per territory per turn)
    MarkTerritoryActed(order.FromTerritoryId ?? order.ToTerritoryId);
    
    return Result.Ok(result);
}
```

**Action Resolution Order:**
- Actions resolve **immediately** in submission order
- State mutates before next action
- Combat, movement, placement all use current state

**Output Events (per action):**
- `OrderSubmittedEvent`
- `OrderResolvedEvent` (success/failure, battle details)
- `TerritoryCapturedEvent` (if applicable)
- `ArmiesPlacedEvent` (for placement)

---

### C. EventProcessing (`TurnStage.EventProcessing`)

**Responsibilities:**
1. Fire events whose scheduled turn has arrived
2. Decrement duration of multi-turn effects
2. Remove expired effects
3. Evaluate condition-based triggers

**Deterministic; no player input.**

```csharp
public EventProcessingResult ExecuteEventProcessing()
{
    var firedEvents = new List<GameEvent>();
    
    // 1. Time-based scheduled events
    var dueEvents = eventQueue
        .Where(e => e.ScheduledTurn <= state.CurrentTurnNumber)
        .OrderBy(e => e.Phase)
        .ThenBy(e => e.InsertionOrder);
    
    foreach (var evt in dueEvents) {
        evt.Execute(state);
        firedEvents.Add(new EffectFiredEvent(evt.Id, evt.Target));
        eventQueue.Remove(evt);
    }
    
    // 2. Decrement durations
    foreach (var effect in activeEffects) {
        effect.DurationTurns--;
        if (effect.DurationTurns <= 0) {
            effect.OnExpire(state);
            firedEvents.Add(new EffectExpiredEvent(effect.Id));
            activeEffects.Remove(effect);
        }
    }
    
    // 3. Condition-based triggers
    var triggered = conditionRegistry.Evaluate(state);
    foreach (var trigger in triggered) {
        trigger.Execute(state);
        firedEvents.Add(trigger.Event);
    }
    
    // 4. Advance stage
    state.CurrentStage = TurnStage.TurnEnd;
    
    return new EventProcessingResult(firedEvents);
}
```

**Output Events:**
- `EffectFiredEvent` (per scheduled effect)
- `EffectExpiredEvent` (per expired effect)
- Custom trigger events

---

### D. TurnEnd (`TurnStage.TurnEnd`)

**Responsibilities:**
1. Apply **end-of-turn** effects
2. Check victory conditions
3. Check elimination
3. Advance to next player's TurnStart

**Deterministic; no player input.**

```csharp
public TurnEndResult ExecuteTurnEnd()
{
    // 1. End-of-turn effects
    var endEffects = eventQueue.Where(e => e.Phase == EffectPhase.TurnEnd);
    foreach (var effect in endEffects) effect.Apply(state);
    
    // 2. Victory check
    var victory = VictoryChecker.CheckVictory(state);
    if (victory.IsVictorious) {
        eventBus.Publish(new VictoryEvent(victory.WinningPlayerId, victory.Condition, victory.Reason));
        state.CurrentStage = TurnStage.GameOver;
        return new TurnEndResult(victory);
    }
    
    // 3. Advance to next player
    var allPlayerIds = state.Players.Select(p => p.Id).ToArray();
    var (nextPlayerId, nextTurnNumber, _) = TurnManager.AdvanceTurn(
        state.CurrentTurnPlayerId,
        state.CurrentTurnPlayerId,
        state.CurrentTurnNumber,
        allPlayerIds
    );
    
    state.CurrentTurnPlayerId = nextPlayerId;
    state.CurrentTurnNumber = nextTurnNumber;
    state.CurrentStage = TurnStage.TurnStart;
    
    // 4. Clear acted territories
    actedTerritoriesThisTurn.Clear();
    
    // 5. Publish turn end
    eventBus.Publish(new TurnEndedEvent(state.CurrentTurnPlayerId, nextPlayerId, nextTurnNumber));
    
    return new TurnEndResult(nextPlayerId, nextTurnNumber);
}
```

**Output Events:**
- `TurnEndedEvent` (currentPlayer, nextPlayer, nextTurnNumber)
- `VictoryEvent` (if game over)

---

## 4. Event Scheduler

### Event Structure
```csharp
record ScheduledEvent(
    string Id,
    EffectPhase Phase,           // TurnStart, TurnEnd, Immediate
    int ScheduledTurn,           // Absolute turn number
    int InsertionOrder,          // Tiebreaker
    Action<GameState> Execute,   // Pure function
    Action<GameState> OnExpire   // Optional cleanup
);
```

### EffectPhase
```csharp
enum EffectPhase { TurnStart, TurnEnd, Immediate }
```

### Scheduling API
```csharp
// Schedule effect to fire in N turns during phase
string Schedule(EffectPhase phase, int turnOffset, Action<GameState> execute, Action<GameState>? onExpire = null);

// Cancel by ID
bool Cancel(string eventId);

// Get all pending events for save
IReadOnlyList<ScheduledEvent> GetPendingEvents();
```

### Ordering
1. `ScheduledTurn` (ascending)
2. `Phase` (TurnStart=0, TurnEnd=1)
3. `InsertionOrder` (ascending)

---

## 5. Effect / Status System

### ActiveEffect
```csharp
record ActiveEffect(
    string Id,
    string TargetId,
    EffectType Type,
    int DurationTurns,           // Decremented each turn in EventProcessing
    ImmutableDictionary<string, object> Params
);
```

### EffectType Behaviors
| Type | Apply | OnExpire | Duration |
|---|---|---|---|
| `SupplyDisruption` | Block supply path through target territory | Restore supply path | N turns |
| `MoraleBonus` | +N to attack/defense for target | Remove bonus | N turns |
| `IncomeModifier` | Multiply income by factor for target | Reset multiplier | N turns |
| `MovementCostChange` | ±N movement cost for target | Reset cost | N turns |

### Duration Semantics
- Duration = **number of full turns remaining**
- Decremented **once per turn** during `EventProcessing` (stage C)
- **Independent of active player** — effects tick for all players equally
- When `DurationTurns` reaches 0 during stage C: `OnExpire` fires, effect removed

---

## 6. Save/Load Boundaries

### Serializable State (Authoritative)
```csharp
record TurnEngineSnapshot(
    string CurrentTurnPlayerId,
    int CurrentTurnNumber,
    TurnStage CurrentStage,
    ImmutableList<ScheduledEvent> PendingEvents,
    ImmutableList<ActiveEffect> ActiveEffects,
    ImmutableHashSet<string> ActedTerritoriesThisTurn
);
```

### Save Timing
- **Autosave:** After `TurnEnd` completes (stage D), before next `TurnStart`
- **Manual save:** At any stage boundary (A, B, C, or D)
- **Never mid-action** — saves only at stage boundaries

### Load Restoration
1. Restore `GameState` from `GameStateSnapshot`
2. Restore `TurnEngineSnapshot`
3. Rebuild `activeEffects` and `eventQueue` from saved data
4. Resume at saved `CurrentStage` (engine continues from that point)

---

## 7. Deterministic Replay Requirements

### Command Log (Ordered)
```csharp
record CommandRecord(
    int TurnNumber,
    string PlayerId,
    Order Order,
    DateTime Timestamp,           // Wall clock for display only
    long LogicalTick              // Monotonic logical time
);
```

### Replay Algorithm
```csharp
GameState Replay(InitialState, CommandLog) {
    var engine = new TurnEngine(initialState);
    foreach (var cmd in commandLog) {
        engine.SubmitOrder(cmd.Order);  // Validation may fail if log corrupted
        engine.AdvanceStagesToNextTurnStart(); // Execute B→C→D→A
    }
    return engine.State;
}
```

### Determinism Guarantees
- Same `InitialState` + same `CommandLog` → identical final state
- No wall-clock time in simulation
- No RNG in authoritative paths
- Event scheduler is pure function of (state, turn number)

---

## 8. Multiplayer Synchronization Points

| Point | Data Sent | Direction |
|---|---|---|
| TurnStart | `TurnStartedEvent` + snapshot | Host → All |
| ActionSubmit | `OrderSubmittedEvent` | Client → Host |
| ActionResolve | `OrderResolvedEvent` + snapshot diff | Host → All |
| EventProcessing | `EffectFiredEvent` + snapshot diff | Host → All |
| TurnEnd | `TurnEndedEvent` + snapshot | Host → All |

**Clients never run TurnEngine.** They apply snapshots and display events.

---

## 9. Public API (TurnEngine)

```csharp
public sealed class TurnEngine
{
    // Construction
    public TurnEngine(GameState initialState);
    
    // State access
    public GameState State { get; }
    public TurnEngineSnapshot Snapshot();
    
    // Stage execution (called in sequence)
    public TurnStartResult ExecuteTurnStart(string playerId);
    public Result<OrderResult> SubmitOrder(Order order);
    public void EndPlayerActions();  // Called when player "Ready"s or timer expires
    public EventProcessingResult ExecuteEventProcessing();
    public TurnEndResult ExecuteTurnEnd();
    
    // Queries
    public IReadOnlyList<Order> GetLegalOrders(string playerId);
    public bool CanAct(string territoryId);
    public IReadOnlyList<ScheduledEvent> GetPendingEvents();
    
    // Serialization
    public TurnEngineSnapshot Snapshot();
    public static TurnEngine Restore(GameState state, TurnEngineSnapshot snap);
}
```

---

## 10. Integration with Existing Code

### Current Code to Refactor/Extend
| Existing | Action |
|---|---|
| `TurnManager.AdvanceTurn` | Extend to use `TurnStage` enum; return next player + turn number |
| `TurnManager.TransitionPhase` | Remove (replaced by stage machine) |
| `GameState.CurrentPhase` | Replace with `TurnStage` enum |
| `CombatSystem.ResolveAttack` | Keep; ensure pure function; used by `ExecuteAction` |
| `VictoryChecker.CheckVictory` | Keep; called in `ExecuteTurnEnd` |
| `SupplyEngine` (new) | Implement supply flood-fill + attrition |
| `EventScheduler` (new) | Core of persistent event system |

### New Files Needed in Core
| File | Purpose |
|---|---|
| `Simulation/TurnEngine.cs` | Main turn state machine |
| `Simulation/EventScheduler.cs` | Scheduled events + effect durations |
| `Simulation/SupplyEngine.cs` | Supply flood-fill + attrition |
| `Simulation/ActionExecutor.cs` | Validate & execute move/attack/fortify/place |
| `Domain/TurnStage.cs` | Enum replacing string phases |
| `Domain/EffectPhase.cs` | Enum for effect timing |
| `Domain/ScheduledEvent.cs` | Event with turn offset |
| `Domain/ActiveEffect.cs` | Effect with duration |
| `Events/EffectFiredEvent.cs` | Event notification |
| `Events/EffectExpiredEvent.cs` | Event notification |