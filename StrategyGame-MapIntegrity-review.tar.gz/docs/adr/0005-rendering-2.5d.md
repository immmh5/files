# ADR-0005: 2D Node-Based Rendering with Layered SubViewports for 2.5D Depth

**Status:** Accepted
**Date:** 2026-11-04

## Decision

Render the strategy map using **Godot's 2D rendering pipeline** (`Node2D`, `TileMap`, `Polygon2D`, `SubViewport`) with layered compositing to achieve a 2.5D depth effect.

Do not introduce a full 3D world, 3D physics simulation, or complex 3D rendering pipeline for the strategy layer.

## Context

The game is a strategic territory-control game, not an action game. The map is primarily a 2D strategic plane. Visual depth (elevation, shadows, layering) is achieved through:
- Polygon shading and border beveling.
- Drop shadows using offset secondary polygon layers.
- Directional light simulation via color modulation.
- Camera zoom with subtle parallax of layered elements.

### Alternatives Considered

| Alternative | Rejected Because |
|---|---|
| **Full 3D scene (Godot 3D or Godot 4 3D)** | Overkill for a 2D strategic map; significantly increases rendering cost; camera complexity; asset pipeline |
| **Godot 2D with CanvasItem shaders only** | Simpler, but hard to layer complex multi-element territories with independent animations |
| **Custom renderer (Vulkan/D3D12 direct)** | Enormous complexity; no editor support; no scene management; out of scope |

## Consequences

- **Positive:** Uses Godot's native 2D system: excellent performance, no external dependencies.
- **Positive:** `SubViewport` isolation allows independent update rates for static vs. dynamic layers.
- **Positive:** 60 FPS on integrated graphics is achievable with the 2D pipeline.
- **Negative:** Some depth effects (e.g., overlapping territories with partial transparency) require careful layer ordering.
- **Mitigation:** Clear layer architecture defined in `docs/RENDERING_AND_2.5D.md`. Test on target hardware early.
