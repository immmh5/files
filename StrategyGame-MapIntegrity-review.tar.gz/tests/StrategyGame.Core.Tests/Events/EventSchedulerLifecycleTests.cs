namespace StrategyGame.Core.Tests.Events;

using System.Text.Json;
using StrategyGame.Core.Events;
using System.Collections.Generic;
using Xunit;

/// <summary>
/// R4.6 regression tests: EventScheduler lifecycle transitions, handler execution,
/// state persistence, and error handling.
/// </summary>
public class EventSchedulerLifecycleTests
{
    /// <summary>
    /// Ensures clean registry state before each test.
    /// </summary>
    public EventSchedulerLifecycleTests()
    {
        EventHandlerRegistry.ClearHandlersForTesting();
        EventTypeRegistrar.ClearForTesting();
        EventTypeRegistrar.RegisterAll();
    }
    private static ScheduledEventRecord MakeRoundEvent(
        string id, int dueRound, int priority = 0, long seq = 0)
    {
        var record = ScheduledEventRecord.CreateWithPayload(
            id, "autumn_attrition", 1,
            new RoundTiming(dueRound), null,
            new() { ["regions"] = JsonSerializer.SerializeToElement(new[] { "north" }) });
        return record with { Priority = priority, SequenceNumber = seq };
    }

    private static ScheduledEventRecord MakePlayerEvent(
        string id, string playerId, int dueTurn, int priority = 0, long seq = 0)
    {
        var record = ScheduledEventRecord.CreateWithPayload(
            id, "berserk_rage", 1,
            null, new PlayerTurnTiming(playerId, dueTurn),
            new() { ["attackBonus"] = JsonSerializer.SerializeToElement(2) });
        return record with { Priority = priority, SequenceNumber = seq };
    }

    // -------------------------------------------------------------
    // 1. Invalid scheduling arguments
    // -------------------------------------------------------------

    [Fact]
    public void Schedule_InvalidStatus_Throws()
    {
        var scheduler = new EventScheduler();
        var record = ScheduledEventRecord.CreateWithPayload(
            "evt_1", "autumn_attrition", 1,
            new RoundTiming(5), null,
            new() { ["regions"] = JsonSerializer.SerializeToElement(new[] { "north" }) });
        
        // Set status to something other than Pending
        var invalidRecord = record with { Status = ScheduledEventStatus.Fired };
        
        Assert.Throws<ArgumentException>(() => scheduler.Schedule(invalidRecord));
    }

    // -------------------------------------------------------------
    // 2. Successful execution transitions to Fired
    // -------------------------------------------------------------

    [Fact]
    public void FireDueEvents_SuccessfulExecution_TransitionsToFired()
    {
        var scheduler = new EventScheduler();
        var record = MakeRoundEvent("evt_1", 3);
        
        // Override the handler to return true (success)
        EventHandlerRegistry.RegisterHandler("autumn_attrition", record => true);
        
        scheduler.Schedule(record);
        
        var firedCount = scheduler.FireDueEvents(new SchedulerQuery 
        { 
            CurrentRoundIndex = 5, 
            CurrentStage = ExecutionStage.EventProcessing 
        });
        
        Assert.Equal(1, firedCount);
        
        var evt = scheduler.TryGetEvent("evt_1");
        Assert.NotNull(evt);
        Assert.Equal(ScheduledEventStatus.Fired, evt!.Status);
    }

    // -------------------------------------------------------------
    // 3. Handler exception transitions to Failed
    // -------------------------------------------------------------

    [Fact]
    public void FireDueEvents_HandlerException_TransitionsToFailed()
    {
        var scheduler = new EventScheduler();
        var record = MakeRoundEvent("evt_1", 3);
        
        // Override handler to throw
        EventHandlerRegistry.RegisterHandler("autumn_attrition", record => 
            throw new InvalidOperationException("Handler failed"));
        
        scheduler.Schedule(record);
        
        var firedCount = scheduler.FireDueEvents(new SchedulerQuery 
        { 
            CurrentRoundIndex = 5, 
            CurrentStage = ExecutionStage.EventProcessing 
        });
        
        // Should not count failed events as fired
        Assert.Equal(0, firedCount);
        
        var evt = scheduler.TryGetEvent("evt_1");
        Assert.NotNull(evt);
        Assert.Equal(ScheduledEventStatus.Failed, evt!.Status);
    }

    // -------------------------------------------------------------
    // 4. Handler exception continues processing other events
    // -------------------------------------------------------------

    [Fact]
    public void FireDueEvents_HandlerException_ContinuesProcessing()
    {
        var scheduler = new EventScheduler();

        // First event will throw
        var record1 = MakeRoundEvent("evt_1", 3);
        EventHandlerRegistry.RegisterHandler("autumn_attrition", record =>
            throw new InvalidOperationException("Handler failed"));
        scheduler.Schedule(record1);

        // Second event should succeed - use different event type
        var record2 = MakeRoundEvent("evt_2", 3);
        record2 = record2 with { EventTypeKey = "berserk_rage" };
        EventHandlerRegistry.RegisterHandler("berserk_rage", record => true);
        scheduler.Schedule(record2);

        var firedCount = scheduler.FireDueEvents(new SchedulerQuery
        {
            CurrentRoundIndex = 5,
            CurrentStage = ExecutionStage.EventProcessing
        });

        // Only the successful event should count
        Assert.Equal(1, firedCount);

        var evt1 = scheduler.TryGetEvent("evt_1");
        Assert.Equal(ScheduledEventStatus.Failed, evt1!.Status);

        var evt2 = scheduler.TryGetEvent("evt_2");
        Assert.Equal(ScheduledEventStatus.Fired, evt2!.Status);
    }

    // -------------------------------------------------------------
    // 5. Missing handler returns false, no state change
    // -------------------------------------------------------------

    [Fact]
    public void FireDueEvents_MissingHandler_ReturnsFalse_NoStateChange()
    {
        var scheduler = new EventScheduler();
        
        // Register event with a type that has no handler registered
        var record = MakeRoundEvent("evt_1", 3);
        record = record with { EventTypeKey = "unknown_type" };
        
        // Don't register a handler for "unknown_type"
        scheduler.Schedule(record);
        
        var firedCount = scheduler.FireDueEvents(new SchedulerQuery 
        { 
            CurrentRoundIndex = 5, 
            CurrentStage = ExecutionStage.EventProcessing 
        });
        
        Assert.Equal(0, firedCount);
        
        var evt = scheduler.TryGetEvent("evt_1");
        Assert.NotNull(evt);
        // State should remain unchanged (still Pending)
        Assert.Equal(ScheduledEventStatus.Pending, evt!.Status);
    }

    // -------------------------------------------------------------
    // 6. Only processes Pending events
    // -------------------------------------------------------------

    [Fact]
    public void FireDueEvents_OnlyProcessesPendingEvents()
    {
        var scheduler = new EventScheduler();

        // Fired event - should not be processed again
        var firedRecord = MakeRoundEvent("evt_1", 3);
        firedRecord = firedRecord with { Status = ScheduledEventStatus.Fired };

        // Cancelled event - should not be processed
        var cancelledRecord = MakeRoundEvent("evt_2", 3);
        cancelledRecord = cancelledRecord with { Status = ScheduledEventStatus.Cancelled };

        // Failed event - should not be processed
        var failedRecord = MakeRoundEvent("evt_3", 3);
        failedRecord = failedRecord with { Status = ScheduledEventStatus.Failed };

        // Only Pending event should be processed
        var pendingRecord = MakeRoundEvent("evt_4", 3);
        EventHandlerRegistry.RegisterHandler("autumn_attrition", record => true);

        // Use InsertEventForTesting to bypass Schedule validation
        scheduler.InsertEventForTesting(firedRecord);
        scheduler.InsertEventForTesting(cancelledRecord);
        scheduler.InsertEventForTesting(failedRecord);
        scheduler.Schedule(pendingRecord);

        var firedCount = scheduler.FireDueEvents(new SchedulerQuery
        {
            CurrentRoundIndex = 5,
            CurrentStage = ExecutionStage.EventProcessing
        });

        Assert.Equal(1, firedCount);

        // Only the pending event should have fired
        var evt4 = scheduler.TryGetEvent("evt_4");
        Assert.Equal(ScheduledEventStatus.Fired, evt4!.Status);

        // Others should remain unchanged
        var evt1 = scheduler.TryGetEvent("evt_1");
        Assert.Equal(ScheduledEventStatus.Fired, evt1!.Status);

        var evt2 = scheduler.TryGetEvent("evt_2");
        Assert.Equal(ScheduledEventStatus.Cancelled, evt2!.Status);

        var evt3 = scheduler.TryGetEvent("evt_3");
        Assert.Equal(ScheduledEventStatus.Failed, evt3!.Status);
    }

    // -------------------------------------------------------------
    // 7. Stage-aware filtering
    // -------------------------------------------------------------

    [Fact]
    public void FireDueEvents_StageAwareFiltering()
    {
        var scheduler = new EventScheduler();
        
        // TurnStart event
        var turnStartRecord = MakeRoundEvent("evt_turnstart", 3);
        turnStartRecord = turnStartRecord with { ExecutionStage = ExecutionStage.TurnStart };
        
        // EventProcessing event
        var eventProcRecord = MakeRoundEvent("evt_eventproc", 3);
        eventProcRecord = eventProcRecord with { ExecutionStage = ExecutionStage.EventProcessing };
        
        // TurnEnd event
        var turnEndRecord = MakeRoundEvent("evt_turnend", 3);
        turnEndRecord = turnEndRecord with { ExecutionStage = ExecutionStage.TurnEnd };
        
        scheduler.Schedule(turnStartRecord);
        scheduler.Schedule(eventProcRecord);
        scheduler.Schedule(turnEndRecord);
        
        EventHandlerRegistry.RegisterHandler("autumn_attrition", record => true);
        
        // Query for TurnStart stage - only evt_turnstart should fire
        var firedCount = scheduler.FireDueEvents(new SchedulerQuery 
        { 
            CurrentRoundIndex = 5, 
            CurrentStage = ExecutionStage.TurnStart 
        });
        
        Assert.Equal(1, firedCount);
        
        var evt = scheduler.TryGetEvent("evt_turnstart");
        Assert.Equal(ScheduledEventStatus.Fired, evt!.Status);
        
        // Others should remain Pending
        var evt2 = scheduler.TryGetEvent("evt_eventproc");
        Assert.Equal(ScheduledEventStatus.Pending, evt2!.Status);
        
        var evt3 = scheduler.TryGetEvent("evt_turnend");
        Assert.Equal(ScheduledEventStatus.Pending, evt3!.Status);
    }

    // -------------------------------------------------------------
    // 8. Cancel marks Cancelled
    // -------------------------------------------------------------

    [Fact]
    public void Cancel_PendingEvent_MarksCancelled()
    {
        var scheduler = new EventScheduler();
        scheduler.Schedule(MakeRoundEvent("evt_1", 3));
        
        var cancelled = scheduler.Cancel("evt_1");
        
        Assert.True(cancelled);
        Assert.True(scheduler.Contains("evt_1")); // Event still exists but is Cancelled
        
        var evt = scheduler.TryGetEvent("evt_1");
        Assert.NotNull(evt);
        Assert.Equal(ScheduledEventStatus.Cancelled, evt!.Status);
        Assert.Equal(0, scheduler.Count); // Count only counts Pending
    }

    // -------------------------------------------------------------
    // 9. Cancel non-Pending returns false
    // -------------------------------------------------------------

    [Fact]
    public void Cancel_NonPendingEvent_ReturnsFalse()
    {
        var scheduler = new EventScheduler();

        // First, schedule and fire an event to get it to Fired state
        var record = MakeRoundEvent("evt_1", 3);
        scheduler.Schedule(record);
        scheduler.FireDueEvents(new SchedulerQuery
        {
            CurrentRoundIndex = 5,
            CurrentStage = ExecutionStage.EventProcessing
        });

        // Now evt_1 is Fired, trying to cancel should return false
        var cancelled = scheduler.Cancel("evt_1");
        Assert.False(cancelled);
    }

    // -------------------------------------------------------------
    // 10. Registered handler returning false transitions to Failed
    // -------------------------------------------------------------

    [Fact]
    public void FireDueEvents_HandlerReturnsFalse_TransitionsToFailed()
    {
        var scheduler = new EventScheduler();
        var record = MakeRoundEvent("evt_1", 3);

        // Register handler that returns false (unimplemented)
        EventHandlerRegistry.RegisterHandler("autumn_attrition", record => false);

        scheduler.Schedule(record);

        var firedCount = scheduler.FireDueEvents(new SchedulerQuery
        {
            CurrentRoundIndex = 5,
            CurrentStage = ExecutionStage.EventProcessing
        });

        Assert.Equal(0, firedCount);

        var evt = scheduler.TryGetEvent("evt_1");
        Assert.NotNull(evt);
        Assert.Equal(ScheduledEventStatus.Failed, evt!.Status);
    }

    // -------------------------------------------------------------
    // 11. All seven event handler keys are registered
    // -------------------------------------------------------------

    [Fact]
    public void EventTypeRegistrar_AllSevenHandlersRegistered()
    {
        // Ensure registrar is in known state
        EventTypeRegistrar.ClearForTesting();
        EventHandlerRegistry.RegisterHandler("autumn_attrition", r => true);
        EventHandlerRegistry.RegisterHandler("continent_bonus", r => true);
        EventHandlerRegistry.RegisterHandler("harvest_festival", r => true);
        EventHandlerRegistry.RegisterHandler("border_fortification", r => true);
        EventHandlerRegistry.RegisterHandler("berserk_rage", r => true);
        EventHandlerRegistry.RegisterHandler("supply_disruption", r => true);
        EventHandlerRegistry.RegisterHandler("fortification_boost", r => true);

        EventTypeRegistrar.RegisterAll();

        var expectedKeys = new[]
        {
            "autumn_attrition",
            "continent_bonus",
            "harvest_festival",
            "border_fortification",
            "berserk_rage",
            "supply_disruption",
            "fortification_boost"
        };

        foreach (var key in expectedKeys)
        {
            Assert.True(
                EventHandlerRegistry.TryGetHandler(key, out _),
                $"Handler for event type '{key}' is not registered.");
        }
    }

    // -------------------------------------------------------------
    // 12. All seven unimplemented handlers return false
    // -------------------------------------------------------------

    [Fact]
    public void UnimplementedHandlers_AllReturnFalse()
    {
        // Each handler should explicitly return false since gameplay effects are not yet approved
        // Use unique event type keys to avoid interference from other tests
        var handlers = new[]
        {
            "autumn_attrition",
            "continent_bonus",
            "harvest_festival",
            "border_fortification",
            "berserk_rage",
            "supply_disruption",
            "fortification_boost"
        };

        foreach (var key in handlers)
        {
            // Reset handler to default implementation for this test
            switch (key)
            {
                case "autumn_attrition":
                    EventHandlerRegistry.RegisterHandler(key, _ => false);
                    break;
                case "continent_bonus":
                    EventHandlerRegistry.RegisterHandler(key, _ => false);
                    break;
                case "harvest_festival":
                    EventHandlerRegistry.RegisterHandler(key, _ => false);
                    break;
                case "border_fortification":
                    EventHandlerRegistry.RegisterHandler(key, _ => false);
                    break;
                case "berserk_rage":
                    EventHandlerRegistry.RegisterHandler(key, _ => false);
                    break;
                case "supply_disruption":
                    EventHandlerRegistry.RegisterHandler(key, _ => false);
                    break;
                case "fortification_boost":
                    EventHandlerRegistry.RegisterHandler(key, _ => false);
                    break;
            }

            Assert.True(
                EventHandlerRegistry.TryGetHandler(key, out var handler),
                $"Handler for event type '{key}' is not registered.");

            var record = ScheduledEventRecord.CreateWithPayload(
                "test_evt", key, 1,
                new RoundTiming(5), null,
                new System.Collections.Generic.Dictionary<string, System.Text.Json.JsonElement>());

            var result = handler!(record);
            Assert.False(result, $"Handler '{key}' should return false (unimplemented).");
        }
    }

    // -------------------------------------------------------------
    // 13. Cold-start initialization guarantees registration
    // -------------------------------------------------------------

    [Fact]
    public void EventScheduler_ColdStart_RegistrationGuaranteed()
    {
        // Reset the static state to simulate cold start
        // Note: We can't fully reset static EventScheduler state due to language limitations,
        // but we verify that a fresh EventScheduler instance has access to handlers
        // without manually calling RegisterAll first.

        var scheduler = new EventScheduler();

        // The static constructor should have already called RegisterAll,
        // so handlers should be available immediately
        Assert.True(
            EventHandlerRegistry.TryGetHandler("autumn_attrition", out _),
            "Handler should be registered via static constructor.");
        Assert.True(
            EventHandlerRegistry.TryGetHandler("berserk_rage", out _),
            "Handler should be registered via static constructor.");
    }

    // -------------------------------------------------------------
    // 14. Explicit deterministic ordering assertions
    // -------------------------------------------------------------

    [Fact]
    public void GetScheduledEvents_DeterministicOrdering_RoundEvents()
    {
        var scheduler = new EventScheduler();

        // Event with later round should come after earlier round
        var earlyEvent = MakeRoundEvent("early", 1);
        var lateEvent = MakeRoundEvent("late", 5);

        scheduler.Schedule(earlyEvent);
        scheduler.Schedule(lateEvent);

        var allEvents = scheduler.GetScheduledEvents();
        Assert.Equal("early", allEvents[0].EventId);
        Assert.Equal("late", allEvents[1].EventId);
    }

    [Fact]
    public void GetScheduledEvents_DeterministicOrdering_Priority()
    {
        var scheduler = new EventScheduler();

        // Same round, different priority
        var highPriority = MakeRoundEvent("high_prio", 5, priority: 1);
        var lowPriority = MakeRoundEvent("low_prio", 5, priority: 10);

        scheduler.Schedule(highPriority);
        scheduler.Schedule(lowPriority);

        var allEvents = scheduler.GetScheduledEvents();
        Assert.Equal("high_prio", allEvents[0].EventId);
        Assert.Equal("low_prio", allEvents[1].EventId);
    }

    [Fact]
    public void GetScheduledEvents_DeterministicOrdering_SequenceNumber()
    {
        var scheduler = new EventScheduler();

        // Same round, same priority, different sequence
        var firstSeq = MakeRoundEvent("first_seq", 5, seq: 1);
        var secondSeq = MakeRoundEvent("second_seq", 5, seq: 2);

        scheduler.Schedule(firstSeq);
        scheduler.Schedule(secondSeq);

        var allEvents = scheduler.GetScheduledEvents();
        Assert.Equal("first_seq", allEvents[0].EventId);
        Assert.Equal("second_seq", allEvents[1].EventId);
    }

    [Fact]
    public void GetScheduledEvents_DeterministicOrdering_EventId()
    {
        var scheduler = new EventScheduler();

        // Same round, same priority, same sequence - EventId is tiebreaker
        var alphaEvent = MakeRoundEvent("alpha", 5, seq: 1);
        var betaEvent = MakeRoundEvent("beta", 5, seq: 1);

        scheduler.Schedule(alphaEvent);
        scheduler.Schedule(betaEvent);

        var allEvents = scheduler.GetScheduledEvents();
        Assert.Equal("alpha", allEvents[0].EventId);
        Assert.Equal("beta", allEvents[1].EventId);
    }

    [Fact]
    public void GetScheduledEvents_DeterministicOrdering_RoundBeforePlayer()
    {
        var scheduler = new EventScheduler();

        // Round-timed events should come before player-timed events
        var roundEvent = MakeRoundEvent("round_evt", 5);
        var playerEvent = MakePlayerEvent("player_evt", "player1", 5);

        scheduler.Schedule(roundEvent);
        scheduler.Schedule(playerEvent);

        var allEvents = scheduler.GetScheduledEvents();
        Assert.Equal("round_evt", allEvents[0].EventId);
        Assert.Equal("player_evt", allEvents[1].EventId);
    }

    // -------------------------------------------------------------
    // Cleanup helper for test isolation
    // -------------------------------------------------------------

    /// <summary>
    /// Cleans up handler registrations after tests that override them.
    /// Call at end of test to restore defaults.
    /// </summary>
    private static void CleanupHandlerRegistrations()
    {
        // Note: Full cleanup requires resetting the static dictionary,
        // which is not publicly exposed. Tests should be written to
        // use unique event type keys or accept the side effect.
    }
}