# UI_UX_SPECIFICATION.md

**Status:** PROPOSED DESIGN

---

## 1. Screen Hierarchy

```
Main Menu
  └─ Game Lobby
        └─ Map Screen
              ├─ Territory Info Panel
              ├─ Player Info Panel
              └─ Turn Controls
```

## 2. Main Menu

- New Game
- Load Game
- Settings
- Exit

## 3. Game Lobby

- Player list (human/AI)
- Faction selection
- Map selection
- AI difficulty selection
- Start Game

## 4. Map Screen

### 4.1 Layout

| Area | Purpose |
|---|---|
| Center | Interactive strategy map |
| Top bar | Turn indicator, phase, round number |
| Left panel | Selected territory info |
| Right panel | Player resources, income |
| Bottom bar | Turn controls (Ready, Skip, End Turn) |

### 4.2 Mouse Interactions

| Action | Effect |
|---|---|
| Left click | Select territory; show info panel |
| Right click | Context menu (move/attack/fortify) |
| Middle click + drag | Pan camera |
| Scroll | Zoom (0.5x–4x) |
| WASD | Pan camera |
| +/- | Zoom |

### 4.3 Camera Behavior

- Smooth tween on selection
- Zoom limits: 0.5x–4x
- Camera clamped to map bounds
- Pan smoothing: 0.2s tween

### 4.4 Selection States

- None: no territory selected
- Selected: territory highlighted; info panel shown
- Target: target territory highlighted for action

### 4.5 Interaction Priority

Modals block map input. No click-through on open menus.

## 5. Territory Info Panel

- Territory name
- Owner (faction color + name)
- Army count
- Terrain type
- Supply status
- Income contribution
- Adjacent territories

## 6. Player Info Panel

- Faction name + color
- Income per turn
- Territories owned
- Armies total
- Turn status

## 7. Turn Controls

- Ready: submit orders early
- Skip: pass turn (no orders)
- End Turn: end phase early

## 8. Notifications

- Supply attrition warning
- Region bonus achieved
- Victory condition met
- Turn timer warning

## 9. Settings

- Audio (master, music, SFX)
- Video (resolution, fullscreen)
- Gameplay (turn timers, animation speed)
- Language

## 10. Pause Menu

- Resume
- Save Game
- Load Game
- Settings
- Quit to Menu