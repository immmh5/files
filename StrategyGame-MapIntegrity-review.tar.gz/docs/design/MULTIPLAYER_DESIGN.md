# MULTIPLAYER_DESIGN.md

**Status:** PROPOSED DESIGN

---

## 1. Network Topology vs Game Authority

**Critical distinction:** Network topology (how peers connect) is independent of game authority (who validates state).

| Model | Topology | Authority | Tradeoff |
|---|---|---|---|
| Host-authoritative | Star (all → host) | Host holds authoritative state | Simple; host failure ends game |
| Full-mesh transport | All-to-all | Host still authoritative | More resilient transport; same authority model |
| Fully distributed | All-to-all | No single authority | Complex; requires lockstep; NOT recommended for first version |

**Recommendation:** Star topology with host authority. Full-mesh transport is a future optimization, not a different authority model.

## 2. Local Multiplayer (Hotspot/LAN)

- No internet required
- Wi-Fi hotspot: host creates ad-hoc network; clients connect
- LAN: UDP broadcast discovery on port 27100
- Manual IP: fallback for NAT/firewall issues

## 3. Host-Authoritative Protocol (Hybrid Turn System)

```
Client → Host: OrderSubmit(playerId, orders)        — during Player Action Phase only
Host → Clients: TurnStarted(playerId, turnNumber)   — begins stage A
Host → Clients: StateSnapshot (after each stage)    — A, C, and D produce updates
Host → Clients: EventNotification(event)            — when scheduled events fire
```

## 4. State Synchronization (including persistent events)

- Host broadcasts StateSnapshot after **each simulation update batch**: Turn Start (A), each action resolution batch in B, Persistent Event Processing (C), and Turn End (D)
- The **pending event queue** (scheduled events with remaining turn durations) is part of authoritative state — it is included in every snapshot, saved in every save file, and restored on reconnect
- Clients apply snapshots to a local read-only mirror; only the host runs CombatSystem, income, attrition, and the event scheduler
- Scheduled events fire on the host only; clients learn of them via EventNotification + snapshot diff — clients never run the scheduler themselves

## 5. Disconnection Recovery

- Host waits N turns before dropping a disconnected player (pause applies; persistent events are frozen with the simulation — they never advance for a disconnected player)
- Reconnection within grace period: host sends current snapshot **plus pending event queue with remaining durations**; client resumes as mirror exactly as if it had never disconnected
- Persistent events do not "fire while a player is disconnected" — the authoritative simulation is paused for that player's turn until reconnect or drop
- Host migration: future feature (Category 2)

## 6. Pause, Save, Load (Multiplayer)

- Host pause freezes the authoritative simulation at a stage boundary; persistent event durations do not tick while paused
- Save files include the pending event queue (see `TURN_AND_EVENT_SYSTEM.md` §6); a loaded game resumes identically for all players
- Load happens host-side; clients receive a fresh snapshot after load

## 7. WebRTC Integration

**Deferred to Category 2.** Requires STUN/TURN for internet; not needed for LAN.

## 7. Version Compatibility

- Save schema version in every packet
- Host rejects incompatible clients
- Migration via command-log transforms

## 8. Network Security

- All orders validated by host before execution
- Clients cannot modify authoritative state
- No trust of client-reported values

## 9. Phased Implementation Plan

| Phase | Transport | Features |
|---|---|---|
| Phase 1 | Loopback | Single-player testing |
| Phase 2 | ENet LAN | Local multiplayer, host-authoritative |
| Phase 3 | Discovery + Reconnect | LAN discovery, manual IP, reconnect |
| Phase 4 | WebRTC | Internet multiplayer (future) |