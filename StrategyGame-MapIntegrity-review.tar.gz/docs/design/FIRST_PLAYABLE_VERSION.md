# FIRST_PLAYABLE_VERSION.md

**Status:** PROPOSED DESIGN

---

## Category 1 — First Playable Version

### Essential Features

#### Core Gameplay
- [x] Hybrid turn loop: Turn Start → Player Actions → Persistent Event Processing → Turn End
- [x] Sequential player turns with persistent cross-turn events
- [x] Deterministic combat (no dice, no RNG)
- [x] Terrain defense bonuses
- [x] Supply lines and attrition
- [x] Continent/region bonuses
- [x] Income system (territories + region bonuses)
- [x] Army placement and movement
- [x] Attack and fortify actions
- [x] One action per territory per turn

#### Victory
- [x] Elimination (last player standing)
- [x] Domination (≥ 60% of territories)
- [x] Victory check after each Turn End

#### Players
- [x] 2–6 players (mix of human and AI)
- [x] 6 factions with mild passive bonuses
- [x] AI opponents (3 difficulty levels)
- [x] Elimination handling

#### Map
- [x] One standard map (~48 territories, 6 regions)
- [x] 6 terrain types
- [x] JSON map data format
- [x] Territory adjacency graph
- [x] Ownership visualization
- [x] Territory selection
- [x] Zooming and panning

#### UI
- [x] Main menu
- [x] Game lobby (faction/map/AI selection)
- [x] Map screen
- [x] Territory info panel
- [x] Player info panel
- [x] Turn controls (Ready, Skip, End Turn)
- [x] Notifications
- [x] Settings
- [x] Pause menu
- [x] Match summary

#### Save/Load
- [x] Save game
- [x] Load game
- [x] Autosave after each turn

#### Technical
- [x] Deterministic state updates
- [x] Event-driven updates (no per-frame rule evaluation)
- [x] Rendering loop independent of simulation clock
- [x] Modular architecture
- [x] Testable core logic
- [x] Unit tests for combat, victory, turn management

---

## Category 2 — Planned Expansion

- Alliances and diplomacy
- Cards and random events
- Technology tree
- Building upgrades
- Strategic resources
- Supply system
- Advanced AI (multi-ply)
- Map editor
- Replay UI
- Additional maps
- WebRTC multiplayer
- Host migration
- Full-mesh transport

---

## Category 3 — Optional Experimental

- Advanced diplomacy (trade, betrayal)
- Scenario-specific rules
- Custom faction abilities
- Procedural map generation
- Mod support / plugin loader
- Campaign mode
- Mobile export