#!/usr/bin/env bash
# =============================================================================
# install-desktop-launcher.sh — Install a KDE/GNOME desktop entry for StrategyGame
#
# Creates a user-level desktop launcher at:
#   ~/.local/share/applications/strategygame-editor.desktop
#
# Usage:
#   ./scripts/install-desktop-launcher.sh
#
# The launcher points to scripts/run-editor.sh which handles all environment
# setup (Godot path, .NET SDK, etc.) automatically.
#
# No sudo required. Does not modify system-wide directories.
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
LAUNCHER_SCRIPT="$PROJECT_ROOT/scripts/run-editor.sh"
DESKTOP_DIR="$HOME/.local/share/applications"
DESKTOP_FILE="$DESKTOP_DIR/strategygame-editor.desktop"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
NC='\033[0m'

die() { echo -e "${RED}ERROR:${NC} $*" >&2; exit 1; }
info() { echo -e "${YELLOW}INFO:${NC} $*"; }
ok()  { echo -e "${GREEN}OK:${NC} $*"; }

# --- Validate prerequisites ---
if [[ ! -f "$LAUNCHER_SCRIPT" ]]; then
    die "Launcher script not found: $LAUNCHER_SCRIPT"
fi

if [[ ! -x "$LAUNCHER_SCRIPT" ]]; then
    die "Launcher script is not executable: $LAUNCHER_SCRIPT"
    die "Run: chmod +x $LAUNCHER_SCRIPT"
fi

# --- Create desktop directory if needed ---
mkdir -p "$DESKTOP_DIR"

# --- Check for existing entry ---
if [[ -f "$DESKTOP_FILE" ]]; then
    die "Desktop entry already exists: $DESKTOP_FILE"
    die "Remove it first or choose a different name."
fi

# --- Write desktop entry ---
cat > "$DESKTOP_FILE" << 'ENTRY'
[Desktop Entry]
Name=StrategyGame - Godot Editor
Comment=Launch the StrategyGame project in the Godot 4.7.2 Mono editor
Exec=/home/USER_PLACEHOLDER/StrategyGame/scripts/run-editor.sh
Icon=utilities-terminal
Type=Application
Categories=Development;GameDevelopment;
Terminal=false
StartupNotify=true
ENTRY

# Replace USER_PLACEHOLDER with actual username
sed -i "s|USER_PLACEHOLDER|$(whoami)|g" "$DESKTOP_FILE"

ok "Desktop entry installed: $DESKTOP_FILE"
info ""
info "To use the launcher:"
info "  1. Log out and log back in (or run: update-desktop-database $DESKTOP_DIR)"
info "  2. Search for 'StrategyGame' in your application menu"
info ""
info "To remove the launcher later:"
info "  rm ~/.local/share/applications/strategygame-editor.desktop"
