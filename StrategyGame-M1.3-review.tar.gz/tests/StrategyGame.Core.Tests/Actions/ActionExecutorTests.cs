namespace StrategyGame.Core.Tests.Actions;

using StrategyGame.Core.Actions;
using StrategyGame.Core.Domain;
using StrategyGame.Core.GameState;
using Xunit;

public class ActionExecutorTests
{
    private MapDefinition CreateTestMap()
    {
        var territories = new List<Territory>
        {
            new("t1", "Alpha", ["t2"]),
            new("t2", "Bravo", ["t1", "t3"]),
            new("t3", "Charlie", ["t2"]),
        };
        return new MapDefinition("test-map", "Test Map", territories);
    }

    private GameState SetupGameState(string[] playerIds, string currentPlayerId)
    {
        var players = new List<Player>();
        foreach (var id in playerIds)
        {
            players.Add(new Player(id, $"Player {id}", new Faction($"{id}f", id, "#000000"), isHuman: true));
        }

        var state = new GameState("g1", CreateTestMap(), players, currentPlayerId, 1, TurnManager.PhaseAttack);

        // t1 owned by p1 with armies, t2 owned by p2
        state.GetTerritory("t1").SetOwner("p1", 5);
        state.GetTerritory("t2").SetOwner("p2", 3);
        state.GetTerritory("t3").SetOwner(null, 0);

        return state;
    }

    [Fact]
    public void Execute_Reinforce_UnknownPlayer_ReturnsFailure()
    {
        var state = SetupGameState(["p1"], "p1");
        var action = new ReinforceAction("a1", "unknown", "t1", 1);

        var result = ActionExecutor.Execute(state, action);

        Assert.False(result.Success);
        Assert.NotNull(result.ErrorMessage);
    }

    [Fact]
    public void Execute_Reinforce_WrongOwner_ReturnsFailure()
    {
        var state = SetupGameState(["p1"], "p1");
        var action = new ReinforceAction("a1", "p1", "t2", 1); // t2 is owned by p2

        var result = ActionExecutor.Execute(state, action);

        Assert.False(result.Success);
        Assert.Contains("not owned by player", result.ErrorMessage!);
    }

    [Fact]
    public void Execute_Reinforce_ZeroArmies_ReturnsFailure()
    {
        var state = SetupGameState(["p1"], "p1");
        var action = new ReinforceAction("a1", "p1", "t1", 0);

        var result = ActionExecutor.Execute(state, action);

        Assert.False(result.Success);
        Assert.Contains("positive", result.ErrorMessage!);
    }

    [Fact]
    public void Execute_Reinforce_ExcessiveAmount_ReturnsFailure()
    {
        var state = SetupGameState(["p1"], "p1");
        var p1 = state.GetPlayer("p1");
        p1.AddArmies(10); // Add some reinforcement balance

        var action = new ReinforceAction("a1", "p1", "t1", 999);

        var result = ActionExecutor.Execute(state, action);

        Assert.False(result.Success);
        Assert.Contains("Insufficient reinforcement", result.ErrorMessage!);
    }

    [Fact]
    public void Execute_Reinforce_ValidAction_PlacesArmies()
    {
        var state = SetupGameState(["p1"], "p1");
        var p1 = state.GetPlayer("p1");
        p1.AddArmies(5);

        var territoryBefore = state.GetTerritory("t1").Armies;
        var action = new ReinforceAction("a1", "p1", "t1", 3);

        var result = ActionExecutor.Execute(state, action);

        Assert.True(result.Success);
        Assert.Equal(territoryBefore + 3, state.GetTerritory("t1").Armies);
        Assert.Equal(2, p1.ArmiesToPlace); // 5 - 3 = 2 remaining
    }

    [Fact]
    public void Execute_Attack_NotAdjacent_ReturnsFailure()
    {
        var state = SetupGameState(["p1", "p2"], "p1");
        var action = new AttackAction("a1", "p1", "t1", "t3"); // t1 and t3 are not adjacent

        var result = ActionExecutor.Execute(state, action);

        Assert.False(result.Success);
        Assert.Contains("not adjacent", result.ErrorMessage!);
    }

    [Fact]
    public void Execute_Attack_SourceHasLessThanTwoArmies_ReturnsFailure()
    {
        var state = SetupGameState(["p1", "p2"], "p1");
        state.GetTerritory("t1").SetOwner("p1", 1); // Only 1 army

        var action = new AttackAction("a1", "p1", "t1", "t2");

        var result = ActionExecutor.Execute(state, action);

        Assert.False(result.Success);
        Assert.Contains("fewer than 2 armies", result.ErrorMessage!);
    }

    [Fact]
    public void Execute_Attack_LegalCapture_ChangesOwnership()
    {
        var state = SetupGameState(["p1", "p2"], "p1");
        // p1 has 5 armies at t1, p2 has 2 at t2
        state.GetTerritory("t1").SetOwner("p1", 5);
        state.GetTerritory("t2").SetOwner("p2", 2);

        var action = new AttackAction("a1", "p1", "t1", "t2");

        var result = ActionExecutor.Execute(state, action);

        Assert.True(result.Success);
        // Attacker wins because attacker_strength (4) > defender_strength (2)
        Assert.Equal("p1", state.GetTerritory("t2").OwnerPlayerId);
        Assert.True(result.Payload != null);
    }

    [Fact]
    public void Execute_Fortify_SameOwnerValidMove_TransfersArmies()
    {
        var map = new MapDefinition("test", "Test", new List<Territory>
        {
            new("t1", "A", ["t2"]),
            new("t2", "B", ["t1", "t3"]),
            new("t3", "C", ["t2"]),
        });
        var p1 = new Player("p1", "Player 1", new Faction("f1", "Red", "#FF0000"), isHuman: true);
        var state = new GameState("g1", map, [p1], "p1", 1, TurnManager.PhaseAttack);

        state.GetTerritory("t1").SetOwner("p1", 5);
        state.GetTerritory("t2").SetOwner("p1", 2);
        state.GetTerritory("t3").SetOwner("p1", 1);

        var action = new FortifyAction("a1", "p1", "t1", "t2", 2);

        var result = ActionExecutor.Execute(state, action);

        Assert.True(result.Success);
        Assert.Equal(3, state.GetTerritory("t1").Armies); // 5 - 2 = 3
        Assert.Equal(4, state.GetTerritory("t2").Armies); // 2 + 2 = 4
    }

    [Fact]
    public void Execute_Fortify_NonAdjacent_ReturnsFailure()
    {
        var map = new MapDefinition("test", "Test", new List<Territory>
        {
            new("t1", "A", ["t2"]),
            new("t2", "B", ["t1", "t3"]),
            new("t3", "C", ["t2"]),
        });
        var p1 = new Player("p1", "Player 1", new Faction("f1", "Red", "#FF0000"), isHuman: true);
        var state = new GameState("g1", map, [p1], "p1", 1, TurnManager.PhaseAttack);

        state.GetTerritory("t1").SetOwner("p1", 5);
        state.GetTerritory("t2").SetOwner("p1", 2);
        state.GetTerritory("t3").SetOwner("p1", 1);

        var action = new FortifyAction("a1", "p1", "t1", "t3", 1); // Not adjacent

        var result = ActionExecutor.Execute(state, action);

        Assert.False(result.Success);
        Assert.Contains("not adjacent", result.ErrorMessage!);
    }

    [Fact]
    public void Execute_GameOver_RejectsAllActions()
    {
        var state = SetupGameState(["p1"], "p1");
        state.SetPhase(TurnManager.PhaseGameOver);

        var reinforce = new ReinforceAction("a1", "p1", "t1", 1);
        var attack = new AttackAction("a1", "p1", "t1", "t2");
        var fortify = new FortifyAction("a1", "p1", "t1", "t2", 1);

        Assert.False(ActionExecutor.Execute(state, reinforce).Success);
        Assert.False(ActionExecutor.Execute(state, attack).Success);
        Assert.False(ActionExecutor.Execute(state, fortify).Success);
    }

    [Fact]
    public void Execute_InvalidActionLeavesStateUnchanged()
    {
        var state = SetupGameState(["p1"], "p1");
        var initialArmyCount = state.GetTerritory("t1").Armies;

        // Try to reinforce on enemy territory (invalid)
        var action = new ReinforceAction("a1", "p1", "t2", 1);
        _ = ActionExecutor.Execute(state, action);

        // State should be unchanged
        Assert.Equal(initialArmyCount, state.GetTerritory("t1").Armies);
    }
}