namespace StrategyGame.Core.Events.Presentation;

using System.Text.Json.Serialization;

/// <summary>
/// Base record for all presentation events (Category D: cosmetic).
/// Presentation events are NON-authoritative, cosmetic reactions derived from domain facts.
/// They must NEVER be authoritative gameplay state changes.
/// A visual animation finishing must not independently decide a game-rule outcome.
/// </summary>
[JsonPolymorphic(TypeDiscriminatorPropertyName = "$type")]
[JsonDerivedType(typeof(ShowAnimationEvent), "showAnimation")]
[JsonDerivedType(typeof(HighlightTerritoryEvent), "highlightTerritory")]
[JsonDerivedType(typeof(PlaySoundEvent), "playSound")]
[JsonDerivedType(typeof(DisplayNotificationEvent), "displayNotification")]
[JsonDerivedType(typeof(UpdateTerritoryVisualEvent), "updateTerritoryVisual")]
[JsonDerivedType(typeof(UpdatePlayerPanelEvent), "updatePlayerPanel")]
public abstract record PresentationEvent(
    long EventId,
    DateTime Timestamp,
    int SchemaVersion = 1);

/// <summary>
/// Request to show a battle/movement/effect animation.
/// </summary>
public sealed record ShowAnimationEvent(
    long EventId,
    DateTime Timestamp,
    string AnimationTypeKey,
    string? FromTerritoryId,
    string? ToTerritoryId,
    System.Collections.Generic.Dictionary<string, object> Parameters,
    int SchemaVersion = 1) : PresentationEvent(EventId, Timestamp, SchemaVersion);

/// <summary>
/// Request to highlight a territory on the map.
/// </summary>
public sealed record HighlightTerritoryEvent(
    long EventId,
    DateTime Timestamp,
    string TerritoryId,
    string HighlightTypeKey,
    float DurationSeconds,
    int SchemaVersion = 1) : PresentationEvent(EventId, Timestamp, SchemaVersion);

/// <summary>
/// Request to play a sound effect.
/// </summary>
public sealed record PlaySoundEvent(
    long EventId,
    DateTime Timestamp,
    string SoundKey,
    float Volume,
    int SchemaVersion = 1) : PresentationEvent(EventId, Timestamp, SchemaVersion);

/// <summary>
/// Request to display a notification to the player.
/// </summary>
public sealed record DisplayNotificationEvent(
    long EventId,
    DateTime Timestamp,
    string NotificationTypeKey,
    string Title,
    string Message,
    float DurationSeconds,
    int SchemaVersion = 1) : PresentationEvent(EventId, Timestamp, SchemaVersion);

/// <summary>
/// Request to update a territory's visual representation.
/// </summary>
public sealed record UpdateTerritoryVisualEvent(
    long EventId,
    DateTime Timestamp,
    string TerritoryId,
    string? OwnerPlayerId,
    int Armies,
    int SchemaVersion = 1) : PresentationEvent(EventId, Timestamp, SchemaVersion);

/// <summary>
/// Request to update a player's panel display.
/// </summary>
public sealed record UpdatePlayerPanelEvent(
    long EventId,
    DateTime Timestamp,
    string PlayerId,
    int ArmiesToPlace,
    System.Collections.Generic.IReadOnlyList<string> OwnedTerritoryIds,
    int SchemaVersion = 1) : PresentationEvent(EventId, Timestamp, SchemaVersion);