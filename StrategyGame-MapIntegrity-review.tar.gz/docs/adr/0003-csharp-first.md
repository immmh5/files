# ADR-0003: C# as Primary Language

**Status:** Accepted
**Date:** 2026-11-04

## Decision

Use **C#** as the primary language for all application code, including Godot scripts.

## Context

C# provides:
- Strong typing, nullable reference types, and modern language features (records, pattern matching, async/await).
- Excellent tooling: Rider, Visual Studio, VS Code with C# Dev Kit.
- Well-understood .NET type system and garbage collection.
- Seamless integration with Godot 4.x via the Mono/.NET edition.

### Alternatives Considered

| Alternative | Rejected Because |
|---|---|
| **GDScript only** | Lacks generics, nullable types, async/await; harder to unit test; less tooling |
| **GDScript + C# (mixed)** | Inconsistent language rules; harder to maintain; boundary unclear |
| **Rust via GDExtension** | No .NET runtime; Rust's ownership model adds complexity for game-logic prototyping; C++ level of complexity |

## Consequences

- **Positive:** One language across the entire codebase. No context switching.
- **Positive:** `StrategyGame.Core` uses C# 12 features (records, required members, file-scoped namespaces).
- **Positive:** Rider and VS Code have excellent C# support.
- **Negative:** GDScript has a slightly better Godot API ergonomic (signal connections, `OnReady` attributes, `Export` properties). C# requires more boilerplate for these.
- **Mitigation:** Use C# attributes (`[Export]`, `[Signal]`) for Godot-specific features. Keep Godot-specific code isolated in the App layer.

## Compiler Configuration

```xml
<PropertyGroup>
  <LangVersion>12</LangVersion>
  <Nullable>enable</Nullable>
  <ImplicitUsings>enable</ImplicitUsings>
  <TreatWarningsAsErrors>true</TreatWarningsAsErrors>
</PropertyGroup>
```
