namespace StrategyGame.Core.Tests.GameState;

using StrategyGame.Core.Domain;
using StrategyGame.Core.GameState;
using Xunit;

public class CombatSystemTests
{
    private MapDefinition CreateSmallMap()
    {
        var territories = new List<Territory>
        {
            new("A", "Alpha", ["B", "C"]),
            new("B", "Bravo", ["A", "C"]),
            new("C", "Charlie", ["A", "B"]),
        };
        return new MapDefinition("test-map", "Test Map", territories);
    }

    private GameState CreateGameState()
    {
        var map = CreateSmallMap();
        var player1 = new Player("p1", "Player 1",
            new Faction("f1", "Red", "#FF0000"), isHuman: true);
        var players = new List<Player> { player1 };

        var state = new GameState("g1", map, players, "p1", 1, TurnManager.PhaseAttack);

        // Set up territories
        state.GetTerritory("A").SetOwner("p1", 5);
        state.GetTerritory("B").SetOwner("p2", 3);
        state.GetTerritory("C").SetOwner("p1", 2);

        return state;
    }

    [Fact]
    public void ResolveAttack_AttackerHasMoreArmies_AttackerWins()
    {
        var state = CreateGameState();
        var result = CombatSystem.ResolveAttack(state, "A", "B");

        Assert.True(result.AttackerWon);
        Assert.Equal("B", result.CapturedTerritoryId);
    }

    [Fact]
    public void ResolveAttack_DefenderHasMoreOrEqualArmies_DefenderHolds()
    {
        var map = CreateSmallMap();
        var player1 = new Player("p1", "Player 1", new Faction("f1", "Red", "#FF0000"), isHuman: true);
        var player2 = new Player("p2", "Player 2", new Faction("f2", "Blue", "#0000FF"), isHuman: false);
        var players = new List<Player> { player1, player2 };

        var state = new GameState("g2", map, players, "p1", 1, TurnManager.PhaseAttack);

        // B has more armies than A
        state.GetTerritory("A").SetOwner("p1", 3);
        state.GetTerritory("B").SetOwner("p2", 5);

        var result = CombatSystem.ResolveAttack(state, "A", "B");

        Assert.False(result.AttackerWon);
        Assert.Null(result.CapturedTerritoryId);
    }

    [Fact]
    public void ResolveAttack_TerritoryNotFound_ThrowsArgumentException()
    {
        var state = CreateGameState();
        Assert.Throws<ArgumentException>(() => CombatSystem.ResolveAttack(state, "X", "Y"));
    }

    [Fact]
    public void ResolveAttack_NotAdjacent_ThrowsInvalidOperationException()
    {
        var map = new MapDefinition("test", "Test", new[]
        {
            new Territory("A", "A", []),
            new Territory("B", "B", []),
        });
        var player1 = new Player("p1", "Player 1", new Faction("f1", "Red", "#FF0000"), isHuman: true);
        var state = new GameState("g3", map, [player1], "p1", 1, TurnManager.PhaseAttack);
        state.GetTerritory("A").SetOwner("p1", 5);
        state.GetTerritory("B").SetOwner("p2", 2);

        // A and B are not adjacent
        Assert.Throws<InvalidOperationException>(() => CombatSystem.ResolveAttack(state, "A", "B"));
    }

    [Fact]
    public void ResolveAttack_AttackerOwnsTargetTerritory_ThrowsInvalidOperationException()
    {
        var state = CreateGameState();
        state.GetTerritory("B").SetOwner("p1", 3); // Same player owns both
        state.GetTerritory("A").SetOwner("p1", 5);

        // Attacking your own territory should not be allowed
        Assert.Throws<InvalidOperationException>(() => CombatSystem.ResolveAttack(state, "A", "B"));
    }

    [Fact]
    public void ResolveAttack_AttackerHasLessThanTwoArmies_ThrowsInvalidOperationException()
    {
        var state = CreateGameState();
        state.GetTerritory("A").SetOwner("p1", 1); // Only 1 army
        state.GetTerritory("B").SetOwner("p2", 2);

        Assert.Throws<InvalidOperationException>(() => CombatSystem.ResolveAttack(state, "A", "B"));
    }
}
