namespace StrategyGame.Core.Tests.Domain;

using StrategyGame.Core.Domain;
using Xunit;

/// <summary>
/// M1.1 — Region definitions: identity, configurable army bonus, validation.
/// </summary>
public class RegionDefinitionTests
{
    [Fact]
    public void ValidRegion_AssignsAllValues()
    {
        var region = new RegionDefinition("northlands", "Northlands", 2);

        Assert.Equal("northlands", region.Id);
        Assert.Equal("Northlands", region.Name);
        Assert.Equal(2, region.ArmyBonus);
    }

    [Fact]
    public void ZeroBonus_IsLegal()
    {
        var region = new RegionDefinition("r", "Region", 0);
        Assert.Equal(0, region.ArmyBonus);
    }

    [Theory]
    [InlineData(-1)]
    [InlineData(-5)]
    public void NegativeBonus_ThrowsArgumentOutOfRange(int bonus)
    {
        Assert.Throws<ArgumentOutOfRangeException>(
            () => new RegionDefinition("r", "Region", bonus));
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("   ")]
    public void EmptyOrWhitespaceId_ThrowsArgument(string? id)
    {
        Assert.Throws<ArgumentException>(() => new RegionDefinition(id!, "Region", 2));
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("   ")]
    public void EmptyOrWhitespaceName_ThrowsArgument(string? name)
    {
        Assert.Throws<ArgumentException>(() => new RegionDefinition("r", name!, 2));
    }
}
