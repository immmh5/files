namespace StrategyGame.Core.Events;

using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text.Json;
using System.Text.Json.Serialization;

/// <summary>
/// Event data model foundation (R4.3) — implements USER-APPROVED decisions D-16-1…D-16-7.
/// </summary>
public static class EventDataModel
{
    /// <summary>Shared serializer options: deterministic, camelCase, indented for debuggability.</summary>
    public static readonly JsonSerializerOptions SerializerOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        WriteIndented = false,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
    };
}

/// <summary>
/// Approved execution stages for scheduled events (D-16-3).
/// PlayerActions (Stage B) is deliberately absent — scheduled events can never
/// target Stage B, enforcing the approved phase-boundary rule at the type level.
/// </summary>
public enum ExecutionStage
{
    /// <summary>Stage A — Turn Start.</summary>
    TurnStart = 0,
    /// <summary>Stage C — Persistent Event Processing.</summary>
    EventProcessing = 2,
    /// <summary>Stage D — Turn End.</summary>
    TurnEnd = 3,
}

/// <summary>
/// Lifecycle status of a scheduled event record (EVENT_LIFECYCLE.md section 1).
/// Stored so cancelled/fired tombstones can be pruned or audited after restore.
/// </summary>
public enum ScheduledEventStatus
{
    /// <summary>The event is pending and awaiting execution.</summary>
    Pending = 0,
    /// <summary>The event is currently being executed.</summary>
    Executing = 1,
    /// <summary>The event fired successfully.</summary>
    Fired = 2,
    /// <summary>The event's handler threw an exception.</summary>
    Failed = 3,
    /// <summary>The event was cancelled.</summary>
    Cancelled = 4,
    /// <summary>The event's duration expired.</summary>
    Expired = 5,
}

/// <summary>
/// Timing discriminator: how the due-time of an event is measured (D-16-2).
/// Global = round-based; Player = the target player's own turn counter.
/// </summary>
public enum TimingKind
{
    /// <summary>Global effect measured against RoundIndex.</summary>
    Round = 0,
    /// <summary>Personal effect measured against the target player's own turn counter.</summary>
    Player = 1,
}

/// <summary>
/// Global (round-based) timing: fires when DueRoundIndex is reached.
/// </summary>
public sealed record RoundTiming(int DueRoundIndex)
{
    public RoundTiming() : this(0) { }
}

/// <summary>
/// Personal (player-turn-based) timing: fires when the target player's own
/// turn counter reaches DuePlayerTurnCount.
/// </summary>
public sealed record PlayerTurnTiming(string PlayerId, int DuePlayerTurnCount)
{
    public PlayerTurnTiming() : this("", 0) { }
}

/// <summary>
/// Strongly typed, fully serializable scheduled-event record (D-16-7).
/// Pure data — delegates/closures are structurally impossible here.
/// Behavior resolution by EventTypeKey against a handler registry is a later phase.
///
/// PAYLOAD OWNERSHIP: This record owns its payload data via eagerly-captured raw
/// JSON text snapshots (_payloadTextSnapshot). The Payload property returns a
/// ReadOnlyDictionary built from those text snapshots — consumers can never read
/// or mutate the original externally-owned JsonElement values.
/// </summary>
public sealed record ScheduledEventRecord
{
    /// <summary>Stable event identity (namespace-isolated, cross-process deterministic).</summary>
    public string EventId { get; init; } = "";

    /// <summary>Per-event-type schema version for migration (D-16-7).</summary>
    public int SchemaVersion { get; init; } = 1;

    /// <summary>Registry key resolving the behavior at execution time. Not a CLR type name.</summary>
    public string EventTypeKey { get; init; } = "";

    /// <summary>TurnSequence at which this event was scheduled (provenance + ordering).</summary>
    public int ScheduledAtTurnSequence { get; init; }

    /// <summary>Stage this event fires during. Never PlayerActions (D-16-3).</summary>
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public ExecutionStage ExecutionStage { get; init; } = ExecutionStage.EventProcessing;

    /// <summary>Priority: lower runs first within the same due moment.</summary>
    public int Priority { get; init; }

    /// <summary>Match-scoped monotonic sequence; final tie-breaker in the total order.</summary>
    public long SequenceNumber { get; init; }

    /// <summary>Round-based timing for global effects (D-16-2). Null for personal effects.</summary>
    public RoundTiming? RoundTiming { get; init; }

    /// <summary>Player-turn timing for personal effects (D-16-2). Null for global effects.</summary>
    public PlayerTurnTiming? PlayerTiming { get; init; }

    /// <summary>
    /// Serializable parameters bag (typed per EventTypeKey by the registry).
    /// Returns an immutable snapshot (ReadOnlyDictionary); the caller cannot mutate
    /// the stored payload. Even a cast back to Dictionary throws InvalidCastException.
    /// </summary>
    [JsonIgnore]
    public IReadOnlyDictionary<string, JsonElement> Payload => _payloadSnapshot;

    /// <summary>Lifecycle status; tombstones (Cancelled/Fired) are pruned at stage boundaries.</summary>
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public ScheduledEventStatus Status { get; init; } = ScheduledEventStatus.Pending;

    // Internal mutable dictionary used during deserialization; frozen into _payloadSnapshot after.
    [JsonInclude]
    [JsonPropertyName("payload")]
    internal Dictionary<string, JsonElement>? _payloadForDeserialization { get; init; }

    /// <summary>
    /// Eagerly-captured raw JSON text for each payload key, populated at construction/deserialization
    /// time so that disposed JsonDocuments cannot invalidate the snapshot.
    /// </summary>
    [JsonIgnore]
    private IReadOnlyDictionary<string, string>? _payloadTextSnapshot;

    /// <summary>
    /// Initializes the eagerly-captured text snapshot from the mutable deserialization dictionary.
    /// Must be called after _payloadForDeserialization is set.
    /// </summary>
    internal void CapturePayloadSnapshot()
    {
        if (_payloadForDeserialization != null && _payloadTextSnapshot == null)
        {
            _payloadTextSnapshot = new Dictionary<string, string>(
                _payloadForDeserialization.ToDictionary(kv => kv.Key, kv => kv.Value.GetRawText()));
        }
    }

    /// <summary>
    /// Immutable snapshot of the payload. Created during deserialization/construction.
    /// Returns a ReadOnlyDictionary rebuilt from eagerly-captured raw JSON text;
    /// casts to mutable Dictionary fail with InvalidCastException.
    /// </summary>
    [JsonIgnore]
    private IReadOnlyDictionary<string, JsonElement> _payloadSnapshot =>
        _payloadTextSnapshot != null
            ? new ReadOnlyDictionary<string, JsonElement>(
                _payloadTextSnapshot.ToDictionary(
                    kv => kv.Key,
                    kv => JsonSerializer.Deserialize<JsonElement>(kv.Value, EventDataModel.SerializerOptions)!))
            : _emptyPayload;

    private static readonly IReadOnlyDictionary<string, JsonElement> _emptyPayload =
        new ReadOnlyDictionary<string, JsonElement>(new Dictionary<string, JsonElement>());

    /// <summary>The timing kind for this record. Throws if the record has neither or both
    /// timing entries (exactly one is required).</summary>
    [JsonIgnore]
    public TimingKind TimingKind => (RoundTiming, PlayerTiming) switch
    {
        (not null, null) => TimingKind.Round,
        (null, not null) => TimingKind.Player,
        _ => throw new InvalidOperationException(
            $"Event '{EventId}' must have exactly one of RoundTiming or PlayerTiming."),
    };

    /// <summary>Serializes this record to versioned JSON (D-16-7).</summary>
    /// <remarks>
    /// Serializes from the eagerly-captured text snapshot (_payloadTextSnapshot),
    /// NOT from the caller's original dictionary (_payloadForDeserialization).
    /// This ensures external mutation and disposed JsonDocuments cannot affect output.
    /// </remarks>
    public string ToJson()
    {
        // Build a serialization-friendly payload dictionary from the text snapshot
        var serializablePayload = _payloadTextSnapshot != null
            ? _payloadTextSnapshot.ToDictionary(
                kv => kv.Key,
                kv => JsonSerializer.Deserialize<JsonElement>(kv.Value, EventDataModel.SerializerOptions)!)
            : new Dictionary<string, JsonElement>();

        // Use anonymous object to control serialization (avoid writing _payloadForDeserialization)
        var serializableRecord = new
        {
            EventId,
            SchemaVersion,
            EventTypeKey,
            ScheduledAtTurnSequence,
            ExecutionStage,
            Priority,
            SequenceNumber,
            RoundTiming,
            PlayerTiming,
            payload = serializablePayload,
            Status
        };
        return JsonSerializer.Serialize(serializableRecord, EventDataModel.SerializerOptions);
    }

    /// <summary>
    /// Deserializes a record from JSON, validating structure and semantics.
    /// Throws <see cref="ScheduledEventValidationException"/> on any inconsistency —
    /// this is the "reject restoration loudly" path of D-16-6.
    /// </summary>
    public static ScheduledEventRecord FromJson(string json)
    {
        ScheduledEventRecord? record;
        try
        {
            record = JsonSerializer.Deserialize<ScheduledEventRecord>(json, EventDataModel.SerializerOptions);
        }
        catch (JsonException ex)
        {
            throw new ScheduledEventValidationException("<unreadable>", $"Malformed JSON: {ex.Message}");
        }

        if (record is null)
            throw new ScheduledEventValidationException("<null>", "Deserialized record was null.");

        record.CapturePayloadSnapshot();
        record.Validate();
        return record;
    }

    /// <summary>
    /// Structural + semantic validation. Unknown event TYPE KEYS are checked by the
    /// handler registry in a later phase (D-16-6); this method enforces the data
    /// invariants that make the record restorable at all.
    /// </summary>
    public void Validate()
    {
        if (string.IsNullOrWhiteSpace(EventId))
            throw new ScheduledEventValidationException(EventId, "EventId is required.");
        if (string.IsNullOrWhiteSpace(EventTypeKey))
            throw new ScheduledEventValidationException(EventId, "EventTypeKey is required.");
        if (SchemaVersion < 1)
            throw new ScheduledEventValidationException(EventId, $"SchemaVersion must be >= 1 (got {SchemaVersion}).");
        if (SequenceNumber < 0)
            throw new ScheduledEventValidationException(EventId, $"SequenceNumber must be >= 0 (got {SequenceNumber}).");
        if (ScheduledAtTurnSequence < 0)
            throw new ScheduledEventValidationException(EventId, $"ScheduledAtTurnSequence must be >= 0 (got {ScheduledAtTurnSequence}).");

        // Exactly one timing entry (D-16-2).
        switch ((RoundTiming, PlayerTiming))
        {
            case (not null, not null):
                throw new ScheduledEventValidationException(EventId,
                    "Event cannot have both RoundTiming and PlayerTiming.");
            case (null, null):
                throw new ScheduledEventValidationException(EventId,
                    "Event must have exactly one of RoundTiming or PlayerTiming.");
            case ({ } round, _):
                if (round.DueRoundIndex < 0)
                    throw new ScheduledEventValidationException(EventId,
                        $"DueRoundIndex must be >= 0 (got {round.DueRoundIndex}).");
                break;
            case (_, { } player):
                if (string.IsNullOrWhiteSpace(player.PlayerId))
                    throw new ScheduledEventValidationException(EventId,
                        "PlayerTiming requires a PlayerId.");
                if (player.DuePlayerTurnCount < 0)
                    throw new ScheduledEventValidationException(EventId,
                        $"DuePlayerTurnCount must be >= 0 (got {player.DuePlayerTurnCount}).");
                break;
        }
    }

    /// <summary>
    /// Gets the typed payload DTO for this event using the registry.
    /// Performs schema version check, strict deserialization, and semantic validation.
    /// </summary>
    /// <returns>The typed payload DTO.</returns>
    /// <exception cref="EventTypeRegistryException">On unknown type, unsupported version, or malformed payload.</exception>
    /// <exception cref="ScheduledEventValidationException">On semantic validation failure.</exception>
    public object GetTypedPayload()
    {
        return EventTypeRegistry.DeserializeAndValidatePayload(this);
    }

    /// <summary>
    /// Creates a scheduled event record with the given payload dictionary.
    /// Used primarily in tests to construct records without going through JSON serialization.
    /// </summary>
    internal static ScheduledEventRecord CreateWithPayload(
        string eventId,
        string eventTypeKey,
        int schemaVersion,
        RoundTiming? roundTiming,
        PlayerTurnTiming? playerTiming,
        Dictionary<string, JsonElement> payload)
    {
        var record = new ScheduledEventRecord
        {
            EventId = eventId,
            EventTypeKey = eventTypeKey,
            SchemaVersion = schemaVersion,
            RoundTiming = roundTiming,
            PlayerTiming = playerTiming,
            _payloadForDeserialization = payload,
        };
        record.CapturePayloadSnapshot();
        return record;
    }
}

/// <summary>
/// Thrown when a scheduled-event record fails structural/semantic validation during
/// deserialization. Per D-16-6, this is a LOUD failure — authoritative events are
/// never silently dropped on restore.
/// </summary>
public sealed class ScheduledEventValidationException(string eventId, string message)
    : Exception($"Scheduled event '{eventId}' failed validation: {message}")
{
    public string EventId { get; } = eventId;
}