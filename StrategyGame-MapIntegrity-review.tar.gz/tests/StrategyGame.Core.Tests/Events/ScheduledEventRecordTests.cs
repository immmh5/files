namespace StrategyGame.Core.Tests.Events;

using System.Text.Json;
using StrategyGame.Core.Events;
using Xunit;

/// <summary>
/// R4.3 regression tests: event data model, timing metadata, versioned JSON
/// serialization, validation, and schema-compatibility foundations.
/// </summary>
public class ScheduledEventRecordTests
{
    private const string Json_RoundTimed =
        """{"eventId":"evt_abc123","schemaVersion":1,"eventTypeKey":"autumn_attrition","scheduledAtTurnSequence":7,"executionStage":"TurnStart","priority":0,"sequenceNumber":1,"roundTiming":{"dueRoundIndex":3},"payload":{"regions":["north"]},"status":"Pending"}""";

    private const string Json_PlayerTimed =
        """{"eventId":"evt_def456","schemaVersion":2,"eventTypeKey":"berserk_rage","scheduledAtTurnSequence":4,"executionStage":"EventProcessing","priority":5,"sequenceNumber":2,"playerTiming":{"playerId":"p2","duePlayerTurnCount":9},"status":"Pending"}""";

    // ------------------------------------------------------------------
    // Deserialization: round-timed global effect
    // ------------------------------------------------------------------

    [Fact]
    public void FromJson_RoundTimed_ParsesAllFields()
    {
        var rec = ScheduledEventRecord.FromJson(Json_RoundTimed);

        Assert.Equal("evt_abc123", rec.EventId);
        Assert.Equal(1, rec.SchemaVersion);
        Assert.Equal("autumn_attrition", rec.EventTypeKey);
        Assert.Equal(7, rec.ScheduledAtTurnSequence);
        Assert.Equal(ExecutionStage.TurnStart, rec.ExecutionStage);
        Assert.Equal(0, rec.Priority);
        Assert.Equal(1, rec.SequenceNumber);
        Assert.Equal(3, rec.RoundTiming!.DueRoundIndex);
        Assert.Null(rec.PlayerTiming);
        Assert.Equal(TimingKind.Round, rec.TimingKind);
        Assert.Equal(ScheduledEventStatus.Pending, rec.Status);
        Assert.True(rec.Payload!.ContainsKey("regions"));
    }

    // ------------------------------------------------------------------
    // Deserialization: player-timed personal effect
    // ------------------------------------------------------------------

    [Fact]
    public void FromJson_PlayerTimed_ParsesAllFields()
    {
        var rec = ScheduledEventRecord.FromJson(Json_PlayerTimed);

        Assert.Equal("evt_def456", rec.EventId);
        Assert.Equal(2, rec.SchemaVersion);
        Assert.Equal("berserk_rage", rec.EventTypeKey);
        Assert.Equal(ExecutionStage.EventProcessing, rec.ExecutionStage);
        Assert.Equal("p2", rec.PlayerTiming!.PlayerId);
        Assert.Equal(9, rec.PlayerTiming.DuePlayerTurnCount);
        Assert.Null(rec.RoundTiming);
        Assert.Equal(TimingKind.Player, rec.TimingKind);
    }

    // ------------------------------------------------------------------
    // Round-trip serialization (D-16-7)
    // ------------------------------------------------------------------

    [Fact]
    public void ToJson_FromJson_RoundTrip_PreservesAllFields()
    {
        var original = ScheduledEventRecord.CreateWithPayload(
            "evt_rt1", "border_fort", 3, null,
            new PlayerTurnTiming("p5", 8),
            new() { ["territoryId"] = JsonSerializer.SerializeToElement("t12"),
                    ["bonus"] = JsonSerializer.SerializeToElement(2) });

        var restored = ScheduledEventRecord.FromJson(original.ToJson());

        // Compare via JSON because JsonElement in Payload doesn't implement value equality
        Assert.Equal(original.ToJson(), restored.ToJson());
    }

    [Fact]
    public void ToJson_RoundTimed_RoundTrip_PreservesAllFields()
    {
        var original = new ScheduledEventRecord
        {
            EventId = "evt_rt2",
            EventTypeKey = "harvest",
            ScheduledAtTurnSequence = 3,
            ExecutionStage = ExecutionStage.EventProcessing,
            SequenceNumber = 7,
            RoundTiming = new RoundTiming(5),
        };

        var restored = ScheduledEventRecord.FromJson(original.ToJson());

        // Compare via JSON because Payload is a reconstructed ReadOnlyDictionary
        Assert.Equal(original.ToJson(), restored.ToJson());
    }

    [Fact]
    public void ToJson_UsesCamelCaseAndIncludesSchemaVersion()
    {
        var json = new ScheduledEventRecord { EventId = "e", EventTypeKey = "k" }.ToJson();

        Assert.Contains("\"schemaVersion\":1", json);
        Assert.Contains("\"eventTypeKey\":", json);
        Assert.Contains("\"scheduledAtTurnSequence\":", json);
    }

    // ------------------------------------------------------------------
    // Stage-B exclusion is structural (D-16-3)
    // ------------------------------------------------------------------

    [Fact]
    public void ExecutionStage_HasNoPlayerActionsValue()
    {
        var values = Enum.GetValues<ExecutionStage>();
        Assert.DoesNotContain(values, v => v.ToString().Contains("PlayerAction"));
        Assert.Equal([ExecutionStage.TurnStart, ExecutionStage.EventProcessing, ExecutionStage.TurnEnd],
            values);
    }

    [Fact]
    public void FromJson_UnknownStageString_ThrowsValidation()
    {
        const string json = """{"eventId":"e","eventTypeKey":"k","executionStage":"PlayerActions","roundTiming":{"dueRoundIndex":1}}""";

        var ex = Assert.ThrowsAny<Exception>(() => ScheduledEventRecord.FromJson(json));
        Assert.IsType<ScheduledEventValidationException>(ex);
    }

    // ------------------------------------------------------------------
    // Validation: loud failures (D-16-6)
    // ------------------------------------------------------------------

    [Theory]
    [InlineData("""{"eventId":"","eventTypeKey":"k","roundTiming":{"dueRoundIndex":1}}""", "EventId")]
    [InlineData("""{"eventId":"e","eventTypeKey":"","roundTiming":{"dueRoundIndex":1}}""", "EventTypeKey")]
    [InlineData("""{"eventId":"e","eventTypeKey":"k","schemaVersion":0,"roundTiming":{"dueRoundIndex":1}}""", "SchemaVersion")]
    [InlineData("""{"eventId":"e","eventTypeKey":"k","sequenceNumber":-1,"roundTiming":{"dueRoundIndex":1}}""", "SequenceNumber")]
    [InlineData("""{"eventId":"e","eventTypeKey":"k","roundTiming":{"dueRoundIndex":-1}}""", "DueRoundIndex")]
    [InlineData("""{"eventId":"e","eventTypeKey":"k","playerTiming":{"playerId":"","duePlayerTurnCount":1}}""", "PlayerId")]
    [InlineData("""{"eventId":"e","eventTypeKey":"k","playerTiming":{"playerId":"p","duePlayerTurnCount":-1}}""", "DuePlayerTurnCount")]
    public void FromJson_InvalidFields_ThrowsWithDiagnostic(string json, string expectedFragment)
    {
        var ex = Assert.Throws<ScheduledEventValidationException>(
            () => ScheduledEventRecord.FromJson(json));
        Assert.Contains(expectedFragment, ex.Message);
    }

    [Fact]
    public void FromJson_BothTimings_Throws()
    {
        const string json = """{"eventId":"e","eventTypeKey":"k","roundTiming":{"dueRoundIndex":1},"playerTiming":{"playerId":"p","duePlayerTurnCount":1}}""";

        var ex = Assert.Throws<ScheduledEventValidationException>(
            () => ScheduledEventRecord.FromJson(json));
        Assert.Contains("both", ex.Message);
    }

    [Fact]
    public void FromJson_NeitherTiming_Throws()
    {
        const string json = """{"eventId":"e","eventTypeKey":"k"}""";

        var ex = Assert.Throws<ScheduledEventValidationException>(
            () => ScheduledEventRecord.FromJson(json));
        Assert.Contains("exactly one", ex.Message);
    }

    [Fact]
    public void FromJson_MalformedJson_ThrowsWithDiagnostic()
    {
        var ex = Assert.Throws<ScheduledEventValidationException>(
            () => ScheduledEventRecord.FromJson("{not json"));
        Assert.Contains("Malformed JSON", ex.Message);
    }

    // ------------------------------------------------------------------
    // Equality + immutability sanity (records are init-only)
    // ------------------------------------------------------------------

    [Fact]
    public void Records_WithSameValues_AreEqual()
    {
        var a = new ScheduledEventRecord { EventId = "e", EventTypeKey = "k", RoundTiming = new RoundTiming(1) };
        var b = new ScheduledEventRecord { EventId = "e", EventTypeKey = "k", RoundTiming = new RoundTiming(1) };
        Assert.Equal(a, b);

        var c = b with { Priority = 9 };
        Assert.NotEqual(a, c);
    }

    // ------------------------------------------------------------------
    // RoundIndex independence guard (D-16-1): no derivation anywhere in type
    // ------------------------------------------------------------------

    [Fact]
    public void ScheduledEventRecord_ExposesNoPlayerCountDerivedRoundProperty()
    {
        var members = typeof(ScheduledEventRecord).GetProperties();
        Assert.DoesNotContain(members, p => p.Name is "PlayerCount" or "DerivedRound");
        // RoundIndex lives in RoundTiming only; record holds no computed round.
        Assert.DoesNotContain(members, p => p.Name == "RoundIndex");
    }

    // ------------------------------------------------------------------
    // Presentation events are not part of this model (D-16-6 category split)
    // ------------------------------------------------------------------

    [Fact]
    public void EventDataModel_HasNoPresentationEventTypes()
    {
        // Presentation events live app-side (EVENT_ARCHITECTURE §2); the Core
        // Events namespace must not define any presentation event record.
        var coreEventTypes = typeof(EventDataModel).Assembly.GetTypes()
            .Where(t => t.Namespace == "StrategyGame.Core.Events")
            .ToList();

        Assert.DoesNotContain(coreEventTypes, t =>
            t.Name.Contains("ShowAnimation", StringComparison.OrdinalIgnoreCase) ||
            t.Name.Contains("PlaySound", StringComparison.OrdinalIgnoreCase) ||
            t.Name.Contains("Highlight", StringComparison.OrdinalIgnoreCase));
    }
}