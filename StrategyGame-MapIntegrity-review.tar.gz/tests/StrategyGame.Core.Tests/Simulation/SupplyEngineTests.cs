namespace StrategyGame.Core.Tests.Simulation;

using StrategyGame.Core.Domain;
using StrategyGame.Core.GameState;
using StrategyGame.Core.Simulation;
using Xunit;

/// <summary>
/// M1.2 — SupplyEngine tests: BFS connectivity from owned supply sources
/// through owned territories; blocking, cycles, isolation, determinism.
/// </summary>
public class SupplyEngineTests
{
    private static GameState CreateState()
    {
        var map = new MapDefinition(
            "supply-map", "Supply Test Map", new[]
            {
                new Territory("a1", "One", ["a2"], TerrainType.Plains, "r1", isSupplySource: true),
                new Territory("a2", "Two", ["a1", "a3"], TerrainType.Plains, "r1", isSupplySource: false),
                new Territory("a3", "Three", ["a2"], TerrainType.Hills, "r1", isSupplySource: false),
                new Territory("b1", "BOne", ["b2"], TerrainType.Plains, "r2", isSupplySource: true),
                new Territory("b2", "BTwo", ["b1"], TerrainType.Plains, "r2", isSupplySource: false),
                new Territory("i1", "Isolated", [], TerrainType.Forest, null, isSupplySource: false),
            },
            [new RegionDefinition("r1", "Region One", 2), new RegionDefinition("r2", "Region Two", 3)]);

        var players = new List<Player>
        {
            new("p1", "One", new Faction("f1", "Red", "#FF0000"), true),
            new("p2", "Two", new Faction("f2", "Blue", "#0000FF"), false),
        };
        return new GameState("g", map, players, "p1", 1, "Reinforce");
    }

    private static void Own(GameState state, string playerId, params string[] ids)
    {
        foreach (var id in ids)
            state.GetTerritory(id).SetOwner(playerId, 3);
    }

    [Fact]
    public void CalculateSupply_SingleOwnedSource_AllConnectedOwnedTerritoriesSupplied()
    {
        var state = CreateState();
        Own(state, "p1", "a1", "a2", "a3"); // a1 is the source

        var result = SupplyEngine.CalculateSupply(state, "p1");

        Assert.True(result.HasOwnedSource);
        Assert.Equal(["a1"], result.SourceTerritoryIds);
        Assert.Equal(["a1", "a2", "a3"], result.SuppliedTerritoryIds);
        Assert.Equal(3, result.OwnedTerritoryCount);
    }

    [Fact]
    public void CalculateSupply_MultipleOwnedSources_UnionOfFloodFills()
    {
        var state = CreateState();
        Own(state, "p1", "a1", "a2", "a3", "b1", "b2"); // sources a1 + b1

        var result = SupplyEngine.CalculateSupply(state, "p1");

        Assert.Equal(["a1", "b1"], result.SourceTerritoryIds);
        Assert.Equal(5, result.SuppliedTerritoryIds.Count);
        Assert.Empty(result.UnsuppliedTerritoryIds);
    }

    [Fact]
    public void CalculateSupply_NeutralTerritoryBlocksConnectivity()
    {
        var state = CreateState();
        Own(state, "p1", "a1", "a2", "a3");
        // a2 stays owned by p1 but insert a neutral blocker by rewiring? Adjacency is
        // immutable; instead give p1 the chain except the middle: a1 (source) owned,
        // a2 set OWNED-BY-NOBODY (neutral blocker), a3 owned at end.
        state.GetTerritory("a2").SetOwner(null, 0);

        var result = SupplyEngine.CalculateSupply(state, "p1");

        Assert.Equal(["a1"], result.SuppliedTerritoryIds);
        Assert.Equal(["a3"], result.UnsuppliedTerritoryIds);
    }

    [Fact]
    public void CalculateSupply_EnemyTerritoryBlocksConnectivity()
    {
        var state = CreateState();
        Own(state, "p1", "a1", "a3"); // a2 owned by enemy
        Own(state, "p2", "a2");

        var result = SupplyEngine.CalculateSupply(state, "p1");

        Assert.Equal(["a1"], result.SuppliedTerritoryIds);
        Assert.Equal(["a3"], result.UnsuppliedTerritoryIds);
    }

    [Fact]
    public void CalculateSupply_DisconnectedOwnedPocket_IsUnsupplied()
    {
        var state = CreateState();
        Own(state, "p1", "a1", "a2", "i1"); // i1 isolated owned pocket

        var result = SupplyEngine.CalculateSupply(state, "p1");

        Assert.Equal(["a1", "a2"], result.SuppliedTerritoryIds);
        Assert.Equal(["i1"], result.UnsuppliedTerritoryIds);
        Assert.Contains(result.Diagnostics, d => d.Contains("not reachable"));
    }

    [Fact]
    public void CalculateSupply_SourceOwnedByEnemy_DoesNotSupplyPlayer()
    {
        var state = CreateState();
        Own(state, "p1", "a2", "a3"); // chain but NOT the source a1
        Own(state, "p2", "a1");       // source held by enemy

        var result = SupplyEngine.CalculateSupply(state, "p1");

        Assert.False(result.HasOwnedSource);
        Assert.Empty(result.SourceTerritoryIds);       // no OWNED source
        Assert.Empty(result.SuppliedTerritoryIds);
        Assert.Equal(["a2", "a3"], result.UnsuppliedTerritoryIds);
    }

    [Fact]
    public void CalculateSupply_PlayerOwnsNoSource_EverythingUnsuppliedWithDiagnostic()
    {
        var state = CreateState();
        Own(state, "p1", "a2", "b2"); // no source among owned

        var result = SupplyEngine.CalculateSupply(state, "p1");

        Assert.False(result.HasOwnedSource);
        Assert.Empty(result.SuppliedTerritoryIds);
        Assert.Equal(["a2", "b2"], result.UnsuppliedTerritoryIds); // sorted ordinally
        Assert.Contains(result.Diagnostics, d => d.Contains("owns no supply source"));
    }

    [Fact]
    public void CalculateSupply_SourceNotOwnedAtAll_NoneSupplied()
    {
        // Nobody owns the sources; nobody is supplied.
        var state = CreateState();
        Own(state, "p1", "a2", "a3");

        var result = SupplyEngine.CalculateSupply(state, "p1");

        Assert.Equal([ "a2", "a3" ], result.UnsuppliedTerritoryIds);
        Assert.Empty(result.SuppliedTerritoryIds);
    }

    [Fact]
    public void CalculateSupply_CycleGraph_TerminatesAndSuppliesAll()
    {
        var map = new MapDefinition("ring", "Ring", new[]
        {
            new Territory("c1", "C1", ["c2", "c3"], TerrainType.Plains, null, isSupplySource: true),
            new Territory("c2", "C2", ["c1", "c3"], TerrainType.Plains, null, isSupplySource: false),
            new Territory("c3", "C3", ["c2", "c1"], TerrainType.Plains, null, isSupplySource: false),
        }, []);
        var players = new List<Player>
        {
            new("p1", "One", new Faction("f1", "Red", "#FF0000"), true),
        };
        var state = new GameState("g", map, players, "p1", 1, "Reinforce");
        Own(state, "p1", "c1", "c2", "c3");

        var result = SupplyEngine.CalculateSupply(state, "p1");

        Assert.Equal(["c1", "c2", "c3"], result.SuppliedTerritoryIds);
        Assert.Empty(result.UnsuppliedTerritoryIds);
    }

    [Fact]
    public void CalculateSupply_SourceLostDuringMatch_PlayerLosesAllSupplyOnRecompute()
    {
        var state = CreateState();
        Own(state, "p1", "a1", "a2", "a3", "i1");

        // Match-time: p2 captures the only source.
        state.GetTerritory("a1").SetOwner("p2", 5);

        var result = SupplyEngine.CalculateSupply(state, "p1");

        Assert.False(result.HasOwnedSource);
        Assert.Empty(result.SuppliedTerritoryIds);
        Assert.Equal(["a2", "a3", "i1"], result.UnsuppliedTerritoryIds);
    }

    [Fact]
    public void CalculateSupply_StateNotMutated()
    {
        var state = CreateState();
        Own(state, "p1", "a1", "a2", "i1");
        var before = state.GetTerritory("i1").Armies;

        _ = SupplyEngine.CalculateSupply(state, "p1");
        _ = SupplyEngine.CalculateSupply(state, "p2");

        Assert.Equal(before, state.GetTerritory("i1").Armies);
        Assert.Equal("p1", state.GetTerritory("i1").OwnerPlayerId); // unchanged ownership
    }

    [Fact]
    public void CalculateSupply_ResultOrdering_IsDeterministicAndSorted()
    {
        var state = CreateState();
        Own(state, "p1", "a1", "a2", "a3", "b1", "b2", "i1");

        var first = SupplyEngine.CalculateSupply(state, "p1");
        var second = SupplyEngine.CalculateSupply(state, "p1");

        Assert.Equal(first.SuppliedTerritoryIds, second.SuppliedTerritoryIds);
        Assert.Equal(first.UnsuppliedTerritoryIds, second.UnsuppliedTerritoryIds);
        Assert.Equal(first.SourceTerritoryIds, second.SourceTerritoryIds);

        Assert.Equal(first.SuppliedTerritoryIds, first.SuppliedTerritoryIds.OrderBy(x => x, StringComparer.Ordinal));
        Assert.Equal(first.UnsuppliedTerritoryIds, first.UnsuppliedTerritoryIds.OrderBy(x => x, StringComparer.Ordinal));
    }

    // ---------------------------------------------------------------
    // Validation
    // ---------------------------------------------------------------

    [Fact]
    public void CalculateSupply_UnknownPlayer_ThrowsKeyNotFound()
    {
        var state = CreateState();
        Assert.Throws<KeyNotFoundException>(() => SupplyEngine.CalculateSupply(state, "ghost"));
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    public void CalculateSupply_EmptyPlayerId_ThrowsArgument(string playerId)
    {
        var state = CreateState();
        Assert.Throws<ArgumentException>(() => SupplyEngine.CalculateSupply(state, playerId));
    }

    [Fact]
    public void CalculateSupply_NullStateOrPlayer_ThrowsArgumentNull()
    {
        var state = CreateState();
        Assert.Throws<ArgumentNullException>(() => SupplyEngine.CalculateSupply(null!, "p1"));
        Assert.Throws<ArgumentNullException>(() => SupplyEngine.CalculateSupply(state, null!));
    }

    // ---------------------------------------------------------------
    // REVIEW v2: returned collections are genuinely read-only.
    // ---------------------------------------------------------------

    [Fact]
    public void SupplyResult_CollectionsAreDefensivelyReadOnly()
    {
        var state = CreateState();
        Own(state, "p1", "a1", "a2");
        var result = SupplyEngine.CalculateSupply(state, "p1");

        foreach (var collection in new IReadOnlyList<string>[]
                 {
                     result.SuppliedTerritoryIds,
                     result.UnsuppliedTerritoryIds,
                     result.SourceTerritoryIds,
                     result.Diagnostics,
                 })
        {
            // Cannot cast back to a mutable List<string>.
            Assert.Throws<InvalidCastException>(() => (List<string>)collection);

            // The read-only wrapper also blocks IList-level mutation attempts.
            var asIList = (System.Collections.IList)collection;
            Assert.Throws<NotSupportedException>(() => asIList.Add("mutant"));
            Assert.Throws<NotSupportedException>(() => asIList.Clear());
        }

        Assert.Equal(2, result.SuppliedTerritoryIds.Count); // unchanged after attempts
    }
}
