namespace StrategyGame.Core.Domain;

using System.Globalization;

/// <summary>
/// M1.1 — Validates map definitions before they can be used.
///
/// Static, pure, deterministic: returns every diagnostic found. A map with zero
/// diagnostics is valid. MapDefinition calls this at construction time so an
/// invalid map cannot exist.
///
/// Checks (per M1.1 requirements):
/// - Map id and name present.
/// - Unique territory ids; territory id/name present.
/// - Adjacency references resolve to declared territories; no self-adjacency.
/// - Unique region ids; region id/name present; non-negative army bonus.
/// - Territory region references resolve to declared regions.
/// - Region/geometry data keyed by existing territory ids.
/// </summary>
public static class MapValidator
{
    /// <summary>
    /// Validates a map definition and returns all diagnostics found.
    /// An empty result means the map is valid.
    /// </summary>
    public static IReadOnlyList<string> Validate(
        string? mapId,
        string? mapName,
        IReadOnlyCollection<Territory> territories,
        IReadOnlyCollection<RegionDefinition> regions,
        IReadOnlyDictionary<string, TerritoryGeometry>? geometry = null)
    {
        List<string> diagnostics = [];

        if (string.IsNullOrWhiteSpace(mapId))
            diagnostics.Add("Map id must not be null or empty.");
        if (string.IsNullOrWhiteSpace(mapName))
            diagnostics.Add($"Map name must not be null or empty (map id: '{mapId ?? "<null>"}').");

        // --- Territories ---------------------------------------------------
        var seenTerritoryIds = new HashSet<string>(StringComparer.Ordinal);
        var declaredIds = new HashSet<string>(StringComparer.Ordinal);

        foreach (var t in territories)
        {
            if (t is null)
            {
                diagnostics.Add("Territory list contains a null entry.");
                continue;
            }

            if (!seenTerritoryIds.Add(t.Id))
                diagnostics.Add($"Duplicate territory id: '{t.Id}'.");
            if (string.IsNullOrWhiteSpace(t.Id))
                diagnostics.Add($"Territory '{t.Id}' has an empty or whitespace id.");
            if (string.IsNullOrWhiteSpace(t.Name))
                diagnostics.Add($"Territory '{t.Id}' has an empty or whitespace name.");

            declaredIds.Add(t.Id); // still collected so reference checks see it

            if (t.AdjacentTerritoryIds.Contains(t.Id, StringComparer.Ordinal))
                diagnostics.Add($"Territory '{t.Id}' is adjacent to itself.");

            // Duplicate adjacency IDs within one territory
            var seenAdj = new HashSet<string>(StringComparer.Ordinal);
            foreach (var adjId in t.AdjacentTerritoryIds)
            {
                if (adjId is not null && adjId.Length > 0 && !seenAdj.Add(adjId))
                    diagnostics.Add($"Territory '{t.Id}' lists duplicate adjacent territory '{adjId}'.");
            }

            foreach (var adjId in t.AdjacentTerritoryIds)
            {
                if (adjId is null)
                    diagnostics.Add($"Territory '{t.Id}' has a null adjacency reference.");
                else if (adjId.Length == 0)
                    diagnostics.Add($"Territory '{t.Id}' has an empty adjacency reference.");
            }
        }

        // --- NEW M1.1 correction: asymmetric adjacency ---
        foreach (var t in territories)
        {
            if (t is null) continue;
            foreach (var adjId in t.AdjacentTerritoryIds)
            {
                if (adjId is null || adjId.Length == 0) continue;
                var neighbor = territories.FirstOrDefault(x => x is not null && x.Id == adjId);
                if (neighbor is not null && !neighbor.AdjacentTerritoryIds.Contains(t.Id, StringComparer.Ordinal))
                {
                    diagnostics.Add($"Asymmetric adjacency: territory '{t.Id}' references '{adjId}' but '{adjId}' does not reference '{t.Id}'.");
                }
            }
        }

        foreach (var t in territories)
        {
            if (t is null) continue;
            foreach (var adjId in t.AdjacentTerritoryIds)
            {
                if (adjId is not null && !declaredIds.Contains(adjId))
                    diagnostics.Add($"Territory '{t.Id}' references unknown adjacent territory '{adjId}'.");
            }
        }

        // --- Regions -------------------------------------------------------
        var seenRegionIds = new HashSet<string>(StringComparer.Ordinal);
        var declaredRegionIds = new HashSet<string>(StringComparer.Ordinal);

        foreach (var r in regions)
        {
            if (r is null)
            {
                diagnostics.Add("Region list contains a null entry.");
                continue;
            }

            if (!seenRegionIds.Add(r.Id))
                diagnostics.Add($"Duplicate region id: '{r.Id}'.");
            if (string.IsNullOrWhiteSpace(r.Name))
                diagnostics.Add($"Region '{r.Id}' has an empty or whitespace name.");
            if (r.ArmyBonus < 0)
                diagnostics.Add($"Region '{r.Id}' has a negative army bonus ({r.ArmyBonus.ToString(CultureInfo.InvariantCulture)}); " +
                                "region bonuses must be non-negative.");

            declaredRegionIds.Add(r.Id);
        }

        // Territory → region references
        foreach (var t in territories)
        {
            if (t is null) continue;
            if (t.RegionId is null)
                continue;
            if (t.RegionId.Length == 0)
                diagnostics.Add($"Territory '{t.Id}' has an empty region reference.");
            else if (!declaredRegionIds.Contains(t.RegionId))
                diagnostics.Add($"Territory '{t.Id}' references undefined region '{t.RegionId}'.");
        }

        // --- Geometry (optional metadata) ----------------------------------
        if (geometry is not null)
        {
            foreach (var (territoryId, geo) in geometry)
            {
                if (!declaredIds.Contains(territoryId))
                    diagnostics.Add($"Geometry is defined for unknown territory '{territoryId}'.");
                if (geo is null)
                    diagnostics.Add($"Territory '{territoryId}' has null geometry data.");
                else
                {
                    // An empty polygon is legal (polygon metadata absent); 1 or 2 points
                    // can never form a valid display polygon.
                    if (geo.Polygon is not null && geo.Polygon.Count is > 0 and < 3)
                        diagnostics.Add($"Territory '{territoryId}' has invalid polygon data " +
                                        $"({geo.Polygon.Count.ToString(CultureInfo.InvariantCulture)} points; " +
                                        "at least 3 required).");
                    if (geo.Polygon is not null)
                    {
                        foreach (var p in geo.Polygon)
                        {
                            if (!double.IsFinite(p.X) || !double.IsFinite(p.Y))
                                diagnostics.Add($"Territory '{territoryId}' polygon contains a non-finite point ({p.X}, {p.Y}).");
                        }
                    }

                    if (!double.IsFinite(geo.Centroid.X) || !double.IsFinite(geo.Centroid.Y))
                        diagnostics.Add($"Territory '{territoryId}' centroid is not finite ({geo.Centroid.X}, {geo.Centroid.Y}).");
                }
            }
        }

        return diagnostics;
    }
}
