namespace StrategyGame.Core.GameState;

using System;
using System.Collections.Generic;
using StrategyGame.Core.Domain;

/// <summary>
/// Handles attack resolution between two territories using a deterministic combat system.
/// </summary>
public static class CombatSystem
{
    public record CombatResult(
        bool AttackerWon,
        int AttackerRemaining,
        int DefenderRemaining,
        string? CapturedTerritoryId);

    /// <summary>
    /// Resolves an attack from one territory to another.
    /// Uses deterministic calculation (no RNG) for Milestone 0; RNG will be added in Milestone 1.
    /// </summary>
    public static CombatResult ResolveAttack(GameState state, string attackerTerritoryId, string defenderTerritoryId)
    {
        if (!state.Map.Territories.ContainsKey(attackerTerritoryId))
            throw new ArgumentException($"Attacker territory '{attackerTerritoryId}' not found.", nameof(attackerTerritoryId));

        if (!state.Map.Territories.ContainsKey(defenderTerritoryId))
            throw new ArgumentException($"Defender territory '{defenderTerritoryId}' not found.", nameof(defenderTerritoryId));

        // Verify adjacency
        var attackerTerritory = state.GetTerritory(attackerTerritoryId);
        if (!attackerTerritory.IsAdjacentTo(defenderTerritoryId))
            throw new InvalidOperationException($"Territories '{attackerTerritoryId}' and '{defenderTerritoryId}' are not adjacent.");

        // Verify attacker owns the territory
        if (attackerTerritory.OwnerPlayerId != state.CurrentTurnPlayerId)
            throw new InvalidOperationException($"Player '{state.CurrentTurnPlayerId}' does not own '{attackerTerritoryId}'.");

        // Retrieve defender before using its properties (needed for self-attack check)
        var defender = state.GetTerritory(defenderTerritoryId);
        var defenderArmies = defender.Armies;
        var defenderOwnerId = defender.OwnerPlayerId;

        // Verify attacker's territory is not the defender's own territory
        if (attackerTerritory.OwnerPlayerId == defenderOwnerId)
            throw new InvalidOperationException($"Cannot attack a territory owned by yourself.");

        // Verify attacker has armies to attack (at least 2 in the territory)
        if (attackerTerritory.Armies < 2)
            throw new InvalidOperationException($"Territory '{attackerTerritoryId}' has fewer than 2 armies.");

        var attackerArmies = attackerTerritory.Armies;

        // Simulate battle: simplified deterministic resolution.
        // In a real game this would use dice rolls; for now we compare raw army counts.
        // Attacker attacks with all but 1 armies; defender defends with all armies.
        int attackPower = attackerArmies - 1;
        int defensePower = defenderArmies;

        // Simple deterministic resolution for Milestone 0:
        // If attack power > defense power, attacker wins.
        bool attackerWins = attackPower > defensePower;

        int attackerRemaining;
        int defenderRemaining;
        string? capturedTerritoryId = null;

        if (attackerWins)
        {
            // Attacker loses some armies; defender loses all (if overrun)
            int attackerLosses = Math.Min(attackPower, defensePower / 2);
            attackerRemaining = attackerArmies - attackerLosses;
            defenderRemaining = 0;
            capturedTerritoryId = defenderTerritoryId;
        }
        else
        {
            int defenderLosses = Math.Min(defensePower, attackPower / 2);
            defenderRemaining = defenderArmies - defenderLosses;
            attackerRemaining = attackerArmies;
        }

        return new CombatResult(attackerWins, attackerRemaining, defenderRemaining, capturedTerritoryId);
    }
}
