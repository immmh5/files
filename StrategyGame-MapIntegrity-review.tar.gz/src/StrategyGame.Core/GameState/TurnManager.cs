namespace StrategyGame.Core.GameState;

/// <summary>
/// Manages turn sequencing and phase transitions.
/// </summary>
public static class TurnManager
{
    /// <summary>
    /// Current phase constants.
    /// </summary>
    public const string PhaseReinforce = "Reinforce";
    public const string PhaseAttack = "Attack";
    public const string PhaseFortify = "Fortify";
    public const string PhaseGameOver = "GameOver";

    /// <summary>
    /// Advances to the next turn and resets phase to Reinforce.
    /// </summary>
    public static (string NextTurnPlayerId, int NextTurnNumber, string NewPhase) AdvanceTurn(
        string currentTurnPlayerId,
        string previousTurnPlayerId,
        int turnNumber,
        IEnumerable<string> allPlayerIds)
    {
        var currentPlayerIndex = Math.Max(0, new List<string>(allPlayerIds).IndexOf(currentTurnPlayerId));
        var nextIndex = (currentPlayerIndex + 1) % allPlayerIds.Count();

        var nextTurnPlayerId = allPlayerIds.ElementAt(nextIndex);
        return (nextTurnPlayerId, turnNumber + 1, PhaseReinforce);
    }

    /// <summary>
    /// Transitions between phases within a single turn.
    /// </summary>
    public static string TransitionPhase(string currentPhase, string targetPhase) => targetPhase switch
    {
        PhaseReinforce when currentPhase == PhaseGameOver => PhaseReinforce,
        PhaseAttack when currentPhase == PhaseReinforce => PhaseAttack,
        PhaseFortify when currentPhase == PhaseAttack => PhaseFortify,
        PhaseGameOver when currentPhase == PhaseFortify => PhaseGameOver,
        _ => throw new InvalidOperationException($"Cannot transition from '{currentPhase}' to '{targetPhase}'.")
    };

    public static bool IsFinalPhase(string phase) =>
        phase == PhaseGameOver || phase == PhaseFortify;
}
