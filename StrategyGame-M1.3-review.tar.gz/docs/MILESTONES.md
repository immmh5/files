# Milestones

## Milestone 0 — Engineering Foundation (Current)

**Goal:** Establish a clean, tested, extensible engineering foundation.

### Deliverables
- [x] Environment inspection completed
- [x] Git repository initialized
- [x] Godot 4.7.2 .NET installed and verified
- [x] .NET SDK 8.0.427 installed and verified
- [x] Project structure created
- [x] `StrategyGame.Core` project (pure C#, builds cleanly)
- [x] `StrategyGame.App` Godot project (builds cleanly)
- [x] Unit test infrastructure (xUnit)
- [x] Integration test infrastructure
- [x] `scripts/verify.sh` and `scripts/verify.ps1`
- [x] Core architecture documentation (all required .md files)
- [x] Architecture Decision Records
- [x] Cross-platform build documentation
- [x] Minimal working app (smoke test)
- [ ] Headless startup verification
- [ ] CI pipelines configured
- [ ] Final report

### Exit Criteria
All acceptance criteria from the Milestone 0 spec must be met.

---

## Milestone 1 — Core Gameplay Systems

**Goal:** Implement the foundational gameplay loop.

### Deliverables
- [x] Basic game state (players, factions, initial map) — *Game base state exists; metadata extended in M1.1*
- [x] Territory adjacency and graph structure — *adjacency validated; M1.1 map foundation*
- [ ] Turn phases: Reinforce → Attack → Fortify
- [ ] Basic army placement and combat resolution — *provisional CombatSystem exists (raw-army comparison, no terrain yet; M1.3 replaces)*
- [ ] Simple AI opponent (random valid orders)
- [ ] Basic UI (territory info panel, order submission)
- [ ] Save/load (serialization of GameState)
- [x] First playable map (5-10 territories) — *deterministic 6-territory `small_map.json` + loader (M1.1); scalable to the planned larger map via the same JSON format*
- [ ] Unit tests for CombatSystem and VictoryChecker — *both exist; terrain-aware combat tests pending M1.3*
- [ ] Single-player smoke test

### M1.1 Sub-milestone status (completed 2026-11-10)
- [x] Explicit terrain type set (Plains/Forest/Hills/Mountains/Marsh/Coast) — `Domain/TerrainType.cs`
- [x] Region definitions with configurable army bonuses — `Domain/RegionDefinition.cs`
- [x] Territory metadata: terrain, region membership, supply-source — `Domain/Territory.cs`
- [x] Map validation with aggregated diagnostics — `Domain/MapValidator.cs`, `Domain/MapValidationException.cs`
- [x] JSON map format + loader (System.Text.Json, no new packages) — `Storage/MapLoader.cs`
- [x] Deterministic test map (6 territories / 2 regions, deterministic) — `tests/StrategyGame.Core.Tests/TestData/small_map.json`
- [x] Tests: metadata, regions, validation, loader, GameState ownership — 329 unit tests pass
- Terrain/region gameplay *effects* (combat defense, income) are deliberately NOT implemented yet: they belong to M1.2/M1.3.
- Phase 0 foundation repair complete in the same change set (see `docs/repair/REPAIR_PROGRESS.md`).

### M1.2 Sub-milestone status (completed 2026-11-10, pending review)
- [x] Economy config (`Simulation/EconomyConfig`) + reinforcement calculation (`Simulation/EconomyEngine`) returning a full breakdown; income divisor configurable (provisional 3); **region bonuses derived from LIVE GameState ownership (never stale map data)** — regression-tested
- [x] Supply connectivity (`Simulation/SupplyEngine`) — deterministic BFS from owned supply sources through owned territories; neutral/enemy block; `SupplyResult` with sorted lists + diagnostics
- [x] Attrition calculation (`Simulation/AttritionEngine` + `Simulation/AttritionConfig`) — pure per-territory report; min-garrison respected; zero-army neutralization is an explicit, config-gated report flag (never applied to state here)
- [x] No minimum-reinforcement rule imposed (D-08 documents none)
- [x] Chain tests (GameState → economy → supply → attrition) on `small_map.json`
- [x] Overflow-safe (checked) arithmetic; validation of configs, player IDs, state consistency
- [x] Core test suite: 329 → **393 tests**, all passing; Integration 7 passing
- Out of scope, verified not implemented: TurnEngine/ActionExecutor, auto-application of budget or attrition, EventScheduler wiring, AI, save/load, UI, multiplayer, strategic resources, buildings, tech
- D-06/D-08 stay PROPOSED; see `docs/architecture/M1_ROADMAP.md` §6 for the provisional-default table

### M1.3 Sub-milestone status (completed 2026-11-10)
- [x] **TurnStage enum** (`Simulation/TurnStage.cs`) — A/B/C/D hybrid cycle stages: TurnStart (A), PlayerActions (B), EventProcessing (C), TurnEnd (D), GameOver
- [x] **GameActions** (`Actions/GameActions.cs`) — ReinforceAction, AttackAction, FortifyAction records implementing `IGameAction`
- [x] **ActionExecutor** (`Actions/ActionExecutor.cs`) — Validates and executes all three actions against GameState; invalid actions leave state unchanged; combat uses updated CombatSystem
- [x] **CombatSystem** (`GameState/CombatSystem.cs`) — Updated per COMBAT_AND_ARMY_RULES.md: deterministic formula `attacker_strength = attacker_armies - 1`, `defender_strength = defender_armies + terrain_bonus`; **defender wins ties**; terrain bonuses: Plains=0, Forest=1, Hills=2, Mountains=3, Marsh=0, Coast=1 (all PROVISIONAL); minimum garrison=1 preserved
- [x] **TurnEngine** (`Simulation/TurnEngine.cs`) — Central orchestrator: Stage A (EconomyEngine+SupplyEngine+AttritionEngine), Stage B (ActionExecutor), Stage C (EventScheduler at ExecutionStage.EventProcessing only), Stage D (VictoryChecker then turn advance)
- [x] **TurnManager** updated with `ToTurnStage`/`ToLegacyPhase` mappings for backward compatibility
- [x] **GameState** extended with mutable internal fields (`CurrentTurnPlayerIdInternal`, `CurrentTurnNumberInternal`, `CurrentPhaseInternal`) and `AdvanceTurn`/`SetPhase` methods
- [x] **EventScheduler integration** — Stage C only (ExecutionStage.EventProcessing); Stage B events excluded by type system (D-16-3)
- [x] **Victory evaluation at Stage D** (per D-16-5) before advancing to next player
- [x] **33 new tests**: TurnEngineTests (11), ActionExecutorTests (12), CombatSystemTerrainTests (7), TurnEngineEndToEndTests (3) — **total 449 Core + 7 Integration passing**
- [x] D-06 supply/attrition and D-08 economy rules remain PROPOSED; no promotion to APPROVED
- [x] Full verification passes: Release builds, verify.sh all checks green, Godot import/startup OK


---

## Milestone 2 — Visual Foundation

**Goal:** Working 2.5D strategy map with basic interactions.

### Deliverables
- [ ] Map rendering with territory polygons
- [ ] Faction-colored territory fills
- [ ] Selection and hover highlighting
- [ ] Army markers at territory centroids
- [ ] Camera pan and zoom
- [ ] Basic HUD (player info, turn counter, phase indicator)
- [ ] Territory info popover on selection
- [ ] Simple order confirmation flow
- [ ] Basic animations (selection pulse, army movement)
- [ ] Performance: stable 60 FPS on test map

---

## Milestone 3 — Complete Game Loop

**Goal:** Fully playable single-player game with victory conditions.

### Deliverables
- [ ] All turn phases functional with UI
- [ ] Victory conditions (domination, elimination)
- [ ] Full AI opponent with basic strategy
- [ ] Map with 20+ territories
- [ ] Game-over screen with restart option
- [ ] Save/load integrated into UI
- [ ] All core domain code unit tested

---

## Milestone 4 — Multiplayer Foundation

**Goal:** LAN multiplayer with host-authoritative model.

### Deliverables
- [ ] `FakeTransport` (loopback for testing)
- [ ] `ENetTransport` (LAN UDP)
- [ ] Room discovery (UDP broadcast)
- [ ] Manual IP connection fallback
- [ ] Host-authoritative state sync
- [ ] Disconnect/reconnect handling
- [ ] Basic lobby UI

---

## Milestone 5 — Polish and Expansion

**Goal:** Improved AI, visual polish, and multiple maps.

### Deliverables
- [ ] Improved AI strategy
- [ ] Multiple playable maps
- [ ] Faction-specific bonuses
- [ ] Card/ability system (stub)
- [ ] Sound effects and ambient audio
- [ ] Main menu and options screen
- [ ] Performance profiling and optimization
- [ ] Linux and Windows release builds

---

## Future Milestones (TBD)

- Online multiplayer (WebRTC or relay service)
- Mod support / plugin loader
- Campaign mode
- Additional game modes
- Mobile export (separate scope)
