namespace StrategyGame.Core.Events;

using System.Collections.Concurrent;
using System.Text.Json;
using System.Text.Json.Serialization;

/// <summary>
/// Event type registry for authoritative scheduled events (R4.4).
/// Maps EventTypeKey to payload schema, deserializer, and validator.
/// Supports explicit schema versions with migration extension points.
///
/// D-16-6: Unknown authoritative event types are rejected.
/// D-16-7: Typed DTOs with versioned JSON serialization.
/// </summary>
public static class EventTypeRegistry
{
    private static readonly ConcurrentDictionary<string, EventTypeInfo> _registry = new();

    // Lock-based one-time initialization (double-checked locking pattern).
    private static readonly object _initLock = new();
    private static bool _initialized; // true after EventTypeRegistrar.RegisterAll() completes

    /// <summary>
    /// Registers an event type with its payload schema.
    /// INTERNAL — only called by EventTypeRegistrar during bootstrap.
    /// Idempotent for identical definitions (same key + PayloadType + versions + allowed keys
    /// + deserializer + validator via exact delegate equality).
    /// Conflicting definitions (same key but different deserializer or validator) are rejected.
    /// </summary>
    /// <exception cref="ArgumentException">If key is already registered with a conflicting definition.</exception>
    internal static void Register(
        string eventTypeKey,
        IReadOnlyList<int> supportedVersions,
        Func<Dictionary<string, JsonElement>, int, object> deserializer,
        Action<object> validator,
        Type payloadType,
        IReadOnlySet<string> allowedKeys)
    {
        if (string.IsNullOrWhiteSpace(eventTypeKey))
            throw new ArgumentException("Event type key cannot be empty.", nameof(eventTypeKey));
        if (supportedVersions == null || supportedVersions.Count == 0)
            throw new ArgumentException("At least one supported version required.", nameof(supportedVersions));
        if (deserializer == null)
            throw new ArgumentNullException(nameof(deserializer));
        if (validator == null)
            throw new ArgumentNullException(nameof(validator));

        var info = new EventTypeInfo(
            EventTypeKey: eventTypeKey,
            SupportedVersions: supportedVersions.ToList().AsReadOnly(),
            Deserializer: deserializer,
            Validator: validator,
            PayloadType: payloadType ?? throw new ArgumentNullException(nameof(payloadType)),
            AllowedKeys: new HashSet<string>(allowedKeys));

        if (!_registry.TryAdd(eventTypeKey, info))
        {
            // Key already present: idempotent no-op for an IDENTICAL definition
            // (enables retry after a partial registration failure); conflicting
            // definitions are rejected loudly.
            // We compare the full stable schema contract: payload type, versions,
            // allowed keys, AND exact delegate equality for deserializer/validator.
            var existing = _registry[eventTypeKey];
            bool identical =
                existing.PayloadType == info.PayloadType &&
                existing.SupportedVersions.SequenceEqual(info.SupportedVersions) &&
                existing.AllowedKeys.SetEquals(info.AllowedKeys) &&
                existing.Deserializer.Equals(info.Deserializer) &&
                existing.Validator.Equals(info.Validator);
            if (!identical)
                throw new ArgumentException(
                    $"Event type '{eventTypeKey}' is already registered with a conflicting definition.",
                    nameof(eventTypeKey));
        }
    }

    /// <summary>
    /// Registers all authoritative event types via a synchronized one-time bootstrap.
    /// THREAD SAFETY: lock-based double-checked initialization — safe to call concurrently.
    /// State transitions: uninitialized -> (lock) -> registrar runs -> initialized.
    /// If the registrar throws, initialization is NOT marked complete: no caller is left
    /// waiting on a completed flag, and the next call retries (identical registrations
    /// are idempotent, so a partial set is completed).
    /// </summary>
    public static void RegisterAll()
    {
        // Fast path: already initialized
        if (Volatile.Read(ref _initialized))
            return;

        lock (_initLock)
        {
            if (_initialized)
                return;

            EventTypeRegistrar.RegisterAll();
            _initialized = true; // only on full success
        }
    }

    /// <summary>
    /// Checks if an event type is registered.
    /// </summary>
    public static bool IsRegistered(string eventTypeKey) =>
        !string.IsNullOrWhiteSpace(eventTypeKey) && _registry.ContainsKey(eventTypeKey);

    /// <summary>
    /// Gets the type info for a registered event type.
    /// Throws if not registered (D-16-6: reject unknown authoritative types).
    /// </summary>
    public static EventTypeInfo GetInfo(string eventTypeKey)
    {
        if (string.IsNullOrWhiteSpace(eventTypeKey))
            throw new EventTypeRegistryException("<empty>", "Event type key cannot be empty.");
        if (!_registry.TryGetValue(eventTypeKey, out var info))
            throw new EventTypeRegistryException(eventTypeKey, $"Unknown authoritative event type '{eventTypeKey}' - not registered in the event type registry.");
        // Return defensive copies so callers cannot mutate the registry's internal state.
        // Note: the returned collection values are isolated copies; SupportedVersions is
        // ReadOnlyCollection<T> (immutable for mutation methods), AllowedKeys is a new
        // HashSet<T> (mutable — callers must not mutate the returned set).
        return info with
        {
            SupportedVersions = info.SupportedVersions.ToList().AsReadOnly(),
            AllowedKeys = new HashSet<string>(info.AllowedKeys)
        };
    }

    /// <summary>
    /// Validates and deserializes a scheduled event's payload using the registry.
    /// Performs: schema version check -> strict key validation -> deserialization -> semantic validation.
    /// </summary>
    /// <returns>The typed payload DTO.</returns>
    /// <exception cref="EventTypeRegistryException">On unknown type, unsupported version, or malformed payload.</exception>
    /// <exception cref="ScheduledEventValidationException">On semantic validation failure.</exception>
    public static object DeserializeAndValidatePayload(ScheduledEventRecord record)
    {
        // Get type info (throws if unknown)
        var info = GetInfo(record.EventTypeKey);

        // Schema version check
        if (!info.SupportedVersions.Contains(record.SchemaVersion))
            throw new EventTypeRegistryException(
                record.EventTypeKey,
                $"Unsupported schema version {record.SchemaVersion} for event type '{record.EventTypeKey}'. Supported: {string.Join(", ", info.SupportedVersions)}");

        // Strict key validation: reject unknown dictionary keys
        var payloadDict = record.Payload != null
            ? new Dictionary<string, JsonElement>(record.Payload)
            : new Dictionary<string, JsonElement>();
        info.ValidateKeys(payloadDict);

        // Deserialize payload
        object payload;
        try
        {
            payload = info.Deserializer(payloadDict, record.SchemaVersion);
        }
        catch (Exception ex) when (ex is not ScheduledEventValidationException && ex is not EventTypeRegistryException)
        {
            throw new EventTypeRegistryException(
                record.EventTypeKey,
                $"Failed to deserialize payload for event type '{record.EventTypeKey}' (schema v{record.SchemaVersion}): {ex.Message}");
        }

        // Semantic validation
        try
        {
            info.Validator(payload);
        }
        catch (Exception ex) when (ex is not ScheduledEventValidationException && ex is not EventTypeRegistryException)
        {
            throw new ScheduledEventValidationException(
                $"<{record.EventTypeKey}>",
                $"Payload validation failed for event type '{record.EventTypeKey}': {ex.Message}");
        }

        return payload;
    }

    /// <summary>
    /// Validates a ScheduledEventRecord's payload using the registry.
    /// Call after structural validation passes.
    /// </summary>
    public static void ValidatePayload(ScheduledEventRecord record)
    {
        DeserializeAndValidatePayload(record);
    }

    /// <summary>
    /// Gets all registered event type keys (for diagnostics / tooling).
    /// </summary>
    public static IReadOnlyList<string> GetRegisteredKeys() =>
        _registry.Keys.OrderBy(k => k).ToList();

    /// <summary>
    /// Clears the registry and the registrar's completion flag. For testing only.
    /// Must be called before tests that validate a fresh bootstrap.
    /// </summary>
    internal static void ClearForTesting()
    {
        _registry.Clear();
        _initialized = false;
        // Also reset the registrar so the next full bootstrap re-runs all registrations.
        EventTypeRegistrar.ClearForTesting();
    }
}

/// <summary>
/// Metadata about a registered event type.
/// Note: GetInfo returns defensive copies (SupportedVersions as ReadOnlyCollection,
/// AllowedKeys as a new HashSet). These are isolated from the registry but AllowedKeys
/// itself is mutable — callers should treat the returned EventTypeInfo as read-only.
/// </summary>
public sealed record EventTypeInfo(
    string EventTypeKey,
    IReadOnlyList<int> SupportedVersions,
    Func<Dictionary<string, JsonElement>, int, object> Deserializer,
    Action<object> Validator,
    Type PayloadType,
    IReadOnlySet<string> AllowedKeys)
{
    /// <summary>
    /// Validates that the payload dictionary contains only allowed keys.
    /// Throws on unknown keys.
    /// </summary>
    public void ValidateKeys(Dictionary<string, JsonElement> payload)
    {
        foreach (var key in payload.Keys)
        {
            if (!AllowedKeys.Contains(key))
                throw new ScheduledEventValidationException(EventTypeKey, $"Unknown payload key '{key}'.");
        }
    }
}

/// <summary>
/// Exception thrown by the event type registry for registration/validation failures.
/// </summary>
public sealed class EventTypeRegistryException(string eventTypeKey, string message)
    : Exception($"Event type '{eventTypeKey}' registry error: {message}")
{
    public string EventTypeKey { get; } = eventTypeKey;
}