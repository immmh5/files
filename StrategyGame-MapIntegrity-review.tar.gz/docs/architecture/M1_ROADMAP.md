# M1_ROADMAP.md — Milestone 1.x Dependency-Based Plan

**Status:** PROPOSED PLAN (planning only; nothing in this file is implemented unless a
section is explicitly marked complete). Recorded 2026-11-10 after M1.1; M1.2 status updated 2026-11-10.
**Scope:** The concrete dependency chain for Milestones 1.2 → 1.5 and later expansion.
**Discipline:** One sub-milestone at a time; no owner approval of thresholds/rules is
assumed; every design-default introduced stays marked PROVISIONAL.

---

## 0. What exists after M1.1 (verified 2026-11-10)

| Foundation | Where | Notes |
|---|---|---|
| Map model: territories w/ terrain, region, supply-source, adjacency | `Domain/Territory.cs`, `Domain/TerrainType.cs` | Validated at construction; **M1.1 correction: symmetric adjacency + no duplicate adjacencies now enforced (DOMAIN_MODEL.md invariants)** |
| Regions w/ configurable army bonus | `Domain/RegionDefinition.cs`, `MapDefinition.GetRegionControlBonus` | Bonus is PROPOSAL D-05 |
| Map JSON format + validated loader | `Storage/MapLoader.cs` | System.Text.Json only (D-16-7) |
| GameState ownership (deep copies, read-only views) | `GameState/GameState.cs` | Regression-tested |
| Event system: EventBus (snapshot publish), EventTypeRegistry, EventScheduler, EventIdSource (boundary-safe) | `Events/*` | D-16 approved |
| Deterministic combat placeholder | `GameState/CombatSystem.cs` | Raw-army comparison; NO terrain; M1.3 replaces |
| Maps/geometry for later rendering | `MapDefinition.Geometry` | Optional metadata |

Everything else (economy, orders, turn engine, AI, save/load, UI) is NOT implemented.

---

## 1. Dependency graph (M1.2 → M1.5)

```
M1.1 Map & Rules Foundation (DONE)
   │
   ├──► M1.2 Economy & World Effects
   │        ├── EconomyConfig (income formula, region bonuses)  [PROVISIONAL]
   │        ├── SupplyEngine (flood-fill from supply sources, D-06 [PROPOSED])
   │        ├── AttritionEngine (unsupplied groups, min garrison 1, neutral at 0)
   │        └── reinforcement budget calculation (floor(territories/3) + region bonuses)
   │                 │
   │                 ▼
   ├──► M1.3 Orders & TurnEngine (hybrid A/B/C/D, USER-APPROVED PROVISIONAL)
   │        ├── Order model + OrderValidator (placement / attack / fortify / move)
   │        ├── CombatSystem upgrade: defender strength = armies + terrain defense (D-04 [PROPOSED]),
   │        │      deterministic, pure function; replaces placeholder math
   │        ├── ActionExecutor: validate → execute → state transition (uses EventIdSource for domain events)
   │        ├── TurnEngine: Stage A (reinforce) → B (actions) → C (event processing) → D (victory eval, D-16-5)
   │        │      and per-turn vs per-round cadences (D-16-1/2)
   │        └── Guard: victory evaluated at Stage D ONLY; threshold still PROVISIONAL
   │                 │
   │                 ├──► M1.4 Deterministic AI + Save/Load
   │                 │        ├── IAIPlayer implementations (Easy/Normal per D-10 [PROPOSED])
   │                 │        │      (deterministic only — no RNG, no external AI)
   │                 │        ├── Event-sourced save: map hash + command log + schema version (D-13 [PROPOSED])
   │                 │        ├── MapLoader reuse for menu map selection
   │                 │        └── Replay = re-execution (loads deterministic engine support)
   │                 │
   │                 └──► M1.5 Godot Presentation & First Playable
   │                          ├── MapView: polygon rendering, region tint, faction fills
   │                          ├── Selection / hover / orders UI, HUD (phase, turn, counts)
   │                          ├── CoreEventBus bridge: Core events → Godot signals
   │                          ├── AI opponent wiring (local, offline)
   │                          └── Result: first playable single-player game loop
   │
   └── Later (each gated on owner decisions):
            Expanded factions with asymmetric passives (D-09 PROPOSED)
            Richer AI (Hard tier, 1-ply response check) — D-10 PROPOSED
            Diplomacy/alliances — OPEN, Cat 2/3
            Abilities/cards — SPECIAL_ABILITIES_AND_EXPANSIONS.md (future)
            Larger maps (~48 territories / 6 regions target — D-05 PROPOSED)
            LAN multiplayer (Milestone 4 plan stands: transport-first, host-authoritative)
```

## 2. M1.2 — Economy, reinforcement, supply, attrition ✅ COMPLETE (2026-11-10)

**Depends on:** M1.1 only. **Status:** implemented, verified, and **review-v2 corrected**; awaiting independent review.

**Delivered (all pure, deterministic, side-effect free; live `GameState` ownership):**
1. `src/StrategyGame.Core/Simulation/EconomyConfig.cs` — validated immutable config;
   mechanic values live in config only. Divisor 3 is the PROVISIONAL D-08 default.
   No minimum-reinforcement rule imposed (D-08 documents none; the legacy
   `GameRules.ComputeReinforcements` minimum remains unused M1.0 scaffolding).
2. `src/StrategyGame.Core/Simulation/EconomyEngine.cs` —
   `CalculateReinforcement(state, playerId, config?)` returns `EconomyReport`
   (owned count, base income, per-region contributions ordered by region id,
   region total, total budget) in a `checked` context. Region control comes from
   LIVE state territories; `RegionDefinition.ArmyBonus` supplies amounts.
   `MapDefinition.GetRegionControlBonus` now documented as static/setup-time only
   (stale during a match); regression test proves live-vs-stale correctness.
   **All returned collections are defensively read-only (`IReadOnlyList<T>` backed by
   `List.AsReadOnly()`).**
3. `src/StrategyGame.Core/Simulation/SupplyEngine.cs` — BFS from owned
   `IsSupplySource` territories through owned territories (neutral/enemy block);
   `SupplyResult` with sorted supplied/unsupplied lists, owned sources, and
   diagnostics; deterministic ordering independent of dictionary order; no
   capacity/army-limit/resource modeling (advanced logistics remain Category-2 future).
   **All returned collections are defensively read-only.**
4. `src/StrategyGame.Core/Simulation/AttritionConfig.cs` — loss per unsupplied
   territory (provisional 1), minimum garrison (provisional 1), and an explicit
   `AllowZeroGarrisonNeutralization` switch (default false) for the documented
   D-06 ambiguity ("min 1 garrison" vs "0 armies → neutral").
5. `src/StrategyGame.Core/Simulation/AttritionEngine.cs` — pure per-territory
   report (before/lost/after/would-be-neutralized) from (state, player, supply,
   config); **refuses stale or inconsistent SupplyResults** by recomputing the
   fresh supply state from the CURRENT GameState and comparing set-wise (ownership
   changes, connectivity changes, forged/incomplete results are rejected with
   `ArgumentException`); **validates negative army counts across ALL player-owned
   territories** (supplied and unsupplied alike) and throws `InvalidOperationException`
   on corrupt state; **returned collections are defensively read-only**; the
   neutralization transition itself is NOT applied here (M1.3 decision).
6. Tests: `EconomyEngineTests`, `SupplyEngineTests`, `AttritionEngineTests`,
   `SupplyAttritionChainTests` (GameState → economy → supply → attrition chain on
   the M1.1 `small_map.json`). **Review-v2 regression tests added:** stale/forged
   supply rejection (5 cases), negative-army detection on supplied territories,
   read-only collection immutability (3 tests). Core total 329 → 405.

**Explicitly NOT delivered (out of scope, verified absent):** TurnEngine wiring,
ActionExecutor, automatic application of budget/attrition to state, EventScheduler
integration, UI, AI, save/load, multiplayer.

## 3. M1.3 — Orders, validation/execution, hybrid TurnEngine

**Depends on:** M1.2 (income feeds Stage A; supply gates orders later), existing event stack.
**Deliverables:** Order/validator/executor (A/B/C/D per `TURN_AND_EVENT_SYSTEM.md` and
`TURN_ENGINE_ARCHITECTURE.md`), terrain-aware deterministic combat per D-04 [PROPOSED],
Stage-D victory evaluation (D-16-5), integration with EventScheduler + EventIdSource.
**Gate:** owner review of the D-04 defaults list before combat replacement lands.

## 4. M1.4 — Deterministic AI + save/load

**Depends on:** M1.3 (legal order enumeration).
**Deliverables:** Easy/Normal AI per D-10 [PROPOSED], event-sourced save/replay per D-13
[PROPOSED], map hash (reuse `IdGenerator.StableHash`), schema-versioned command log.

## 5. M1.5 — Godot visualization & first playable

**Depends on:** M1.1 geometry, M1.3 engine, optionally M1.4 for the AI seat.
**Deliverables:** MapView (polygons/tints/markers per MAP_AND_TERRITORY_DESIGN 1.5–1.6),
HUD, order submission UI, CoreEventBus → Godot bridge, offline single-player loop.
**Gate:** `verify.sh` + Play-mode checklist + 60 FPS validation still provisional-only.

---

## 6. Rules still requiring owner approval (do NOT implement silently)

| Rule | Source | Current provisional default |
|---|---|---|
| Region bonus numbers (2–5, tuned per size) | D-05 [PROPOSED] | Test map uses 2 (north) / 3 (south) |
| Income = floor(territories / 3) | D-08 [PROPOSED] | Implemented as `EconomyConfig` divisor default 3; no minimum-reinforcement rule imposed |
| Supply semantics + attrition rates | D-06 [PROPOSED] | Primitives implemented in M1.2: BFS from owned supply sources through owned territories; loss 1/unsupplied territory; garrison floor 1; `AllowZeroGarrisonNeutralization` flag OFF. The D-06 "0 armies → neutral" vs "min 1 garrison" CONFLICT is unresolved — neutralization remains a separate later-system rule unless an owner decision flips the flag |
| Combat: terrain defense, defender-wins-ties, losses = floor/2 | D-04 [PROPOSED] | Placeholder raw-army compare |
| Domination 60% + denominator + priority | D-07 [PROPOSED], D-16-5 timing only | Hard-coded 0.6 with explicit provisional doc |

Point-based victory, alliances, deeper ability systems remain OPEN and unimplemented.
