namespace StrategyGame.Core.Networking;

using System.Net;

/// <summary>
/// Network transport abstraction. Implementations may use ENet, WebRTC, or a local loopback channel.
/// No Godot dependencies.
/// </summary>
public interface INetworkTransport : IDisposable
{
    /// <summary>Attempts to connect to the remote endpoint.</summary>
    Task ConnectAsync(EndPoint endpoint, CancellationToken ct);

    /// <summary>Gracefully disconnects from the remote peer.</summary>
    Task DisconnectAsync();

    /// <summary>Sends a packet to the connected peer.</summary>
    Task SendPacketAsync(GamePacket packet, TransmissionType type, CancellationToken ct = default);

    /// <summary>Receives packets from the remote peer as an async stream.</summary>
    IAsyncEnumerable<GamePacket> ReceivePacketsAsync(CancellationToken ct);

    /// <summary>True if currently connected to a peer.</summary>
    bool IsConnected { get; }

    /// <summary>Local peer identifier.</summary>
    string LocalPeerId { get; }

    /// <summary>Remote peer identifier (set after connection established).</summary>
    string? RemotePeerId { get; }
}

/// <summary>
/// LAN room discovery service. Broadcasts and receives discovery packets on the local network.
/// </summary>
public record struct DiscoveredRoom(string RoomId, string HostId, int PlayerCount, int MaxPlayers, string RoomName);

public interface INetworkDiscovery : IDisposable
{
    Task StartDiscoveryAsync(TimeSpan timeout, CancellationToken ct);
    void StopDiscovery();
    Task<IReadOnlyList<DiscoveredRoom>> GetDiscoveredRoomsAsync();
    Task CreateRoomAsync(string roomId, string hostId, int maxPlayers, CancellationToken ct);
    event Action<DiscoveredRoom>? OnRoomDiscovered;
    event Action<string>? OnRoomRemoved;
}
