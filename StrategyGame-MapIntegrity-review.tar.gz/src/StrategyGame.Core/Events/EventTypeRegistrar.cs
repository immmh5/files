namespace StrategyGame.Core.Events;

using System.Text.Json;

/// <summary>
/// Registers all authoritative scheduled event types with the EventTypeRegistry.
/// Call this once at application startup (R4.4).
/// </summary>
public static class EventTypeRegistrar
{
    private static readonly object _registrationLock = new();
    private static bool _registered;

    /// <summary>
    /// Internal test seam: invoked before each registration call inside RegisterAll.
    /// When non-null, throwing from it simulates a failure mid-initialization.
    /// Used ONLY by tests; never set in production code.
    /// </summary>
    internal static Action<string>? TestBeforeRegistration;

    /// <summary>
    /// Registers all known authoritative scheduled event types.
    /// THREAD SAFETY: synchronized one-time initialization — safe to call concurrently.
    /// The completion flag is set only AFTER every registration succeeds, so an
    /// exception never leaves a misleading completed state; later callers retry, and
    /// EventTypeRegistry.Register is idempotent for identical definitions, which
    /// completes any partially-registered set.
    /// </summary>
    public static void RegisterAll()
    {
        // Benign fast-path read: worst case a concurrent caller takes the lock and
        // returns immediately (double-checked locking).
        if (Volatile.Read(ref _registered))
            return;

        lock (_registrationLock)
        {
            if (_registered)
                return;

            RegisterOne("autumn_attrition", RegisterAutumnAttrition);
            RegisterOne("continent_bonus", RegisterContinentBonus);
            RegisterOne("harvest_festival", RegisterHarvestFestival);
            RegisterOne("border_fortification", RegisterBorderFortification);
            RegisterOne("berserk_rage", RegisterBerserkRage);
            RegisterOne("supply_disruption", RegisterSupplyDisruption);
            RegisterOne("fortification_boost", RegisterFortificationBoost);

            // Only mark complete after ALL registrations succeeded.
            _registered = true;
        }
    }

    private static void RegisterOne(string key, Action registration)
    {
        TestBeforeRegistration?.Invoke(key);
        registration();
    }

    /// <summary>
    /// Resets the registrar's completion flag. For testing only — callers must
    /// not invoke this while other threads may be calling RegisterAll concurrently.
    /// </summary>
    internal static void ClearForTesting()
    {
        lock (_registrationLock)
        {
            _registered = false;
        }
    }

    /// <summary>
    /// Test seam: clears all registered handlers. For testing only — callers must
    /// not invoke this while other threads may be calling RegisterAll concurrently.
    /// </summary>
    internal static void ClearHandlersForTesting()
    {
        EventHandlerRegistry.ClearHandlersForTesting();
    }

    // =====================================================================
    // Static deserializer and validator methods for stable handler identity
    // =====================================================================

    // Global (round-based) effects

    internal static object DeserializeAutumnAttrition(Dictionary<string, JsonElement> payload, int schemaVersion)
    {
        var regions = EventPayloads.GetRequiredStringArray(payload, "regions");
        var armiesLost = EventPayloads.GetOptionalInt(payload, "armiesLostPerGroup", 1);
        return new EventPayloads.AutumnAttritionPayload(regions, armiesLost);
    }

    internal static void ValidateAutumnAttrition(object payload)
    {
        var p = (EventPayloads.AutumnAttritionPayload)payload;
        if (p.AffectedRegions.Length == 0)
            throw new ScheduledEventValidationException("autumn_attrition", "At least one affected region is required.");
        if (p.ArmiesLostPerGroup < 1)
            throw new ScheduledEventValidationException("autumn_attrition", "ArmiesLostPerGroup must be >= 1.");
    }

    internal static void RegisterAutumnAttrition()
    {
        EventTypeRegistry.Register(
            eventTypeKey: "autumn_attrition",
            supportedVersions: [1],
            deserializer: DeserializeAutumnAttrition,
            validator: ValidateAutumnAttrition,
            payloadType: typeof(EventPayloads.AutumnAttritionPayload),
            allowedKeys: new HashSet<string> { "regions", "armiesLostPerGroup" });

        EventHandlerRegistry.RegisterHandler("autumn_attrition", HandleAutumnAttrition);
    }

    internal static bool HandleAutumnAttrition(ScheduledEventRecord record)
    {
        // Autumn attrition: all unsupplied groups lose armies at round start.
        // NOT IMPLEMENTED - no gameplay effects defined yet.
        // Returning false to indicate unimplemented handler.
        return false;
    }

    internal static object DeserializeContinentBonus(Dictionary<string, JsonElement> payload, int schemaVersion)
    {
        var continentId = EventPayloads.GetRequiredString(payload, "continentId");
        var bonusArmies = EventPayloads.GetRequiredInt(payload, "bonusArmies");
        var controllingPlayers = EventPayloads.GetRequiredStringArray(payload, "controllingPlayerIds");
        return new EventPayloads.ContinentBonusPayload(continentId, bonusArmies, controllingPlayers);
    }

    internal static void ValidateContinentBonus(object payload)
    {
        var p = (EventPayloads.ContinentBonusPayload)payload;
        if (string.IsNullOrWhiteSpace(p.ContinentId))
            throw new ScheduledEventValidationException("continent_bonus", "ContinentId is required.");
        if (p.BonusArmies < 1)
            throw new ScheduledEventValidationException("continent_bonus", "BonusArmies must be >= 1.");
        if (p.ControllingPlayerIds.Length == 0)
            throw new ScheduledEventValidationException("continent_bonus", "At least one controlling player required.");
    }

    internal static void RegisterContinentBonus()
    {
        EventTypeRegistry.Register(
            eventTypeKey: "continent_bonus",
            supportedVersions: [1],
            deserializer: DeserializeContinentBonus,
            validator: ValidateContinentBonus,
            payloadType: typeof(EventPayloads.ContinentBonusPayload),
            allowedKeys: new HashSet<string> { "continentId", "bonusArmies", "controllingPlayerIds" });

        EventHandlerRegistry.RegisterHandler("continent_bonus", HandleContinentBonus);
    }

    internal static bool HandleContinentBonus(ScheduledEventRecord record)
    {
        // Continent bonus: grants reinforcement armies to players controlling a continent.
        // NOT IMPLEMENTED - no gameplay effects defined yet.
        // Returning false to indicate unimplemented handler.
        return false;
    }

    internal static object DeserializeHarvestFestival(Dictionary<string, JsonElement> payload, int schemaVersion)
    {
        var bonusPercent = EventPayloads.GetRequiredInt(payload, "bonusIncomePercent");
        var duration = EventPayloads.GetRequiredInt(payload, "durationRounds");
        return new EventPayloads.HarvestFestivalPayload(bonusPercent, duration);
    }

    internal static void ValidateHarvestFestival(object payload)
    {
        var p = (EventPayloads.HarvestFestivalPayload)payload;
        if (p.BonusIncomePercent < 1)
            throw new ScheduledEventValidationException("harvest_festival", "BonusIncomePercent must be >= 1.");
        if (p.DurationRounds < 1)
            throw new ScheduledEventValidationException("harvest_festival", "DurationRounds must be >= 1.");
    }

    internal static void RegisterHarvestFestival()
    {
        EventTypeRegistry.Register(
            eventTypeKey: "harvest_festival",
            supportedVersions: [1],
            deserializer: DeserializeHarvestFestival,
            validator: ValidateHarvestFestival,
            payloadType: typeof(EventPayloads.HarvestFestivalPayload),
            allowedKeys: new HashSet<string> { "bonusIncomePercent", "durationRounds" });

        EventHandlerRegistry.RegisterHandler("harvest_festival", HandleHarvestFestival);
    }

    internal static bool HandleHarvestFestival(ScheduledEventRecord record)
    {
        // Harvest festival: temporary economic boost for all players.
        // NOT IMPLEMENTED - no gameplay effects defined yet.
        // Returning false to indicate unimplemented handler.
        return false;
    }

    internal static object DeserializeBorderFortification(Dictionary<string, JsonElement> payload, int schemaVersion)
    {
        var territories = EventPayloads.GetRequiredStringArray(payload, "territoryIds");
        var defenseBonus = EventPayloads.GetRequiredInt(payload, "defenseBonus");
        return new EventPayloads.BorderFortificationPayload(territories, defenseBonus);
    }

    internal static void ValidateBorderFortification(object payload)
    {
        var p = (EventPayloads.BorderFortificationPayload)payload;
        if (p.TerritoryIds.Length == 0)
            throw new ScheduledEventValidationException("border_fortification", "At least one territory ID required.");
        if (p.DefenseBonus < 1)
            throw new ScheduledEventValidationException("border_fortification", "DefenseBonus must be >= 1.");
    }

    internal static void RegisterBorderFortification()
    {
        EventTypeRegistry.Register(
            eventTypeKey: "border_fortification",
            supportedVersions: [1],
            deserializer: DeserializeBorderFortification,
            validator: ValidateBorderFortification,
            payloadType: typeof(EventPayloads.BorderFortificationPayload),
            allowedKeys: new HashSet<string> { "territoryIds", "defenseBonus" });

        EventHandlerRegistry.RegisterHandler("border_fortification", HandleBorderFortification);
    }

    internal static bool HandleBorderFortification(ScheduledEventRecord record)
    {
        // Border fortification: defensive bonus on specific territories for one round.
        // NOT IMPLEMENTED - no gameplay effects defined yet.
        // Returning false to indicate unimplemented handler.
        return false;
    }

    // =====================================================================
    // Personal (player-turn-based) effects
    // =====================================================================

    internal static object DeserializeBerserkRage(Dictionary<string, JsonElement> payload, int schemaVersion)
    {
        var attackBonus = EventPayloads.GetRequiredInt(payload, "attackBonus");
        var duration = EventPayloads.GetRequiredInt(payload, "durationPlayerTurns");
        return new EventPayloads.BerserkRagePayload(attackBonus, duration);
    }

    internal static void ValidateBerserkRage(object payload)
    {
        var p = (EventPayloads.BerserkRagePayload)payload;
        if (p.AttackBonus < 1)
            throw new ScheduledEventValidationException("berserk_rage", "AttackBonus must be >= 1.");
        if (p.DurationPlayerTurns < 1)
            throw new ScheduledEventValidationException("berserk_rage", "DurationPlayerTurns must be >= 1.");
    }

    internal static void RegisterBerserkRage()
    {
        EventTypeRegistry.Register(
            eventTypeKey: "berserk_rage",
            supportedVersions: [1, 2],
            deserializer: DeserializeBerserkRage,
            validator: ValidateBerserkRage,
            payloadType: typeof(EventPayloads.BerserkRagePayload),
            allowedKeys: new HashSet<string> { "attackBonus", "durationPlayerTurns" });

        EventHandlerRegistry.RegisterHandler("berserk_rage", HandleBerserkRage);
    }

    internal static bool HandleBerserkRage(ScheduledEventRecord record)
    {
        // Berserk rage: player's next attacks gain bonus strength for N turns.
        // NOT IMPLEMENTED - no gameplay effects defined yet.
        // Returning false to indicate unimplemented handler.
        return false;
    }

    internal static object DeserializeSupplyDisruption(Dictionary<string, JsonElement> payload, int schemaVersion)
    {
        var armiesLost = EventPayloads.GetRequiredInt(payload, "armiesLostPerTurn");
        var duration = EventPayloads.GetRequiredInt(payload, "durationPlayerTurns");
        return new EventPayloads.SupplyDisruptionPayload(armiesLost, duration);
    }

    internal static void ValidateSupplyDisruption(object payload)
    {
        var p = (EventPayloads.SupplyDisruptionPayload)payload;
        if (p.ArmiesLostPerTurn < 1)
            throw new ScheduledEventValidationException("supply_disruption", "ArmiesLostPerTurn must be >= 1.");
        if (p.DurationPlayerTurns < 1)
            throw new ScheduledEventValidationException("supply_disruption", "DurationPlayerTurns must be >= 1.");
    }

    internal static void RegisterSupplyDisruption()
    {
        EventTypeRegistry.Register(
            eventTypeKey: "supply_disruption",
            supportedVersions: [1],
            deserializer: DeserializeSupplyDisruption,
            validator: ValidateSupplyDisruption,
            payloadType: typeof(EventPayloads.SupplyDisruptionPayload),
            allowedKeys: new HashSet<string> { "armiesLostPerTurn", "durationPlayerTurns" });

        EventHandlerRegistry.RegisterHandler("supply_disruption", HandleSupplyDisruption);
    }

    internal static bool HandleSupplyDisruption(ScheduledEventRecord record)
    {
        // Supply disruption: player's territories suffer attrition for N turns.
        // NOT IMPLEMENTED - no gameplay effects defined yet.
        // Returning false to indicate unimplemented handler.
        return false;
    }

    internal static object DeserializeFortificationBoost(Dictionary<string, JsonElement> payload, int schemaVersion)
    {
        var bonusArmies = EventPayloads.GetRequiredInt(payload, "bonusArmies");
        var duration = EventPayloads.GetRequiredInt(payload, "durationPlayerTurns");
        return new EventPayloads.FortificationBoostPayload(bonusArmies, duration);
    }

    internal static void ValidateFortificationBoost(object payload)
    {
        var p = (EventPayloads.FortificationBoostPayload)payload;
        if (p.BonusArmies < 1)
            throw new ScheduledEventValidationException("fortification_boost", "BonusArmies must be >= 1.");
        if (p.DurationPlayerTurns < 1)
            throw new ScheduledEventValidationException("fortification_boost", "DurationPlayerTurns must be >= 1.");
    }

    internal static void RegisterFortificationBoost()
    {
        EventTypeRegistry.Register(
            eventTypeKey: "fortification_boost",
            supportedVersions: [1],
            deserializer: DeserializeFortificationBoost,
            validator: ValidateFortificationBoost,
            payloadType: typeof(EventPayloads.FortificationBoostPayload),
            allowedKeys: new HashSet<string> { "bonusArmies", "durationPlayerTurns" });

        EventHandlerRegistry.RegisterHandler("fortification_boost", HandleFortificationBoost);
    }

    internal static bool HandleFortificationBoost(ScheduledEventRecord record)
    {
        // Fortification boost: player's next fortifications are more effective.
        // NOT IMPLEMENTED - no gameplay effects defined yet.
        // Returning false to indicate unimplemented handler.
        return false;
    }
}