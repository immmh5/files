# Networking Design

## Design Philosophy

Networking is designed as a **transport-agnostic service layer**. The game domain and state management should never know or care whether they are running locally or over a network connection. All network I/O is isolated behind well-defined interfaces.

## Key Interfaces

### INetworkTransport

```csharp
public interface INetworkTransport
{
    Task ConnectAsync(EndPoint endpoint, CancellationToken ct);
    Task DisconnectAsync();
    Task SendPacketAsync(GamePacket packet, TransmissionType type);
    IAsyncEnumerable<GamePacket> ReceivePacketsAsync(CancellationToken ct);
    bool IsConnected { get; }
    string LocalPeerId { get; }
    string RemotePeerId { get; }
}

public enum TransmissionType
{
    Unreliable,  // Fire-and-forget (e.g., real-time input)
    Reliable,    // Acknowledged, ordered (e.g., order submission)
    ReliableOrdered  // Ordered with deduplication (e.g., state sync)
}
```

### INetworkDiscovery

```csharp
public interface INetworkDiscovery
{
    Task<IReadOnlyList<DiscoveredRoom>> DiscoverRoomsAsync(TimeSpan timeout, CancellationToken ct);
    Task<RoomInfo> CreateRoomAsync(RoomOptions options, CancellationToken ct);
    Task JoinRoomAsync(string roomId, CancellationToken ct);
    event Action<RoomInfo>? OnRoomDiscovered;
    event Action<string>? OnRoomRemoved;
}
```

### GamePacket

All network data flows through typed `GamePacket` envelopes:

```csharp
public readonly struct GamePacket
{
    public PacketType Type { get; }          // Enum discriminator
    public byte[] Payload { get; }           // MessagePack-serialised body
    public string SenderId { get; }
    public long SequenceNumber { get; }
    public DateTime Timestamp { get; }
}

public enum PacketType
{
    JoinRequest,
    JoinAccept,
    Leave,
    OrderSubmit,
    OrderAck,
    StateSnapshot,
    Heartbeat,
    RoomDiscovery,
    ChatMessage,
}
```

---

## Network Topology

- **Primary topology:** Host-authoritative full-mesh.
  - All peers connect to the host.
  - Host holds the authoritative `GameState`.
  - Each peer maintains a **read-only mirror** of the game state.
  - Only the host's `CombatSystem` and `TurnManager` run; all others are mirrors.

- **Direct peer-to-peer (future):** Optional full-mesh for dedicated server mode or when host is absent. Requires WebRTC or a relay.

## LAN Multiplayer Requirements

Must work without internet:
- **Room discovery:** UDP broadcast on the local network segment (port 27100).
- **Fallback:** Manual IP:port entry by the joining player.
- **No STUN/TURN:** No cloud service required for LAN.

## Host-Authoritative Turn Flow

```
1. Host starts game, all clients connect.
2. Host sends StateSnapshot to all clients (initial).
3. Each turn phase:
   a. Host broadcasts TurnStartedEvent.
   b. Clients submit orders via OrderSubmit packets.
   c. Host collects orders until timeout or all ready.
   d. Host resolves orders (CombatSystem).
   e. Host broadcasts new StateSnapshot to all clients.
   f. Clients apply snapshot to local mirror (readonly for game logic).
4. On disconnect: Host waits for reconnect timer, then continues or drops.
```

## Serialization

- `MessagePack-CSharp` for efficient binary serialization.
- Core types (GameState, Orders, Events) are fully serializable.
- Versioned schema with forward/backward compatibility via `[MessagePackFormatter]` attributes.

## Initial Implementation Scope (Future Milestones)

- Milestone 1: `FakeTransport` (single-player loopback for testing).
- Milestone 2: `ENetTransport` for LAN (UDP reliable/unreliable).
- Milestone 3: Room discovery via UDP broadcast.
- Milestone 4: Full host-authoritative sync.

## Known Limitations

- NAT traversal for direct internet connections requires STUN/TURN (future).
- This spec does NOT include cloud matchmaking — it's entirely LAN-first.
