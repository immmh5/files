namespace StrategyGame.Core.Common;

/// <summary>
/// Represents a domain entity with a stable identity.
/// </summary>
public abstract class Entity
{
    public required string Id { get; init; }

    public override bool Equals(object? obj)
    {
        if (obj is not Entity other) return false;
        return Id == other.Id;
    }

    public override int GetHashCode() => Id.GetHashCode();

    public static bool operator ==(Entity? a, Entity? b) =>
        ReferenceEquals(a, b) || (a is not null && b is not null && a.Equals(b));

    public static bool operator !=(Entity? a, Entity? b) => !(a == b);
}
