# DOMAIN_MODEL.md

**Status:** PROPOSED ARCHITECTURE
**Purpose:** Define the core domain entities, value objects, aggregates, and their invariants.

---

## 1. Domain Entity Overview

| Entity | Identity | Aggregate Root | Purpose |
|---|---|---|---|
| `Territory` | `Id` (string) | `GameState` | Land area with armies, ownership, adjacency |
| `Player` | `Id` (string) | `GameState` | Human or AI participant with faction |
| `Faction` | `Id` (string) | `MapDefinition` (static) | Identity, color, passive bonus |
| `GameState` | `GameId` (string) | Self | Root aggregate; owns territories, players, turn state |

---

## 2. Territory

### Properties
| Property | Type | Mutability | Description |
|---|---|---|---|
| `Id` | `string` | Immutable | Unique within map |
| `Name` | `string` | Immutable | Display name |
| `AdjacentTerritoryIds` | `IReadOnlyList<string>` | Immutable | Adjacency graph edges |
| `OwnerPlayerId` | `string?` | Mutable (TurnEngine only) | Owning player; `null` = neutral |
| `Armies` | `int` | Mutable (TurnEngine only) | Army count; min 1 if owned |

### Constructors
```csharp
// New territory (start of game / map loading)
public Territory(string id, string name, IReadOnlyList<string> adjacentTerritoryIds)

// From save / snapshot
public Territory(string id, string name, IReadOnlyList<string> adjacentTerritoryIds,
    string? ownerPlayerId, int armies)
```

### Methods
| Method | Purpose | Preconditions |
|---|---|---|
| `SetOwner(playerId, armies)` | Transfer ownership | `armies >= 1` |
| `AddArmies(count)` | Reinforce | `count > 0` |
| `RemoveArmies(count)` | Attrition / movement cost | `count >= 0 && count <= Armies` |
| `IsAdjacentTo(otherId)` | Graph query | — |
| `CanAttackFrom` | `Armies > 1` | — |
| `Snapshot()` | Immutable copy for serialization | — |

### Invariants
- `Armies >= 1` if `OwnerPlayerId != null`
- `OwnerPlayerId == null` ⇔ `Armies == 0`
- `AdjacentTerritoryIds` contains no duplicates, no self-references
- Adjacency is symmetric (if A adjacent to B, then B adjacent to A)

---

## 3. Player

### Properties
| Property | Type | Mutability | Description |
|---|---|---|---|
| `Id` | `string` | Immutable | Unique |
| `Name` | `string` | Mutable (setup only) | Display name |
| `Faction` | `Faction` | Immutable | Faction reference |
| `IsHuman` | `bool` | Immutable | Human vs AI |
| `ArmiesToPlace` | `int` | Mutable (TurnEngine only) | Pending reinforcement armies |

### Methods
| Method | Purpose |
|---|---|
| `AddArmies(count)` | Credit income / reinforcement |
| `PlaceArmies(count)` | Spend armies during placement |
| `Snapshot()` | Immutable copy |

### Invariants
- `ArmiesToPlace >= 0`
- Exactly one `Faction` per player

---

## 4. Faction (Static Data)

### Properties
| Property | Type | Description |
|---|---|---|
| `Id` | `string` | Unique; used as key in lookups |
| `Name` | `string` | Display name |
| `ColorHex` | `string` | UI color (e.g., `#FF0000`) |
| `ArmyBonusPerTerritory` | `int` | Income modifier (first playable = 0) |
| `InitialTerritories` | `int` | Setup parameter |

### First-Playable Factions
| Id | Name | Color | Passive Bonus |
|---|---|---|---|
| `aethelgard` | Aethelgard | `#FF0000` | Plains defense +1 |
| `varkul` | Varkul Clan | `#000000` | Marsh attrition −1 |
| `sapphire` | Sapphire Covenant | `#0000FF` | Coast supply radius +1 |
| `verdant` | Verdant League | `#00FF00` | Forest movement cost −1 |
| `ironstone` | Ironstone Dominion | `#808080` | Hills income +10% |
| `crimson` | Crimson Ascendancy | `#FF8C00` | Mountain attack penalty −1 |

---

## 5. MapDefinition (Static Data)

### Properties
| Property | Type | Description |
|---|---|---|
| `Id` | `string` | Map identifier |
| `Name` | `string` | Display name |
| `Territories` | `IReadOnlyDictionary<string, Territory>` | All territories by ID |
| `Regions` | `IReadOnlyList<Region>` | Continent/bonus groups |

### Region
```csharp
record Region(string Id, string Name, int BonusArmies);
```

---

## 6. Order / Action Model

### OrderType
```csharp
enum OrderType { Move, Attack, Fortify, PlaceArmies }
```

### Order (Command DTO)
```csharp
record Order(
    string Id,
    string PlayerId,
    OrderType Type,
    string? FromTerritoryId,
    string? ToTerritoryId,
    int Armies
);
```

### Factory Methods
```csharp
Order.Move(id, playerId, fromId, toId, armies)
Order.Attack(id, playerId, fromId, toId, armies)
Order.Fortify(id, playerId, fromId, toId, armies)
Order.PlaceArmies(id, playerId, toId, armies)
```

### Validation Rules (Enforced by TurnEngine)
- `Move`: `from` owned by player, `from` has ≥ 2 armies, `to` adjacent and owned by same player
- `Attack`: `from` owned by player, `from` has ≥ 2 armies, `to` adjacent and enemy-owned
- `Fortify`: `from` owned by player, `from` has ≥ 2 armies, `to` adjacent, owned by same player, not on front line
- `PlaceArmies`: `to` owned by player, `ArmiesToPlace >= armies`

---

## 7. GameState (Root Aggregate)

### Properties
| Property | Type | Description |
|---|---|---|
| `GameId` | `string` | Unique per match |
| `Map` | `MapDefinition` | Static map reference |
| `Players` | `IReadOnlyList<Player>` | All players in match |
| `Territories` | `IReadOnlyDictionary<string, Territory>` | Live territory state |
| `CurrentTurnPlayerId` | `string` | Active player |
| `CurrentTurnNumber` | `int` | Increments per player turn |
| `CurrentStage` | `TurnStage` | A: Start, B: Actions, C: Events, D: End |

### TurnStage Enum
```csharp
enum TurnStage { TurnStart, PlayerActions, EventProcessing, TurnEnd }
```

### Derived Queries
- `GetTerritory(id)` → Territory
- `GetPlayer(id)` → Player
- `GetAllTerritories()` → all territories
- `GetTerritoriesOwnedBy(playerId)` → player's territories
- `GetTerritoriesOnFrontLine(playerId)` → territories adjacent to enemy

### Invariants
- Exactly one player has `CurrentTurnPlayerId`
- `CurrentTurnNumber` increments only on `TurnEnd` (stage D)
- All territories in `Territories` are copies from `Map.Territories` (not the same instances)

---

## 8. Combat & Resolution

### CombatResult
```csharp
record CombatResult(
    bool AttackerWon,
    int AttackerRemaining,
    int DefenderRemaining,
    string? CapturedTerritoryId
);
```

### Resolution Algorithm (Pure Function)
```
AttackerStrength = AttackerArmies - 1
DefenderStrength = DefenderArmies + TerrainBonus + FactionDefenseBonus

if AttackerStrength > DefenderStrength:
    AttackerWins = true
    AttackerLosses = floor(DefenderStrength / 2)
    DefenderLosses = DefenderArmies
    Captured = true
else:
    AttackerWins = false
    AttackerLosses = 0
    DefenderLosses = floor(AttackerStrength / 2)
    Captured = false
```
**Defender wins ties.**

---

## 9. Supply / Attrition

### Supply Source
- Capital territory (designated in map)
- Coast territory (terrain = Coast)

### Supply Check (Flood Fill)
```
SuppliedTerritories = FloodFill from all supply sources through owned adjacent territories
UnsuppliedGroup = OwnedTerritories \ SuppliedTerritories
```

### Attrition (Applied in Turn Start)
```
For each UnsuppliedGroup:
    For each territory in group:
        Remove 1 army (min 1 garrison remains)
        If Armies == 0: SetOwner(null, 0) → becomes neutral
```

---

## 10. Event Model

### GameEvent (Base)
```csharp
interface GameEvent {
    long EventId { get; }
    DateTime Timestamp { get; }
}
```

### Core Events
| Event | Payload |
|---|---|
| `TurnStartedEvent` | `PlayerId`, `TurnNumber`, `Stage` |
| `OrderSubmittedEvent` | `PlayerId`, `OrderId`, `Type`, `From`, `To`, `Armies` |
| `OrderResolvedEvent` | `OrderId`, `Success`, `ResultDetails` |
| `TerritoryCapturedEvent` | `TerritoryId`, `NewOwnerPlayerId`, `ArmiesOnCapture` |
| `ArmiesPlacedEvent` | `TerritoryId`, `PlayerId`, `Armies` |
| `SupplyAttritionEvent` | `TerritoryId`, `ArmiesLost` |
| `EffectAppliedEvent` | `EffectId`, `Target`, `Duration` |
| `EffectExpiredEvent` | `EffectId`, `Target` |
| `VictoryEvent` | `WinningPlayerId`, `Condition`, `Reason` |
| `TurnEndedEvent` | `PlayerId`, `NextPlayerId`, `TurnNumber` |

---

## 11. Effect / Status Model

### Effect
```csharp
record Effect(
    string Id,
    string TargetId,           // Territory or Player
    EffectType Type,
    int DurationTurns,         // Remaining turns
    Dictionary<string, object> Params
);
```

### EffectType
```csharp
enum EffectType {
    SupplyDisruption,   // Cannot trace supply through this territory
    MoraleBonus,        // +N attack/defense
    IncomeModifier,     // ×N income for territory/player
    MovementCostChange  // ±N movement cost
}
```

---

## 12. Save Serialization Model

### SaveFile
```csharp
record SaveFile(
    int SchemaVersion,
    string MapId,
    string MapHash,
    GameStateSnapshot InitialState,
    ImmutableList<CommandRecord> CommandLog,
    SaveMetadata Metadata,
    string Checksum
);

record CommandRecord(
    int TurnNumber,
    string PlayerId,
    Order Order,
    DateTime Timestamp
);

record SaveMetadata(
    DateTime CreatedAt,
    TimeSpan Duration,
    ImmutableList<string> PlayerNames,
    int TurnCount
);
```

### GameStateSnapshot (Immutable)
```csharp
record GameStateSnapshot(
    string GameId,
    ImmutableList<TerritorySnapshot> Territories,
    ImmutableList<PlayerSnapshot> Players,
    string CurrentTurnPlayerId,
    int CurrentTurnNumber,
    TurnStage CurrentStage,
    ImmutableList<EffectSnapshot> PendingEffects
);
```

---

## 13. Type Identity Map (Namespace Guide)

| Type | Namespace |
|---|---|
| `Territory`, `Player`, `Faction`, `MapDefinition`, `Region` | `StrategyGame.Core.Domain` |
| `GameState`, `TurnEngine`, `CombatSystem`, `VictoryChecker`, `SupplyEngine` | `StrategyGame.Core.GameState` |
| `GameEvent`, `EventBus`, `*Event` types | `StrategyGame.Core.Events` |
| `ValueObject`, `Entity`, `Result<T>`, `IdGenerator` | `StrategyGame.Core.Common` |
| `ISaveSerializer`, `IMapLoader` | `StrategyGame.Core.Storage` |
| `INetworkTransport`, `INetworkDiscovery`, `GamePacket` | `StrategyGame.Core.Networking` |
| `IAIPlayer` | `StrategyGame.Core.AI` |