# CORE_GAME_LOOP.md

**Status:** PROPOSED DESIGN (awaiting user approval)
**Supersedes:** none
**Referenced by:** all documents in `docs/design/`

---

## 1. The Game in One Paragraph

**Iron Dominion** (working title) is a turn-based territorial strategy game for 2–6 players using a **hybrid turn system** — classic sequential player turns combined with persistent gameplay events that span and act across turns. Every battle is resolved by deterministic rules: no dice, no randomness in combat. The tension comes from outthinking opponents, not from lucky rolls. Depth comes from supply lines, terrain, and opponent modeling on a fully readable map.

## 2. Design Pillars

| # | Pillar | Meaning |
|---|---|---|
| P1 | **Deterministic warfare** | Identical inputs always produce identical outcomes. No RNG in combat, income, or AI. Enables replays, testability, and skill expression. |
| P2 | **Hybrid turns** | Classic sequential player turns, each split into Turn Start → Player Actions → Persistent Event Processing → Turn End. Persistent events span turns. *(User-approved provisional; supersedes the earlier simultaneous-planning proposal.)* |
| P3 | **Supply is life** | Armies cut off from friendly territory attrit. Flanking and encirclement are real strategies, not just attack/defend alternation. |
| P4 | **Readable map, hidden intent** | Full information on the board; uncertainty exists only in *what the active opponent will do*. The game is won by prediction, not by hidden stats. |
| P5 | **A turn is a decision** | Each player's turn is one meaningful strategic commitment. A full game is 15–30 turns per player; a turn takes 1–3 minutes. |

## 3. The Turn Loop (Hybrid: Sequential Turns + Persistent Events)

```
┌───────────────────────────────────────────────────────────┐
│ PLAYER N's TURN                                            │
│                                                            │
│  A. TURN START               (deterministic, automatic)    │
│     ├─ Calculate reinforcements (income + region bonuses) │
│     ├─ Apply scheduled start-of-turn effects              │
│     └─ Update resources (income credited, attrition)      │
│                                                            │
│  B. PLAYER ACTION PHASE      (player-controlled)          │
│     ├─ Active player issues move/attack/fortify orders    │
│     ├─ Actions resolve as issued (deterministic combat)   │
│     └─ Turn timer optional (flow control, not sim clock)  │
│                                                            │
│  C. PERSISTENT EVENT PROCESSING (deterministic, automatic)│
│     ├─ Fire events whose conditions/times were reached    │
│     ├─ Decrement multi-turn effect durations              │
│     └─ Remove expired effects                             │
│                                                            │
│  D. TURN END                 (deterministic, automatic)    │
│     ├─ Apply end-of-turn effects                          │
│     ├─ Victory & elimination check                        │
│     └─ Advance to next player's Turn Start                │
└───────────────────────────────────────────────────────────┘
```

**Persistent events** (multi-turn effects) are processed at stage C of **every** player's turn — they are attached to the game, not the player. See `TURN_AND_EVENT_SYSTEM.md` for the authoritative specification.

## 4. Player Actions Available Each Turn

| Action | Cost | Constraint | Effect |
|---|---|---|---|
| Move | 1 order slot | Source has ≥ 2 armies; territory not already acting | Transfer armies to an **adjacent owned** territory |
| Attack | 1 order slot | Source has ≥ 2 armies; target is adjacent **enemy** territory | Commit all but 1 army into a battle |
| Fortify | 1 order slot | Source has ≥ 2 armies; territory not on a front line (no adjacent enemy) | Move armies deeper into friendly territory |
| Place armies | Income | Only during Turn Start / Action Phase; only on owned territories | Distribute newly earned armies |

**One action per territory per turn** — a territory that moves/attacks/fortifies cannot act again this turn. This is the primary action economy. (Command Points are a future expansion; see `SPECIAL_ABILITIES_AND_EXPANSIONS.md`.)

**Action resolution:** In the hybrid system, actions resolve **as issued** during stage B — there is no batch planning phase. Combat resolution remains a deterministic pure function.

## 5. The Strategic Depth Model

Depth emerges from four interacting systems:

1. **Terrain** — defense bonuses make some routes expensive; attacking into mountains is a real commitment.
2. **Supply** — a bold deep strike that gets cut off bleeds armies every turn. Encirclement wins wars.
3. **Sequential turns** — you act, then opponents respond; prediction and tempo matter.
4. **Continent bonuses** — overextending to grab a bonus invites the counterattack that takes it back.

## 6. What Differentiates This From Classic Risk

| Classic Risk | Iron Dominion |
|---|---|
| Dice-based combat | Deterministic combat; outcomes are computable in advance |
| Reinforcements only at turn start | Turn-start reinforcements + start-of-turn effects |
| No supply concept | Supply lines and attrition |
| Armies are interchangeable blobs | Terrain, fronts, and encirclement matter |
| Snowballing winner | Attrition and overextension create natural comebacks |
| Static world between turns | Persistent events span and act across turns |

## 7. Target Player Experience

- **Session length:** 20–45 minutes for a standard 2–4 player game.
- **Cognitive profile:** thinky but not punishing; every loss is legible ("I overextended the salient and it got cut off"), never "unlucky dice."
- **Emotional arc:** probing opening → tense mid-game standoff → decisive commitment.
- **Audience:** strategy players who dislike randomness-heavy classics (Risk, dice games) and want a deterministic, board-game-feeling experience playable in an evening.

## 8. Essential vs Optional

**Essential (first playable):** turn loop above, deterministic combat, terrain defense bonuses, supply/attrition, continent bonuses, 2–6 players (mix of human and AI), one standard map, elimination + domination victory, save/load.

**Optional (later):** alliances, diplomacy, cards, tech, special abilities, multiplayer transports, map editor, replay UI, additional maps. See `FIRST_PLAYABLE_VERSION.md` for the authoritative scope split.
