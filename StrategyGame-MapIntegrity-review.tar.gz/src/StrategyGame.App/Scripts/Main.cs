using Godot;
using System.Runtime.InteropServices;

/// <summary>
/// Root scene for the application. Smoke test only.
/// </summary>
[GlobalClass]
public partial class Main : Node
{
    private const string Version = "0.0.1-dev";
    private const string AppName = "StrategyGame";

    public override void _Ready()
    {
        GD.Print($"[{AppName}] Starting v{Version}");
        GD.Print($"[{AppName}] Engine: Godot 4.7.2 Mono");
        GD.Print($"[{AppName}] .NET: {typeof(object).Assembly.GetName().Version}");
        GD.Print($"[{AppName}] Environment: {RuntimeInformation.OSDescription}");
        GD.Print($"[{AppName}] Ready.");
    }

    public override void _Input(InputEvent @event)
    {
        if (@event is InputEventKey keyEvent && keyEvent.Keycode == Key.Escape)
        {
            GD.Print($"[{AppName}] Quit.");
            GetTree().Quit();
        }
    }
}
