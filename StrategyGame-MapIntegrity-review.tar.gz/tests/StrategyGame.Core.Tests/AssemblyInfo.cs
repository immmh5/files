using Xunit;

// Disable parallel test execution to avoid test isolation issues with global static state
[assembly: CollectionBehavior(DisableTestParallelization = true)]