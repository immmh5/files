namespace StrategyGame.Core.Events;

/// <summary>
/// Base interface for all game events.
/// All events are immutable value objects (records).
/// </summary>
public interface GameEvent
{
    long EventId { get; }
    DateTime Timestamp { get; }
}

/// <summary>
/// In-process event bus for decoupled state change notification.
/// Used by the App layer to react to domain events.
/// </summary>
public interface IEventBus
{
    void Subscribe<T>(Action<T> handler) where T : GameEvent;
    void Unsubscribe<T>(Action<T> handler) where T : GameEvent;
    void Publish<T>(T @event) where T : GameEvent;
    int SubscriptionCount<T>() where T : GameEvent;
}

/// <summary>
/// Simple synchronous in-process event bus implementation.
/// Single-threaded use (typical Godot main-loop usage); no multithreading support.
///
/// DISPATCH SEMANTICS (R4.1, documented and tested):
/// - Each Publish processes a stable snapshot of subscribers taken at dispatch start.
///   Subscribe/Unsubscribe during dispatch affect SUBSEQUENT publishes only.
/// - Handler invocation order is deterministic: registration order, FIFO.
/// - Duplicate subscriptions are allowed; each registration runs once per publish.
/// - Nested Publish is permitted; the inner dispatch completes before the outer
///   handler continues, and each level uses its own snapshot.
/// - Exception policy: fail-fast. A throwing handler propagates to the caller;
///   remaining handlers for that publish are skipped. Callers needing resilience
///   must catch inside their handlers.
/// </summary>
public sealed class EventBus : IEventBus
{
    private readonly Dictionary<Type, List<Delegate>> _handlers = new();

    public void Subscribe<T>(Action<T> handler) where T : GameEvent
    {
        ArgumentNullException.ThrowIfNull(handler);
        var key = typeof(T);
        if (!_handlers.TryGetValue(key, out var handlers))
            _handlers[key] = handlers = [];
        handlers.Add(handler);
    }

    public void Unsubscribe<T>(Action<T> handler) where T : GameEvent
    {
        var key = typeof(T);
        if (_handlers.TryGetValue(key, out var handlers))
            handlers.Remove(handler);
    }

    public void Publish<T>(T @event) where T : GameEvent
    {
        var key = typeof(T);
        if (!_handlers.TryGetValue(key, out var handlers) || handlers.Count == 0)
            return;

        // Snapshot at dispatch start so re-entrant Subscribe/Unsubscribe from
        // handlers cannot mutate the collection being enumerated.
        Delegate[] snapshot = [.. handlers];
        foreach (var handler in snapshot)
            ((Action<T>)handler)(@event);
    }

    public int SubscriptionCount<T>() where T : GameEvent =>
        _handlers.TryGetValue(typeof(T), out var handlers) ? handlers.Count : 0;
}
