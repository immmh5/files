namespace StrategyGame.Integration.Tests;

using StrategyGame.Core.Domain;
using StrategyGame.Core.GameState;
using Xunit;

/// <summary>
/// Integration/smoke tests for the Core library.
/// These verify that the game core initializes correctly and can produce a valid GameState.
/// </summary>
public class AppStartupTests
{
    [Fact]
    public void GameState_CanCreateWithMultiplePlayers_Succeeds()
    {
        var map = new MapDefinition("map-test", "Test Map", new[]
        {
            new Territory("A", "A", ["B"]),
            new Territory("B", "B", ["A"]),
        });

        var p1 = new Player("p1", "Alice", new Faction("f1", "Red", "#FF0000"), true);
        var p2 = new Player("p2", "Bob", new Faction("f2", "Blue", "#0000FF"), false);

        var state = new GameState("g1", map, [p1, p2], "p1", 1, TurnManager.PhaseReinforce);

        Assert.Equal("g1", state.GameId);
        Assert.Equal("map-test", state.Map.Id);
        Assert.Equal(2, state.Players.Count);
        Assert.Equal("p1", state.CurrentTurnPlayerId);
        Assert.Equal(1, state.CurrentTurnNumber);
        Assert.Equal(TurnManager.PhaseReinforce, state.CurrentPhase);
    }

    [Fact]
    public void GameState_Snapshot_ReturnsEquivalentState_DifferentReference()
    {
        var map = new MapDefinition("map-snap", "Snapshot", new[]
        {
            new Territory("A", "A", []),
        });
        var player = new Player("p1", "Test", new Faction("f1", "Red", "#FF0000"), true);
        var state = new GameState("g1", map, [player], "p1", 1, TurnManager.PhaseReinforce);

        state.GetTerritory("A").SetOwner("p1", 3);
        var snapshot = state.Snapshot();

        Assert.Equal(state.GameId, snapshot.GameId);
        Assert.NotSame(state, snapshot); // Deep copy
        Assert.Equal("p1", snapshot.GetTerritory("A").OwnerPlayerId);
    }

    [Fact]
    public void TurnManager_AdvanceTurn_CyclesThroughPlayers()
    {
        var players = new[] { "p1", "p2", "p3" };
        var result = TurnManager.AdvanceTurn("p3", "p2", 5, players);

        Assert.Equal("p1", result.NextTurnPlayerId);
        Assert.Equal(6, result.NextTurnNumber);
        Assert.Equal(TurnManager.PhaseReinforce, result.NewPhase);
    }

    [Fact]
    public void TurnManager_TransitionPhase_ReinforceToAttack_Succeeds()
    {
        var next = TurnManager.TransitionPhase(TurnManager.PhaseReinforce, TurnManager.PhaseAttack);
        Assert.Equal(TurnManager.PhaseAttack, next);
    }

    [Fact]
    public void TurnManager_TransitionPhase_InvalidTransition_ThrowsInvalidOperationException()
    {
        Assert.Throws<InvalidOperationException>(() =>
            TurnManager.TransitionPhase(TurnManager.PhaseAttack, TurnManager.PhaseReinforce));
    }

    [Fact]
    public void GameRules_ComputeReinforcements_WithTenTerritories_ReturnsThree()
    {
        var rules = new GameRules(armyRatioForReinforcement: 3, maximumReinforcements: 10);
        var reinforcements = rules.ComputeReinforcements(10);
        Assert.Equal(3, reinforcements);
    }

    [Fact]
    public void GameRules_ComputeReinforcements_WithExcessiveTerritories_CapsAtMaximum()
    {
        var rules = new GameRules(armyRatioForReinforcement: 3, maximumReinforcements: 5);
        var reinforcements = rules.ComputeReinforcements(100);
        Assert.Equal(5, reinforcements);
    }
}
