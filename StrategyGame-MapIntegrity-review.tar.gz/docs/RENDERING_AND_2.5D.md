# Rendering and 2.5D Strategy Map — Design Document

## Rendering Approach

The strategy map uses a **2D forward rendering pipeline with layered depth** — not a full 3D world. The goal is to achieve the visual illusion of depth (elevation, shadows, layering) on a primarily 2D strategic plane.

## Layer Architecture

| Layer | Type | Contents | Z-Index |
|---|---|---|---|
| Map Base | `Node2D` / `TileMap` | Territory polygons, terrain textures | 0 |
| Terrain Detail | `Node2D` | Decorative overlays (forests, mountains via sprites) | 1 |
| Borders | `Line2D` / `Polygon2D` | Territory border lines with faction coloring | 2 |
| Highlight | `SubViewport` | Selection ring, hover glow, attack animations | 3 |
| Army Markers | `Node2D` | Sprite-based unit markers at territory centroids | 4 |
| Effects | `Node2D` | Particle-like animations (combat, reinforcement) | 5 |
| UI Canvas | `CanvasLayer` | Control-based HUD (health bars, buttons, labels) | 100 |

## Camera

- `Camera2D` with **smooth zoom** (0.5x–4.0x range) and **pan via drag or WASD**.
- Camera bounds clamped to map extents.
- Tween-based smooth follow for territory selection transitions.

## Visual Depth Techniques

1. **Shadow layers:** Each territory has a `Polygon2D` shadow beneath it, offset slightly to suggest elevation.
2. **Shading gradients:** Territory interiors shaded by a directional light vector (simulating sun angle).
3. **Elevation tint:** Higher-elevation territories are slightly desaturated with a cooler tint.
4. **Border depth:** Borders drawn with a slight inner bevel / outer shadow.
5. **Layered opacity:** Front-layer territories rendered with slight transparency to suggest overlap.

## Territory Rendering

- Territories defined as **convex or concave polygons** stored in `MapDefinition`.
- Rendered via `Polygon2D` nodes created dynamically from the map data.
- Each territory node is a `SubViewportContainer` holding:
  - Background polygon (terrain fill).
  - Shadow polygon (offset, dark).
  - Border polygon (faction-colored outline).
  - Interactive hit area (Area2D with polygon collision).

## Selection and Interaction

1. `Area2D` on each territory captures `mouse_entered` / `mouse_exited`.
2. Selection state stored in `GameController` (App layer), mapped to territory IDs.
3. Selection visual via a `Polygon2D` highlight layer (pulsing opacity animation).
4. Click triggers order submission (right-click context or bottom panel).

## Color and Style

- **Palette:** Dark fantasy / strategic map aesthetic.
- **Faction colors:** Distinct hues, 6+ saturation, 60% lightness for legibility.
- **UI:** Dark theme, minimal chrome, clear typography.
- All assets original or open-license (no proprietary game art).

## Performance Considerations

- Static map layers cached to `ViewportTexture` to avoid re-drawing every frame.
- Dynamic layers (selection, effects) use dedicated `SubViewport` to isolate redraw.
- Territory highlight updates only on selection state change, not per-frame.
- Army marker positions precomputed from territory centroid data.

## Future Considerations

- If territory count exceeds ~500, consider GPU instancing via `MultiMeshInstance2D`.
- If rendering becomes a bottleneck, profile first — the 2D pipeline is usually sufficient for strategy maps.
- C++ through GDExtension only if measured evidence proves necessity.
