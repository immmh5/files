namespace StrategyGame.Core.Tests.Domain;

using StrategyGame.Core.Domain;
using Xunit;

public class TerritoryTests
{
    [Fact]
    public void NewTerritory_WithValidArgs_IsInitializedCorrectly()
    {
        var adjacent = new[] { "B", "C" };
        var territory = new Territory("A", "Test Territory", adjacent);

        Assert.Equal("A", territory.Id);
        Assert.Equal("Test Territory", territory.Name);
        Assert.Equal(0, territory.Armies);
        Assert.Null(territory.OwnerPlayerId);
        Assert.Equal(2, territory.AdjacentTerritoryIds.Count);
        Assert.True(territory.IsAdjacentTo("B"));
        Assert.True(territory.IsAdjacentTo("C"));
        Assert.False(territory.IsAdjacentTo("D"));
    }

    [Fact]
    public void SetOwner_AssignsOwnershipAndArmies_Correctly()
    {
        var territory = new Territory("A", "A", []);
        territory.SetOwner("player1", 5);

        Assert.Equal("player1", territory.OwnerPlayerId);
        Assert.Equal(5, territory.Armies);
    }

    [Fact]
    public void AddArmies_IncrementsArmyCount_Correctly()
    {
        var territory = new Territory("A", "A", []);
        territory.AddArmies(3);
        territory.AddArmies(2);

        Assert.Equal(5, territory.Armies);
    }

    [Fact]
    public void RemoveArmies_RemovesCorrectAmount_ReturnsTrue()
    {
        var territory = new Territory("A", "A", [], ownerPlayerId: null!, armies: 5);
        var result = territory.RemoveArmies(2);

        Assert.True(result);
        Assert.Equal(3, territory.Armies);
    }

    [Fact]
    public void RemoveArmies_WithInsufficientArmies_ReturnsFalse()
    {
        var territory = new Territory("A", "A", [], ownerPlayerId: null!, armies: 2);
        var result = territory.RemoveArmies(5);

        Assert.False(result);
        Assert.Equal(2, territory.Armies);
    }

    [Fact]
    public void RemoveArmies_NegativeValue_ThrowsArgumentOutOfRangeException()
    {
        var territory = new Territory("A", "A", [], ownerPlayerId: null!, armies: 3);
        Assert.Throws<ArgumentOutOfRangeException>(() => territory.AddArmies(-1));
    }

    [Fact]
    public void CanAttackFrom_WhenArmiesGreaterThanOrEqual2_ReturnsTrue()
    {
        var territory = new Territory("A", "A", [], ownerPlayerId: null!, armies: 2);
        Assert.True(territory.CanAttackFrom);
    }

    [Fact]
    public void CanAttackFrom_WhenSingleArmy_ReturnsFalse()
    {
        var territory = new Territory("A", "A", [], ownerPlayerId: null!, armies: 1);
        Assert.False(territory.CanAttackFrom);
    }

    [Fact]
    public void NullId_ThrowsArgumentNullException()
    {
        Assert.Throws<ArgumentNullException>(() => new Territory(null!, "Name", []));
    }

    [Fact]
    public void NullName_ThrowsArgumentNullException()
    {
        Assert.Throws<ArgumentNullException>(() => new Territory("A", null!, []));
    }

    [Fact]
    public void NullAdjacent_ThrowsArgumentNullException()
    {
        Assert.Throws<ArgumentNullException>(() => new Territory("A", "Name", (IReadOnlyList<string>)null!));
    }

    [Fact]
    public void Snapshot_CreatesIndependentCopy_DoesNotMutateWithOriginal()
    {
        var territory = new Territory("A", "A", ["B"]);
        territory.AddArmies(5);
        territory.SetOwner("p1", 3);

        var snapshot = territory.Snapshot();
        territory.AddArmies(10);

        Assert.Equal(3, snapshot.Armies); // Snapshot reflects state at time of capture
        Assert.Equal("A", snapshot.Id);
        Assert.Equal(["B"], snapshot.AdjacentTerritoryIds);
    }
}
