namespace StrategyGame.Core.Tests.Common;

using System.Collections.Concurrent;
using System.Reflection;
using StrategyGame.Core.Common;
using Xunit;

public class IdGeneratorTests
{
    // -----------------------------------------------------------------------
    // Golden deterministic vectors.
    // These literals are SHA-256(namespace NUL seed NUL sequence) truncated to
    // 128 bits, computed independently (Python hashlib). They pin the canonical
    // encoding and byte order, so Windows CI and Linux CI must produce exactly
    // these values — cross-process AND cross-platform determinism in one test.
    // -----------------------------------------------------------------------

    [Theory]
    [InlineData("order", 42, 0, "order_6e630f0b4d9fa248740cd3a0fbc6735c")]
    [InlineData("order", 42, 1, "order_b289104b7741344735153882e5c70531")]
    [InlineData("event", 42, 0, "event_928767e5d8a200f949a460c980456872")]
    [InlineData("player", -7, 3, "player_2159c4c128c7720b5827b7425f79af92")]
    public void NewDeterministicId_MatchesGoldenVector(
        string ns, int seed, int seq, string expected)
    {
        Assert.Equal(expected, IdGenerator.NewDeterministicId(ns, seed, seq));
    }

    [Fact]
    public void StableHash_MatchesFipsVectors()
    {
        // FIPS 180-4 SHA-256 of "abc" and "" truncated to first 16 bytes.
        Assert.Equal("ba7816bf8f01cfea414140de5dae2223",
            StableHash.ToHex(StableHash.GetStableHashCode("abc")));
        Assert.Equal("e3b0c44298fc1c149afbf4c8996fb924",
            StableHash.ToHex(StableHash.GetStableHashCode("")));
    }

    // -----------------------------------------------------------------------
    // Width and format
    // -----------------------------------------------------------------------

    [Fact]
    public void Digest_Is128Bits_StableAcrossCalls()
    {
        var d = StableHash.GetStableHashCode("width-check");
        Assert.Equal(StableHash.DigestWidthBytes, d.Length); // 16 bytes = 128 bits
        Assert.Equal(d, StableHash.GetStableHashCode("width-check"));
    }

    [Fact]
    public void NewDeterministicId_FormatIsNamespacePlus32Hex()
    {
        var id = IdGenerator.NewDeterministicId("unit", 1, 0);
        Assert.StartsWith("unit_", id);
        Assert.Equal("unit_".Length + 32, id.Length);
        Assert.Matches(@"^unit_[0-9a-f]{32}$", id);
    }

    // -----------------------------------------------------------------------
    // Determinism properties
    // -----------------------------------------------------------------------

    [Fact]
    public void NewDeterministicId_SameInputs_ReturnsSameId()
    {
        Assert.Equal(
            IdGenerator.NewDeterministicId("player", 12345, 0),
            IdGenerator.NewDeterministicId("player", 12345, 0));
    }

    [Fact]
    public void NewDeterministicId_DifferentSeeds_ReturnsDifferentIds()
    {
        Assert.NotEqual(
            IdGenerator.NewDeterministicId("player", 12345, 0),
            IdGenerator.NewDeterministicId("player", 54321, 0));
    }

    [Fact]
    public void NewDeterministicId_DifferentSequences_ReturnsDifferentIds()
    {
        Assert.NotEqual(
            IdGenerator.NewDeterministicId("player", 12345, 0),
            IdGenerator.NewDeterministicId("player", 12345, 5));
    }

    [Fact]
    public void NewDeterministicId_NegativeSeed_ValidAndDistinct()
    {
        var pos = IdGenerator.NewDeterministicId("player", 7, 0);
        var neg = IdGenerator.NewDeterministicId("player", -7, 0);
        Assert.NotEqual(pos, neg);
        Assert.Equal(neg, IdGenerator.NewDeterministicId("player", -7, 0));
    }

    [Fact]
    public void NewDeterministicId_IndependentNamespaces_CannotReuseInputSpace()
    {
        // Namespace isolation: same seed+sequence, different namespace => different ID.
        // Canonical NUL separators prevent crafted-namespace collisions such as
        // ("ab", 1, 2) vs ("a", 12, ...) style ambiguity.
        Assert.NotEqual(
            IdGenerator.NewDeterministicId("order", 42, 0),
            IdGenerator.NewDeterministicId("event", 42, 0));
        Assert.NotEqual(
            IdGenerator.NewDeterministicId("ab", 1, 2),
            IdGenerator.NewDeterministicId("a", 12, 2));
    }

    [Fact]
    public void NewDeterministicId_NoProcessGlobalState_ResultsNeverDependOnHistory()
    {
        // Generate many unrelated IDs first; a fresh triple must still equal its golden value.
        for (int i = 0; i < 1000; i++)
            IdGenerator.NewDeterministicId("noise", i, i);

        Assert.Equal("order_6e630f0b4d9fa248740cd3a0fbc6735c",
            IdGenerator.NewDeterministicId("order", 42, 0));
    }

    // -----------------------------------------------------------------------
    // Ref-sequence overload behavior
    // -----------------------------------------------------------------------

    [Fact]
    public void NewDeterministicId_RefOverload_IncrementsAfterValidation()
    {
        int seq = 0;
        var id1 = IdGenerator.NewDeterministicId("player", 42, ref seq);
        var id2 = IdGenerator.NewDeterministicId("player", 42, ref seq);
        var id3 = IdGenerator.NewDeterministicId("player", 42, ref seq);

        Assert.Equal(3, seq);
        Assert.Equal(id1, IdGenerator.NewDeterministicId("player", 42, 0));
        Assert.Equal(id2, IdGenerator.NewDeterministicId("player", 42, 1));
        Assert.NotEqual(id1, id2);
        Assert.NotEqual(id2, id3);
    }

    [Fact]
    public void NewDeterministicId_AtSequenceMax_ThrowsInsteadOfWrapping()
    {
        int seq = int.MaxValue;
        Assert.Throws<OverflowException>(() => IdGenerator.NewDeterministicId("player", 42, ref seq));
        Assert.Equal(int.MaxValue, seq); // unchanged on failure
    }

    // -----------------------------------------------------------------------
    // Invalid inputs
    // -----------------------------------------------------------------------

    [Theory]
    [InlineData("")]
    [InlineData("\0")]
    [InlineData("bad\0ns")]
    public void NewDeterministicId_InvalidNamespace_Throws(string ns)
    {
        Assert.ThrowsAny<ArgumentException>(() => IdGenerator.NewDeterministicId(ns, 1, 0));
    }

    [Fact]
    public void NewDeterministicId_NegativeSequence_Throws()
    {
        Assert.Throws<ArgumentOutOfRangeException>(() => IdGenerator.NewDeterministicId("player", 1, -1));
        int seq = -1;
        Assert.Throws<ArgumentOutOfRangeException>(() => IdGenerator.NewDeterministicId("player", 1, ref seq));
    }

    [Theory]
    [InlineData("")]
    [InlineData("x\0y")]
    public void NonDeterministicModes_InvalidNamespace_Throws(string ns)
    {
        Assert.ThrowsAny<ArgumentException>(() => IdGenerator.NewRandomId(ns));
        Assert.ThrowsAny<ArgumentException>(() => IdGenerator.NewId(ns));
    }

    // -----------------------------------------------------------------------
    // Random / timestamp modes
    // -----------------------------------------------------------------------

    [Fact]
    public void NewRandomId_ReturnsValidFormat()
    {
        var id = IdGenerator.NewRandomId("test");
        Assert.Matches(@"^test_[0-9a-f]{32}$", id);
    }

    [Fact]
    public void NewRandomId_HighVolume_AllUnique()
    {
        var ids = new HashSet<string>();
        for (int i = 0; i < 10_000; i++)
            ids.Add(IdGenerator.NewRandomId("test"));

        // 128-bit CSPRNG-derived space: duplicates would indicate an entropy bug,
        // not mere bad luck. (Probabilistic identifiers offer no absolute guarantee.)
        Assert.Equal(10_000, ids.Count);
    }

    [Fact]
    public void NewId_ReturnsValidFormat_AndHighVolumeUnique()
    {
        var id = IdGenerator.NewId("entity");
        Assert.Matches(@"^entity_[0-9a-f]{32}$", id);

        var ids = new HashSet<string>();
        for (int i = 0; i < 10_000; i++)
            ids.Add(IdGenerator.NewId("entity"));
        Assert.Equal(10_000, ids.Count);
    }

    // -----------------------------------------------------------------------
    // Parallel generation
    // -----------------------------------------------------------------------

    [Fact]
    public void Parallel_NewId_AllUnique()
    {
        var results = new ConcurrentBag<string>();
        Parallel.For(0, 5_000, _ => results.Add(IdGenerator.NewId("parallel")));
        Assert.Equal(5_000, results.Distinct().Count());
    }

    [Fact]
    public void Parallel_DeterministicOwnSequences_EqualResults()
    {
        // Deterministic mode is a pure function: threads with identical inputs
        // MUST agree, regardless of scheduling.
        var results = new ConcurrentBag<string>();
        Parallel.For(0, 100, _ => results.Add(IdGenerator.NewDeterministicId("parallel", 999, 0)));
        Assert.All(results, id => Assert.Equal("parallel_" + ExpectedParallelDigest(), id));
    }

    private static string ExpectedParallelDigest() =>
        StableHash.ToHex(StableHash.GetStableHashCode("parallel\0" + 999 + "\0" + 0));

    // -----------------------------------------------------------------------
    // Removed misleading tracking (regression guard)
    // -----------------------------------------------------------------------

    [Fact]
    public void IdGenerator_ExposesNoCollisionTrackingApi()
    {
        // R3.1 finding #3: the old _seen dictionary recorded but never prevented
        // duplicates. It has been removed; verify via reflection that no such API remains.
        var members = typeof(IdGenerator).GetMembers(BindingFlags.Public | BindingFlags.Static);
        Assert.DoesNotContain(members, m => m.Name is "ResetCollisionTracking" or "TrackedCount");
    }
}