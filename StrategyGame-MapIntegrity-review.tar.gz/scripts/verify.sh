#!/usr/bin/env bash
# =============================================================================
# verify.sh — Complete project verification (Linux/macOS)
#
# Runs all required checks in order. Fails fast on any error.
# Exit code 0 = all checks passed; non-zero = one or more checks failed.
#
# Environment variables:
#   GODOT_BIN  — Full path to Godot 4.7.2 mono executable (optional)
#                Falls back to PATH lookup, then known user-local paths.
#
# NOTE: no set -e — each command is checked explicitly with if/then/else.
# =============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
# Only ensure ~/.local/dotnet is on PATH if not already present; preserve any pre-existing entries (e.g. test fakes).
if [[ ":$PATH:" != *":$HOME/.local/dotnet:"* ]]; then
    export PATH="$HOME/.local/dotnet:$PATH"
fi
export DOTNET_ROOT="${DOTNET_ROOT:-$HOME/.local/dotnet}"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[0;33m'; NC='\033[0m'
PASS()  { echo -e "${GREEN}[PASS]${NC} $*"; }
FAIL()  { echo -e "${RED}[FAIL]${NC} $*"; exit 1; }
INFO()  { echo -e "${YELLOW}[INFO]${NC} $*"; }

INFO "StrategyGame verification starting"
INFO "Project root: $PROJECT_ROOT"

# ===================================================================
# Step 1: .NET SDK
# ===================================================================
if ! command -v dotnet &>/dev/null; then
    FAIL ".NET SDK not found. Install .NET SDK 8.0+ and ensure ~/.local/dotnet is on PATH."
fi

DOTNET_VERSION=""
if DOTNET_VERSION=$(dotnet --version); then
    PASS ".NET SDK: $DOTNET_VERSION"
else
    FAIL "dotnet --version failed with exit code $?."
fi

# ===================================================================
# Step 2: Build Core
# ===================================================================
INFO "Building StrategyGame.Core..."
if dotnet build "$PROJECT_ROOT/src/StrategyGame.Core/StrategyGame.Core.csproj" -c Release --nologo -v quiet; then
    PASS "StrategyGame.Core built successfully."
else
    FAIL "Core build failed (exit $?)."
fi

# ===================================================================
# Step 3: Build App
# ===================================================================
INFO "Building StrategyGame.App..."
if dotnet build "$PROJECT_ROOT/src/StrategyGame.App/StrategyGame.App.csproj" -c Release --nologo -v quiet; then
    PASS "StrategyGame.App built successfully."
else
    FAIL "App build failed (exit $?)."
fi

# ===================================================================
# Step 4: Unit tests
# ===================================================================
INFO "Running Core unit tests..."
if dotnet test "$PROJECT_ROOT/tests/StrategyGame.Core.Tests/StrategyGame.Core.Tests.csproj" -c Release --nologo -v minimal; then
    PASS "StrategyGame.Core.Tests passed."
else
    FAIL "Core unit tests failed (exit $?)."
fi

# ===================================================================
# Step 5: Integration tests
# ===================================================================
INFO "Running integration tests..."
if dotnet test "$PROJECT_ROOT/tests/Integration.Tests/Integration.Tests.csproj" -c Release --nologo -v minimal; then
    PASS "Integration tests passed."
else
    FAIL "Integration tests failed (exit $?)."
fi

# ===================================================================
# Step 6: Godot project import validation
# ===================================================================
GODOT_BIN="${GODOT_BIN:-$(command -v godot 2>/dev/null || echo '')}"

# Fallback to known user-local installations
if [[ -z "$GODOT_BIN" ]]; then
    for candidate in \
        "$HOME/.local/godot/4.7.2/Godot_v4.7.2-stable_mono_linux.x86_64" \
        "$HOME/.local/godot/4.7.2/Godot_v4.7.2-stable_mono_linux_arm64" \
        "$HOME/.local/godot/4.7.2/Godot_v4.7.2-stable_mono_linux_x86_64"; do
        if [[ -x "$candidate" ]]; then
            GODOT_BIN="$candidate"
            break
        fi
    done
fi

if [[ -z "$GODOT_BIN" ]] || [[ ! -x "$GODOT_BIN" ]]; then
    FAIL "Godot 4.7.2 mono executable not found."
    FAIL "Set GODOT_BIN=<path> or place the Godot 4.7.2 mono binary on PATH."
fi

# Validate exact Godot version: must match 4.7.2 prefix followed by non-digit suffix or end
GODOT_VERSION=""
if GODOT_VERSION=$("$GODOT_BIN" --version 2>&1); then
    :
else
    FAIL "Godot --version failed with exit code $?."
fi
if [[ ! "$GODOT_VERSION" =~ ^4\.7\.2(\.[a-zA-Z]|$) ]]; then
    FAIL "Expected Godot 4.7.2 but got: $GODOT_VERSION. Must match semantic version prefix 4.7.2 followed by non-numeric suffix (e.g. 4.7.2.stable). Rejected: 4.7.20, 4.7.1, 4.8.0, 4.7.2.1."
fi
INFO "Godot executable: $GODOT_BIN"
INFO "Godot version: $GODOT_VERSION"

INFO "Running Godot project import validation..."
if timeout 60 "$GODOT_BIN" --headless --path "$PROJECT_ROOT/src/StrategyGame.App" --import; then
    PASS "Godot project import validation passed."
else
    IMPORT_EXIT=$?
    if [[ $IMPORT_EXIT -eq 124 ]]; then
        FAIL "Godot project import timed out after 60 seconds."
    fi
    FAIL "Godot project import failed with exit code $IMPORT_EXIT."
fi

# ===================================================================
# Step 7: Godot application startup
# ===================================================================
INFO "Running Godot headless application startup..."
if timeout 30 "$GODOT_BIN" --headless --path "$PROJECT_ROOT/src/StrategyGame.App" --quit; then
    PASS "Godot application startup passed."
else
    STARTUP_EXIT=$?
    if [[ $STARTUP_EXIT -eq 124 ]]; then
        FAIL "Godot application startup timed out after 30 seconds."
    fi
    FAIL "Godot application startup failed with exit code $STARTUP_EXIT."
fi

# ===================================================================
# Summary
# ===================================================================
echo ""
PASS "All verifications passed."
INFO "Git status:"
git -C "$PROJECT_ROOT" status --short || true
exit 0
