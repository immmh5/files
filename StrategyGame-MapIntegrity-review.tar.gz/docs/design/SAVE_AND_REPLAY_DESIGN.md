# SAVE_AND_REPLAY_DESIGN.md

**Status:** PROPOSED DESIGN

---

## 1. Save Format

Event-sourced saves. A save contains:

```
SaveFile
  ├─ schemaVersion (int)
  ├─ mapId (string)
  ├─ mapHash (string) — for integrity
  ├─ initialState (GameState snapshot)
  ├─ commandLog (ordered list of player commands)
  ├─ metadata (timestamp, player names, duration)
  └─ checksum (integrity)
```

## 2. Game Versioning

- Schema version in every save
- Forward migration via command-log transforms
- Old saves replayed into new version

## 3. Save Compatibility

- Version check on load
- Migration if needed
- Fallback: load as-is if no migration available

## 4. Recovery

- Autosave after each turn
- Manual save at any time
- Crash recovery: last autosave

## 5. Match History

- Ordered list of rounds
- Each round: orders submitted, resolution outcome, events fired
- Stored in command log

## 6. Game Events Log

- All game events recorded in order
- Timestamped
- Replayable

## 7. Replay Architecture

Replay = re-execution of command log against initial state.

```
replay(initialState, commandLog) → finalState
```

Deterministic engine ensures replay matches original.

## 8. Migration Between Game Versions

- Command-log transforms
- Schema version tracking
- Migration scripts per version