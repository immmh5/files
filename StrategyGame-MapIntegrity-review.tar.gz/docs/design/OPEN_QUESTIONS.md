# OPEN_QUESTIONS.md

**Status:** UNRESOLVED — recorded for user decision

---

## Q-1. Game Name

**Question:** What should the game be called?

**Alternatives:**
- (a) Iron Dominion (current working title)
- (b) Other name TBD
- (c) User provides name

**Tradeoffs:** Affects branding, marketing, and all UI text.

**Recommendation:** (a) Iron Dominion for now; user can rename.

**Status:** OPEN — awaiting user decision.

---

## Q-2. First Map Layout

**Question:** What should the first map look like?

**Alternatives:**
- (a) Generic fantasy continent (safe, flexible)
- (b) Specific named world (more identity, more design work)
- (c) Procedural generation (less design work, less control)

**Tradeoffs:** (a) is safe but generic; (b) is more work but more identity; (c) is less work but less control.

**Recommendation:** (a) Generic fantasy continent for first playable version.

**Status:** OPEN — awaiting user decision.

---

## Q-3. Victory Conditions Beyond Elimination/Domination

**Question:** Should there be additional victory conditions?

**Alternatives:**
- (a) Elimination + Domination only (simplest)
- (b) Add score-based/timed victory
- (c) Add scenario-specific victory conditions

**Tradeoffs:** (a) is simplest; (b) prevents endless games but adds complexity; (c) is most flexible but most work.

**Recommendation:** (a) for first playable version; (b) and (c) deferred to Category 2.

**Status:** OPEN — awaiting user decision.

---

## Q-4. Faction Bonuses

**Question:** Should faction bonuses be more complex than a single passive modifier?

**Alternatives:**
- (a) One mild passive bonus per faction (current design)
- (b) Multiple bonuses per faction
- (c) Active abilities with cooldowns

**Tradeoffs:** (a) is simplest and easiest to balance; (b) adds complexity; (c) adds active decision-making but more balance work.

**Recommendation:** (a) for first playable version; (b) and (c) deferred to Category 2/3.

**Status:** OPEN — awaiting user decision.

---

## Q-5. Turn Timers

**Question:** Should turn timers be on by default?

**Alternatives:**
- (a) Off by default; user enables in settings
- (b) On by default (60s/phase)
- (c) Configurable per game type

**Tradeoffs:** (a) is most relaxed; (b) prevents AFK games; (c) is most flexible.

**Recommendation:** (c) Configurable per game type; default off for single-player, 60s/phase for multiplayer.

**Status:** OPEN — awaiting user decision.

---

## Q-6. Map Editor

**Question:** Should the map editor be included in the first playable version?

**Alternatives:**
- (a) No — maps are JSON files, edited externally
- (b) Basic in-game editor
- (c) Full-featured editor

**Tradeoffs:** (a) is simplest; (b) adds UI complexity; (c) is most work.

**Recommendation:** (a) for first playable version; (b) and (c) deferred to Category 2.

**Status:** OPEN — awaiting user decision.

---

## Q-R4-1 … Q-R4-7 — Event Architecture Timing & Format Questions (R4.2.1 refinements, NOW USER-APPROVED)

Recorded during R4.0/R4.2 design; full decision analysis with recommendations in
**`docs/design/EVENT_SYSTEM_DECISIONS.md`** (all seven decisions now **USER-APPROVED**).

| ID | Question | Approved Decision | Status |
|---|---|---|---|
| **Q-R4-1** | Authoritative clock: `TurnSequence` + `RoundIndex` + `PresentationTime` | Dual clocks: monotonic `TurnSequence` + explicit `RoundIndex` (NOT derived) + local `PresentationTime`; round advances when last active player completes turn | **USER-APPROVED** |
| **Q-R4-2** | Effect cadence | Global effects use `RoundIndex`; personal cooldowns use per-player `PlayerTurnCounter`; two distinct classes | **USER-APPROVED** |
| **Q-R4-3** | Scheduled events during Stage B | No — phase-boundary execution only (A/C/D); commands still resolve immediately | **USER-APPROVED** |
| **Q-R4-4** | Disconnect/pause | Host crash ⇒ recover from last persisted checkpoint (no new autosave possible); graceful shutdown ⇒ checkpoint+pause; non-current client ⇒ continue idle; current player ⇒ grace then auto-EndTurn; no implicit global pauses | **USER-APPROVED** |
| **Q-R4-5** | Victory evaluation timing | Stage D checkpoint; timing approval decoupled from still-unapproved victory rules | **USER-APPROVED** |
| **Q-R4-6** | Unknown scheduled event at load | Migrate known-old; reject unknown-authoritative; drop unknown-presentation | **USER-APPROVED** |
| **Q-R4-7** | Event payload serialization format | Typed DTOs + versioned JSON (System.Text.Json); binary deferred until measured | **USER-APPROVED** |

**Dependencies:** Q-R4-1 → Q-R4-2/Q-R4-3/Q-R4-5; Q-R4-2 → Q-R4-4; Q-R4-6/Q-R4-7 independent.

**Status:** **USER-APPROVED** — all seven decisions approved by project owner 2026-11-04. Implementation (R4.3) may proceed per future authorization.
