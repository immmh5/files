namespace StrategyGame.Core.Actions;

using StrategyGame.Core.Domain;
using StrategyGame.Core.GameState;
using StrategyGame.Core.Simulation;

/// <summary>
/// M1.3 — Result of an action validation or execution.
/// </summary>
public sealed record ActionResult(
    bool Success,
    string? ErrorMessage = null,
    object? Payload = null);

/// <summary>
/// M1.3 — Action validation and execution logic.
/// Invalid actions leave GameState unchanged.
/// </summary>
public static class ActionExecutor
{
    /// <summary>
    /// Validates and executes a player action against the current game state.
    /// Returns an ActionResult indicating success/failure and any payload.
    /// </summary>
    public static ActionResult Execute(GameState state, IGameAction action)
    {
        // 1. Confirm game is active (check both legacy and internal phase)
        var currentPhase = string.IsNullOrEmpty(state.CurrentPhaseInternal) ? state.CurrentPhase : state.CurrentPhaseInternal;
        if (currentPhase == TurnManager.PhaseGameOver)
            return new ActionResult(false, "Game has ended; no further actions allowed.");

        // 2. Confirm actor is the active player
        var activePlayer = state.CurrentTurnPlayerIdInternal;
        if (!string.Equals(action.PlayerId, activePlayer, StringComparison.Ordinal))
            return new ActionResult(false, $"Action player '{action.PlayerId}' is not the active player '{activePlayer}'.");

        // 3. Confirm current stage accepts player actions
        if (currentPhase != TurnManager.PhaseAttack && currentPhase != TurnManager.PhaseReinforce && currentPhase != TurnManager.PhaseFortify)
            return new ActionResult(false, $"Current phase '{currentPhase}' does not accept player actions.");

        return action.Type switch
        {
            ActionType.Reinforce => ExecuteReinforce(state, (ReinforceAction)action),
            ActionType.Attack => ExecuteAttack(state, (AttackAction)action),
            ActionType.Fortify => ExecuteFortify(state, (FortifyAction)action),
            _ => new ActionResult(false, $"Unknown action type: {action.Type}"),
        };
    }

    private static ActionResult ExecuteReinforce(GameState state, ReinforceAction action)
    {
        var player = state.GetPlayer(action.PlayerId);
        var territory = state.GetTerritory(action.TerritoryId);

        // Validate territory is owned by player
        if (!string.Equals(territory.OwnerPlayerId, action.PlayerId, StringComparison.Ordinal))
            return new ActionResult(false, $"Territory '{action.TerritoryId}' is not owned by player '{action.PlayerId}'.");

        // Validate positive amount
        if (action.Armies <= 0)
            return new ActionResult(false, "Reinforcement amount must be positive.");

        // Validate within available balance
        if (action.Armies > player.ArmiesToPlace)
            return new ActionResult(false, $"Insufficient reinforcement balance: {player.ArmiesToPlace} available, {action.Armies} requested.");

        // Execute atomically
        territory.AddArmies(action.Armies);
        player.PlaceArmies(action.Armies);

        return new ActionResult(true, null,
            new { TerritoryId = action.TerritoryId, ArmiesPlaced = action.Armies, RemainingBalance = player.ArmiesToPlace });
    }

    private static ActionResult ExecuteAttack(GameState state, AttackAction action)
    {
        var attackerTerritory = state.GetTerritory(action.FromTerritoryId);
        var defenderTerritory = state.GetTerritory(action.ToTerritoryId);

        // Validate source ownership
        if (!string.Equals(attackerTerritory.OwnerPlayerId, action.PlayerId, StringComparison.Ordinal))
            return new ActionResult(false, $"Attacker territory '{action.FromTerritoryId}' is not owned by player '{action.PlayerId}'.");

        // Validate target is adjacent
        if (!attackerTerritory.IsAdjacentTo(action.ToTerritoryId))
            return new ActionResult(false, $"Territories '{action.FromTerritoryId}' and '{action.ToTerritoryId}' are not adjacent.");

        // Validate attacker has ≥ 2 armies
        if (attackerTerritory.Armies < 2)
            return new ActionResult(false, $"Attacker territory '{action.FromTerritoryId}' has fewer than 2 armies.");

        // Resolve combat
        var combatResult = CombatSystem.ResolveAttack(state, action.FromTerritoryId, action.ToTerritoryId);

        // Apply combat result
        if (combatResult.AttackerWon)
        {
            // Attacker captures territory
            attackerTerritory.RemoveArmies(attackerTerritory.Armies - combatResult.AttackerRemaining);
            defenderTerritory.SetOwner(action.PlayerId, combatResult.AttackerRemaining);
        }
        else
        {
            // Defender holds
            defenderTerritory.RemoveArmies(defenderTerritory.Armies - combatResult.DefenderRemaining);
            // Attacker loses the committed armies (all but 1) - handled by combat system logic
            // In our combat system, attackerRemaining = attackerArmies when defender wins (no losses)
            // But per rules, committed armies are at risk. Let's use the combat result.
            attackerTerritory.RemoveArmies(attackerTerritory.Armies - combatResult.AttackerRemaining);
        }

        return new ActionResult(true, null,
            new
            {
                AttackerWon = combatResult.AttackerWon,
                FromTerritoryId = action.FromTerritoryId,
                ToTerritoryId = action.ToTerritoryId,
                AttackerRemaining = combatResult.AttackerRemaining,
                DefenderRemaining = combatResult.DefenderRemaining,
                Captured = combatResult.CapturedTerritoryId != null
            });
    }

    private static ActionResult ExecuteFortify(GameState state, FortifyAction action)
    {
        var fromTerritory = state.GetTerritory(action.FromTerritoryId);
        var toTerritory = state.GetTerritory(action.ToTerritoryId);

        // Validate ownership of both
        if (!string.Equals(fromTerritory.OwnerPlayerId, action.PlayerId, StringComparison.Ordinal))
            return new ActionResult(false, $"Source territory '{action.FromTerritoryId}' is not owned by player '{action.PlayerId}'.");
        if (!string.Equals(toTerritory.OwnerPlayerId, action.PlayerId, StringComparison.Ordinal))
            return new ActionResult(false, $"Destination territory '{action.ToTerritoryId}' is not owned by player '{action.PlayerId}'.");

        // Validate adjacency
        if (!fromTerritory.IsAdjacentTo(action.ToTerritoryId))
            return new ActionResult(false, $"Territories '{action.FromTerritoryId}' and '{action.ToTerritoryId}' are not adjacent.");

        // Validate source has ≥ 2 armies (minimum 1 stays)
        if (fromTerritory.Armies < 2)
            return new ActionResult(false, $"Source territory '{action.FromTerritoryId}' has fewer than 2 armies.");

        // Validate amount positive and within available (minus minimum garrison)
        if (action.Armies <= 0)
            return new ActionResult(false, "Fortification amount must be positive.");
        if (action.Armies > fromTerritory.Armies - 1)
            return new ActionResult(false, $"Cannot move {action.Armies} armies; source would fall below minimum garrison of 1.");

        // Execute atomically
        fromTerritory.RemoveArmies(action.Armies);
        toTerritory.AddArmies(action.Armies);

        return new ActionResult(true, null,
            new { FromTerritoryId = action.FromTerritoryId, ToTerritoryId = action.ToTerritoryId, ArmiesMoved = action.Armies });
    }
}