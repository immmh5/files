namespace StrategyGame.Core.Events;

using System.Text.Json.Serialization;
using StrategyGame.Core.Domain;

/// <summary>
/// Base record for all domain events (Category B: facts).
/// Domain events are immutable statements that something HAS happened as a result of authoritative execution.
/// They are emitted by simulation only and never by UI/AI controllers.
/// R4.7: DomainEvent now implements <see cref="GameEvent"/>, making domain events publishable
/// through the existing <see cref="IEventBus"/> without a new bus interface.
/// </summary>
[JsonPolymorphic(TypeDiscriminatorPropertyName = "$type")]
[JsonDerivedType(typeof(TurnStartedEvent), "turnStarted")]
[JsonDerivedType(typeof(OrderSubmittedEvent), "orderSubmitted")]
[JsonDerivedType(typeof(TerritoryCapturedEvent), "territoryCaptured")]
[JsonDerivedType(typeof(BattleResolvedEvent), "battleResolved")]
[JsonDerivedType(typeof(GameOverEvent), "gameOver")]
[JsonDerivedType(typeof(SupplyAttritionEvent), "supplyAttrition")]
[JsonDerivedType(typeof(EffectAppliedEvent), "effectApplied")]
[JsonDerivedType(typeof(EffectExpiredEvent), "effectExpired")]
[JsonDerivedType(typeof(EffectFailedEvent), "effectFailed")]
public abstract record DomainEvent(
    long EventId,
    DateTime Timestamp,
    int SchemaVersion = 1) : GameEvent;

/// <summary>
/// Published at the start of each player's turn.
/// </summary>
public sealed record TurnStartedEvent(
    long EventId,
    DateTime Timestamp,
    string PlayerId,
    int TurnNumber,
    string Phase,
    int ReinforcementsAvailable,
    int SchemaVersion = 1) : DomainEvent(EventId, Timestamp, SchemaVersion);

/// <summary>
/// Published when a player submits an order during their turn.
/// </summary>
public sealed record OrderSubmittedEvent(
    long EventId,
    DateTime Timestamp,
    string PlayerId,
    string OrderId,
    OrderType Type,
    string? FromTerritoryId = null,
    string? ToTerritoryId = null,
    int Armies = 0,
    int SchemaVersion = 1) : DomainEvent(EventId, Timestamp, SchemaVersion);

/// <summary>
/// Published when a territory changes ownership.
/// </summary>
public sealed record TerritoryCapturedEvent(
    long EventId,
    DateTime Timestamp,
    string TerritoryId,
    string NewOwnerPlayerId,
    int ArmiesOnCapture,
    int SchemaVersion = 1) : DomainEvent(EventId, Timestamp, SchemaVersion);

/// <summary>
/// Published when a battle is resolved.
/// </summary>
public sealed record BattleResolvedEvent(
    long EventId,
    DateTime Timestamp,
    string AttackerPlayerId,
    string DefenderPlayerId,
    string FromTerritoryId,
    string ToTerritoryId,
    int AttackerArmiesCommitted,
    int DefenderArmies,
    int AttackerLosses,
    int DefenderLosses,
    bool AttackerWon,
    string? CapturedTerritoryId = null,
    int SchemaVersion = 1) : DomainEvent(EventId, Timestamp, SchemaVersion);

/// <summary>
/// Published when a victory condition is met and the game ends.
/// </summary>
public sealed record GameOverEvent(
    long EventId,
    DateTime Timestamp,
    string WinningPlayerId,
    string Reason,
    string ReasonText,
    int SchemaVersion = 1) : DomainEvent(EventId, Timestamp, SchemaVersion);

/// <summary>
/// Published when supply attrition is applied to unsupplied groups.
/// </summary>
public sealed record SupplyAttritionEvent(
    long EventId,
    DateTime Timestamp,
    string TerritoryId,
    int ArmiesLost,
    int SchemaVersion = 1) : DomainEvent(EventId, Timestamp, SchemaVersion);

/// <summary>
/// Published when a scheduled effect is applied (R4.7: published by EventScheduler on successful execution).
/// </summary>
public sealed record EffectAppliedEvent(
    long EventId,
    DateTime Timestamp,
    string EffectEventId,
    string EffectTypeKey,
    string? TargetEntityId,
    int SchemaVersion = 1) : DomainEvent(EventId, Timestamp, SchemaVersion);

/// <summary>
/// Published when a scheduled effect expires.
/// Reserved for future duration-based expiration. NOT used for handler failures.
/// </summary>
public sealed record EffectExpiredEvent(
    long EventId,
    DateTime Timestamp,
    string EffectEventId,
    string EffectTypeKey,
    int SchemaVersion = 1) : DomainEvent(EventId, Timestamp, SchemaVersion);

/// <summary>
/// Stable failure classification for scheduled event handler failures (R4.7).
/// </summary>
public enum EffectFailureReason
{
    /// <summary>The registered handler returned false (unimplemented or rejected).</summary>
    HandlerReturnedFalse = 0,

    /// <summary>The registered handler threw an exception during execution.</summary>
    HandlerException = 1,
}

/// <summary>
/// Published when a scheduled effect fails to execute (R4.7).
/// Carries enough information to identify the failed scheduled event and the failure cause.
/// Does NOT carry unstable stack traces or raw exception messages in identity fields.
/// </summary>
public sealed record EffectFailedEvent(
    long EventId,
    DateTime Timestamp,
    string EffectEventId,
    string EffectTypeKey,
    EffectFailureReason FailureReason,
    int SchemaVersion = 1) : DomainEvent(EventId, Timestamp, SchemaVersion);
