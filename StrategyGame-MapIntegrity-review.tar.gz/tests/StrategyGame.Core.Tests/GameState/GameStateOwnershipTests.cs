namespace StrategyGame.Core.Tests.GameState;

using System.Collections.Generic;
using StrategyGame.Core.Domain;
using StrategyGame.Core.GameState;
using Xunit;

/// <summary>
/// Phase 0 (R-GameState) — Regression tests for GameState ownership:
/// the input player list is copied, Players is a read-only view of the internal
/// collection, and Players / GetPlayer() / Snapshot() always agree.
/// </summary>
public class GameStateOwnershipTests
{
    private static MapDefinition CreateTwoTerritoryMap() => new("map-own", "Ownership Map", new[]
    {
        new Territory("A", "Alpha", ["B"]),
        new Territory("B", "Bravo", ["A"]),
    });

    private static List<Player> CreateTwoPlayers() =>
    [
        new Player("p1", "Alice", new Faction("f1", "Red", "#FF0000"), true),
        new Player("p2", "Bob", new Faction("f2", "Blue", "#0000FF"), false),
    ];

    [Fact]
    public void Players_PropertysConsistentWithGetPlayer_SameInstancesEveryPlayer()
    {
        var state = new GameState("g1", CreateTwoTerritoryMap(), CreateTwoPlayers(), "p1", 1, "Reinforce");

        Assert.Equal(2, state.Players.Count);
        foreach (var p in state.Players)
        {
            Assert.Same(p, state.GetPlayer(p.Id));
        }
    }

    [Fact]
    public void Constructor_InputListMutatedAfterwards_GameStateUnaffected()
    {
        var callerPlayers = CreateTwoPlayers();
        var expectedCount = callerPlayers.Count;

        var state = new GameState("g1", CreateTwoTerritoryMap(), callerPlayers, "p1", 1, "Reinforce");

        var nameBefore = state.GetPlayer("p1").Name;
        var armiesBefore = state.GetPlayer("p1").ArmiesToPlace;

        // Caller mutates both the list structure and a Player object afterwards.
        callerPlayers.Add(new Player("p3", "Mallory", new Faction("f3", "Green", "#00FF00"), true));
        callerPlayers[0].AddArmies(50);

        Assert.Equal(expectedCount, state.Players.Count);
        Assert.Throws<KeyNotFoundException>(() => state.GetPlayer("p3"));
        Assert.Equal(nameBefore, state.GetPlayer("p1").Name);
        Assert.Equal(armiesBefore, state.GetPlayer("p1").ArmiesToPlace);
    }

    [Fact]
    public void Constructor_CallerPlayerObjectMutatedAfterwards_GameStateUnaffected()
    {
        var callerPlayers = CreateTwoPlayers();

        var state = new GameState("g1", CreateTwoTerritoryMap(), callerPlayers, "p1", 1, "Reinforce");
        var statePlayerArmies = state.GetPlayer("p2").ArmiesToPlace;

        callerPlayers[1].AddArmies(7);

        Assert.Equal(statePlayerArmies, state.GetPlayer("p2").ArmiesToPlace);
        Assert.Equal(statePlayerArmies, state.Players.First(p => p.Id == "p2").ArmiesToPlace);
    }

    [Fact]
    public void Players_IsReadOnlyView_MutationBlocked()
    {
        var state = new GameState("g1", CreateTwoTerritoryMap(), CreateTwoPlayers(), "p1", 1, "Reinforce");

        // Not castable to a mutable List<T>.
        Assert.IsNotAssignableFrom<List<Player>>(state.Players);

        // ICollection<Player> (implemented by the read-only view) rejects mutation.
        if (state.Players is ICollection<Player> collection)
        {
            Assert.Throws<NotSupportedException>(() => collection.Add(
                new Player("px", "Intruder", new Faction("fx", "X", "#123456"), true)));
            Assert.Throws<NotSupportedException>(() => collection.Clear());
        }
        else
        {
            Assert.Fail("Players must expose a read-only collection view.");
        }
    }

    [Fact]
    public void Snapshot_ConsistentWithPlayersAndGetPlayer()
    {
        var state = new GameState("g1", CreateTwoTerritoryMap(), CreateTwoPlayers(), "p1", 1, "Reinforce");
        var snapshot = state.Snapshot();

        Assert.Equal(state.Players.Count, snapshot.Players.Count);
        foreach (var p in state.Players)
        {
            var snapP = snapshot.GetPlayer(p.Id);
            Assert.Equal(p.Id, snapP.Id);
            Assert.Equal(p.ArmiesToPlace, snapP.ArmiesToPlace);
            Assert.NotSame(p, snapP); // deep copy
        }
    }

    [Fact]
    public void Constructor_NullPlayerEntry_ThrowsArgumentNullException()
    {
        var players = new List<Player?> { CreateTwoPlayers()[0], null };
        Assert.Throws<ArgumentNullException>(() =>
            new GameState("g1", CreateTwoTerritoryMap(), players!, "p1", 1, "Reinforce"));
    }

    [Fact]
    public void Constructor_PlayerDataIsCopied_OriginalInstancesNotReferenced()
    {
        var callerPlayers = CreateTwoPlayers();
        var state = new GameState("g1", CreateTwoTerritoryMap(), callerPlayers, "p1", 1, "Reinforce");

        foreach (var p in state.Players)
        {
            Assert.DoesNotContain(p, callerPlayers);
        }
    }
}
