using StrategyGame.Core.Common;

namespace StrategyGame.Core.Simulation;

using System.Text.Json.Serialization;

/// <summary>
/// Cancellation status of a scheduled event.
/// </summary>
[JsonConverter(typeof(JsonStringEnumConverter))]
public enum EventCancellation
{
    /// <summary>Event is active and pending execution.</summary>
    Active = 0,

    /// <summary>Event was explicitly cancelled before firing.</summary>
    Cancelled = 1,

    /// <summary>Event has fired and completed successfully.</summary>
    Fired = 2,

    /// <summary>Event handler threw an exception during execution.</summary>
    Failed = 3,

    /// <summary>Event expired (duration elapsed) without firing.</summary>
    Expired = 4,
}

/// <summary>
/// Phase within the hybrid turn structure when a scheduled event is eligible to fire.
/// </summary>
[JsonConverter(typeof(JsonStringEnumConverter))]
public enum EffectPhase
{
    /// <summary>Fires during Turn Start (Stage A).</summary>
    TurnStart = 0,

    /// <summary>Fires during Persistent Event Processing (Stage C).</summary>
    EventProcessing = 1,

    /// <summary>Fires during Turn End (Stage D).</summary>
    TurnEnd = 2,
}

/// <summary>
/// Canonical serializable record for a scheduled gameplay event.
/// Pure data — no delegates, no behavior, fully deterministic and versioned.
/// </summary>
/// <param name="EventId">Deterministic, namespace-isolated unique identifier.</param>
/// <param name="SchemaVersion">Payload schema version for migration.</param>
/// <param name="EventTypeKey">Registry key for handler lookup (not a CLR type name).</param>
/// <param name="DueTurnSequence">TurnSequence value when the event becomes due.</param>
/// <param name="DueRoundIndex">RoundIndex value when the event becomes due (for global effects).</param>
/// <param name="DuePlayerTurnCounts">Per-player turn counters when the event becomes due (for personal effects).</param>
/// <param name="Phase">Phase within A–D when the event is eligible to fire.</param>
/// <param name="Priority">Tie-break level (lower runs first).</param>
/// <param name="SequenceNumber">Monotonic within match; final tie-breaker.</param>
/// <param name="TargetEntityId">Optional target entity (territory/player/event).</param>
/// <param name="IssuerTurnNumber">Provenance turn number for duplicate detection.</param>
/// <param name="PayloadJson">Serialized parameters (versioned JSON via System.Text.Json).</param>
/// <param name="Status">Cancellation/execution status.</param>
/// <param name="CreatedAtTurnSequence">TurnSequence when this record was created.</param>
/// <param name="LineageEventId">Optional original EventId if this is a rescheduled instance.</param>
public sealed record ScheduledEventRecord(
    string EventId,
    int SchemaVersion,
    string EventTypeKey,
    int DueTurnSequence,
    int DueRoundIndex,
    System.Collections.Generic.Dictionary<string, int> DuePlayerTurnCounts,
    EffectPhase Phase,
    int Priority,
    long SequenceNumber,
    string? TargetEntityId,
    int IssuerTurnNumber,
    string PayloadJson,
    EventCancellation Status,
    int CreatedAtTurnSequence,
    string? LineageEventId = null)
{
    /// <summary>Creates a new active scheduled event with generated metadata.</summary>
    public static ScheduledEventRecord CreateNew(
        string eventTypeKey,
        int dueTurnSequence,
        int dueRoundIndex,
        System.Collections.Generic.Dictionary<string, int> duePlayerTurnCounts,
        EffectPhase phase,
        int priority,
        long sequenceNumber,
        string? targetEntityId,
        int issuerTurnNumber,
        string payloadJson,
        int currentTurnSequence,
        string eventId)
    {
        return new ScheduledEventRecord(
            EventId: eventId,
            SchemaVersion: 1,
            EventTypeKey: eventTypeKey,
            DueTurnSequence: dueTurnSequence,
            DueRoundIndex: dueRoundIndex,
            DuePlayerTurnCounts: duePlayerTurnCounts ?? new(),
            Phase: phase,
            Priority: priority,
            SequenceNumber: sequenceNumber,
            TargetEntityId: targetEntityId,
            IssuerTurnNumber: issuerTurnNumber,
            PayloadJson: payloadJson,
            Status: EventCancellation.Active,
            CreatedAtTurnSequence: currentTurnSequence,
            LineageEventId: null);
    }

    /// <summary>Creates a rescheduled copy preserving lineage.</summary>
    public ScheduledEventRecord Reschedule(
        int newDueTurnSequence,
        int newDueRoundIndex,
        System.Collections.Generic.Dictionary<string, int> newDuePlayerTurnCounts,
        int newPriority,
        long newSequenceNumber,
        int currentTurnSequence)
    {
        var newEventId = IdGenerator.NewDeterministicId("sched", BitConverter.ToInt32(StableHash.GetStableHashCode(this.EventId + "_reschedule"), 0), 0);
        return new ScheduledEventRecord(
            EventId: newEventId,
            SchemaVersion: this.SchemaVersion,
            EventTypeKey: this.EventTypeKey,
            DueTurnSequence: newDueTurnSequence,
            DueRoundIndex: newDueRoundIndex,
            DuePlayerTurnCounts: newDuePlayerTurnCounts ?? new(),
            Phase: this.Phase,
            Priority: newPriority,
            SequenceNumber: newSequenceNumber,
            TargetEntityId: this.TargetEntityId,
            IssuerTurnNumber: this.IssuerTurnNumber,
            PayloadJson: this.PayloadJson,
            Status: EventCancellation.Active,
            CreatedAtTurnSequence: currentTurnSequence,
            LineageEventId: this.EventId);
    }

    /// <summary>Returns a cancelled copy of this event.</summary>
    public ScheduledEventRecord Cancelled(int currentTurnSequence)
    {
        return this with
        {
            Status = EventCancellation.Cancelled,
            CreatedAtTurnSequence = currentTurnSequence,
            LineageEventId = this.LineageEventId ?? this.EventId
        };
    }

    /// <summary>Returns a fired copy of this event.</summary>
    public ScheduledEventRecord Fired(int currentTurnSequence)
    {
        return this with
        {
            Status = EventCancellation.Fired,
            CreatedAtTurnSequence = currentTurnSequence
        };
    }

    /// <summary>Returns a failed copy of this event.</summary>
    public ScheduledEventRecord Failed(int currentTurnSequence)
    {
        return this with
        {
            Status = EventCancellation.Failed,
            CreatedAtTurnSequence = currentTurnSequence
        };
    }

    /// <summary>Returns an expired copy of this event.</summary>
    public ScheduledEventRecord Expired(int currentTurnSequence)
    {
        return this with
        {
            Status = EventCancellation.Expired,
            CreatedAtTurnSequence = currentTurnSequence
        };
    }

    /// <summary>Checks if this event is in a terminal state.</summary>
    public bool IsTerminal => Status is EventCancellation.Cancelled or EventCancellation.Fired or EventCancellation.Failed or EventCancellation.Expired;

    /// <summary>Checks if this event is a global (round-based) effect.</summary>
    public bool IsGlobalEffect => DueRoundIndex > 0;

    /// <summary>Checks if this event has any personal (player-turn-based) effects.</summary>
    public bool HasPersonalEffects => DuePlayerTurnCounts.Count > 0;
}