namespace StrategyGame.Core.Simulation;

using StrategyGame.Core.Domain;
using StrategyGame.Core.GameState;

/// <summary>
/// M1.2 — Pure, deterministic reinforcement/income calculation.
///
/// CRITICAL OWNERSHIP RULE (M1.2): region control is computed from the LIVE
/// <see cref="GameState"/> territory copies — never from
/// <see cref="MapDefinition"/> territory objects, which the game state never
/// mutates after construction. Using map ownership would produce stale bonuses
/// the moment any territory is captured or lost during a match. The map's
/// <c>RegionDefinition</c> data supplies only the STATIC facts: region
/// membership (via <see cref="Territory.RegionId"/> read from state copies) and
/// the configurable <see cref="RegionDefinition.ArmyBonus"/>.
///
/// PROVISIONAL FORMULA (D-08 [PROPOSED], not owner-approved):
/// <c>income = floor(ownedTerritories / TerritoriesPerIncomeGroup)</c>
///   <c>            + sum(ArmyBonus of regions fully controlled by the player)</c>
///
/// - A region counts only when the player owns ALL of its member territories.
/// - A region with zero member territories grants nothing.
/// - Multiple fully controlled regions each contribute.
/// - Neutral and enemy territories never count toward the owned-territory count.
/// - No minimum reinforcement is imposed (D-08 documents none; see EconomyConfig).
///
/// PURE CALCULATION: this engine neither adds armies to <c>Player.ArmiesToPlace</c>
/// nor mutates state. Applying the budget at turn start belongs to the later
/// turn/action system (M1.3).
///
/// Overflow: all arithmetic runs in an explicitly <c>checked</c> context and
/// throws <see cref="OverflowException"/> instead of silently wrapping.
/// </summary>
public static class EconomyEngine
{
    /// <summary>One fully controlled region's contribution to income.</summary>
    public readonly record struct RegionBonusContribution(
        string RegionId, string RegionName, int ArmyBonus, int MemberTerritoryCount);

    /// <summary>
    /// Immutable breakdown of a reinforcement calculation for one player.
    /// </summary>
    /// <param name="PlayerId">Player the budget was calculated for.</param>
    /// <param name="OwnedTerritoryCount">Territories owned in the live GameState.</param>
    /// <param name="BaseIncome">floor(owned / TerritoriesPerIncomeGroup).</param>
    /// <param name="ControlledRegionBonuses">Every fully controlled region, ordered by region id.</param>
    /// <param name="RegionBonusTotal">Sum of all region contributions.</param>
    /// <param name="TotalReinforcementBudget">BaseIncome + RegionBonusTotal.</param>
    public sealed record EconomyReport(
        string PlayerId,
        int OwnedTerritoryCount,
        int BaseIncome,
        IReadOnlyList<RegionBonusContribution> ControlledRegionBonuses,
        int RegionBonusTotal,
        int TotalReinforcementBudget);

    /// <summary>
    /// Calculates the reinforcement budget for a player from live game state.
    /// Side-effect free.
    /// </summary>
    /// <exception cref="ArgumentNullException">State or playerId is null.</exception>
    /// <exception cref="ArgumentException">PlayerId is empty/whitespace.</exception>
    /// <exception cref="KeyNotFoundException">No player with that id exists in state.</exception>
    /// <exception cref="OverflowException">Arithmetic exceeds int range (checked).</exception>
    public static EconomyReport CalculateReinforcement(
        GameState state, string playerId, EconomyConfig? config = null)
    {
        ArgumentNullException.ThrowIfNull(state);
        if (playerId is null)
            throw new ArgumentNullException(nameof(playerId));
        if (string.IsNullOrWhiteSpace(playerId))
            throw new ArgumentException("Player id must not be null, empty or whitespace.", nameof(playerId));
        var economyConfig = config ?? EconomyConfig.Default;

        // Validates player existence; also makes the intent explicit.
        _ = state.GetPlayer(playerId);

        // LIVE ownership: iterate the GameState's own territory copies once.
        IReadOnlyList<Territory> stateTerritories = state.GetAllTerritories();

        int ownedCount = 0;
        foreach (var territory in stateTerritories)
        {
            if (string.Equals(territory.OwnerPlayerId, playerId, StringComparison.Ordinal))
                ownedCount++;
        }

        int regionBonusTotal = 0;
        List<RegionBonusContribution> contributions = [];

        // Static region data from the map; live membership from state copies.
        // Region list sorted by id so the breakdown is deterministic regardless
        // of dictionary iteration order.
        foreach (var region in state.Map.Regions.Values.OrderBy(r => r.Id, StringComparer.Ordinal))
        {
            int memberCount = 0;
            bool ownsAll = true;
            foreach (var territory in stateTerritories)
            {
                if (!string.Equals(territory.RegionId, region.Id, StringComparison.Ordinal))
                    continue;
                memberCount++;
                if (!string.Equals(territory.OwnerPlayerId, playerId, StringComparison.Ordinal))
                {
                    ownsAll = false;
                    break;
                }
            }
            if (memberCount == 0 || !ownsAll)
                continue; // partially controlled / empty region grants no bonus (D-08)

            contributions.Add(new RegionBonusContribution(region.Id, region.Name, region.ArmyBonus, memberCount));
        }

        checked
        {
            int baseIncome = ownedCount / economyConfig.TerritoriesPerIncomeGroup;

            foreach (var contribution in contributions)
            {
                regionBonusTotal += contribution.ArmyBonus; // OverflowException propagates
            }

            int total = baseIncome + regionBonusTotal;
            return new EconomyReport(
                playerId,
                ownedCount,
                baseIncome,
                contributions.AsReadOnly(), // defensive: callers cannot mutate engine output
                regionBonusTotal,
                total);
        }
    }
}
