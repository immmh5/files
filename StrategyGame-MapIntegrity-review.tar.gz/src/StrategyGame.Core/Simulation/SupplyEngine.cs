namespace StrategyGame.Core.Simulation;

using StrategyGame.Core.GameState;

/// <summary>
/// M1.2 — Pure, deterministic supply connectivity calculation.
///
/// PROVISIONAL RULE (D-06 [PROPOSED], not owner-approved): supply reaches a
/// player's owned territories through connected OWNED territories originating at
/// owned supply sources ("capitals or ports"). Neutral and enemy territories
/// block propagation. A source territory is supplied if (and only if) the player
/// owns it. No supply capacity, army limits, resource consumption or advanced
/// logistics are modeled in M1.2 (those remain future Category-2 systems).
///
/// ALGORITHM: breadth-first search from every owned supply source through owned
/// territories of the same player, using the validated map adjacency. Traversal
/// order is deterministic (sources sorted ordinally; neighbors in adjacency-list
/// order), and result lists are sorted ordinally so no output depends on
/// dictionary iteration order.
///
/// PURE: <see cref="GameState"/> and <see cref="Domain.MapDefinition"/> are not
/// mutated.
/// </summary>
public static class SupplyEngine
{
    /// <summary>
    /// Immutable supply result for one player.
    /// </summary>
    /// <param name="PlayerId">Player the connectivity was calculated for.</param>
    /// <param name="OwnedTerritoryCount">Total territories owned by the player (supplied + unsupplied).</param>
    /// <param name="SuppliedTerritoryIds">Owned-and-connected territories, sorted ordinally.</param>
    /// <param name="UnsuppliedTerritoryIds">Owned territories not reachable from any owned source, sorted ordinally.</param>
    /// <param name="SourceTerritoryIds">Owned territories flagged as supply sources (even if the list is the entire seed set), sorted ordinally.</param>
    /// <param name="HasOwnedSource">True if the player owns at least one supply source.</param>
    /// <param name="Diagnostics">Deterministic, human-readable notes for testing/debugging.</param>
    public sealed record SupplyResult(
        string PlayerId,
        int OwnedTerritoryCount,
        IReadOnlyList<string> SourceTerritoryIds,
        bool HasOwnedSource,
        IReadOnlyList<string> SuppliedTerritoryIds,
        IReadOnlyList<string> UnsuppliedTerritoryIds,
        IReadOnlyList<string> Diagnostics);

    /// <summary>
    /// Calculates supply connectivity for a player from the live game state.
    /// </summary>
    /// <exception cref="ArgumentNullException">State or playerId is null.</exception>
    /// <exception cref="ArgumentException">PlayerId is empty/whitespace.</exception>
    /// <exception cref="KeyNotFoundException">No player with that id exists in state.</exception>
    public static SupplyResult CalculateSupply(GameState state, string playerId)
    {
        ArgumentNullException.ThrowIfNull(state);
        if (playerId is null)
            throw new ArgumentNullException(nameof(playerId));
        if (string.IsNullOrWhiteSpace(playerId))
            throw new ArgumentException("Player id must not be null, empty or whitespace.", nameof(playerId));

        // Validates player existence.
        _ = state.GetPlayer(playerId);

        List<string> diagnostics = [];

        // All territories owned by the player (from the live state copies).
        List<string> ownedIds = [];
        foreach (var territory in state.GetAllTerritories())
        {
            if (string.Equals(territory.OwnerPlayerId, playerId, StringComparison.Ordinal))
                ownedIds.Add(territory.Id);
        }
        ownedIds.Sort(StringComparer.Ordinal);
        var ownedSet = new HashSet<string>(ownedIds, StringComparer.Ordinal);

        // Seeds: owned supply sources, sorted ordinally for deterministic traversal.
        List<string> sources = [];
        foreach (var id in ownedIds)
        {
            if (state.GetTerritory(id).IsSupplySource)
                sources.Add(id);
        }
        List<string> allSources = new(sources);
        bool hasOwnedSource = sources.Count > 0;

        var supplied = new HashSet<string>(StringComparer.Ordinal);

        if (!hasOwnedSource)
        {
            diagnostics.Add($"Player '{playerId}' owns no supply source; " +
                            "all owned territories are unsupplied (D-06 provisional).");
        }
        else
        {
            var queue = new Queue<string>();
            foreach (var source in sources)
            {
                // An owned source is itself supplied by definition.
                if (supplied.Add(source))
                    queue.Enqueue(source);
            }

            while (queue.Count > 0)
            {
                var current = queue.Dequeue();
                var territory = state.GetTerritory(current);
                foreach (var neighborId in territory.AdjacentTerritoryIds)
                {
                    // Validated maps guarantee references exist; defend anyway and
                    // record a diagnostic rather than throwing on a corrupt setup.
                    var neighbor = state.Map.GetTerritory(neighborId);
                    if (neighbor is null)
                    {
                        diagnostics.Add($"Territory '{current}' references unknown adjacent territory '{neighborId}'.");
                        continue;
                    }

                    // Only owned territories of this player may be traversed.
                    if (!ownedSet.Contains(neighborId))
                        continue; // neutral/enemy blocking; normal game state, not a diagnostic

                    if (supplied.Add(neighborId))
                        queue.Enqueue(neighborId);
                }
            }
        }

        List<string> suppliedIds = [.. supplied];
        suppliedIds.Sort(StringComparer.Ordinal);

        List<string> unsuppliedIds = [];
        foreach (var id in ownedIds)
        {
            if (!supplied.Contains(id))
                unsuppliedIds.Add(id);
        }

        if (unsuppliedIds.Count > 0)
        {
            diagnostics.Add($"Player '{playerId}' has {unsuppliedIds.Count} owned territory(ies) " +
                            "not reachable from any owned supply source.");
        }

        return new SupplyResult(
            playerId,
            ownedIds.Count,
            allSources.AsReadOnly(),        // defensive: callers cannot mutate engine output
            hasOwnedSource,
            suppliedIds.AsReadOnly(),
            unsuppliedIds.AsReadOnly(),
            diagnostics.AsReadOnly());
    }
}
