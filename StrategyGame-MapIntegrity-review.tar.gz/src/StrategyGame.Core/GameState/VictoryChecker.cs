namespace StrategyGame.Core.GameState;

using StrategyGame.Core.Domain;

/// <summary>
/// Evaluates victory conditions.
/// Domination: control ≥60% of all territories (including neutral).
/// Elimination: only one player owns any territories.
/// </summary>
/// <remarks>
/// <para>
/// <b>PROVISIONAL STATUS — NOT OWNER-APPROVED (recorded)</b>. Per
/// <c>docs/design/DESIGN_DECISIONS.md</c> D-07 and D-16-5:
/// </para>
/// <list type="number">
/// <item>The 60% domination threshold (<see cref="DominationThreshold"/>) is
/// <c>[PROPOSED]</c> ("threshold configurable per match"). It is hard-coded here
/// only because per-match rule configuration does not exist yet; it must not be
/// treated as a confirmed balance decision.</item>
/// <item>The domination denominator (all territories including neutral) is
/// <c>[PROPOSED]</c>; alternatives (owned-only, starting totals) are undecided.</item>
/// <item>Checking Domination before Elimination is an implementation choice, not
/// an approved priority rule.</item>
/// <item>D-16-5 (USER-APPROVED) covers evaluation <b>timing</b> only: victory is
/// to be evaluated at Stage D by the TurnEngine (M1.3). This checker itself is
/// currently callable at any time; enforcing Stage-D-only invocation is pending.</item>
/// <item>Point-based victory is <c>[OPEN]</c> (OPEN_QUESTIONS.md Q-3); the
/// <see cref="VictoryCondition.PointBased"/> value is declared but never returned.</item>
/// </list>
/// </remarks>
public static class VictoryChecker
{
    public enum VictoryCondition
    {
        None,
        Domination,
        Elimination,
        PointBased
    }

    public record VictoryInfo(
        bool IsVictorious,
        VictoryCondition Condition,
        string? WinningPlayerId,
        string Reason);

    private const double DominationThreshold = 0.6; // PROVISIONAL — see class-level note above and VictoryCheckerTests.

    public static VictoryInfo CheckVictory(GameState state)
    {
        // Check Domination first (stronger condition)
        var dominationInfo = CheckDominationVictory(state);
        if (dominationInfo.IsVictorious)
            return dominationInfo;

        // Check Elimination
        var eliminationInfo = CheckEliminationVictory(state);
        if (eliminationInfo.IsVictorious)
            return eliminationInfo;

        return new VictoryInfo(false, VictoryCondition.None, null, "No victory condition met.");
    }

    private static VictoryInfo CheckDominationVictory(GameState state)
    {
        var territories = state.GetAllTerritories();
        int totalTerritories = territories.Count;
        if (totalTerritories == 0)
            return new VictoryInfo(false, VictoryCondition.None, null, "No territories exist.");

        var territoryCounts = new Dictionary<string, int>();
        foreach (var t in territories)
        {
            if (t.OwnerPlayerId is not null)
            {
                territoryCounts.TryGetValue(t.OwnerPlayerId, out int count);
                territoryCounts[t.OwnerPlayerId] = count + 1;
            }
        }

        if (territoryCounts.Count == 0)
            return new VictoryInfo(false, VictoryCondition.None, null, "No territories owned by any player.");

        // Find player with most territories
        var maxEntry = territoryCounts.MaxBy(kvp => kvp.Value);
        double percentage = (double)maxEntry.Value / totalTerritories;

        if (percentage >= DominationThreshold)
        {
            return new VictoryInfo(
                true,
                VictoryCondition.Domination,
                maxEntry.Key,
                $"Player {maxEntry.Key} controls {maxEntry.Value} of {totalTerritories} territories ({percentage:P0}).");
        }

        return new VictoryInfo(false, VictoryCondition.None, null, "No player has ≥60% territory control.");
    }

    private static VictoryInfo CheckEliminationVictory(GameState state)
    {
        var territories = state.GetAllTerritories();
        if (territories.Count == 0)
            return new VictoryInfo(false, VictoryCondition.None, null, "No territories exist.");

        var activePlayers = new HashSet<string>();
        foreach (var t in territories)
        {
            if (t.OwnerPlayerId is not null)
                activePlayers.Add(t.OwnerPlayerId);
        }

        if (activePlayers.Count == 1)
        {
            var soleOwner = activePlayers.First();
            return new VictoryInfo(
                true,
                VictoryCondition.Elimination,
                soleOwner,
                $"Only player {soleOwner} remains with territories.");
        }

        return new VictoryInfo(false, VictoryCondition.None, null, "Multiple players still have territories.");
    }
}