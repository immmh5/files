namespace StrategyGame.Core.Commands;

using System.Text.Json.Serialization;
using StrategyGame.Core.Events;

/// <summary>
/// Base record for all player commands (Category A: intent).
/// Commands represent player intentions and require validation + host authorization before execution.
/// </summary>
[JsonPolymorphic(TypeDiscriminatorPropertyName = "$type")]
[JsonDerivedType(typeof(ReinforceCommand), "reinforce")]
[JsonDerivedType(typeof(AttackCommand), "attack")]
[JsonDerivedType(typeof(FortifyCommand), "fortify")]
[JsonDerivedType(typeof(EndTurnCommand), "endTurn")]
public abstract record PlayerCommand(
    string CommandId,
    string PlayerId,
    int IssuedAtTurnSequence,
    int SchemaVersion = 1);

/// <summary>
/// Command to reinforce a territory with armies.
/// </summary>
public sealed record ReinforceCommand(
    string CommandId,
    string PlayerId,
    int IssuedAtTurnSequence,
    string TerritoryId,
    int Armies,
    int SchemaVersion = 1) : PlayerCommand(CommandId, PlayerId, IssuedAtTurnSequence, SchemaVersion);

/// <summary>
/// Command to attack from one territory to another.
/// </summary>
public sealed record AttackCommand(
    string CommandId,
    string PlayerId,
    int IssuedAtTurnSequence,
    string FromTerritoryId,
    string ToTerritoryId,
    int CommitArmies,
    int SchemaVersion = 1) : PlayerCommand(CommandId, PlayerId, IssuedAtTurnSequence, SchemaVersion);

/// <summary>
/// Command to fortify (move armies between owned territories).
/// </summary>
public sealed record FortifyCommand(
    string CommandId,
    string PlayerId,
    int IssuedAtTurnSequence,
    string FromTerritoryId,
    string ToTerritoryId,
    int Armies,
    int SchemaVersion = 1) : PlayerCommand(CommandId, PlayerId, IssuedAtTurnSequence, SchemaVersion);

/// <summary>
/// Command to end the current player's turn.
/// </summary>
public sealed record EndTurnCommand(
    string CommandId,
    string PlayerId,
    int IssuedAtTurnSequence,
    int SchemaVersion = 1) : PlayerCommand(CommandId, PlayerId, IssuedAtTurnSequence, SchemaVersion);

/// <summary>
/// Result of command validation.
/// </summary>
public sealed record CommandValidationResult(
    bool IsValid,
    string? ErrorCode,
    string? ErrorMessage);

/// <summary>
/// Result of command execution.
/// </summary>
public sealed record CommandExecutionResult(
    bool Success,
    string? ErrorCode,
    string? ErrorMessage,
    System.Collections.Generic.IReadOnlyList<DomainEvent> ProducedEvents);