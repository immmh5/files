namespace StrategyGame.Core.Events;

using System.Text.Json;

/// <summary>
/// Strongly typed payload DTOs for registered scheduled event types.
/// These are the authoritative payload shapes (D-16-7).
///
/// DESIGN STATUS: All event types and their gameplay semantics are PROPOSED.
/// Their presence in the registry does NOT constitute USER-APPROVED gameplay rules.
/// See DESIGN_DECISIONS.md for approval status of related mechanics (D-03, D-05, D-06, D-09).
/// </summary>
public static class EventPayloads
{
    // =====================================================================
    // Global (round-based) effects - use RoundTiming
    // =====================================================================

    /// <summary>
    /// Autumn attrition: all unsupplied groups lose armies at round start.
    /// GAMEPLAY MECHANIC: PROPOSED (D-06 Supply &amp; Attrition).
    /// </summary>
    public sealed record AutumnAttritionPayload(
        string[] AffectedRegions,
        int ArmiesLostPerGroup = 1)
    {
        public AutumnAttritionPayload() : this(Array.Empty<string>(), 1) { }
    }

    /// <summary>
    /// Continent bonus: grants reinforcement armies to players controlling a continent.
    /// GAMEPLAY MECHANIC: PROPOSED (D-05 Map &amp; Territory, D-08 Economy).
    /// </summary>
    public sealed record ContinentBonusPayload(
        string ContinentId,
        int BonusArmies,
        string[] ControllingPlayerIds)
    {
        public ContinentBonusPayload() : this("", 0, Array.Empty<string>()) { }
    }

    /// <summary>
    /// Harvest festival: temporary economic boost for all players.
    /// GAMEPLAY MECHANIC: PROPOSED (D-08 Economy, D-09 Factions).
    /// </summary>
    public sealed record HarvestFestivalPayload(
        int BonusIncomePercent,
        int DurationRounds)
    {
        public HarvestFestivalPayload() : this(0, 0) { }
    }

    /// <summary>
    /// Border fortification: defensive bonus on specific territories for one round.
    /// GAMEPLAY MECHANIC: PROPOSED (D-06 Supply &amp; Attrition, D-09 Factions).
    /// </summary>
    public sealed record BorderFortificationPayload(
        string[] TerritoryIds,
        int DefenseBonus)
    {
        public BorderFortificationPayload() : this(Array.Empty<string>(), 0) { }
    }

    // =====================================================================
    // Personal (player-turn-based) effects - use PlayerTurnTiming
    // =====================================================================

    /// <summary>
    /// Berserk rage: player's next attacks gain bonus strength for N turns.
    /// GAMEPLAY MECHANIC: PROPOSED (D-09 Factions).
    /// </summary>
    public sealed record BerserkRagePayload(
        int AttackBonus,
        int DurationPlayerTurns)
    {
        public BerserkRagePayload() : this(0, 0) { }
    }

    /// <summary>
    /// Supply disruption: player's territories suffer attrition for N turns.
    /// GAMEPLAY MECHANIC: PROPOSED (D-06 Supply &amp; Attrition).
    /// </summary>
    public sealed record SupplyDisruptionPayload(
        int ArmiesLostPerTurn,
        int DurationPlayerTurns)
    {
        public SupplyDisruptionPayload() : this(0, 0) { }
    }

    /// <summary>
    /// Fortification boost: player's next fortifications are more effective.
    /// GAMEPLAY MECHANIC: PROPOSED (D-09 Factions).
    /// </summary>
    public sealed record FortificationBoostPayload(
        int BonusArmies,
        int DurationPlayerTurns)
    {
        public FortificationBoostPayload() : this(0, 0) { }
    }

    // =====================================================================
    // Deserialization helpers (strict validation)
    // =====================================================================

    /// <summary>
    /// Tries to get a required string value from the payload dictionary.
    /// </summary>
    public static string GetRequiredString(Dictionary<string, JsonElement> payload, string key)
    {
        if (!payload.TryGetValue(key, out var element) || element.ValueKind == JsonValueKind.Null)
            throw new ScheduledEventValidationException("<unknown>", $"Missing required field: {key}");
        if (element.ValueKind != JsonValueKind.String)
            throw new ScheduledEventValidationException("<unknown>", $"Field '{key}' must be a string (got {element.ValueKind}).");
        return element.GetString()!;
    }

    /// <summary>
    /// Tries to get a required int value from the payload dictionary.
    /// </summary>
    public static int GetRequiredInt(Dictionary<string, JsonElement> payload, string key)
    {
        if (!payload.TryGetValue(key, out var element) || element.ValueKind == JsonValueKind.Null)
            throw new ScheduledEventValidationException("<unknown>", $"Missing required field: {key}");
        if (element.ValueKind != JsonValueKind.Number)
            throw new ScheduledEventValidationException("<unknown>", $"Field '{key}' must be an integer (got {element.ValueKind}).");
        if (!element.TryGetInt32(out var value))
            throw new ScheduledEventValidationException("<unknown>", $"Field '{key}' is not a valid 32-bit integer.");
        return value;
    }

    /// <summary>
    /// Tries to get an optional int value from the payload dictionary (with default).
    /// </summary>
    public static int GetOptionalInt(Dictionary<string, JsonElement> payload, string key, int defaultValue = 0)
    {
        if (!payload.TryGetValue(key, out var element) || element.ValueKind == JsonValueKind.Null)
            return defaultValue;
        if (element.ValueKind != JsonValueKind.Number)
            throw new ScheduledEventValidationException("<unknown>", $"Field '{key}' must be an integer (got {element.ValueKind}).");
        if (!element.TryGetInt32(out var value))
            throw new ScheduledEventValidationException("<unknown>", $"Field '{key}' is not a valid 32-bit integer.");
        return value;
    }

    /// <summary>
    /// Tries to get a required string array from the payload dictionary.
    /// </summary>
    public static string[] GetRequiredStringArray(Dictionary<string, JsonElement> payload, string key)
    {
        if (!payload.TryGetValue(key, out var element) || element.ValueKind == JsonValueKind.Null)
            throw new ScheduledEventValidationException("<unknown>", $"Missing required field: {key}");
        if (element.ValueKind != JsonValueKind.Array)
            throw new ScheduledEventValidationException("<unknown>", $"Field '{key}' must be an array (got {element.ValueKind}).");
        var list = new List<string>();
        foreach (var item in element.EnumerateArray())
        {
            if (item.ValueKind != JsonValueKind.String)
                throw new ScheduledEventValidationException("<unknown>", $"Array '{key}' contains non-string element.");
            list.Add(item.GetString()!);
        }
        return list.ToArray();
    }
}