namespace StrategyGame.Core.AI;

using StrategyGame.Core.Domain;
using StrategyGame.Core.GameState;

/// <summary>
/// AI player interface. Implementations produce orders for a given game state.
/// No Godot dependencies.
/// </summary>
public interface IAIPlayer
{
    /// <summary>Unique identifier for this AI player instance.</summary>
    string Id { get; }

    /// <summary>
    /// Returns a list of orders to submit during the current turn.
    /// Called during the player's turn phase.
    /// </summary>
    /// <returns>List of orders; may be empty if no action is warranted.</returns>
    IReadOnlyList<Order> ChooseOrders(GameState state);

    /// <summary>Human-readable name for logging and UI display.</summary>
    string DisplayName { get; }

    /// <summary>AI difficulty level.</summary>
    Difficulty Difficulty { get; }
}

public enum Difficulty
{
    Easy,
    Normal,
    Hard
}
