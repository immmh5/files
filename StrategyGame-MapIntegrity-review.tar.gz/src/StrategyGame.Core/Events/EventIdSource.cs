namespace StrategyGame.Core.Events;

using System.Threading;

/// <summary>
/// R4.7 (revised, Phase 0) — Match-scoped domain event ID allocator.
/// Produces monotonically increasing long IDs for domain events within a single match.
///
/// OWNERSHIP: Each live match owns exactly one EventIdSource instance. The match
/// composition owner creates it and passes it explicitly to all systems that publish
/// domain events (currently EventScheduler; future: TurnEngine, ActionExecutor, etc.).
///
/// GUARANTEES:
/// - Strictly monotonically increasing within the source's lifetime.
/// - Never repeats, never wraps, never returns zero or a negative identifier.
/// - Thread-safe: safe for concurrent calls to Next() from multiple threads.
/// - Allocates long.MaxValue exactly once; every subsequent allocation throws
///   OverflowException.
/// - IsExhausted becomes true only after long.MaxValue has actually been allocated
///   (no window in which another thread can observe an unallocated negative ID).
/// - Peek is consistent with allocation state: it reports the value that the next
///   successful allocation would return; once exhausted it reports long.MaxValue
///   (the final allocated value) and IsExhausted is true.
/// - No static global state; each instance is independent.
/// - IDs may legitimately overlap across different match instances.
///
/// IMPLEMENTATION NOTE (Phase 0 fix): The previous lock-free CAS implementation
/// wrote <c>unchecked(long.MaxValue + 1)</c> into the signed <c>_next</c> field,
/// producing <c>long.MinValue</c> before the volatile <c>_exhausted</c> flag was
/// set — a second thread could observe and allocate a negative ID in that window.
/// A plain lock is used instead: the exhaustion flag and the counter are updated
/// atomically under the lock, which is simple and provably correct. Allocation
/// frequency is far too low for lock contention to matter.
///
/// LIMITATIONS (explicitly NOT guaranteed in R4.7):
/// - Persistence of the high-water mark across save/load.
/// - Cross-process replay continuity.
/// - These require future persistence support.
/// </summary>
public sealed class EventIdSource
{
    private readonly object _lock = new();
    private long _next;     // Next value a successful allocation will return.
    private bool _exhausted; // True once long.MaxValue has been handed out.

    /// <summary>
    /// Creates a new EventIdSource starting from the documented initial value (1).
    /// </summary>
    public EventIdSource()
        : this(1)
    {
    }

    /// <summary>
    /// Creates a new EventIdSource starting from a specific value.
    /// Used for testing or future persistence restoration.
    /// </summary>
    /// <param name="startValue">The first value that Next() will return. Must be >= 1.</param>
    public EventIdSource(long startValue)
    {
        if (startValue < 1)
            throw new ArgumentOutOfRangeException(nameof(startValue), startValue,
                "EventIdSource start value must be >= 1.");
        _next = startValue;
    }

    /// <summary>
    /// Allocates the next domain event ID. Strictly monotonically increasing.
    /// Thread-safe: safe for concurrent calls from multiple threads.
    /// Throws OverflowException if the long range is exhausted
    /// (i.e. after long.MaxValue has already been allocated).
    /// </summary>
    public long Next()
    {
        lock (_lock)
        {
            if (_exhausted)
            {
                throw new OverflowException(
                    "EventIdSource has exhausted the long range. " +
                    "No further domain event IDs can be allocated for this match.");
            }

            long id = _next;
            if (id == long.MaxValue)
            {
                // long.MaxValue is allocated exactly once; exhaustion takes effect
                // atomically with the allocation, under the same lock.
                _exhausted = true;
            }
            else
            {
                _next = id + 1;
            }

            return id;
        }
    }

    /// <summary>
    /// Returns the next value that a successful allocation would return, without
    /// consuming it. Once the source is exhausted, Peek reports long.MaxValue
    /// (the final allocated value) and IsExhausted reports true.
    /// Useful for diagnostics and testing.
    /// </summary>
    public long Peek
    {
        get { lock (_lock) { return _next; } }
    }

    /// <summary>
    /// Returns true if the source has exhausted its ID range
    /// (i.e. long.MaxValue has been allocated).
    /// </summary>
    public bool IsExhausted
    {
        get { lock (_lock) { return _exhausted; } }
    }
}
