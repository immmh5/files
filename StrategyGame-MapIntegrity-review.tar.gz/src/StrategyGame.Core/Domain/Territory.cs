namespace StrategyGame.Core.Domain;

/// <summary>
/// Represents a single territory on the game map.
/// M1.1: extended with terrain, region membership and supply-source metadata.
/// Visual/geometry data (polygon, centroid) intentionally lives in
/// MapDefinition, keeping the logical territory model independent of its
/// visual representation (see docs/design/MAP_AND_TERRITORY_DESIGN.md 1.7).
/// </summary>
public sealed class Territory
{
    public string Id { get; }
    public string Name { get; }
    public IReadOnlyList<string> AdjacentTerritoryIds { get; }
    public string? OwnerPlayerId { get; private set; }
    public int Armies { get; private set; }

    /// <summary>Terrain category of this territory. Default Plains for legacy constructions.</summary>
    public TerrainType Terrain { get; }

    /// <summary>
    /// Region this territory belongs to (null = no region / not part of any region bonus).
    /// Must reference a region declared on the owning MapDefinition.
    /// </summary>
    public string? RegionId { get; }

    /// <summary>
    /// True if this territory acts as a supply source (capital or port).
    /// PROVISIONAL per D-06 [PROPOSED]; consumed by the supply system (M1.2).
    /// </summary>
    public bool IsSupplySource { get; }

    public Territory(string id, string name, IReadOnlyList<string> adjacentTerritoryIds)
        : this(id, name, adjacentTerritoryIds, ownerPlayerId: null, armies: 0,
              TerrainType.Plains, regionId: null, isSupplySource: false)
    {
    }

    /// <summary>Constructor used when loading a saved game / copying state.</summary>
    public Territory(string id, string name, IReadOnlyList<string> adjacentTerritoryIds,
        string? ownerPlayerId, int armies)
        : this(id, name, adjacentTerritoryIds, ownerPlayerId, armies,
              TerrainType.Plains, regionId: null, isSupplySource: false)
    {
    }

    /// <summary>M1.1 constructor with map metadata, starting owned by nobody.</summary>
    public Territory(string id, string name, IReadOnlyList<string> adjacentTerritoryIds,
        TerrainType terrain, string? regionId, bool isSupplySource)
        : this(id, name, adjacentTerritoryIds, ownerPlayerId: null, armies: 0,
              terrain, regionId, isSupplySource)
    {
    }

    /// <summary>Full constructor: metadata + ownership/armies (state copies, save loading).</summary>
    public Territory(string id, string name, IReadOnlyList<string> adjacentTerritoryIds,
        string? ownerPlayerId, int armies, TerrainType terrain, string? regionId, bool isSupplySource)
    {
        Id = id ?? throw new ArgumentNullException(nameof(id));
        Name = name ?? throw new ArgumentNullException(nameof(name));
        if (adjacentTerritoryIds is null) throw new ArgumentNullException(nameof(adjacentTerritoryIds));
        OwnerPlayerId = ownerPlayerId;
        Armies = armies;

        // Defensive copy: the caller keeps ownership of its own list; later mutation
        // of the input list must not change this territory's adjacency.
        AdjacentTerritoryIds = [.. adjacentTerritoryIds];

        Terrain = terrain switch
        {
            TerrainType.Plains or TerrainType.Forest or TerrainType.Hills
                or TerrainType.Mountains or TerrainType.Marsh or TerrainType.Coast => terrain,
            _ => throw new ArgumentOutOfRangeException(nameof(terrain), terrain,
                "Unknown terrain value (outside the defined TerrainType range)."),
        };

        RegionId = regionId;
        IsSupplySource = isSupplySource;
    }

    public void SetOwner(string? playerId, int armies)
    {
        OwnerPlayerId = playerId;
        Armies = armies;
    }

    public void AddArmies(int count)
    {
        if (count < 0) throw new ArgumentOutOfRangeException(nameof(count));
        Armies += count;
    }

    public bool RemoveArmies(int count)
    {
        if (count < 0 || count > Armies) return false;
        Armies -= count;
        return true;
    }

    public bool IsAdjacentTo(string otherId) => AdjacentTerritoryIds.Contains(otherId);

    public bool CanAttackFrom => Armies > 1;

    public TerritorySnapshot Snapshot() =>
        new(Id, Name, new List<string>(AdjacentTerritoryIds), OwnerPlayerId, Armies,
            Terrain, RegionId, IsSupplySource);
}

/// <summary>
/// Immutable snapshot of territory state.
/// </summary>
public readonly record struct TerritorySnapshot(
    string Id,
    string Name,
    IReadOnlyList<string> AdjacentTerritoryIds,
    string? OwnerPlayerId,
    int Armies,
    TerrainType Terrain = TerrainType.Plains,
    string? RegionId = null,
    bool IsSupplySource = false);
