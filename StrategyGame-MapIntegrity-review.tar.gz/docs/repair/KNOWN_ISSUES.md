# KNOWN_ISSUES.md

## StrategyGame / Iron Dominion — Known Issues Register
**Last Updated**: 2026-11-10
**Project Root**: /home/qam3/StrategyGame

---

## Issue Status Labels

- **CONFIRMED** — Verified by direct code inspection and/or test
- **PARTIAL** — Partially verified, needs more investigation
- **SUSPECTED** — Reported but not yet verified
- **RESOLVED** — Fixed and regression-tested
- **WONT_FIX** — Accepted limitation, documented

---

## RESOLVED Issues

### ISSUE-T: EventIdSource Concurrency Defect at long.MaxValue — **RESOLVED ✅ (Phase 0, R4.7-fix)**
**File**: `src/StrategyGame.Core/Events/EventIdSource.cs`
**Status**: RESOLVED ✅ (2026-11-10)
**Confirmed defect**: When `_next == long.MaxValue`, the lock-free CAS path wrote
`unchecked(long.MaxValue + 1)` (`long.MinValue`) into the signed `_next` field and only
**afterwards** set `_exhausted`. A racing thread could observe the wrapped value and
allocate a negative ID (confirmed by the boundary-concurrency regression tests after
re-analysis; the old tests never exercised concurrent calls near the boundary).
**Fix**: Replaced CAS state machine with a plain `lock`. The counter stays in the valid
positive range; exhaustion is set atomically **with** the allocation of `long.MaxValue`.
Guarantees: positive monotonic IDs; `long.MaxValue` allocated exactly once; every later
allocation throws `OverflowException`; `Peek`/`IsExhausted` consistent (Peek reports
`long.MaxValue` when exhausted).
**Verification**: 6 new boundary tests in `EventIdSourceTests.cs` (incl. barrier-synchronized
8-thread allocation starting at `long.MaxValue - 9`, post-exhaustion hammering) — all pass.

### ISSUE-U: GameState.InitialConstructor Exposed Caller's Players List — **RESOLVED ✅ (Phase 0)**
**File**: `src/StrategyGame.Core/GameState/GameState.cs`
**Status**: RESOLVED ✅ (2026-11-10)
**Confirmed defect**: The initial constructor assigned `Players = players` (the caller's
original list) while a separately cloned `_players` list was used by `GetPlayer()`, so a
caller mutating its list made `Players` and `GetPlayer()` disagree. The copy (snapshot)
constructor did not share the list but exposed no equivalence guarantee.
**Fix**: The initial constructor now (1) defensively copies every `Player` entry
(null entry rejected), (2) exposes `Players = _players.AsReadOnly()` — a read-only view
of the same internal collection, so `Players`, `GetPlayer()` and `Snapshot()` always agree,
and (3) is immune to later mutation of the caller's list or Player objects.
**Verification**: 7 regression tests in `GameStateOwnershipTests.cs` — all pass.

### ISSUE-V: VictoryChecker Threshold/Status Discipline — **RECORDED, NOT APPROVED (Phase 0)**
**File**: `src/StrategyGame.Core/GameState/VictoryChecker.cs`, `docs/design/DESIGN_DECISIONS.md`
**Status**: DOCUMENTED (still provisional — NOT RESOLVED as "approved")
The 60% domination threshold, the domination denominator (all territories incl. neutral)
and the domination-before-elimination priority remain `[PROPOSED]` per D-07; D-16-5
approved evaluation **timing** only. The class XML doc now records this explicitly so no
future change can silently assume owner approval. Point-based victory remains `[OPEN]`
(Q-3). Do not tune these rules without owner approval.


### ISSUE-A: GameState Snapshot and Collection Ownership — **RESOLVED ✅**
**File**: `src/StrategyGame.Core/GameState/GameState.cs`
**Lines**: 38, 57, 66 (was 43-61, 66)
**Status**: RESOLVED ✅
**Resolution** (2026-11-04):
1. Added `Player(string id, string name, Faction faction, bool isHuman, int armiesToPlace)` constructor
2. Modified `GameState` primary constructor to deep-copy `Player` objects
3. Modified `GameState` copy constructor (used by `Snapshot()`) to deep-copy `Player` objects
4. Both constructors now create new `Player` instances with `ArmiesToPlace` copied

**Verification**: Added 7 regression tests in `GameStateSnapshotTests.cs` — all pass.

### ISSUE-B: VictoryChecker WinningPlayerId Not Populated — **RESOLVED ✅**
**File**: `src/StrategyGame.Core/GameState/VictoryChecker.cs`
**Status**: RESOLVED ✅
**Resolution** (2026-11-04):
1. Complete rewrite of `VictoryChecker.CheckVictory()` and helper methods
2. `CheckDominationVictory` now returns winning player ID when domination threshold met
3. `CheckEliminationVictory` now returns winning player ID when sole owner remains
4. Domination threshold changed from 100% (`ownerIds.Count == 1`) to ≥60% of total territories (including neutral)
5. Neutral territories now counted in domination denominator

**Verification**: Added 14 regression tests in `VictoryCheckerTests.cs` — all pass.

### ISSUE-E: VictoryChecker Domination Threshold — **RESOLVED ✅**
**File**: `src/StrategyGame.Core/GameState/VictoryChecker.cs`
**Status**: RESOLVED ✅ (merged with ISSUE-B fix)
**Resolution**: Implemented ≥60% domination threshold per design document D-07.

### ISSUE-G: GameState Snapshot Not Truly Immutable — **RESOLVED ✅**
**File**: `src/StrategyGame.Core/GameState/GameState.cs`
**Lines**: 38, 57, 66 (was 43-61, 66)
**Status**: RESOLVED ✅
**Resolution** (2026-11-04):
1. Added `Player(string id, string name, Faction faction, bool isHuman, int armiesToPlace)` constructor
2. Modified `GameState` primary constructor to deep-copy `Player` objects
3. Modified `GameState` copy constructor (used by `Snapshot()`) to deep-copy `Player` objects
4. Both constructors now create new `Player` instances with `ArmiesToPlace` copied

**Verification**: Added 7 regression tests in `GameStateSnapshotTests.cs` — all pass.

---

## CONFIRMED Issues

### ISSUE-C: IdGenerator Non-Deterministic — **RESOLVED ✅**
**File**: `src/StrategyGame.Core/Common/IdGenerator.cs`
**Status**: RESOLVED ✅ (2026-11-04)
**Resolution**:
1. Replaced non-deterministic `string.GetHashCode()` with stable FNV-1a 32-bit hash
2. Added `NewDeterministicId(category, seed, ref sequence)` for replay scenarios
3. Added `NewRandomId(category)` using shared Random instance
4. Preserved original `NewId(category)` API signature (backward compatible)
5. Documented that IdGenerator was previously unused by any entity constructors
6. Collision tracking kept as informational only (documented limitation)

**Verification**: Added 13 regression tests in `IdGeneratorTests.cs` — all pass.

### ISSUE-C (hardening follow-up, R3.2) — **RESOLVED ✅**
**File**: `src/StrategyGame.Core/Common/IdGenerator.cs`
**Status**: RESOLVED ✅ (2026-11-04, R3.2)
**R3.1 review gaps closed**:
1. 32-bit FNV-1a → SHA-256 truncated to 128 bits (birthday-safe at game scale)
2. Misleading `_seen` collision tracking removed (never prevented duplicates; would corrupt determinism if it did)
3. Canonical NUL-separated namespace encoding — subsystem isolation proven by test
4. BitConverter byte-order dependence eliminated; UTF-8 + InvariantCulture pinned
5. Golden-value tests pin cross-process/cross-platform determinism (verified against independent Python hashlib implementation; Windows CI runs same vectors)
6. Sequence overflow throws instead of silently wrapping into duplicate inputs
7. Empty/NUL-containing namespaces and negative sequences rejected

**Verification**: 27 tests in `IdGeneratorTests.cs` — all pass. Full suite: 67 core + 7 integration = 74 passed.

### ISSUE-P: EventBus Mutation During Enumeration — **RESOLVED ✅**
**File**: `src/StrategyGame.Core/Events/GameEvent.cs` (EventBus.Publish)
**Status**: RESOLVED ✅ (2026-11-04, R4.1)
**Defect (empirically reproduced pre-fix)**: A subscriber calling Subscribe/Unsubscribe
during Publish threw `InvalidOperationException` (live `List<Delegate>` modified while
enumerated). Self-unsubscribe during dispatch was the minimal repro.
**Resolution**:
1. `Publish<T>` iterates a snapshot of handlers taken at dispatch start
2. Documented semantics: mid-dispatch subscription changes affect subsequent publishes only; deterministic FIFO handler order; duplicate subscriptions allowed (each invoked once per publish); nested publish permitted with per-level snapshots; fail-fast exception policy (propagates, skips remaining handlers, bus stays usable)
3. Null-handler guard on Subscribe
4. No locks added (single-threaded usage is actual requirement); public API unchanged

**Verification**: 13 new regression tests in `EventBusTests.cs` — all assert documented semantics. Full suite: 80 core + 7 integration = 87 passed; verify.sh exit 0.

### ISSUE-S: Missing Scheduled Event Data Model — **RESOLVED ✅**
**File**: `src/StrategyGame.Core/Events/ScheduledEventRecord.cs` (NEW)
**Status**: RESOLVED ✅ (2026-11-05, R4.3)
**Resolution**:
1. Strongly typed scheduled-event DTO implementing D-16-1 through D-16-7
2. `TurnSequence` + `RoundIndex` (explicit, not derived) + `PlayerTurnTiming` for personal effects
3. `ExecutionStage` enum excludes Stage B (structural enforcement of D-16-3)
4. `ScheduledEventValidationException` loud-failures on any deserialization inconsistency (D-16-6)
5. Versioned JSON via System.Text.Json with `SchemaVersion`; camelCase; round-trip tested (D-16-7)
6. Two timing kinds: `RoundTiming` (global) + `PlayerTurnTiming` (personal) — exactly one required (D-16-2)
6. No delegates/closures; pure data; behavior resolved via `EventTypeKey` registry (future phase)

**Verification**: 35 regression tests in `ScheduledEventRecordTests.cs` — all pass. Full suite: 139 core + 7 integration = 146 passed; verify.sh exit 0.

### ISSUE-T: Missing Event Type Registry & Typed Payload Validation — **RESOLVED ✅**
**Files**: `src/StrategyGame.Core/Events/EventTypeRegistry.cs` (NEW), `src/StrategyGame.Core/Events/EventPayloads.cs` (NEW), `src/StrategyGame.Core/Events/EventTypeRegistrar.cs` (NEW)
**Status**: RESOLVED ✅ (2026-11-05, R4.4)
**Resolution**:
1. `EventTypeRegistry` — concurrent dictionary mapping `EventTypeKey` → `EventTypeInfo` (versions, deserializer, validator, payload type)
2. 7 strongly typed payload DTOs (4 global + 3 personal) in `EventPayloads.cs`
3. `EventTypeRegistrar.RegisterAll()` bootstraps 7 authoritative event types at startup
4. Deserialization: `Dictionary<string, JsonElement>` → typed DTO via per-type deserializer
5. Validation: structural (registry) + semantic (per-type validator) → throws `ScheduledEventValidationException` / `EventTypeRegistryException`
5. Versioning: per-type `supportedVersions` list; unsupported versions rejected with diagnostic
6. Unknown authoritative event type rejection (D-16-6): `GetInfo` throws `EventTypeRegistryException` for unregistered keys; presentation events excluded from registry
6. Versioned JSON via System.Text.Json with `SchemaVersion`; camelCase; round-trip tested (D-16-7)
7. No delegates/closures; pure data; behavior resolved via `EventTypeKey` registry (future phase)

**Verification**: 22 regression tests in `EventTypeRegistryTests.cs` — all pass. Full suite: 161 core + 7 integration = 168 passed; verify.sh exit 0.

---

### ISSUE-D: CombatSystem Missing Terrain and Faction Bonuses
**File**: `src/StrategyGame.Core/GameState/CombatSystem.cs`
**Lines**: 57-58
**Status**: CONFIRMED
**Description**:
- Design documents specify `defender_strength = defender_armies + terrain_bonus + faction_bonus`
- Current implementation: `defensePower = defenderArmies` (no terrain/faction bonuses)
- `COMBAT_AND_ARMY_RULES.md` §3 specifies terrain bonus in formula

**Evidence**: Line 58: `int defensePower = defenderArmies;`

**Risk**: Combat doesn't match design specification; terrain/faction choices have no combat effect.

---

### ISSUE-F: IdGenerator Non-Deterministic (Duplicate Entry)
**File**: `src/StrategyGame.Core/Common/IdGenerator.cs`
**Line**: 19
**Status**: CONFIRMED
**Description**: Same as ISSUE-C — duplicate entry.

---

### ISSUE-H: TurnManager Uses String Phases, Not Hybrid A-D
**File**: `src/StrategyGame.Core/GameState/TurnManager.cs`
**Lines**: 11-14, 19-30
**Status**: CONFIRMED
**Description**:
- Uses string constants `PhaseReinforce`, `PhaseAttack`, `PhaseFortify`, `PhaseGameOver`
- Design documents specify hybrid A-D turn structure (TurnStart → PlayerActions → EventProcessing → TurnEnd)
- Current implementation uses round-based phases, not per-player turn phases

**Evidence**: Lines 11-14 define string phases; `AdvanceTurn` increments round number, not per-player turn.

---

### ISSUE-I: No SupplyEngine / Attrition System
**File**: N/A (missing)
**Status**: CONFIRMED
**Description**:
- Design documents specify supply lines and attrition system
- No `SupplyEngine` class exists
- No attrition logic in Turn Start phase

---

### ISSUE-J: No EventScheduler / Persistent Events
**File**: N/A (missing)
**Status**: CONFIRMED
**Description**:
- Design documents specify persistent events spanning turns
- No `EventScheduler` class exists
- No event queue, duration tracking, or turn-based event firing

---

### ISSUE-J: No ActionExecutor / TurnEngine
**File**: N/A (missing)
**Status**: CONFIRMED
**Description**:
- No `ActionExecutor` for order validation/execution
- No `TurnEngine` orchestrating A-D stages
- Current `TurnManager` uses round-based phases, not hybrid A-D

---

### ISSUE-K: TurnStage Enum Missing
**File**: N/A (missing)
**Status**: CONFIRMED
**Description**:
- Design requires `TurnStage` enum: `TurnStart`, `PlayerActions`, `EventProcessing`, `TurnEnd`
- `GameState.CurrentPhase` is string, not enum

---

### ISSUE-L: SupplyEngine / Attrition Missing
**File**: N/A (missing)
**Status**: CONFIRMED
**Description**:
- Design specifies supply lines (capitals/ports), attrition at Turn Start
- No supply path finding, no attrition logic

---

## PARTIAL / SUSPECTED Issues

### ISSUE-M: EventBus Thread Safety
**File**: `src/StrategyGame.Core/Events/GameEvent.cs`
**Status**: SUSPECTED
**Description**: EventBus documented as "thread-safe for single-threaded use" but uses `Dictionary<Type, List<Delegate>>` without locks. If multi-threaded access occurs, may have race conditions.
**Status**: SUSPECTED — not yet verified under multi-threaded access.

---

### ISSUE-N: TurnManager AdvanceTurn Parameter Confusion
**File**: `src/StrategyGame.Core/GameState/TurnManager.cs`
**Lines**: 19-23
**Status**: SUSPECTED
**Description**: `AdvanceTurn` takes both `currentTurnPlayerId` and `previousTurnPlayerId` but uses `currentTurnPlayerId` for index lookup. Parameter naming suggests previous player but code uses current.
**Evidence**: Line 25: `IndexOf(currentTurnPlayerId)` but parameter named `currentTurnPlayerId` (first param) vs `previousTurnPlayerId` (second param).

---

### ISSUE-O: IdGenerator Collision Handling
**File**: `src/StrategyGame.Core/Common/IdGenerator.cs`
**Lines**: 12, 19-23
**Status**: SUSPECTED
**Description**: Uses `ConcurrentDictionary<string, int> _seen` but never checks for collisions before returning. Truncates hash to 8 hex chars (32 bits) — collision probability increases with volume.

---

## WONT_FIX / ACCEPTED LIMITATIONS

*None yet*

---

## OPEN Issues (new in M1.2, 2026-11-10)

### ISSUE-M2-1: D-06 rule conflict — min-garrison vs zero-army neutralization — **OPEN (documented, not silently resolved)**
**Files**: `docs/design/MAP_AND_TERRITORY_DESIGN.md` (D-06 [PROPOSED]), `src/StrategyGame.Core/Simulation/AttritionConfig.cs`
**Status**: OPEN — needs an explicit owner decision before M1.3 wiring
D-06 states BOTH "minimum one army remains in an owned territory after attrition" AND
"a territory at 0 armies becomes neutral". These conflict: under a min-garrison rule
attrition can never produce a zero garrison, so neutralization would never trigger and
under-strength frontier garrisons become permanently unkillable, while a pure
zero-neutralization rule has no garrison floor at all.
**Provisional M1.2 behavior (NOT user-approved):** min-garrison (default 1) wins;
attrition never reduces a positive garrison below `AttritionConfig.MinimumGarrison`.
Zero-army neutralization exists only behind the explicit
`AttritionConfig.AllowZeroGarrisonNeutralization` flag (default false); even when it is
enabled the engine only REPORTS `WouldBeNeutralized` — the ownership transition remains
a separate state-change rule for the later turn system (M1.3). Do not flip the flag
without owner approval.

### ISSUE-M2-2: Territory negative-army validation hole — **OPEN (pre-existing M1.0, guarded in M1.2 engines, expanded in review v2)**
**File**: `src/StrategyGame.Core/Domain/Territory.cs`
**Status**: OPEN — pre-existing hole (not introduced by M1.2); engine-level guard expanded
`Territory.SetOwner(playerId, armies)` and the `Territory` constructor do not validate
`armies >= 0` (armies moving through `AddArmies`/`RemoveArmies` ARE guarded), so a
constructed or map-copied state can carry a negative garrison.
**M1.2 mitigation (review v2):** `AttritionEngine.CalculateAttrition` now validates
**all** territories owned by the requested player (both supplied AND unsupplied) before
computing, and throws `InvalidOperationException` ("negative army count; state is
corrupt") rather than propagating garbage numbers; locked in by
`AttritionEngineTests.CalculateAttrition_SuppliedTerritoryWithNegativeArmies_IsRejected`.
**Proper fix deferred**: centralizing army validation inside `Territory` mutations is a
public-behavior change that deserves its own owner-approved task (it can throw in
existing call paths in M1.0/M1.1 code).

### ISSUE-M2-3: AttritionEngine accepted stale SupplyResult — **RESOLVED ✅ (review v2)**
**File**: `src/StrategyGame.Core/Simulation/AttritionEngine.cs`
**Status**: RESOLVED ✅ (2026-11-10 review v2)

### ISSUE-M1-ADJ: MapValidator missing adjacency invariants — **RESOLVED ✅ (M1.1 correction)**
**File**: `src/StrategyGame.Core/Domain/MapValidator.cs`
**Status**: RESOLVED ✅ (2026-11-10)
**Resolution**: Added two invariant checks matching `docs/architecture/DOMAIN_MODEL.md` §2 Territory Invariants:
- Duplicate adjacency IDs within one territory rejected with clear diagnostic.
- Asymmetric adjacency (A→B without B→A) rejected with clear diagnostic identifying both territories.
No silent repair — invalid maps are rejected. `MapDefinition` construction and `MapLoader` surface errors consistently.
**Verification**: 5 focused tests in `MapValidatorAdjacencyTests.cs` — all pass; existing `small_map.json` remains valid.
**Resolution**: Engine now recomputes the fresh supply state from the CURRENT
GameState and compares set-wise (supplied, unsupplied, owned count, sources,
HasOwnedSource). Structural invalidity (duplicates, unknown ids, overlapping sets,
null lists) and staleness (ownership/connectivity changes, forged/incomplete claims)
are rejected with `ArgumentException` containing diagnostic detail. Attrition is never
silently skipped for a territory that became newly unsupplied after the supply result
was produced.
**Verification**: 5 regression tests in `AttritionEngineTests` — all pass.

---

## Investigation Queue (Next to Verify)

1. **ISSUE-M**: EventBus thread safety under concurrent access
2. **ISSUE-N**: TurnManager parameter naming confusion
3. **ISSUE-O**: IdGenerator collision probability at scale
4. Verify `TurnManager.TransitionPhase` state machine completeness
5. Verify `GameState.Snapshot()` deep-copy behavior for all nested types
6. Verify `GameRules.ComputeReinforcements` integration with Turn Start

---

*Last Updated: 2026-11-10 (M1.2 review v2)*
*Next Review: M1.3 (turn/action wiring of economy, supply, attrition)*