# ADR-0004: Host-Authoritative Networking with Transport Abstraction

**Status:** Accepted
**Date:** 2026-11-04

## Decision

1. **Authority model:** Host-authoritative. The host holds the authoritative `GameState`; all other peers maintain a read-only mirror.
2. **Transport abstraction:** `INetworkTransport` interface isolates all networking I/O from game logic. Transport implementations are swappable.
3. **Topology:** Star topology (peers connect to host) as the primary model. Full-mesh optional in a future milestone.
4. **LAN-first:** No mandatory internet connection or cloud services for local play.

## Context

A strategy game requires deterministic, synchronized game state. Direct peer-to-peer state authority (all peers independently running the game) is fragile due to floating-point differences and event ordering. Host-authoritative ensures a single source of truth.

### Alternatives Considered

| Alternative | Rejected Because |
|---|---|
| **Full P2P (all peers run game independently)** | Floating-point nondeterminism; requires lock-step simulation; harder to debug; anti-cheat harder |
| **Authoritative server (dedicated)** | Adds infrastructure cost; not required for LAN/local multiplayer; complicates the initial scope |
| **Deterministic lockstep** | Requires perfect determinism (hard in .NET); complex rollback; overkill for initial scope |

## Consequences

- **Positive:** Simple, deterministic state sync. Only host runs `CombatSystem`. No desync issues.
- **Positive:** Transport is swappable — we can implement LAN (ENet) now and add WebRTC or a relay later without changing game logic.
- **Positive:** LAN play works without internet.
- **Negative:** Host disconnect ends the game (unless reconnect logic is implemented).
- **Mitigation:** Reconnection timeout and host migration are documented in the networking design for future implementation.

## Initial Implementation Scope

- Milestone 0: Networking interfaces defined (no implementation).
- Milestone 1: `FakeTransport` for single-player loopback testing.
- Milestone 2: `ENetTransport` for LAN.
- Milestone 3: Full host-authoritative sync.
