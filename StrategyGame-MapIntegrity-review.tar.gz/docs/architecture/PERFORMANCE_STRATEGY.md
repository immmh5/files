# PERFORMANCE_STRATEGY.md

**Status:** PROPOSED ARCHITECTURE
**Purpose:** Define performance targets, memory management, and optimization strategies for the hybrid turn engine.

---

## 1. Design Targets (Not Measurements)

*These are design targets for the first playable version. Actual measurements come from profiling.*

| Metric | Target | Conditions |
|---|---|---|
| **Turn resolution time** | < 5 ms | 200 territories, 6 players, single turn (A→D) |
| **Frame rate (rendering)** | 60 FPS | 1080p, integrated GPU, 100 territories |
| **UI frame time** | < 16 ms | 1080p, no GC spikes |
| **Memory baseline** | < 150 MB | Game loaded, one map, no replay |
| **Memory per 100 territories** | < 5 MB | Additional territories |
| **Save file size** | < 2 MB | 200 territories, 30 turns, full command log |
| **Network snapshot size** | < 50 KB | State diff after turn |

---

## 2. Memory Ownership & Lifetime

| Object | Owner | Lifetime | Allocation Strategy |
|---|---|---|---|
| `GameState` | `TurnEngine` | Match duration | Single allocation; mutated in-place |
| `Territory[]` | `GameState` | Match duration | Pre-allocated array; no per-turn allocation |
| `Player[]` | `GameState` | Match duration | Pre-allocated array |
| `ScheduledEvent` | `EventScheduler` | Until fired/cancelled | Pooled (object pool) |
| `ActiveEffect` | `EventScheduler` | Until expiry | Pooled |
| `Order` DTOs | `TurnEngine` | Per action | Short-lived; stack allocation where possible |
| `CombatResult` | `CombatSystem` | Per resolution | Struct; no allocation |
| `GameStateSnapshot` | `TurnEngine` | On save/sync | Allocated on demand (not per frame) |
| `CommandRecord` | `TurnEngine` | Per action | Appended to list; periodic trim |

---

## 3. Allocation Avoidance

### Hot Path (Per Turn)
| Operation | Allocation | Mitigation |
|---|---|---|
| `CombatSystem.ResolveAttack` | Zero (struct return) | ✅ Already struct |
| `SupplyEngine.FloodFill` | `HashSet<string>` per call | Pre-allocated `HashSet` reused; `Stack<string>` for DFS |
| `EventScheduler.Dequeue` | `List<T>` enumeration | Pre-allocated `List<ScheduledEvent>`; manual index loop |
| `Territory.GetAdjacent` | `IReadOnlyList` | Returns existing list; no copy |
| `Player.AddArmies` | None | Mutable field |

### Per-Frame (Rendering)
| Operation | Allocation | Mitigation |
|---|---|---|
| UI text updates | String interpolation | `StringBuilder` pooled; cached formatted strings |
| Territory highlight | New material | Material property block; shared material |
| Army marker positions | New array | Pre-computed centroids; `Vector2[]` cached |

---

## 4. Event Queue Efficiency

### Data Structure
```csharp
// Binary heap (min-heap) ordered by (ScheduledTurn, Phase, InsertionOrder)
// O(log n) insert, O(1) peek, O(log n) pop
// Pre-allocated capacity: 10,000
```

### Operations
| Operation | Complexity | Notes |
|---|---|---|
| `Schedule` | O(log n) | Heap insert |
| `Cancel` | O(n) | Lazy deletion (mark cancelled; skip on pop) |
| `GetDueEvents` | O(k log n) | Pop while `ScheduledTurn <= currentTurn` |
| `GetAllForSave` | O(n) | Iterate heap array |

### Lazy Cancellation
- Cancelled events marked `IsCancelled = true`
- Skipped during `GetDueEvents` / `GetAllForSave`
- Actual heap removal only on pop (amortized)

---

## 5. Map Scaling Strategy

| Territory Count | Strategy |
|---|---|
| ≤ 50 | Direct arrays; O(n) scans acceptable |
| 50–200 | Spatial index (grid/quadtree) for adjacency queries; adjacency list for graph |
| 200+ | Quadtree + chunked rendering; territory LOD |

### Adjacency Queries
- **Current:** `Territory.IsAdjacentTo(id)` → `List.Contains` O(n)
- **Optimized:** `bool[,]` adjacency matrix (200×200 = 40KB) or `HashSet<string>` per territory

### Rendering LOD
| Zoom Level | Rendered |
|---|---|
| < 0.75x | Region outlines only; no territory details |
| 0.75x–1.5x | Territory fills + borders + army counts |
| > 1.5x | Full detail + territory names + effects |

---

## 6. Save/Load Performance

| Operation | Target | Technique |
|---|---|---|
| Serialize 200 territories, 30 turns | < 100 ms | MessagePack binary; streaming write |
| Deserialize | < 100 ms | Streaming read; object pooling for deserialized objects |
| Save file size | < 2 MB | MessagePack + delta compression for command log |
| Autosave frequency | After TurnEnd | Non-blocking; background thread |

### Delta Compression (Command Log)
- Store only changed fields per command
- Reference previous state for unchanged fields
- Typical reduction: 70% vs full state per turn

---

## 6. Profiling Methodology

### Tools
| Tool | Purpose |
|---|---|
| `dotnet-trace` | CPU sampling, GC analysis |
| `dotnet-gcdump` | Heap analysis, allocation tracking |
| `dotnet-counters` | Real-time GC, thread pool, lock contention |
| Godot Profiler | Rendering, script, physics time |
| `PerfView` (Windows) | ETW traces, JIT, GC |

### Profiling Scenarios
| Scenario | Metrics Collected |
|---|---|
| 100-turn game (2 players, 100 territories) | Total time, per-turn time, GC count, Gen 0/1/2 collections |
| 500 territories, 6 players, 30 turns | Peak memory, turn resolution time, frame time |
| MP game (4 players, 100 territories) | Network latency, snapshot size, sync time |
| Save/Load 30-turn game | Serialize/deserialize time, file size |

### CI Profiling Gate
```yaml
# Fail if:
- Average turn resolution > 50 ms (200 territories)
- Gen 2 GC > 1 per 100 turns
- Memory growth > 10 MB per 100 turns
```

---

## 7. GC Strategy

| Generation | Target |
|---|---|
| Gen 0 | Frequent; short-lived (orders, events) |
| Gen 1 | Rare; medium-lived (snapshots, effects) |
| Gen 2 | Near zero; long-lived (GameState, MapDefinition) |

### Practices
- **Pre-allocate** all hot-path collections (capacity = max expected)
- **Structs** for all hot DTOs (`CombatResult`, `Order`, `TerritorySnapshot`)
- **Object pools** for `ScheduledEvent`, `ActiveEffect`, `StringBuilder`
- **Avoid** `LINQ` in hot paths; use `for` loops, `Span<T>`
- **No boxing** in hot paths; use generic interfaces, `readonly struct`

---

## 8. Network Optimization

| Optimization | Target |
|---|---|
| Snapshot diff (not full state) | < 50 KB per turn |
| Delta compression (zstd) | 70% reduction |
| Client-side prediction | Hide 100ms latency |
| Interest management | Only send visible territories |

---

## 9. Monitoring / Observability

| Metric | Source | Alert Threshold |
|---|---|---|
| `turn_resolution_ms` | `TurnEngine` | > 50 ms |
| `gc_gen0_per_turn` | `GC` | > 100 |
| `gc_gen2_total` | `GC` | > 5 per game |
| `memory_mb` | `Process` | > 300 MB |
| `snapshot_size_kb` | Network | > 100 KB |
| `frame_time_ms` | Godot | > 16.67 ms |

---

## 9. Capacity Planning

| Players | Territories | Expected Turn Time | Memory |
|---|---|---|---|
| 2 | 50 | 1 ms | 50 MB |
| 4 | 100 | 3 ms | 100 MB |
| 6 | 200 | 10 ms | 180 MB |

*These are design estimates; actuals from profiling will update this table.*