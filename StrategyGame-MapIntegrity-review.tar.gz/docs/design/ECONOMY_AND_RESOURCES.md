# ECONOMY_AND_RESOURCES.md

**Status:** PROPOSED DESIGN (rules [PROPOSED] per DESIGN_DECISIONS.md D-05/D-08).
The **income-only** first-playable economy below is implemented as of M1.2 (2026-11-10)
with configurable provisional defaults — implementation does NOT promote these rules to
USER-APPROVED. Section 2 systems remain unimplemented future work.

---

## 0. Implementation status (M1.2, 2026-11-10)

| Design element | Implementation | Notes |
|---|---|---|
| Income formula §1.1 | `Simulation/EconomyEngine.CalculateReinforcement` with `Simulation/EconomyConfig` | `floor(owned / divisor)` + controlled region bonuses; divisor defaults to 3 (PROVISIONAL D-08); report breakdown includes per-region contributions |
| Region bonuses | from each map's `RegionDefinition.ArmyBonus`; computed from LIVE `GameState` ownership | Full control required; empty/partial regions grant nothing; contribution deterministic (region-id order). `MapDefinition.GetRegionControlBonus` is static/setup-only — see its XML doc |
| Army placement §1.2 | NOT implemented | Applying the budget to `Player.ArmiesToPlace` is a turn-start action for M1.3; the engine is pure |
| Supply §2.2 | primitive implemented EARLY in M1.2 | `Simulation/SupplyEngine` flood-fill from owned supply sources through owned territories (D-06 provisional). **Reconciliation with §2.2:** this is the *basic connectivity+attrition foundation* only — supply LINES limiting army group size, supply-disruption events, and advanced logistics remain future (Category 2) systems |
| Attrition | `Simulation/AttritionEngine` with `Simulation/AttritionConfig` | loss 1 per unsupplied territory (provisional), min garrison 1 (provisional). The D-06 conflict between "min 1 garrison" and "0 armies→neutral" is documented, not silently resolved: neutralization stays a separate later-system rule unless an owner flips the explicit config flag |
| Strategic resources / buildings / tech §2 | NOT implemented (future) | outside M1.2 scope by design |

---

## 1. First Playable Economy

**Scope:** Income only. No resources, buildings, or tech in first playable version.

### 1.1 Income Formula

```
income = floor(territories / 3) + sum(region_bonuses)
```

Where `region_bonuses` are the bonus armies for each region the player controls.

### 1.2 Army Placement

- During Turn Start phase
- Only on owned territories
- No deep deployment (cannot place on territories not connected to owned territory)

## 2. Future Economy Systems (Category 2)

### 2.1 Strategic Resources

- Resource nodes on certain territories
- Production per turn
- Resource requirements for upgrades

### 2.2 Supply System

- Supply lines from capital/port
- Supply limits army group size
- Supply disruption events

### 2.3 Building Upgrades

- Territory-level upgrades
- Income modifiers
- Defense modifiers

### 2.4 Technology Progression

- Faction-wide tech tree
- unlocks new abilities
- Economic and military branches

## 3. Economic Tradeoffs

- Overextending for region bonuses invites counterattack
- Supply lines create vulnerability
- Income vs military spending decisions

## 4. Recommendation

**First playable version:** Income only. All other systems deferred to Category 2.