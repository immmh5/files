namespace StrategyGame.Core.GameState;

using StrategyGame.Core.Simulation;

/// <summary>
/// Manages turn sequencing and phase transitions.
/// </summary>
public static class TurnManager
{
    /// <summary>
    /// Legacy phase constants (for backward compatibility).
    /// </summary>
    public const string PhaseReinforce = "Reinforce";
    public const string PhaseAttack = "Attack";
    public const string PhaseFortify = "Fortify";
    public const string PhaseGameOver = "GameOver";

    /// <summary>
    /// M1.3 — Turn stage enumeration aligned with hybrid A/B/C/D cycle.
    /// </summary>
    public static TurnStage ToTurnStage(string phase) => phase switch
    {
        PhaseReinforce => TurnStage.TurnStart,
        PhaseAttack => TurnStage.PlayerActions,
        PhaseFortify => TurnStage.PlayerActions, // Fortify is part of Player Actions in hybrid model
        PhaseGameOver => TurnStage.GameOver,
        _ => throw new ArgumentException($"Unknown phase: {phase}"),
    };

    /// <summary>
    /// Converts TurnStage to legacy phase string.
    /// </summary>
    public static string ToLegacyPhase(TurnStage stage) => stage switch
    {
        TurnStage.TurnStart => PhaseReinforce,
        TurnStage.PlayerActions => PhaseAttack, // PlayerActions encompasses Attack/Fortify/Reinforce placement
        TurnStage.EventProcessing => PhaseAttack, // No legacy equivalent; map to active phase
        TurnStage.TurnEnd => PhaseFortify, // End of turn processing
        TurnStage.GameOver => PhaseGameOver,
        _ => throw new ArgumentOutOfRangeException(nameof(stage), stage, null),
    };

    /// <summary>
    /// Advances to the next turn and resets phase to Reinforce.
    /// </summary>
    public static (string NextTurnPlayerId, int NextTurnNumber, string NewPhase) AdvanceTurn(
        string currentTurnPlayerId,
        string previousTurnPlayerId,
        int turnNumber,
        IEnumerable<string> allPlayerIds)
    {
        var currentPlayerIndex = Math.Max(0, new List<string>(allPlayerIds).IndexOf(currentTurnPlayerId));
        var nextIndex = (currentPlayerIndex + 1) % allPlayerIds.Count();

        var nextTurnPlayerId = allPlayerIds.ElementAt(nextIndex);
        return (nextTurnPlayerId, turnNumber + 1, PhaseReinforce);
    }

    /// <summary>
    /// Transitions between phases within a single turn.
    /// </summary>
    public static string TransitionPhase(string currentPhase, string targetPhase) => targetPhase switch
    {
        PhaseReinforce when currentPhase == PhaseGameOver => PhaseReinforce,
        PhaseAttack when currentPhase == PhaseReinforce => PhaseAttack,
        PhaseFortify when currentPhase == PhaseAttack => PhaseFortify,
        PhaseGameOver when currentPhase == PhaseFortify => PhaseGameOver,
        _ => throw new InvalidOperationException($"Cannot transition from '{currentPhase}' to '{targetPhase}'.")
    };

    public static bool IsFinalPhase(string phase) =>
        phase == PhaseGameOver || phase == PhaseFortify;
}
