namespace StrategyGame.Core.Tests.Events.Presentation;

using System.Text.Json;
using System.Text.Json.Serialization;
using StrategyGame.Core.Events.Presentation;
using Xunit;

public class PresentationEventTests
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = false,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        Converters = { new JsonStringEnumConverter() }
    };

    [Fact]
    public void ShowAnimationEvent_JsonRoundTrip_PreservesAllFields()
    {
        var original = new ShowAnimationEvent(
            1, DateTime.UtcNow, "battle", "t1", "t2",
            new Dictionary<string, object> { { "intensity", 5 } });

        var json = JsonSerializer.Serialize(original, JsonOptions);
        var deserialized = JsonSerializer.Deserialize<ShowAnimationEvent>(json, JsonOptions);

        Assert.NotNull(deserialized);
        Assert.Equal(original.EventId, deserialized.EventId);
        Assert.Equal(original.AnimationTypeKey, deserialized.AnimationTypeKey);
        Assert.Equal(original.FromTerritoryId, deserialized.FromTerritoryId);
        Assert.Equal(original.ToTerritoryId, deserialized.ToTerritoryId);
        // Dictionary values may be deserialized as JsonElement, compare by converting to string
        Assert.Equal(original.Parameters["intensity"].ToString(), deserialized.Parameters["intensity"].ToString());
    }

    [Fact]
    public void HighlightTerritoryEvent_JsonRoundTrip_PreservesAllFields()
    {
        var original = new HighlightTerritoryEvent(1, DateTime.UtcNow, "t1", "attack", 2.5f);

        var json = JsonSerializer.Serialize(original, JsonOptions);
        var deserialized = JsonSerializer.Deserialize<HighlightTerritoryEvent>(json, JsonOptions);

        Assert.NotNull(deserialized);
        Assert.Equal(original.TerritoryId, deserialized.TerritoryId);
        Assert.Equal(original.HighlightTypeKey, deserialized.HighlightTypeKey);
        Assert.Equal(original.DurationSeconds, deserialized.DurationSeconds);
    }

    [Fact]
    public void PlaySoundEvent_JsonRoundTrip_PreservesAllFields()
    {
        var original = new PlaySoundEvent(1, DateTime.UtcNow, "explosion", 0.8f);

        var json = JsonSerializer.Serialize(original, JsonOptions);
        var deserialized = JsonSerializer.Deserialize<PlaySoundEvent>(json, JsonOptions);

        Assert.NotNull(deserialized);
        Assert.Equal(original.SoundKey, deserialized.SoundKey);
        Assert.Equal(original.Volume, deserialized.Volume);
    }

    [Fact]
    public void DisplayNotificationEvent_JsonRoundTrip_PreservesAllFields()
    {
        var original = new DisplayNotificationEvent(1, DateTime.UtcNow, "victory", "Victory!", "Player 1 wins!", 5.0f);

        var json = JsonSerializer.Serialize(original, JsonOptions);
        var deserialized = JsonSerializer.Deserialize<DisplayNotificationEvent>(json, JsonOptions);

        Assert.NotNull(deserialized);
        Assert.Equal(original.NotificationTypeKey, deserialized.NotificationTypeKey);
        Assert.Equal(original.Title, deserialized.Title);
        Assert.Equal(original.Message, deserialized.Message);
        Assert.Equal(original.DurationSeconds, deserialized.DurationSeconds);
    }

    [Fact]
    public void UpdateTerritoryVisualEvent_JsonRoundTrip_PreservesAllFields()
    {
        var original = new UpdateTerritoryVisualEvent(1, DateTime.UtcNow, "t1", "p1", 5);

        var json = JsonSerializer.Serialize(original, JsonOptions);
        var deserialized = JsonSerializer.Deserialize<UpdateTerritoryVisualEvent>(json, JsonOptions);

        Assert.NotNull(deserialized);
        Assert.Equal(original.TerritoryId, deserialized.TerritoryId);
        Assert.Equal(original.OwnerPlayerId, deserialized.OwnerPlayerId);
        Assert.Equal(original.Armies, deserialized.Armies);
    }

    [Fact]
    public void UpdatePlayerPanelEvent_JsonRoundTrip_PreservesAllFields()
    {
        var original = new UpdatePlayerPanelEvent(1, DateTime.UtcNow, "p1", 5, new[] { "t1", "t2", "t3" });

        var json = JsonSerializer.Serialize(original, JsonOptions);
        var deserialized = JsonSerializer.Deserialize<UpdatePlayerPanelEvent>(json, JsonOptions);

        Assert.NotNull(deserialized);
        Assert.Equal(original.PlayerId, deserialized.PlayerId);
        Assert.Equal(original.ArmiesToPlace, deserialized.ArmiesToPlace);
        Assert.Equal(original.OwnedTerritoryIds.Count, deserialized.OwnedTerritoryIds.Count);
    }

    [Fact]
    public void PolymorphicSerialization_IncludesTypeDiscriminator()
    {
        // Test polymorphic serialization through base type
        PresentationEvent original = new ShowAnimationEvent(1, DateTime.UtcNow, "battle", "t1", "t2", new());
        var json = JsonSerializer.Serialize(original, JsonOptions);
        Assert.Contains("\"$type\":\"showAnimation\"", json);

        PresentationEvent highlight = new HighlightTerritoryEvent(1, DateTime.UtcNow, "t1", "attack", 1.0f);
        json = JsonSerializer.Serialize(highlight, JsonOptions);
        Assert.Contains("\"$type\":\"highlightTerritory\"", json);
    }
}