# ADR-0001: Use Godot Engine 4.7.2 with .NET (Mono) Edition

**Status:** Accepted
**Date:** 2026-11-04

## Decision

Use **Godot Engine 4.7.2 stable (mono)** as the game engine.

## Context

We needed a cross-platform game engine that supports:
- C# as the primary scripting language.
- .NET 8 compatibility.
- 2D and 2.5D rendering.
- Export to Windows and Linux.
- No royalty or mandatory cloud services.
- A large, active community and long-term viability.

### Alternatives Considered

| Alternative | Rejected Because |
|---|---|
| **Unity** | Heavier runtime, C# is supported but Unity's architecture is heavier for 2D; royalties after revenue threshold; large project size |
| **Unreal Engine 5** | Primarily C++ with Blueprint; heavy for a 2D strategy game; long compile times |
| **MonoGame** | No built-in editor; everything custom-built; less productive for rapid iteration |
| **FlatRedBall** | Primarily Windows-focused; smaller community |
| **Custom engine (raylib + C#)** | Would require building editor, scene management, and export pipeline from scratch; enormous scope creep |

## Consequences

- **Positive:** Godot ships a built-in editor, scene system, 2D renderer, input system, and export pipeline. The community is large and stable.
- **Positive:** .NET Mono edition uses .NET 8 SDK with excellent tooling (Rider, VS Code, VS).
- **Negative:** Godot's C# support is second-class compared to GDScript — some Godot APIs are less ergonomic in C#.
- **Mitigation:** We keep the core game logic in pure C# (no Godot refs) and use GDScript or C# only in the App layer. The Godot-specific surface area is minimized.

## Technical Requirements

- Godot 4.7.2.stable.mono.official.ed1daf0bf
- .NET SDK 8.0.100 or later
- Godot export templates for target platforms (to be installed separately)
